Play Console > Main store listing > Graphics

phone/      8 phone screenshots 1080x1920   -> "Phone screenshots" (upload all 8, in this order)
tablet-7/   8 screenshots 1200x1920         -> "7-inch tablet screenshots"
tablet-10/  8 screenshots 1600x2560         -> "10-inch tablet screenshots"
pc/         3 screenshots 1920x1080         -> "Chromebook" / PC screenshots (if your listing shows that section)
feature-graphic-1024x500-v2.png             -> "Feature graphic"
(App icon 512x512 stays the same: store-assets/icon-512.png in the Android project zip)
