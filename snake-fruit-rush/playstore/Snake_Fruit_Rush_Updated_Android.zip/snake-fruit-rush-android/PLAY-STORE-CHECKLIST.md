# Play Console checklist - Snake: Fruit Rush 2.0.0 (versionCode 10)

Package: `com.snakefruitrush.game` (same as the live app)  |  Release: `.aab` signed with the SAME key as v1.0

## 1. Store listing (copy / paste)
**App name (max 30):** Snake - Fruit Rush

**Short description (max 80):**
Swipe, eat fruit and escape! 100 snake puzzle levels plus endless mode.

**Full description (max 4000):**
Snake - Fruit Rush brings the classic snake back with a twist: eat all the fruit, then find the exit!

100 PUZZLE LEVELS IN 5 WORLDS
- Garden: walls, fruit and the exit
- Desert: winding canyons and dead ends
- Ice: slippery floors where you slide until you stop
- Volcano: dodge the bombs
- Night: keys and doors, switches and gates, magic portals - everything together

Every level is hand-checked to be winnable and fair, with 1 to 3 stars to collect. Fruit lands in new places every time you play.

ENDLESS MODE
Four classic modes - Classic, No walls, Ghost and Ultimate - with combos, golden fruit, power-ups and a daily challenge.

CUSTOMISE
- 26 snake skins, from cute animals to royal crowns
- 5 colour themes and 5 board patterns for Endless mode
- Power-ups: Slow-Mo, Shield, Defuse and 2x Coins
- Daily spin and mystery egg

SMOOTH AND SIMPLE
Swipe to steer. One-hand play, short levels, no sign-up. Works offline.

The game contains ads. Optional rewarded ads give you extras such as a hint, a revive or bonus coins - you never have to watch one to play.

**Category:** Games > Puzzle (or Arcade)   **Tags:** snake, puzzle, casual, offline

## 2. Graphics (folder `store-assets/`)
- App icon 512x512: `icon-512.png`   - Feature graphic 1024x500: `feature-graphic-1024x500.png`
- Phone screenshots (1080x1920, 7 files): `screenshot-1-menu.png` ... `screenshot-7-shop.png`

## 3. App content
- **Privacy policy URL:** host `privacy-policy.html` (fill in the 3 REPLACE-... fields first) on any public page (GitHub Pages, Google Sites ...) and paste the link. REQUIRED because the app has ads.
- **Ads:** Yes, the app contains ads.
- **Advertising ID:** Yes (AdMob uses it). The manifest already declares `com.google.android.gms.permission.AD_ID`.
- **Target audience and content:** choose an age group of 13+ / "not primarily for children". If you pick an audience that includes children under 13, Google's Families policy applies and you must switch AdMob to child-directed handling first - ask before doing that.
- **Content rating:** answer the IARC questionnaire honestly: no violence, no gambling (the daily spin / egg use free in-game coins only and cannot be bought with real money), no user-generated content. "Contains ads" = yes.
- **Data safety** (check against Google's current AdMob guidance before submitting):
  - Data collected and shared with Google AdMob for advertising: *Device or other IDs* (Advertising ID); *App activity / diagnostics* and approximate *location* (IP) as collected by the Google Mobile Ads SDK.
  - The game itself collects nothing else: progress and coins stay on the device. No accounts. No data sold.
  - Data is encrypted in transit: yes. Users can request deletion: uninstall deletes local data.
- **News app / COVID / government:** no.

## 4. Release
1. Production (or Internal testing first) > Create new release > upload `app-release.aab`.
2. Release name: `2.0.0 (10)`. Release notes (copy):
   - "NEW: 100 puzzle levels in 5 worlds, shop with power-ups, 15 new skins, smoother movement, and an improved Endless mode."
3. Check Pre-launch report, then roll out.

## 5. Before upload - quick self test on a phone
- Install a debug/test build with `ADS_USE_TEST_IDS = true` (see README) and check: banner on menu only, rewarded revive / hint / +50 coins, interstitial after ~3 levels (needs 90 s since app start).
- Then build the release with `ADS_USE_TEST_IDS = false`.
