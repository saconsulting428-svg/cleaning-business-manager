# Snake - Fruit Rush  (Android / Play Store project)  -  version 2.0.0 (versionCode 10)

Ye wahi app hai jo Play Store par already hai: **Package ID `com.snakefruitrush.game`** (same), app ka naam same, icon same.
Is update mein: 100 level campaign (5 worlds), Endless mode, shop + power-ups, 26 skins, aur AdMob ads.

## Version
| | Play Store par abhi | Is zip mein |
|---|---|---|
| versionCode | 1 | **10** |
| versionName | 1.0 | **2.0.0** |
| minSdk / targetSdk | 24 / 36 | 24 / 36 |

Keystore ya password kisi ko na bhejein (mujhe bhi nahi) aur is project ya git mein na rakhein - `.gitignore` is se bachata hai. Key sahi hai ya nahi, ye check: `keytool -list -v -keystore snakefruitrush-release.jks` ka **SHA256** ye hona chahiye: `CB:55:07:0E:90:06:76:75:D2:C7:45:10:27:2B:54:0F:3D:D6:9C:00:9E:F0:E5:E8:88:21:47:5B:F9:91:DE:4B` (ye wo certificate hai jis se Play Store wala 1.0 sign hua hai).

Agar Play Console mein 10 se bada versionCode pehle se ho to `android/app/build.gradle` mein `versionCode` usse bada kar dein (har upload par bada hona chahiye).

## Zaroorat
- Node.js 22+ (nodejs.org) aur Android Studio (latest, JDK 21 saath aata hai)
- Internet (Gradle pehli dafa libraries download karta hai)

## .aab banane ke steps
1. Zip extract karein, folder mein terminal kholein.
2. `npm install`   (Capacitor + AdMob plugin install hota hai)
3. `npx cap sync android`
4. `npx cap open android`   (Android Studio khulega; pehli Gradle sync mein kuch minute lagte hain)
5. **Signing key (ek baar setup):** apni `snakefruitrush-release.jks` file ko `package.json` wale folder mein rakhein, `keystore.properties.example` ko copy karke `keystore.properties` banayein aur apna password bharein (alias `snakefruitrush` hai). Phir terminal mein `cd android` aur `./gradlew bundleRelease` (Windows: `gradlew bundleRelease`) seedha **signed** `.aab` bana deta hai.
   Ya Android Studio se: **Build > Generate Signed App Bundle / APK > Android App Bundle**
   - **Wohi keystore / upload key use karein jis se version 1.0 sign hua tha.** Nayi key banayi to Play Console upload reject karega.
   - Build variant: **release**
6. File banegi: `android/app/build/outputs/bundle/release/app-release.aab` (Android Studio wale tareeqe mein jo folder aap chunen)  -> Play Console > Production (ya Internal testing) mein upload.

## Ads ko pehle TEST karna (zaroori - live ads par khud click na karein)
1. `www/index.html` kholein aur ye line dhoondhein: `const ADS_USE_TEST_IDS = false;`
2. Isko `true` karein, phir `npx cap sync android`, phir phone par Run karein.
   Ab Google ke official **test ads** aate hain (banner, interstitial, rewarded). Live ads par apne aap click karna AdMob policy ke khilaf hai (account band ho sakta hai).
3. Sab theek ho to wapas `false` karein, `npx cap sync android` karein, aur phir release .aab banayein.
4. Release .aab hamesha `ADS_USE_TEST_IDS = false` ke saath hona chahiye, warna asli kamai nahi hogi.

AdMob IDs sirf `www/index.html` ke ads wale hisse mein (`LIVE = {...}`) aur App ID `android/app/src/main/AndroidManifest.xml` mein hain:
- App ID: `ca-app-pub-4552686824557844~5490413597`
- Banner `.../8189814263`, Interstitial `.../4376807748`, Rewarded `.../7573816720`

## Game mein kya hai
- Home par **Levels** ya **Endless** chunna hota hai. Levels: 100 levels, 5 worlds (Garden, Desert, Ice, Volcano, Night). Endless: Classic / No walls / Ghost / Ultimate modes, themes, patterns.
- Skins, Shop (power-ups), Gifts dono mode mein hain.
- Ads: banner sirf menu screens par; interstitial level ke result ke baad (har ~3 levels, 90 sec gap); rewarded sirf optional (revive, hint, +50 coins - din mein 3 baar).
- Game ka code ek hi file: `www/index.html` (Phaser andar hi hai). Game badalni ho to `game-source/` dekhein.

## Folder
- `android/`  Android Studio project   - `www/`  game   - `store-assets/`  Play listing ke images
- `PLAY-STORE-CHECKLIST.md`  Play Console mein kya bharna hai (listing text, Data safety, Ads, content rating)
- `privacy-policy.html`  Privacy policy (host karke URL Play Console mein dein)
- `docs/LEVELS.md`  100 levels ki details   - `game-source/`  level generator, validator, tests

## Test jo yahan ho chuke hain / jo nahi
- Game (HTML) ke 100 levels validate, bot ne 100/100 jeete, ads ka poora logic simulated AdMob plugin ke saath test (49 checks), movement/performance tests.
- **Android build (Gradle/AAB) is environment mein nahi ban sakti (Android SDK download blocked)** - isliye .aab aap Android Studio mein banayenge. Project Capacitor 8 + `@capacitor-community/admob` 8.2.1 ke saath `cap sync` ho chuka hai.
