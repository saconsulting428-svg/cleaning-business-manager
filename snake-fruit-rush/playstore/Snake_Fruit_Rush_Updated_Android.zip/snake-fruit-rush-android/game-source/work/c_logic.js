  // ---------- Campaign logic ----------
  let lvPage = 0;                                    // world shown on the level select screen
  let lvMsg = null;                                  // {s, until}: short message on the level select screen
  const campUnlocked = () => (UNLOCK_ALL ? LEVEL_COUNT : DATA.camp.unlocked);
  const campNext = () => Math.min(LEVEL_COUNT, Math.max(1, DATA.camp.cur));
  function useWorld(w) { CT = WORLDS[w].pal; applyTheme(); }
  function openLevels() {
    lvPage = Math.floor((campNext() - 1) / 20);
    useWorld(lvPage);
    setState('levels');
  }
  const menuPal = () => (DATA.menuMode === 'endless' ? null : WORLDS[Math.floor((campNext() - 1) / 20)].pal);
  function setMenuMode(levels) {
    DATA.menuMode = levels ? 'levels' : 'endless';
    if (levels && DATA.tab < 3) DATA.tab = 3;                 // Modes / Themes / Pattern only exist in Endless
    writeData(); CT = menuPal(); applyTheme();
  }
  function playSelected() { if (DATA.menuMode === 'endless') newGame(); else playCampaign(); }
  function playCampaign() { startLevel(campNext()); }
  // Fruit goes to new random places on the route every time a level starts (always cells the solution passes, so it stays solvable).
  function randomFruit(L) {
    const q = lvLayer(L.Q), cells = [], want = L.F.length;
    for (let i = 0; i < COLS * ROWS; i++) if (q[i]) cells.push(i);
    for (const gap of [3, 2, 1]) {
      const pool = cells.slice(), out = [];
      while (pool.length && out.length < want) {
        const c = pool.splice(rnd(pool.length), 1)[0], x = c % COLS, y = (c / COLS) | 0;
        if (out.every((o) => Math.max(Math.abs(o[0] - x), Math.abs(o[1] - y)) >= gap)) out.push([x, y]);
      }
      if (out.length === want) return Object.assign({}, L, { F: out });
    }
    return L;
  }


  // ---------- Campaign daily challenge (separate from the Endless one) ----------
  let cdCheck = 0;
  function cdEnsure() {
    const now = Date.now();
    if (DATA.cdaily && now - cdCheck < 4000) return DATA.cdaily;
    cdCheck = now;
    const today = dateKey(new Date());
    if (!DATA.cdaily || DATA.cdaily.date !== today) { DATA.cdaily = makeCD(today); writeData(); }
    return DATA.cdaily;
  }
  function cdAdd(id, n) {
    const d = cdEnsure();
    if (d.id !== id || d.claimed) return;
    d.progress = Math.min(d.target, d.progress + n);
    if (d.progress >= d.target) {
      d.claimed = true; addCoins(d.reward); if (G) G.dailyCoins = (G.dailyCoins | 0) + d.reward;
      showBanner('CAMPAIGN DAILY DONE!  +' + d.reward + ' coins', 'Challenge complete', '#facc15', 2200);
      sfx.win(); buzz(40);
    }
    writeData();
  }

  // ---------- adaptive difficulty (internal only, never shown) ----------
  const SK_KEY = 'snakeFruitRush.skill.v1';
  const SK_FRESH = () => ({ v: 1, lvl: 0, h: [], mech: {}, cur: null });
  const skClamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function skLoad() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(SK_KEY)); } catch (e) { d = null; }
    const s = SK_FRESH();
    if (!d || d.v !== 1 || !Array.isArray(d.h)) return s;
    s.lvl = skClamp(d.lvl | 0, -2, 2);
    s.h = d.h.filter((r) => r && isFinite(r.sc)).slice(-10).map((r) => ({ id: r.id | 0, sc: skClamp(+r.sc, 0, 1), at: skClamp(r.at | 0, 1, 99) }));
    if (d.mech && typeof d.mech === 'object') ['trap', 'door', 'gate'].forEach((k) => { s.mech[k] = skClamp(d.mech[k] | 0, 0, 9); });
    return s;
  }
  let SK = skLoad();
  function skSave() { try { localStorage.setItem(SK_KEY, JSON.stringify({ v: 1, lvl: SK.lvl, h: SK.h, mech: SK.mech })); } catch (e) { /* storage blocked: adaptation lasts for this session only */ } }
  const skProfile = () => (SK.lvl <= -1 ? 'beginner' : SK.lvl >= 1 ? 'skilled' : 'intermediate');
  const skHas = (L, k) => !!L[k] && (typeof L[k] === 'string' ? /[^0]/.test(L[k]) : L[k].length > 0);
  function skRecord(id, fails, moves, par, ms, delay) {            // called once when a level is completed
    const first = fails === 0 ? 1 : fails === 1 ? 0.5 : fails <= 3 ? 0.2 : 0;
    const eff = skClamp(par / Math.max(1, moves), 0, 1), spd = skClamp(par * delay / Math.max(1, ms), 0, 1);
    SK.h.push({ id: id, sc: 0.5 * first + 0.3 * eff + 0.2 * spd, at: fails + 1 });
    if (SK.h.length > 10) SK.h.shift();
    Object.keys(SK.mech).forEach((k) => { SK.mech[k] = Math.max(0, SK.mech[k] - 1); });
    if (SK.h.length >= 4) {                                          // ~4 levels of data first, then one small step per level
      const w = SK.h.slice(-6), avg = w.reduce((a, r) => a + r.sc, 0) / w.length;
      const target = avg < 0.35 ? -2 : avg < 0.5 ? -1 : avg > 0.84 ? 2 : avg > 0.74 ? 1 : 0;
      SK.lvl += Math.sign(target - SK.lvl);
    }
    skSave();
  }
  function skFail(id, reason) {
    if (!SK.cur || SK.cur.id !== id) SK.cur = { id: id, fails: 0, ms: 0 };
    SK.cur.fails++;
    if (SK.mech[reason] !== undefined) SK.mech[reason] = Math.min(9, SK.mech[reason] + 1);
    skSave();
  }
  // Settings for the NEXT level only (called from startLevel, never while a level runs).
  function skAdapt(L, id) {
    let e = SK.lvl;
    const last2 = SK.h.slice(-2);
    if (last2.length === 2 && last2.every((r) => r.at >= 3)) e -= 1;                       // easier breather after two hard levels (based on finished levels only: retrying never eases a level)
    e = skClamp(e, -2, 2);
    return { e: e, bias: e < 0 ? -1 : e > 0 ? 1 : 0, s2: -e * 1.5 | 0, s3: -e, d: e <= -2 ? 1.08 : e === -1 ? 1.04 : 1, ready: e <= -2 ? 500 : 0, hint: false };
  }
  function adaptiveFruit(L, bias) {                                  // layouts are drawn from the validated Q mask, so every one stays solvable by the stored route
    if (!bias) return randomFruit(L);
    let best = null, bs = 0;
    for (let i = 0; i < 6; i++) {
      const cand = randomFruit(L), sc = cand.F.reduce((a, f) => a + Math.abs(f[0] - L.s[0]) + Math.abs(f[1] - L.s[1]), 0);
      if (!best || (bias < 0 ? sc < bs : sc > bs)) { best = cand; bs = sc; }
    }
    return best;
  }
  // Fruit places are made once per level (first entry), saved, and reused on every retry / restart.
  const FRUIT_KEY = 'snakeFruitRush.fruit.v3';
  // Fruit in tight spots: of several valid random layouts (all on the stored route, never touching), keep the one whose fruit sit in the narrowest
  // gaps. More candidates on later levels, so the pull towards tight corridors grows with the level number.
  function tightness(base, F) {
    const wl = lvLayer(base.W), bl = base.B ? lvLayer(base.B) : null;
    let s = 0;
    F.forEach((f) => {
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const x = f[0] + dx, y = f[1] + dy;
        if (x < 0 || y < 0 || x >= COLS || y >= ROWS || wl[y * COLS + x] || (bl && bl[y * COLS + x])) s++;
      }
    });
    return s;
  }
  function fruitCount(id) {                                          // fruit per level: more and more as the campaign goes on
    if (id <= 5) return 3;
    if (id <= 10) return 4;
    if (id <= 20) return id <= 15 ? 4 : 5;
    if (id <= 30) return 5;
    if (id <= 40) return id <= 35 ? 5 : 6;
    if (id <= 50) return 6;
    if (id <= 60) return id <= 55 ? 6 : 7;
    if (id <= 70) return 7;
    if (id <= 80) return id <= 75 ? 7 : 8;
    return 8;
  }
  const D4V = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  function routeWins(base, F) {                                      // the stored solution must still win with this layout (same replay as the validator)
    const L2 = Object.assign({}, base, { F: F }), rt = E.makeRuntime(engineLevel(L2)), st = E.newState(rt), route = base.R;
    let status = 'ok';
    for (let k = 1; k < route.length; k++) {
      const cur = route[k], head = st.body[0], d = D4V.findIndex((v) => v[0] === (cur % COLS) - (head % COLS) && v[1] === ((cur / COLS) | 0) - ((head / COLS) | 0));
      if (d < 0) return false;
      let q, g = 0;
      do { q = E.step(rt, st, D4V[d]); g++; } while (q.status === 'wait' && g < 5);
      status = q.status;
      if (status === 'fail') return false;
      if ((base.P || []).some((pp) => (pp[1] * COLS + pp[0]) === cur)) k++;
    }
    return status === 'win';
  }
  function fruitPool(base) {                                         // route cells a fruit may sit on (never devices, bombs, portals, start lane, exit)
    const bl = base.B ? lvLayer(base.B) : null, bad = new Set(), R = base.R;
    [base.K, base.D, base.G].forEach((a) => (a || []).forEach((c) => bad.add(c[1] * COLS + c[0])));
    (base.S || []).forEach((s) => bad.add(s[1] * COLS + s[0]));
    (base.P || []).forEach((p) => { bad.add(p[1] * COLS + p[0]); bad.add(p[3] * COLS + p[2]); });
    const out = [];
    for (let k = 4; k < R.length - 2; k++) if (!bad.has(R[k]) && !(bl && bl[R[k]])) out.push(R[k]);
    return out;
  }
  function tightFruit(base, id) {
    const want = fruitCount(id), pool = fruitPool(base), tries = 4 + Math.ceil(id * 0.4), R = base.R;
    for (let n = want; n >= 1; n--) {
      let best = null, bs = -1, found = 0;
      for (let i = 0; i < tries * 6 && found < tries; i++) {
        const p = pool.slice(), F = [];
        while (p.length && F.length < n) {
          const c = p.splice(rnd(p.length), 1)[0], x = c % COLS, y = (c / COLS) | 0;
          if (F.every((o) => Math.max(Math.abs(o[0] - x), Math.abs(o[1] - y)) >= 2)) F.push([x, y]);
        }
        if (F.length < n || !routeWins(base, F)) continue;
        found++;
        const last = Math.max.apply(null, F.map((f) => R.indexOf(f[1] * COLS + f[0])));
        const sc = tightness(base, F) + Math.min(4, (R.length - 1 - last) / 8);   // tight gaps + a longer trip to the exit afterwards
        if (sc > bs) { bs = sc; best = F; }
      }
      if (best) return best;
    }
    return base.F;
  }
  function fruitSaved(id, base) {
    let m = {};
    try { m = JSON.parse(localStorage.getItem(FRUIT_KEY)) || {}; } catch (e) { m = {}; }
    const f = m[id], q = lvLayer(base.Q);
    const pool = new Set(fruitPool(base));
    const ok = Array.isArray(f) && f.length >= 1 && f.length <= fruitCount(id) && f.every((c) => Array.isArray(c) && c[0] >= 0 && c[0] < COLS && c[1] >= 0 && c[1] < ROWS && pool.has(c[1] * COLS + c[0]))
      && f.every((a, i) => f.every((b, j) => i === j || Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])) >= 2)) && routeWins(base, f);
    if (ok) return f;
    const F2 = tightFruit(base, id);
    m[id] = F2;
    try { localStorage.setItem(FRUIT_KEY, JSON.stringify(m)); } catch (e) { /* blocked: layout lasts for this session only */ }
    return F2;
  }
  function startLevel(id, showRoute) {
    id = Math.min(LEVEL_COUNT, Math.max(1, id | 0));
    if (id > campUnlocked()) return;
    const base = LV[id - 1], ad = skAdapt(base, id);
    if (!SK.cur || SK.cur.id !== id) SK.cur = { id: id, fails: 0, ms: 0 };
    SK.cur.ms = 0;
    let L = Object.assign({}, base, { F: fruitSaved(id, base) });
    if (ad.e) L = Object.assign({}, L, { s3: Math.max(base.par, L.s3 + ad.s3), s2: Math.max(base.par + 1, L.s2 + ad.s2), d: Math.round(L.d * ad.d) });
    if (ad.hint) showRoute = true;
    const el = engineLevel(L), rt = E.makeRuntime(el), st = E.newState(rt);
    G = {
      camp: { id: id, L: L, ad: ad.e, rt: rt, st: st, ready: READY_MS + ad.ready, over: null, won: false, endT: 0, moves: 0, route: showRoute ? L.R : null, routeIdx: null, exitOpen: false, slowT: 0, shield: false, hold: false, coinMul: 1, stars: 0, coins: 0, hint: L.h || '', flash: [], iceList: [], fr: [] },
      snake: st.body.map((c) => [c % COLS, (c / COLS) | 0]), dir: st.dir, queue: [], score: 0, eaten: 0, fx: {}, combo: 0, combo_t: 0, bonus: null, power: null, gold: null,
      food: null, bombs: [], coins: 0, dailyCoins: 0, playMs: 0, adMsg: '', shareMsg: '', mode: 'classic', speed: DATA.speed
    };
    const C0 = G.camp;
    for (let i = 0; i < COLS * ROWS; i++) if (rt.ice[i]) C0.iceList.push(i);
    if (C0.route) { C0.routeIdx = new Map(); C0.route.forEach((cell, i) => C0.routeIdx.set(cell, i)); }
    rt.fruits.forEach((f, i) => C0.fr.push({ cell: f.cell, kind: FRUITS[(i + id) % FRUITS.length] }));
    popups = []; fxs = []; banner = null; prevSnake = null; acc = 0;
    adToken++; gift = null; sheetOpen = false; sheetT = 0;
    DATA.camp.cur = id;
    writeData();
    useWorld(L.w);
    setState('play');
    if (!navigator.webdriver || window.__forceTips) { if (helpItems(L).some((i) => !tipsSeen.has(i.id))) { C0.help = true; togglePause(); } }   // first time a thing appears: the card opens by itself
  }
  const PORTAL_MS = 950;                            // portal-entry animation before the result screen
  const campSliding = () => !!G.camp && E.resolveDir(G.camp.rt, G.camp.st, null).forced;
  const cellOf = (i) => cellXY(i % COLS, (i / COLS) | 0);
  const campPlaying = () => G && G.camp && !G.camp.over && !G.camp.won;

  function campStep() {
    const C0 = G.camp, rt = C0.rt, st = C0.st;
    if (C0.over || C0.won) return;
    if (C0.hold) { if (!G.queue.length) return; C0.hold = false; }          // after a shield save the snake waits for a turn
    let input = null;
    if (!campSliding() && G.queue.length) input = G.queue.shift();          // on ice the player cannot steer: the turn waits in the queue
    const oldDir = st.dir;
    const res = E.step(rt, st, input);
    if (res.status === 'fail' && C0.shield && res.reason !== 'stuck') {
      st.done = false; st.dir = oldDir; G.dir = oldDir; C0.shield = false; C0.hold = true;
      const hp = headXY(); ring(hp.x, hp.y, '#38bdf8'); burst(hp.x, hp.y, '#7dd3fc', 12);
      showBanner('SHIELD SAVED YOU!', 'now turn away', '#38bdf8', 1400);
      sfx.power(); buzz(40);
      return;
    }
    G.dir = st.dir;
    if (res.status === 'wait') return;                                      // slid safely to a stop: wait for a turn
    if (res.status !== 'fail') {
      G.snake = st.body.map((c) => [c % COLS, (c / COLS) | 0]);
      C0.moves = st.moves;
      if (C0.slowT > 0) C0.slowT--;
      trailPuff();
      if (rt.ice[st.body[0]]) { const p = headXY(); if (fxs.length < MAX_FX - 6) fxs.push({ k: 0, x: p.x, y: p.y, vx: (Math.random() - 0.5) * 0.03, vy: (Math.random() - 0.5) * 0.03, r: 2.4, color: '#ffffff', life: 380, max: 380 }); }
    }
    res.events.forEach((e) => {
      const p = cellOf(e.cell);
      if (e.t === 'fruit') {
        G.eaten++; G.coins += COIN_FRUIT * C0.coinMul; addCoins(COIN_FRUIT * C0.coinMul); cdAdd('cfruit', 1);
        const fk = (C0.fr.find((f) => f.cell === e.cell) || {}).kind, fc = FRUIT_COL[fk] || th().accent;
        burst(p.x, p.y, fc, 10); burst(p.x, p.y, '#ffffff', 4); ring(p.x, p.y, fc);
        popup('+1', th().accent, 30);
        sfx.eat(Math.min(G.eaten - 1, 9)); buzz(12);                       // the pop gets higher with every fruit of the level
      } else if (e.t === 'key') {
        ring(p.x, p.y, '#facc15'); burst(p.x, p.y, '#facc15', 8); popup('KEY!', '#facc15', 30);
        sfx.key(); buzz(20);
      } else if (e.t === 'door') {
        const q = cellOf(e.cell); ring(q.x, q.y, '#facc15'); burst(q.x, q.y, '#fde68a', 10); C0.flash.push({ cell: e.cell, t: 600 });
        sfx.door();
      } else if (e.t === 'switch') {
        const q = cellOf(e.cell); ring(q.x, q.y, GATE_COLS[e.gate % GATE_COLS.length]);
        const gc = rt.gates[e.gate].cells[0], gp = cellOf(gc);
        ring(gp.x, gp.y, GATE_COLS[e.gate % GATE_COLS.length]); C0.flash.push({ cell: gc, t: 600 });
        popup(e.open ? 'GATE OPEN' : 'GATE CLOSED', GATE_COLS[e.gate % GATE_COLS.length], 30);
        sfx.sw(e.open); buzz(20);
      } else if (e.t === 'portal') {
        const a = cellOf(e.from), b = cellOf(e.to);
        ring(a.x, a.y, '#c084fc'); ring(b.x, b.y, '#38bdf8'); burst(b.x, b.y, '#a5f3fc', 8);
        sfx.portal(); buzz(15);
      }
    });
    if (!C0.exitOpen && E.exitReady(rt, st)) {
      C0.exitOpen = true; C0.exitT = anim;
      const ep = cellOf(rt.exit);
      ring(ep.x, ep.y, '#4ade80'); burst(ep.x, ep.y, '#bbf7d0', 12);
      showBanner('EXIT OPEN!', 'reach the glowing exit', '#4ade80', 1100);
      sfx.yum();
    }
    if (res.status === 'win') {
      C0.won = true; C0.endT = 0;
      adsMeta.levels++;                                  // counts toward the next interstitial (shown only after the result screen)
      const moves = st.moves, L = C0.L;
      C0.stars = moves <= L.s3 ? 3 : moves <= L.s2 ? 2 : 1;
      const prev = DATA.camp.stars[C0.id] | 0;
      if (C0.stars > prev) DATA.camp.stars[C0.id] = C0.stars;
      cdAdd('clevel', 1); cdAdd('cstars', C0.stars); if (C0.stars === 3) cdAdd('c3', 1); if (SK.cur && SK.cur.id === C0.id && SK.cur.fails === 0) cdAdd('cfirst', 1);
      if (SK.cur && SK.cur.id === C0.id) skRecord(C0.id, SK.cur.fails, moves, LV[C0.id - 1].par, SK.cur.ms, C0.L.d);
      SK.cur = null;
      C0.coins = (5 + 5 * C0.stars) * C0.coinMul;
      addCoins(C0.coins); G.coins += C0.coins;
      if (C0.id < LEVEL_COUNT) { DATA.camp.cur = C0.id + 1; if (DATA.camp.unlocked < C0.id + 1) DATA.camp.unlocked = C0.id + 1; }
      else DATA.camp.cur = C0.id;
      writeData();
      const hp = headXY(); burst(hp.x, hp.y, 'rand', 16); ring(hp.x, hp.y, '#fde047');
      sfx.win(); buzz(40);
    } else if (res.status === 'fail') {
      C0.over = res.reason; C0.endT = 0;
      skFail(C0.id, res.reason);
      if (res.reason === 'trap') { G.boom = [res.cell % COLS, (res.cell / COLS) | 0]; sfx.boom(); buzz(80); shake(300, 0.014); }
      else {
        sfx.over(); buzz(50); shake(140, 0.006);
        const hp = headXY(); ring(hp.x, hp.y, '#f87171'); burst(hp.x, hp.y, '#f87171', 10);
        if (res.reason === 'door') { const nx = st.body[0] % COLS + st.dir[0], ny = ((st.body[0] / COLS) | 0) + st.dir[1], ni = ny * COLS + nx; C0.over = rt.gateAt[ni] >= 0 ? 'gate' : 'door'; }
      }
    }
  }
  function campTick(delta) {                         // called every frame while state is 'play' and G.camp exists
    const C0 = G.camp;
    C0.flash.forEach((f) => { f.t -= delta; });
    C0.flash = C0.flash.filter((f) => f.t > 0);
    if (C0.over || C0.won) {
      C0.endT += delta;
      if (C0.won && C0.endT > PORTAL_MS) setState('won');
      else if (C0.over && C0.endT > (C0.over === 'trap' ? 900 : 650)) setState('over');
      return;
    }
    if (C0.ready > 0) { C0.ready -= delta; acc = 0; if (C0.ready <= 0) { C0.ready = 0; sfx.click(); } return; }
    if (SK.cur) SK.cur.ms += delta;
    acc += stepClock(delta);
    let delay = stepDelay(), guardSteps = 0;
    while (state === 'play' && !C0.over && !C0.won && acc >= delay && guardSteps++ < 2) {
      acc -= delay;
      prevSnake = G.snake.map((s) => [s[0], s[1]]);
      campStep();
    }
    if (acc > delay) acc = delay;
    G.playMs += delta;
  }
  function usePower(k) {
    if (state !== 'play' || !campPlaying() || G.camp.ready > 0) return;
    const C0 = G.camp, rt = C0.rt, st = C0.st, p = PW[k];
    if ((k === 'shield' && C0.shield) || (k === 'coin2' && C0.coinMul > 1) || (k === 'slow' && C0.slowT > 0)) return;
    const hx = st.body[0] % COLS, hy = (st.body[0] / COLS) | 0, near = [];
    if (k === 'sweep') {
      for (let i = 0; i < COLS * ROWS; i++) if (rt.bomb[i] && Math.max(Math.abs((i % COLS) - hx), Math.abs(((i / COLS) | 0) - hy)) <= 7) near.push(i);
      if (!near.length) { popup('No bombs near', '#ff5a5f', 34); sfx.err(); return; }
    }
    if (!DATA.pw[k]) {
      if (DATA.coins < p.cost) { popup('Need ' + p.cost + ' coins', '#ff5a5f', 34); sfx.err(); return; }
      DATA.coins -= p.cost; DATA.pw[k]++;
    }
    DATA.pw[k]--; writeData();
    const hp = headXY();
    if (k === 'slow') C0.slowT = 28;
    else if (k === 'shield') C0.shield = true;
    else if (k === 'coin2') C0.coinMul = 2;
    else near.forEach((i) => { rt.bomb[i] = 0; const q = cellOf(i); burst(q.x, q.y, '#fbbf24', 8); ring(q.x, q.y, '#fbbf24'); });
    ring(hp.x, hp.y, '#38bdf8'); popup(p.name + '!', th().accent, 34);
    sfx.power(); buzz(25);
  }
  let shopMsg = null;
  function buyPower(k) {
    const p = PW[k];
    if (DATA.coins < p.cost) { shopMsg = { s: 'Need ' + (p.cost - DATA.coins) + ' more coins for ' + p.name + '!', until: anim + 2400, bad: true }; sfx.err(); buzz(40); return; }
    DATA.coins -= p.cost; DATA.pw[k] = Math.min(99, DATA.pw[k] + 1); writeData(); sfx.coin();
    shopMsg = { s: p.name + ' added!', until: anim + 1500 };
  }
  function drawShop(top) {
    const t = th();
    if (shopMsg && anim < shopMsg.until) {
      txt(W / 2, top + 96, shopMsg.s, 15, shopMsg.bad ? '#f87171' : '#4ade80');
    } else {
      const ct = coinText(DATA.coins) + ' coins', ox = ct.length * 4.4;
      drawCoin(W / 2 - ox - 12, top + 96, 10);
      txt(W / 2 - ox + 2, top + 96, ct, 15, t.accent, 0);
    }
    PW_KEYS.forEach((k, i) => {
      const p = PW[k], w = 212, h = 112, cx = W / 2 + (i % 2 ? 110 : -110), cy = top + 176 + Math.floor(i / 2) * 124, can = DATA.coins >= p.cost;
      rrect(cx - w / 2, cy - h / 2 + 3, w, h, 15, shade(t.panel, -0.3));
      rrect(cx - w / 2, cy - h / 2, w, h, 15, t.panel);
      dot(cx - w / 2 + 30, cy - 22, 22, t.board1);
      drawPwIcon(k, cx - w / 2 + 30, cy - 23, false);
      txt(cx - w / 2 + 62, cy - 30, p.name, 16, t.btnText, 0);
      wrapText(p.desc, 18).forEach((l, j) => txt(cx - w / 2 + 62, cy - 8 + j * 15, l, 11, t.btnText, 0, false));
      txt(cx - w / 2 + 12, cy + 38, 'You have ' + (DATA.pw[k] | 0), 12, t.btnText, 0, false);
      rrect(cx + w / 2 - 74, cy + 24, 64, 28, 14, can ? t.accent : shade(t.panel, -0.25));
      drawCoin(cx + w / 2 - 60, cy + 38, 6.5);
      txt(cx + w / 2 - 50, cy + 38, String(p.cost), 13, can ? '#1b1b1b' : t.btnText, 0);
      buttons.push({ x: cx - w / 2, y: cy - h / 2, w: w, h: h, fn: () => buyPower(k) });
    });
    if (!(DATA.coins < 90 && adCoinsButton(top + 404))) {
      txt(W / 2, top + 396, 'Tap a power-up to buy it. Use them inside levels.', 12.5, t.text, 0.5, false);
      txt(W / 2, top + 420, 'In a level you can also tap its button to buy and use it.', 12.5, t.text, 0.5, false);
    }
  }
  function toggleVibe() { DATA.vibe = !DATA.vibe; writeData(); if (DATA.vibe) buzz(30); }
  function toggleTap() { DATA.tapSteer = !DATA.tapSteer; writeData(); tone(660, 0.08, 'triangle', 0.2); }
  function campRetry() { startLevel(G.camp.id, !!G.camp.route); }          // a hint bought with an ad stays for the rest of that level
  function campNextLevel() {
    const next = G.camp.id < LEVEL_COUNT ? () => startLevel(G.camp.id + 1) : openLevels;
    maybeInter('level', next);                       // an ad only if one is due AND ready; otherwise straight on
  }
  function leaveToLevels() { saveGame(); openLevels(); }
  function goHome() { setState('menu'); }

  // ---------- Level select + campaign drawing ----------
  function starShape(x, y, r, color, alpha) {
    const pts = [];
    for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * 0.45 : r, ang = -Math.PI / 2 + i * Math.PI / 5; pts.push({ x: x + Math.cos(ang) * rr, y: y + Math.sin(ang) * rr }); }
    g.fillStyle(C(color), alpha === undefined ? 1 : alpha);
    g.fillPoints(pts, true);
  }
  function lockIcon(x, y, s, color) {
    g.lineStyle(3 * s, C(color), 1);
    g.beginPath(); g.arc(x, y - 4 * s, 6 * s, Math.PI, 0); g.strokePath();
    rrect(x - 9 * s, y - 4 * s, 18 * s, 14 * s, 4 * s, color);
    dot(x, y + 2 * s, 2 * s, '#00000066');
  }
  function worldStars(w) { let n = 0; for (let i = w * 20 + 1; i <= w * 20 + 20; i++) n += DATA.camp.stars[i] | 0; return n; }
  function worldDone(w) { let n = 0; for (let i = w * 20 + 1; i <= w * 20 + 20; i++) if (DATA.camp.stars[i]) n++; return n; }
  function drawLevels() {
    const t = th(), cp = DATA.camp, w = lvPage, W0 = WORLDS[Math.min(w, WORLDS.length - 1)], un = campUnlocked(), soon = w >= WORLDS.length;
    // header
    rrect(BX, 22, 96, 40, 20, t.panel);
    line(BX + 22, 42, BX + 32, 35, t.btnText, 3.4); line(BX + 22, 42, BX + 32, 49, t.btnText, 3.4);
    txt(BX + 40, 42, 'Home', 17, t.btnText, 0);
    buttons.push({ x: BX - 6, y: 16, w: 108, h: 52, fn: goHome });
    txt(W / 2 + 20, 42, 'Levels', 32, t.accent);
    const cw = 52 + coinText(DATA.coins).length * 11;
    rrect(W - BX - cw, 22, cw, 40, 20, t.panel, 0.8);
    drawCoin(W - BX - cw + 22, 42, 11);
    txt(W - BX - cw + 40, 42, coinText(DATA.coins), 16, t.accent, 0);
    // world card
    const cy = 96, ch = 118;
    rrect(BX, cy + 5, BW, ch, 24, shade(t.panel, -0.35));
    rrect(BX, cy, BW, ch, 24, t.panel);
    // world art strip
    const wl = W0.wall;
    for (let i = 0; i < 9; i++) { const bx = BX + 78 + i * 36, by = cy + ch - 22; rrect(bx, by + 1, 24, 18, 5, wl.edge); rrect(bx, by, 24, 14, 5, wl.base); rrect(bx + 2, by + 1.5, 20, 4, 2, wl.top, 0.9); }
    txt(W / 2, cy + 22, 'WORLD ' + (w + 1) + ' of 6', 12, t.text, 0.5, false);
    txt(W / 2, cy + 52, soon ? 'Coming Soon' : W0.name, soon ? 30 : 36, t.accent);
    txt(W / 2, cy + 82, soon ? 'A brand new world is on the way' : W0.sub, 13, t.text, 0.5, false);
    // arrows
    [[-1, BX + 28], [1, BX + BW - 28]].forEach((a) => {
      const can = w + a[0] >= 0 && w + a[0] <= WORLDS.length;
      dot(a[1], cy + 52, 20, can ? shade(t.panel, 0.25) : shade(t.panel, -0.2), can ? 1 : 0.6);
      if (can) {
        line(a[1] - a[0] * 4, cy + 42, a[1] + a[0] * 5, cy + 52, t.btnText, 3.6);
        line(a[1] + a[0] * 5, cy + 52, a[1] - a[0] * 4, cy + 62, t.btnText, 3.6);
        buttons.push({ x: a[1] - 26, y: cy + 26, w: 52, h: 52, fn: () => { lvPage = w + a[0]; useWorld(Math.min(lvPage, WORLDS.length - 1)); sfx.click(); } });
      }
    });
    // dots
    for (let i = 0; i <= WORLDS.length; i++) {
      const x = W / 2 + (i - 2.5) * 22;
      dot(x, cy + ch + 20, i === w ? 6 : 4, i === w ? t.accent : t.panel);
      buttons.push({ x: x - 11, y: cy + ch + 8, w: 22, h: 24, fn: () => { lvPage = i; useWorld(Math.min(i, WORLDS.length - 1)); } });
    }
    if (soon) {                                      // World 6: locked, not playable
      const a = anim / 1000, cx = W / 2, my = 440;
      rrect(BX, 262, BW, 420, 28, shade(t.panel, -0.35)); rrect(BX, 256, BW, 420, 28, t.panel);
      for (let i = 0; i < 18; i++) { const sx = BX + 20 + hh(i, 6, 1) * (BW - 40), sy = 272 + hh(i, 6, 2) * 390; dot(sx, sy, 1.2 + 1.3 * hh(i, 6, 3), '#ffffff', 0.25 + 0.55 * Math.abs(Math.sin(a * 1.4 + i * 2))); }
      dot(cx, my, 78 + 4 * Math.sin(a * 2), t.accent, 0.12); dot(cx, my, 58, t.accent, 0.2);
      g.lineStyle(3, C(t.accent), 0.8); g.beginPath(); g.arc(cx, my, 46, a, a + 4.2); g.strokePath();
      g.lineStyle(2, C('#ffffff'), 0.6); g.beginPath(); g.arc(cx, my, 36, -a * 1.4, -a * 1.4 + 3); g.strokePath();
      lockIcon(cx, my - 2, 1.9, t.btnText);
      txt(cx, 548, 'WORLD 6', 34, t.accent);
      txt(cx, 586, 'COMING SOON', 22, t.btnText);
      txt(cx, 622, 'New puzzles, new mechanics.', 14, t.text, 0.5, false);
      button(W / 2, 722, 320, 54, 'Locked', null, { disabled: true, size: 20 });
      return;
    }
    // level grid
    const tile = 76, gap = 13, x0 = (W - (5 * tile + 4 * gap)) / 2, y0 = 262;
    for (let k = 0; k < 20; k++) {
      const id = w * 20 + k + 1, col = k % 5, row = (k / 5) | 0, x = x0 + col * (tile + gap), y = y0 + row * (tile + 12);
      const open = id <= un, st = cp.stars[id] | 0, cur = id === cp.cur && open;
      const face = !open ? shade(t.panel, -0.3) : st ? t.accent : shade(t.panel, 0.18);
      rrect(x, y + 5, tile, tile, 18, shade(face, -0.38), open ? 1 : 0.7);
      rrect(x, y, tile, tile, 18, face, open ? 1 : 0.85);
      if (cur) { g.lineStyle(3.5, C('#ffffff'), 0.55 + 0.45 * Math.sin(anim / 160)); g.strokeRoundedRect(x - 3, y - 3, tile + 6, tile + 6, 21); }
      if (open) {
        txt(x + tile / 2, y + (st ? 29 : 38), String(id), 28, st ? '#1b1b1b' : t.btnText);
        if (st) for (let s = 0; s < 3; s++) starShape(x + tile / 2 + (s - 1) * 19, y + 59, 8.5, s < st ? '#b45309' : '#00000033');
      } else {
        lockIcon(x + tile / 2, y + tile / 2 - 2, 1.15, shade(t.text, -0.35));
      }
      buttons.push({ x: x, y: y, w: tile, h: tile + 6, fn: () => { if (open) startLevel(id); else { lvMsg = { s: 'Clear level ' + (un) + ' to unlock this one', until: anim + 2200 }; sfx.err(); } } });
    }
    // footer
    const first = w * 20 + 1, canPlay = first <= un;
    let target = Math.min(un, w * 20 + 20);
    for (let i = first; i <= w * 20 + 20 && i <= un; i++) { if (!cp.stars[i]) { target = i; break; } }
    txt(W / 2, 636, worldDone(w) + ' / 20 cleared   ' + worldStars(w) + ' / 60 stars', 14, t.text, 0.5, false);
    if (canPlay) button(W / 2, 688, 320, 62, 'Play level ' + target, () => startLevel(target), { primary: true, size: 24 });
    else button(W / 2, 688, 320, 62, 'Locked', null, { disabled: true, size: 22 });
    if (lvMsg && anim < lvMsg.until) txt(W / 2, 744, lvMsg.s, 14, '#ff5a5f', 0.5, false);
    else txt(W / 2, 744, canPlay ? 'Clear a level to unlock the next one' : 'Finish world ' + w + ' to unlock', 13, t.text, 0.5, false);
  }

  // ----- tiles -----
  function floorDecor(gr, w, c, r, id) {
    const v = hh(c, r, id * 3 + w);
    if (v > 0.07) return;
    const x = BX + c * CELL + CELL / 2 + (hh(c, r, 5) - 0.5) * 8, y = BY + r * CELL + CELL / 2 + (hh(c, r, 6) - 0.5) * 8;
    const fill = (px, py, rad, col, al) => { gr.fillStyle(C(col), al); gr.fillCircle(px, py, rad); };
    if (w === 0) { [[0, -2.4], [2.4, 0], [0, 2.4], [-2.4, 0]].forEach((o) => fill(x + o[0], y + o[1], 1.7, '#ffffff', 0.85)); fill(x, y, 1.6, '#ffd23f', 1); }
    else if (w === 1) { fill(x, y, 2.2, '#c99a5b', 0.7); fill(x + 4, y + 3, 1.3, '#c99a5b', 0.7); }
    else if (w === 2) { gr.lineStyle(1.2, C('#ffffff'), 0.85); gr.lineBetween(x - 3.5, y, x + 3.5, y); gr.lineBetween(x, y - 3.5, x, y + 3.5); gr.lineBetween(x - 2.5, y - 2.5, x + 2.5, y + 2.5); gr.lineBetween(x + 2.5, y - 2.5, x - 2.5, y + 2.5); }
    else if (w === 3) { fill(x, y, 2.4, '#ff7a1a', 0.45); fill(x, y, 1.2, '#ffd166', 0.8); }
    else { gr.fillStyle(C('#a5b4fc'), 0.7); gr.fillCircle(x, y, 1.1); gr.fillStyle(C('#a5b4fc'), 0.25); gr.fillCircle(x, y, 2.6); }
  }
  function wallTile(gr, w, c, r, id) {
    const P = WORLDS[w].wall, x = BX + c * CELL, y = BY + r * CELL, v = hh(c, r, id), v2 = hh(c, r, id + 11);
    gr.fillStyle(0x000000, 0.28); gr.fillRoundedRect(x + 0.5, y + 3, CELL, CELL, 6);
    gr.fillStyle(C(P.edge), 1); gr.fillRoundedRect(x, y + 1.5, CELL, CELL - 1.5, 6);
    gr.fillStyle(C(P.base), 1); gr.fillRoundedRect(x, y, CELL, CELL - 3, 6);
    gr.fillStyle(C(P.top), 0.95); gr.fillRoundedRect(x + 2, y + 1.4, CELL - 4, 5.2, 3);
    if (w === 0) {                                              // hedge: leafy bumps
      gr.fillStyle(C(P.top), 0.9); gr.fillCircle(x + 5 + v * 3, y + 11, 3.2); gr.fillCircle(x + 15 - v2 * 3, y + 9, 3);
      gr.fillStyle(C('#1b5a28'), 0.5); gr.fillCircle(x + 11, y + 14.5, 2.6);
      if (v > 0.8) { gr.fillStyle(C('#ff6b81'), 1); gr.fillCircle(x + 7, y + 12, 1.7); }
    } else if (w === 1) {                                       // sandstone bricks
      gr.lineStyle(1.2, C(P.edge), 0.55); gr.lineBetween(x + 2, y + 10.5, x + CELL - 2, y + 10.5); gr.lineBetween(x + 6 + v * 8, y + 10.5, x + 6 + v * 8, y + CELL - 4);
      gr.fillStyle(C(P.edge), 0.35); gr.fillCircle(x + 5 + v2 * 10, y + 7.5, 1);
    } else if (w === 2) {                                       // ice crystal
      gr.lineStyle(1.6, C('#ffffff'), 0.85); gr.lineBetween(x + 5, y + 16, x + 11, y + 8); gr.lineBetween(x + 12, y + 17, x + 16, y + 11);
      gr.fillStyle(C('#ffffff'), 0.9); gr.fillCircle(x + 16.5, y + 5.5, 1.3);
    } else if (w === 3) {                                       // basalt with glowing cracks
      gr.lineStyle(1.8, C('#ff7a1a'), 0.95); gr.beginPath(); gr.moveTo(x + 4, y + 8 + v * 4); gr.lineTo(x + 10, y + 12); gr.lineTo(x + 14, y + 9); gr.lineTo(x + 19, y + 14 + v2 * 2); gr.strokePath();
      gr.lineStyle(0.8, C('#ffd166'), 0.9); gr.beginPath(); gr.moveTo(x + 10, y + 12); gr.lineTo(x + 14, y + 9); gr.strokePath();
    } else {                                                    // night stone with a glowing rune
      if (v > 0.45) { gr.lineStyle(1.5, C('#7cf5ff'), 0.9); gr.strokeCircle(x + CELL / 2, y + 10.5, 3.4); gr.fillStyle(C('#7cf5ff'), 0.9); gr.fillCircle(x + CELL / 2, y + 10.5, 1);
      } else { gr.fillStyle(C('#c4b5fd'), 0.8); gr.fillCircle(x + 5 + v2 * 12, y + 8, 1.2); }
    }
  }
  function iceTile(gr, c, r, id) {
    const x = BX + c * CELL, y = BY + r * CELL;
    gr.fillStyle(0x7dd3fc, 0.35); gr.fillRoundedRect(x + 0.5, y + 0.5, CELL - 1, CELL - 1, 4);
    gr.fillStyle(0xffffff, 0.6); gr.fillRoundedRect(x + 1.5, y + 1.5, CELL - 3, CELL - 3, 4);
    gr.lineStyle(1.2, 0x38bdf8, 0.9); gr.strokeRoundedRect(x + 1, y + 1, CELL - 2, CELL - 2, 4);
    gr.lineStyle(1.6, 0xffffff, 0.95); gr.lineBetween(x + 4, y + 8, x + 9, y + 3.5); gr.lineBetween(x + 7, y + 12, x + 15, y + 4.5);
  }
  // The board (floor, walls, ice) never changes during a level, so it is drawn once into a texture instead of being redrawn every frame.
  let boardRT = null;
  let boardKeyBaked = '';
  function bakeBoard() {
    try {
      if (!boardRT) { boardRT = scene.add.renderTexture(0, 0, W * ZOOM, H * ZOOM); boardRT.setOrigin(0, 0); boardRT.setScale(1 / ZOOM); boardRT.setDepth(boardG.depth); }
      boardRT.clear(); boardRT.setVisible(true);
      boardG.setScale(ZOOM); boardG.setVisible(true);
      boardRT.draw(boardG, 0, 0);
      boardG.setScale(1); boardG.setVisible(false);
      return true;
    } catch (e) { boardG.setScale(1); boardG.setVisible(true); if (boardRT) boardRT.setVisible(false); }
  }
  function drawCampBoardFull() {
    const C0 = G.camp, rt = C0.rt, w = C0.L.w, t = th();
    const bkey = C0.id + '|' + w + '|' + JSON.stringify(t);
    if (boardRT && boardKeyBaked === bkey) { boardRT.setVisible(true); boardG.setVisible(false); return; }   // retry / restart: the baked board is reused
    boardG.clear();
    boardG.setVisible(true);
    boardG.fillStyle(C(shade(t.panel, -0.25)), 1);
    boardG.fillRoundedRect(BX - 8, BY - 5, BW + 16, BH + 17, 14);
    boardG.fillStyle(C(t.panel), 1);
    boardG.fillRoundedRect(BX - 8, BY - 8, BW + 16, BH + 16, 14);
    boardG.fillStyle(C(t.board1), 1);
    boardG.fillRect(BX, BY, BW, BH);
    drawPattern(boardG, WORLDS[w].pattern, BX, BY, COLS, ROWS, CELL);
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      const i = r * COLS + c;
      if (rt.wall[i]) continue;
      if (rt.ice[i]) iceTile(boardG, c, r, C0.id); else floorDecor(boardG, w, c, r, C0.id);
    }
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) if (rt.wall[r * COLS + c]) wallTile(boardG, w, c, r, C0.id);
    if (bakeBoard()) { boardKeyBaked = bkey; boardG.clear(); } else boardKeyBaked = '';   // clear frees the ~46k recorded commands
  }

  // The board is recorded and baked in six small steps (one per frame) so a level start never freezes the game for one long frame.
  let boardJob = null;
  function drawCampBoard() {
    const C0 = G.camp, rt = C0.rt, w = C0.L.w, t = th();
    const bkey = C0.id + '|' + w + '|' + JSON.stringify(t);
    if (boardRT && boardKeyBaked === bkey) { boardRT.setVisible(true); boardG.setVisible(false); return; }   // retry / restart: the baked board is reused
    if (boardJob && boardJob.key === bkey && boardJob.C0 === C0) return;
    boardKeyBaked = '';
    try {
      if (!boardRT) { boardRT = scene.add.renderTexture(0, 0, W * ZOOM, H * ZOOM); boardRT.setOrigin(0, 0); boardRT.setScale(1 / ZOOM); boardRT.setDepth(boardG.depth); }
      boardRT.clear(); boardRT.setVisible(true);
    } catch (e) { boardJob = null; drawCampBoardFull(); return; }
    boardJob = { key: bkey, C0: C0, rt: rt, w: w, t: t, stage: 0 };
    boardStep();
  }
  function boardStep() {
    const J = boardJob;
    if (!J) return;
    if (!(G && G.camp && G.camp === J.C0 && state !== 'menu' && state !== 'levels')) { boardJob = null; return; }   // left the level: start over next time
    const rt = J.rt, w = J.w, t = J.t, C0 = J.C0, s = J.stage++;
    boardG.clear();
    if (s === 0) {
      boardG.fillStyle(C(shade(t.panel, -0.25)), 1);
      boardG.fillRoundedRect(BX - 8, BY - 5, BW + 16, BH + 17, 14);
      boardG.fillStyle(C(t.panel), 1);
      boardG.fillRoundedRect(BX - 8, BY - 8, BW + 16, BH + 16, 14);
      boardG.fillStyle(C(t.board1), 1);
      boardG.fillRect(BX, BY, BW, BH);
      drawPattern(boardG, WORLDS[w].pattern, BX, BY, COLS, ROWS, CELL);
    } else if (s <= 3) {
      for (let r = (s - 1) * 9; r < Math.min(ROWS, s * 9); r++) for (let c = 0; c < COLS; c++) {
        const i = r * COLS + c;
        if (rt.wall[i]) continue;
        if (rt.ice[i]) iceTile(boardG, c, r, C0.id); else floorDecor(boardG, w, c, r, C0.id);
      }
    } else {
      for (let r = (s - 4) * 13; r < Math.min(ROWS, (s - 3) * 13); r++) for (let c = 0; c < COLS; c++) if (rt.wall[r * COLS + c]) wallTile(boardG, w, c, r, C0.id);
    }
    try {
      boardG.setScale(ZOOM); boardG.setVisible(true);
      boardRT.draw(boardG, 0, 0);
    } catch (e) { boardG.setScale(1); boardJob = null; drawCampBoardFull(); return; }
    boardG.setScale(1); boardG.setVisible(false); boardG.clear();
    if (s >= 5) { boardKeyBaked = J.key; boardJob = null; }
  }

  // ----- dynamic items -----
  function drawKey(x, y, s) {
    const bob = Math.sin(anim / 220) * 1.5;
    y += bob;
    dot(x, y, 12 * s, '#facc15', 0.22);
    line(x - 1 * s, y + 1 * s, x + 8 * s, y + 1 * s, '#b45309', 3.6 * s);
    line(x + 4 * s, y + 1 * s, x + 4 * s, y + 5.5 * s, '#b45309', 2.6 * s); line(x + 7.5 * s, y + 1 * s, x + 7.5 * s, y + 4.5 * s, '#b45309', 2.6 * s);
    line(x - 1 * s, y + 1 * s, x + 8 * s, y + 1 * s, '#facc15', 2 * s);
    dot(x - 5 * s, y + 1 * s, 5.2 * s, '#b45309'); dot(x - 5 * s, y + 1 * s, 4 * s, '#fde047'); dot(x - 5 * s, y + 1 * s, 1.8 * s, '#b45309');
  }
  function drawDoor(x, y, open, flash) {
    if (open) {
      rrect(x - 10, y - 10, 20, 20, 5, '#facc15', 0.18 + (flash ? 0.25 : 0));
      g.lineStyle(1.6, C('#facc15'), 0.75); g.strokeRoundedRect(x - 10, y - 10, 20, 20, 5);
      return;
    }
    rrect(x - 11, y - 11 + 2, 22, 22, 5, '#5b3410');
    rrect(x - 11, y - 11, 22, 22, 5, '#a8672a');
    rrect(x - 9, y - 9, 18, 5, 3, '#d99a55', 0.8);
    line(x - 9, y + 2, x + 9, y + 2, '#6b3d12', 1.4);
    dot(x, y + 1, 4.6, '#fde047'); dot(x, y + 0.2, 1.6, '#7c4a10'); rrect(x - 0.9, y + 0.5, 1.8, 4, 0.6, '#7c4a10');
  }
  function drawGate(x, y, open, col, flash) {
    if (open) {
      rrect(x - 10, y - 10, 20, 3, 1.5, col, 0.55); rrect(x - 10, y + 7, 20, 3, 1.5, col, 0.55);
      g.fillStyle(C(col), 0.25); g.fillRoundedRect(x - 10, y - 10, 20, 20, 5);
      return;
    }
    rrect(x - 11, y - 11, 22, 22, 5, '#1f2937');
    for (let i = 0; i < 4; i++) { rrect(x - 8.5 + i * 5.6, y - 10, 3, 20, 1.5, col); rrect(x - 8.5 + i * 5.6, y - 10, 1.2, 20, 0.6, '#ffffff', 0.45); }
    rrect(x - 11, y - 3, 22, 3, 1.5, col, 0.9);
    if (flash) dot(x, y, 14, col, 0.3);
  }
  function drawSwitch(x, y, col, on) {
    dot(x, y, 12, col, on ? 0.12 : 0.28);
    rrect(x - 10, y - 8, 20, 17, 6, '#111827', 0.8);
    rrect(x - 10, y - 10 + (on ? 3 : 0), 20, 17 - (on ? 3 : 0), 6, '#475569');
    dot(x, y - 1 + (on ? 2 : 0), 6.2, on ? shade(col, -0.35) : col);
    if (!on) dot(x - 1.8, y - 3, 1.8, '#ffffff', 0.7);
  }
  function drawPortal(x, y, col, flip) {
    const a = anim / 400 * (flip ? -1 : 1);
    dot(x, y, 15, col, 0.18 + 0.08 * Math.sin(anim / 240));
    dot(x, y, 11.5, '#0b1020');
    for (let i = 0; i < 3; i++) {
      g.lineStyle(2.4 - i * 0.4, C(i === 1 ? '#ffffff' : col), 0.95);
      g.beginPath(); g.arc(x, y, 10.5 - i * 3, a + i * 2.1, a + i * 2.1 + 3.2); g.strokePath();
    }
    dot(x, y, 2, '#ffffff', 0.9);
  }
  const PORTAL_COLS = [['#4ade80', '#bef264', '#14532d'], ['#fbbf24', '#fde68a', '#78350f'], ['#67e8f9', '#e0f2fe', '#0c4a6e'], ['#fb923c', '#fde047', '#7f1d1d'], ['#c084fc', '#f0abfc', '#3b0764']];
  function drawExitTile(x, y, open) {
    const C0 = G.camp, pc = PORTAL_COLS[C0.L.w] || PORTAL_COLS[0], a = anim / 1000;
    let near = 0;
    if (open && !C0.won) { const hp = headXY(), d = Math.hypot(hp.x - x, hp.y - y) / CELL; near = d < 4 ? 1 - d / 4 : 0; }
    const ent = C0.won ? Math.min(1, C0.endT / PORTAL_MS) : 0;
    if (!open) {                                                  // locked: dim, slow, broken ring
      dot(x, y, 14, '#0b0b12', 0.7);
      g.lineStyle(2, C(pc[0]), 0.4);
      for (let i = 0; i < 3; i++) { const s0 = a * 0.5 + i * 2.1; g.beginPath(); g.arc(x, y, 11.5, s0, s0 + 1.3); g.strokePath(); }
      dot(x, y, 3.2, pc[0], 0.35);
      return;
    }
    const k = 1 + 0.07 * Math.sin(a * 4) + near * 0.18 + ent * 0.5, sp = 1 + near * 1.2 + ent * 5, wake = C0.exitT === undefined ? 1 : Math.min(1, (anim - C0.exitT) / 450);
    const sc = (0.4 + 0.6 * wake) * k;                            // opens up smoothly right after the last fruit
    dot(x, y, 20 * sc, pc[0], 0.16 + 0.1 * near + 0.2 * ent);
    dot(x, y, 15.5 * sc, pc[2], 0.95);
    for (let i = 0; i < 3; i++) {                                 // swirling arcs
      g.lineStyle(2.6 - i * 0.5, C(i === 1 ? pc[1] : pc[0]), 0.95);
      const s0 = a * sp * (i % 2 ? -2.2 : 2.6) + i * 2.1, r = (13.5 - i * 3.6) * sc;
      g.beginPath(); g.arc(x, y, r, s0, s0 + 3.4 - i * 0.5); g.strokePath();
    }
    dot(x, y, 4.2 * sc, pc[1], 0.95); dot(x, y, 2 * sc, '#ffffff', 0.95);
    if (!LITE) for (let i = 0; i < 4; i++) {                      // sparks pulled into the centre
      const t2 = (a * (0.8 + near) + i / 4) % 1, an = i * 1.57 + a, r = 22 * (1 - t2);
      dot(x + Math.cos(an) * r, y + Math.sin(an) * r, 1.5, pc[1], 0.9 * t2);
    }
    if (ent > 0.55) dot(x, y, 26 * (ent - 0.55) * 2.2, '#ffffff', 0.55 * (1 - ent) + 0.15);   // soft flash as the snake goes in
  }
  function drawAmbient(w) {
    const a = anim / 1000;
    for (let i = 0; i < 14; i++) {
      const s = hh(i, w, 7), s2 = hh(i, w, 9);
      let x = BX + s * BW, y = BY + s2 * BH;
      if (w === 0) { x += Math.sin(a * 0.8 + i) * 10; y += Math.cos(a * 0.6 + i * 2) * 8; dot(x, y, 1.7, '#fffbd0', 0.45 + 0.3 * Math.sin(a * 2 + i)); }
      else if (w === 1) { x = BX + ((s * BW + a * 20 * (0.5 + s2)) % BW); y += Math.sin(a + i) * 4; dot(x, y, 1.4, '#fff1c9', 0.55); }
      else if (w === 2) { y = BY + ((s2 * BH + a * 24 * (0.6 + s)) % BH); x += Math.sin(a * 1.3 + i) * 8; dot(x, y, 1.9, '#ffffff', 0.85); }
      else if (w === 3) { y = BY + BH - ((s2 * BH + a * 28 * (0.5 + s)) % BH); x += Math.sin(a * 1.6 + i) * 6; dot(x, y, 2, '#ff9a2e', 0.5); dot(x, y, 1, '#fff2a0', 0.9); }
      else dot(x, y, 1.2 + 1.2 * s, '#c7d2fe', 0.2 + 0.55 * Math.abs(Math.sin(a * 1.5 + i * 3)));
    }
  }
  function wrapText(s, n) {
    const words = s.split(' '), out = [];
    let cur = '';
    words.forEach((w) => { if ((cur + ' ' + w).trim().length > n) { out.push(cur); cur = w; } else cur = (cur + ' ' + w).trim(); });
    if (cur) out.push(cur);
    return out;
  }
  function objective(C0) {
    const rt = C0.rt, n = rt.fruits.length;
    const parts = [];
    if (rt.keys.length) parts.push('take the key');
    if (rt.switches.length) parts.push('press the switch');
    parts.push(n === 1 ? 'eat the fruit' : 'eat all ' + n + ' fruit');
    parts.push('reach the exit');
    const s = parts.join(', then ');
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  function drawCampHud() {
    const C0 = G.camp, t = th(), rt = C0.rt, st = C0.st;
    txt(BX, 22, WORLDS[C0.L.w].name.toUpperCase() + '  -  WORLD ' + (C0.L.w + 1), 11, t.text, 0, false);
    txt(BX, 50, 'Level ' + C0.id, 28, t.accent, 0);
    txt(BX + BW, 22, 'Moves', 12, t.text, 1, false);
    txt(BX + BW, 50, String(C0.moves), 28, C0.moves > C0.L.s2 ? '#ff5a5f' : t.text, 1);
    // tracker: fruit, keys, exit
    const items = rt.fruits.length + rt.keys.length + 1, pit = Math.min(24, 240 / items), x0 = 284 - (items - 1) * pit / 2;   // sits between the level title and the moves counter
    let k = 0;
    rt.fruits.forEach((f, i) => {
      const x = x0 + k * pit, eaten = (st.fruitMask >> i) & 1;
      dot(x, 40, 10.5, t.panel); if (eaten) { dot(x, 40, 10.5, '#4ade80', 0.35); drawFruit(C0.fr[i].kind, x, 42, 0.62); } else { dot(x, 40, 7, t.bg, 0.55); }
      k++;
    });
    rt.keys.forEach((kk, i) => { const x = x0 + k * pit, has = (st.keyMask >> i) & 1; dot(x, 40, 10.5, t.panel); if (has) drawKey(x, 40, 0.62); else dot(x, 40, 5, '#facc15', 0.3); k++; });
    { const x = x0 + k * pit, open = C0.exitOpen; dot(x, 40, 10.5, open ? '#22c55e' : t.panel); g.fillStyle(C(open ? '#14532d' : t.text), open ? 1 : 0.5); g.fillTriangle(x - 3, 34, x - 3, 46, x + 5, 40); }
    txt(W / 2, 80, objective(C0), 12.5, t.text, 0.5, false);
  }
  function drawPwIcon(k, x, y, on) {
    if (k === 'slow') drawPower('slow', x, y, 0.95);
    else if (k === 'coin2') drawPower('double', x, y, 0.95);
    else if (k === 'shield') {
      g.fillStyle(C(on ? '#ffffff' : '#38bdf8'), 1);
      g.fillPoints([{ x: x - 10, y: y - 10 }, { x: x + 10, y: y - 10 }, { x: x + 10, y: y + 1 }, { x: x, y: y + 12 }, { x: x - 10, y: y + 1 }], true);
      g.fillStyle(C('#0c4a6e'), 0.55); g.fillPoints([{ x: x - 5, y: y - 6 }, { x: x + 5, y: y - 6 }, { x: x + 5, y: y }, { x: x, y: y + 6 }, { x: x - 5, y: y }], true);
    } else { drawBomb(x, y + 1, 0.8); line(x - 8, y + 8, x + 8, y - 8, '#4ade80', 3); }
  }
  function toggleBtn(cx, cy, kind, on, label, fn) {
    const t = th();
    dot(cx, cy + 3, 25, shade(t.panel, -0.3)); dot(cx, cy, 25, on ? t.accent : shade(t.panel, -0.15));
    g.fillStyle(0x000000, 0); drawIcon(kind, cx, cy, on ? '#1b1b1b' : t.btnText);
    txt(cx, cy + 40, label + (on ? '' : ' off'), 12, t.btnText, 0.5, false);
    buttons.push({ x: cx - 40, y: cy - 30, w: 80, h: 80, fn: fn });
  }
  function drawCampBottom() {
    const C0 = G.camp, t = th();
    PW_KEYS.forEach((k, i) => {
      const x = BX + i * 58, y = 694, n = DATA.pw[k] | 0;
      const on = (k === 'slow' && C0.slowT > 0) || (k === 'shield' && C0.shield) || (k === 'coin2' && C0.coinMul > 1);
      blit('pw', stamp('st_pw_' + k + (on ? 1 : 0) + '_' + C0.L.w, () => { rrect(6, 9, 52, 52, 13, shade(t.panel, -0.3)); rrect(6, 6, 52, 52, 13, on ? '#0ea5e9' : t.panel); drawPwIcon(k, 32, 29, on); }, 64), x + 26, y + 26, 1, 5);
      useLayer(2);
      if (n > 0) { dot(x + 44, y + 8, 9.5, t.accent); txt(x + 44, y + 8, String(n), 12, '#1b1b1b'); }
      else { drawCoin(x + 14, y + 43, 5.5); txt(x + 22, y + 43, String(PW[k].cost), 11, DATA.coins >= PW[k].cost ? t.accent : t.btnText, 0); }
      useLayer(0);
      buttons.push({ x: x - 3, y: y - 3, w: 58, h: 58, fn: () => usePower(k) });
    });
    txt(BX + 236, 706, '3 stars: ' + C0.L.s3 + ' moves', 11.5, t.text, 0, false);
    txt(BX + 236, 728, '2 stars: ' + C0.L.s2 + ' moves', 11.5, t.text, 0, false);
    const qx = BX + BW - 78, qy = 718;                          // "?" = what is in this level
    dot(qx, qy, 15, t.panel); txt(qx, qy + 1, '?', 20, t.btnText);
    buttons.push({ x: qx - 20, y: qy - 24, w: 40, h: 48, fn: openHelp });
    const px = BX + BW - 52, py = 692;
    rrect(px, py, 52, 52, 12, t.panel);
    line(px + 19, py + 15, px + 19, py + 37, t.btnText, 6);
    line(px + 33, py + 15, px + 33, py + 37, t.btnText, 6);
    buttons.push({ x: px - 6, y: py - 6, w: 64, h: 64, fn: togglePause });
  }

  // ---------- Pre-drawn stamps: fruit, bombs, keys, gates, doors and power-up buttons are drawn once into small textures and then only
  // positioned as images, instead of re-recording hundreds of Graphics commands every frame. Same pictures, far less work per frame. ----------
  const stampKeep = [], pools = {};
  function stamp(key, fn, size) {
    if (!scene.textures.exists(key)) {
      const S = size || 44, rt = scene.make.renderTexture({ width: S * ZOOM, height: S * ZOOM }, false), tg = scene.make.graphics({ add: false }), pg = g;
      g = tg;
      try { fn(S / 2, S / 2); } finally { g = pg; }
      tg.setScale(ZOOM); rt.draw(tg, 0, 0); rt.saveTexture(key); tg.destroy(); stampKeep.push(rt);
    }
    return key;
  }
  function blit(pool, key, x, y, alpha, depth) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key).setScale(1 / ZOOM).setDepth(depth); im._k = key; P.a.push(im); }
    P.n++;
    if (im._k !== key) { im.setTexture(key); im._k = key; }
    im.setPosition(x, y); im.setAlpha(alpha === undefined ? 1 : alpha); im.setVisible(true);
  }
  function poolsBegin() { for (const k in pools) pools[k].n = 0; }
  function poolsEnd() { for (const k in pools) { const P = pools[k]; for (let i = P.n; i < P.a.length; i++) if (P.a[i]._vis !== false) { P.a[i].setVisible(false); } } }
  function withStillClock(fn) { const a0 = anim; anim = 0; try { fn(); } finally { anim = a0; } }
  const bombSt = (flick) => ['st_bomb_' + (flick ? 1 : 0), (cx, cy) => {
    line(cx + 4, cy - 6, cx + 8, cy - 11, '#a16207', 2.2);
    dot(cx, cy + 1, 8.5, '#1f2937'); dot(cx - 2.8, cy - 1.8, 2.4, '#6b7280'); rrect(cx + 1.5, cy - 8.5, 5, 4, 1, '#374151');
    dot(cx + 8.5, cy - 11.5, flick ? 3.2 : 2.4, flick ? '#fbbf24' : '#f97316');
  }];
  function stampBomb(x, y) {
    const a = anim / 60, flick = Math.sin(a * 1.7) > 0;
    blit('bombGlow', stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 13, '#ef4444', 1)), x, y, 0.18 + 0.12 * Math.sin(a * 0.35), 4);
    blit('bomb', stamp(...bombSt(flick)), x, y, 1, 5);
  }
  const fruitSt = (kind) => ['st_fr_' + kind, (cx, cy) => drawFruit(kind, cx, cy, 1.1)];
  const keySt = () => ['st_key', (cx, cy) => withStillClock(() => drawKey(cx, cy, 1))];
  const doorSt = (open, flash) => ['st_door_' + (open ? 1 : 0) + (flash ? 1 : 0), (cx, cy) => drawDoor(cx, cy, open, flash)];
  const gateSt = (open, col, flash) => ['st_gate_' + col + (open ? 1 : 0) + (flash ? 1 : 0), (cx, cy) => drawGate(cx, cy, open, col, flash)];
  const stampFruit = (kind, x, y) => blit('fruit', stamp(...fruitSt(kind)), x, y, 1, 5);
  const stampKey = (x, y) => blit('key', stamp(...keySt()), x, y + Math.sin(anim / 220) * 1.5, 1, 5);
  const stampDoor = (x, y, open, flash) => blit('door', stamp(...doorSt(open, flash)), x, y, 1, 5);
  const stampGate = (x, y, open, col, flash) => blit('gate', stamp(...gateSt(open, col, flash)), x, y, 1, 5);
  // The stamps are made one per frame while the menu / level map is on screen, so starting a level does not have to build them.
  let warmQ = null;
  function warmStep() {
    if (state !== 'menu' && state !== 'levels') return;
    if (!warmQ) {
      warmQ = [];
      FRUITS.forEach((k) => warmQ.push(() => stamp(...fruitSt(k))));
      [true, false].forEach((f) => warmQ.push(() => stamp(...bombSt(f))));
      warmQ.push(() => stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 13, '#ef4444', 1)));
      warmQ.push(() => stamp(...keySt()));
      [[0, 0], [1, 0], [0, 1], [1, 1]].forEach((v) => warmQ.push(() => stamp(...doorSt(!!v[0], !!v[1]))));
      GATE_COLS.forEach((col) => [[0, 0], [1, 0], [0, 1], [1, 1]].forEach((v) => warmQ.push(() => stamp(...gateSt(!!v[0], col, !!v[1])))));
    }
    if (warmQ.length) warmQ.shift()();
  }
  function drawCampGame() {
    const C0 = G.camp, rt = C0.rt, st = C0.st, a = anim / 60, w = C0.L.w;
    drawCampHud();
    drawCampBottom();
    if (!LITE) drawAmbient(w);
    // sparkles on the ice
    for (let n = 0; n < C0.iceList.length && !LITE; n++) {
      if ((n * 7 + Math.floor(anim / 380)) % 11) continue;
      const i = C0.iceList[n], p = cellOf(i), s = 0.5 + 0.5 * Math.sin(anim / 120 + n);
      line(p.x - 3 * s - 1, p.y, p.x + 3 * s + 1, p.y, '#ffffff', 1.4); line(p.x, p.y - 3 * s - 1, p.x, p.y + 3 * s + 1, '#ffffff', 1.4);
    }
    if (C0.route) {                                   // hint: a trail of dots along the way to the exit
      const hi = C0.routeIdx.get(st.body[0]), from = hi === undefined ? 0 : hi + 1, pulse = anim / 170;
      for (let i = from; i < C0.route.length; i += LITE ? 2 : 1) { const p = cellOf(C0.route[i]); dot(p.x, p.y, 3, '#ffffff', 0.3 + 0.3 * Math.sin(pulse - i * 0.55)); }
    }
    drawExitTile(cellOf(rt.exit).x, cellOf(rt.exit).y, C0.exitOpen);
    rt.portalTo.forEach((to, i) => { if (to >= 0) { const p = cellOf(i), cols = ['#c084fc', '#38bdf8']; drawPortal(p.x, p.y, cols[(i < to) ? 0 : 1], i < to); } });
    rt.switches.forEach((s) => { const p = cellOf(s.cell); drawSwitch(p.x, p.y, GATE_COLS[s.gateIdx % GATE_COLS.length], E.gateOpen(rt, st, s.gateIdx)); });
    rt.gates.forEach((gt, gi) => gt.cells.forEach((c) => { const p = cellOf(c); stampGate(p.x, p.y, E.gateOpen(rt, st, gi), GATE_COLS[gi % GATE_COLS.length], C0.flash.some((f) => f.cell === c)); }));
    rt.doors.forEach((d) => { const p = cellOf(d.cell); stampDoor(p.x, p.y, E.doorOpen(rt, st, d), C0.flash.some((f) => f.cell === d.cell)); });
    rt.keys.forEach((k, i) => { if (!((st.keyMask >> i) & 1)) { const p = cellOf(k.cell); stampKey(p.x, p.y); } });
    for (let i = 0; i < COLS * ROWS; i++) if (rt.bomb[i]) { const b = cellOf(i); stampBomb(b.x, b.y); }
    C0.fr.forEach((f, i) => { if (!((st.fruitMask >> i) & 1)) { const p = cellOf(f.cell); stampFruit(f.kind, p.x, p.y + 1.5 * Math.sin(a * 0.4 + i)); } });
    useLayer(2);                                      // snake, effects and messages go above the stamped items
    drawSnake(snakePoints(), G.dir, null);
    if (G.boom && C0.over === 'trap') { const b = cellXY(G.boom[0], G.boom[1]); drawBoom(b.x, b.y); }
    fxs.forEach((e) => {
      const k = e.life / e.max;
      if (e.k === 1) { g.lineStyle(3 * k + 1, C(e.color), k); g.strokeCircle(e.x, e.y, e.r + (1 - k) * 26); }
      else dot(e.x, e.y, e.r * k + 0.5, e.color, k);
    });
    if (state === 'play') popups.forEach((p) => txt(p.x, p.y - (900 - p.life) * 0.03, p.s, 13, p.color));
    if (banner) {
      const k = banner.life / banner.max, grow = Math.min(1, (1 - k) * 8), alpha = Math.min(1, k * 4);
      const bw = 300 * (0.7 + 0.3 * grow), by = BY + 46 - (1 - k) * 14;
      rrect(W / 2 - bw / 2, by - 24, bw, banner.sub ? 52 : 38, 18, '#000000', 0.55 * alpha);
      txt(W / 2, by - (banner.sub ? 7 : 0), banner.s, banner.sub ? 20 : 22, banner.color);
      if (banner.sub) txt(W / 2, by + 15, banner.sub, 11, '#ffffff', 0.5, false);
    }
    if (C0.hint && G.playMs < 9000 && C0.ready <= 0 && !C0.over && !C0.won) {
      const lines = wrapText(C0.hint, 40), hgt = 16 + lines.length * 22, ty = BY + BH - hgt - 14;
      rrect(BX + 20, ty, BW - 40, hgt, 16, '#000000', 0.62);
      lines.forEach((l, i) => txt(W / 2, ty + 18 + i * 22, l, 14.5, '#ffffff', 0.5, false));
    }
    if (C0.shield) { const p = headXY(); g.lineStyle(2.5, C('#38bdf8'), 0.75 + 0.25 * Math.sin(anim / 120)); g.strokeCircle(p.x, p.y, 17); }
    if (C0.hold) txt(W / 2, BY + 60, 'Turn now!', 22, '#38bdf8');
    if (C0.ready > 0) {
      const go = C0.ready < 380, k = go ? C0.ready / 380 : 1, bw = 190;
      rrect(W / 2 - bw / 2, BY + BH * 0.42 - 34, bw, 68, 22, '#000000', 0.55);
      txt(W / 2, BY + BH * 0.42, go ? 'GO!' : 'READY', go ? 40 + (1 - k) * 8 : 34, go ? '#4ade80' : '#ffffff');
    }
  }
  function drawCampOverlayFrame(h) {
    const t = th(), top = (H - h) / 2;
    g.fillStyle(0x000000, 0.4); g.fillRect(0, 0, W, H);
    rrect(W / 2 - 186, top - 6, 372, h + 12, 26, t.bg);
    rrect(W / 2 - 180, top, 360, h, 22, t.panel);
    return top;
  }

  // ---------- "How to play" card: what is in this level (opens by itself the first time a thing appears, and from the "?" button) ----------
  const TIPS_KEY = 'snakeFruitRush.tips.v1';
  const tipsSeen = (() => {
    try { const a = JSON.parse(localStorage.getItem(TIPS_KEY)); return new Set(Array.isArray(a) ? a.filter((x) => typeof x === 'string').slice(0, 20) : []); } catch (e) { return new Set(); }
  })();
  function helpItems(L) {
    const it = [
      { id: 'swipe', title: 'Swipe to turn', text: 'Swipe anywhere to turn. Walls and your own body stop you.' },
      { id: 'fruit', title: 'Eat all the fruit', text: 'The exit only opens after every fruit is eaten.' }
    ];
    if (skHas(L, 'I')) it.push({ id: 'ice', title: 'Ice', text: 'You slide and cannot turn until the ice ends.' });
    if (skHas(L, 'B')) it.push({ id: 'bomb', title: 'Bombs', text: 'Touch a bomb and the level ends. Go around!' });
    if (skHas(L, 'D')) it.push({ id: 'door', title: 'Key and door', text: 'Take the key first. Then the door opens for you.' });
    if (skHas(L, 'G')) it.push({ id: 'gate', title: 'Switch and gate', text: 'Step on the switch to open (or close) the gate of the same colour.' });
    if (skHas(L, 'P')) it.push({ id: 'portal', title: 'Portals', text: 'Enter one portal and you come out of the other.' });
    it.push({ id: 'exit', title: 'The exit', text: 'It glows when all fruit is eaten. Then go in!' });
    return it;
  }
  function drawHelpIcon(id, x, y) {
    if (id === 'swipe') { g.fillStyle(C('#ffffff'), 0.95); g.fillTriangle(x - 13, y, x - 2, y - 9, x - 2, y + 9); g.fillTriangle(x + 13, y, x + 2, y - 9, x + 2, y + 9); dot(x, y, 4, '#ffffff'); }
    else if (id === 'fruit') drawFruit('apple', x, y, 1.1);
    else if (id === 'ice') { rrect(x - 12, y - 12, 24, 24, 6, '#bfe6ff'); line(x - 7, y + 4, x + 3, y - 6, '#ffffff', 2.2); line(x - 2, y + 8, x + 8, y - 2, '#ffffff', 2.2); }
    else if (id === 'bomb') drawBomb(x, y, 1.15);
    else if (id === 'door') { drawKey(x - 12, y, 0.8); drawDoor(x + 12, y, false, false); }
    else if (id === 'gate') { drawSwitch(x - 12, y, GATE_COLS[0], false); drawGate(x + 12, y, false, GATE_COLS[0], false); }
    else if (id === 'portal') { drawPortal(x - 12, y, '#c084fc', true); drawPortal(x + 12, y, '#38bdf8', false); }
    else if (id === 'exit') drawExitTile(x, y, true);
  }
  function drawCampHelp() {
    const t = th(), C0 = G.camp, items = helpItems(C0.L), rowH = 66, h = 118 + items.length * rowH + 64, top = drawCampOverlayFrame(h);
    buttons = [];                                                      // only this card reacts
    txt(W / 2, top + 36, 'How to play', 28, t.accent);
    txt(W / 2, top + 66, 'What is in level ' + C0.id, 13, t.btnText, 0.5, false);
    items.forEach((it, i) => {
      const y = top + 108 + i * rowH;
      rrect(W / 2 - 168, y - 28, 336, rowH - 6, 14, t.bg, 0.55);
      drawHelpIcon(it.id, W / 2 - 130, y + 4);
      txt(W / 2 - 96, y - 14, it.title, 15, t.btnText, 0);
      if (!tipsSeen.has(it.id)) { rrect(W / 2 + 118, y - 23, 42, 18, 9, t.accent); txt(W / 2 + 139, y - 14, 'NEW', 10, '#1b1b1b'); }
      wrapText(it.text, 34).forEach((l, k) => txt(W / 2 - 96, y + 6 + k * 16, l, 12, t.text, 0, false));
    });
    button(W / 2, top + h - 40, 260, 52, 'Got it!', closeHelp, { primary: true, size: 20 });
  }
  function openHelp() {
    if (!G || !G.camp || state !== 'play' || G.camp.over || G.camp.won) return;
    G.camp.help = true; togglePause();
  }
  function closeHelp() {
    const C0 = G.camp;
    helpItems(C0.L).forEach((i) => tipsSeen.add(i.id));
    try { localStorage.setItem(TIPS_KEY, JSON.stringify(Array.from(tipsSeen))); } catch (e) { /* blocked: shows again next time */ }
    C0.help = false; togglePause();
  }
  function drawCampPause() {
    const t = th(), C0 = G.camp, top = drawCampOverlayFrame(420);
    txt(W / 2, top + 38, 'Paused', 33, t.accent);
    txt(W / 2, top + 74, 'Level ' + C0.id + '  -  ' + WORLDS[C0.L.w].name, 16, t.btnText);
    toggleBtn(W / 2 - 96, top + 122, 'sound', DATA.sound, 'Sound', toggleSound);
    toggleBtn(W / 2, top + 122, 'vibe', DATA.vibe, 'Vibrate', toggleVibe);
    toggleBtn(W / 2 + 96, top + 122, 'tap', DATA.tapSteer, 'Tap to turn', toggleTap);
    button(W / 2, top + 232, 290, 56, 'Resume', togglePause, { primary: true, size: 21 });
    button(W / 2, top + 300, 290, 50, 'Restart level', campRetry, { dark: true, size: 18 });
    button(W / 2, top + 362, 290, 50, 'Levels', leaveToLevels, { dark: true, size: 18 });
  }
  function drawCampFail() {
    const t = th(), C0 = G.camp, hintOk = !C0.route && adAvailable(), top = drawCampOverlayFrame(hintOk ? 366 : 300);
    txt(W / 2, top + 44, C0.over === 'trap' ? 'Boom!' : 'Oops!', 34, '#ff5a5f');
    const why = C0.over === 'gate' ? 'The gate is closed - use the switch' : C0.over === 'door' ? 'The door is locked - get the key first' : (FAIL_TEXT[C0.over] || 'Try again');
    txt(W / 2, top + 88, why, 15, t.btnText);
    txt(W / 2, top + 114, 'Level ' + C0.id, 13, t.btnText, 0.5, false);
    button(W / 2, top + 176, 290, 58, 'Try again', campRetry, { primary: true, size: 22 });
    let y = top + 246;
    if (hintOk) { adBtn(W / 2, y, 290, 50, 'Watch ad - get hint', adHint, 17); y += 62; }
    button(W / 2, y, 290, 50, 'Levels', leaveToLevels, { dark: true, size: 18 });
    if (G.adMsg) txt(W / 2, top + 146, G.adMsg, 12.5, '#ff5a5f', 0.5, false);
  }

  // ---------- Game feel: camera shake (off with reduced motion) ----------
  function shake(ms, k) { if (REDUCED || !scene) return; try { scene.cameras.main.shake(ms, k); } catch (e) { /* ignore */ } }
  const FRUIT_COL = { apple: '#e53935', orange: '#ff9a1f', cherry: '#d81b60', grapes: '#8e5bd6', strawberry: '#ff4d6d' };   // fruit pop colours
  function drawConfetti() {                                           // falling confetti on the "level cleared" screen (cheap: no state)
    const n = LITE ? 10 : 22;
    for (let i = 0; i < n; i++) {
      const t0 = (anim / 1000 * (0.16 + 0.2 * hh(i, 9, 2)) + hh(i, 9, 3)) % 1, x = BX + hh(i, 9, 1) * BW + Math.sin(anim / 400 + i) * 10, y = -10 + t0 * (H + 20);
      g.fillStyle(C(CONFETTI[i % CONFETTI.length]), 0.9); g.fillRect(x, y, 6, 9);
    }
  }
  function drawCampWon() {
    const t = th(), C0 = G.camp, last = C0.id >= LEVEL_COUNT, top = drawCampOverlayFrame(last ? 430 : 512);
    txt(W / 2, top + 44, last ? 'You did it!' : 'Level cleared!', 32, t.accent);
    txt(W / 2, top + 80, last ? 'All ' + LEVEL_COUNT + ' levels complete' : 'Level ' + C0.id + '  -  ' + WORLDS[C0.L.w].name, 15, t.btnText);
    for (let s = 0; s < 3; s++) {
      const k = Math.min(1, Math.max(0, (C0.endT - PORTAL_MS - s * 220 + 700) / 260)), got = s < C0.stars;
      const x = W / 2 + (s - 1) * 62, y = top + 140 - (s === 1 ? 8 : 0), sc = got ? 1 + 0.35 * Math.sin(Math.min(1, k) * Math.PI) : 1;
      starShape(x, y + 3, 30 * sc, '#000000', 0.25);
      starShape(x, y, 30 * sc, got ? '#fde047' : '#00000044');
      if (got) starShape(x - 2, y - 3, 14 * sc, '#fffbe0', 0.6);
    }
    txt(W / 2, top + 208, C0.moves + ' moves', 20, t.btnText);
    const gap3 = C0.moves - C0.L.s3, gap2 = C0.moves - C0.L.s2;
    txt(W / 2, top + 236, C0.stars < 3 ? (C0.stars < 2 ? (gap2 <= 3 ? 'So close! ' + gap2 + ' move' + (gap2 > 1 ? 's' : '') + ' more than 2 stars' : '2 stars: ' + C0.L.s2 + ' moves   3 stars: ' + C0.L.s3) : (gap3 <= 4 ? 'So close! Just ' + gap3 + ' move' + (gap3 > 1 ? 's' : '') + ' too many for 3 stars' : '3 stars: ' + C0.L.s3 + ' moves or less')) : 'Perfect run!', 13, t.btnText, 0.5, false);
    drawCoin(W / 2 - 52, top + 262, 9);
    if (!C0.wonT) C0.wonT = anim;
    txt(W / 2 - 38, top + 262, '+' + Math.round(G.coins * Math.min(1, (anim - C0.wonT) / 700)) + ' coins', 15, '#fbbf24', 0);   // counts up
    if (!last) {
      const nx = LV[C0.id], mech = [skHas(nx, 'I') && 'ice', skHas(nx, 'B') && 'bombs', skHas(nx, 'D') && 'door', skHas(nx, 'G') && 'gate', skHas(nx, 'P') && 'portal'].filter(Boolean).slice(0, 2).join(' + ');
      txt(W / 2, top + 296, 'Next: level ' + (C0.id + 1) + '  -  ' + fruitCount(C0.id + 1) + ' fruit' + (mech ? '  -  ' + mech : ''), 13, t.btnText, 0.5, false);
    }
    drawConfetti();
    let y = top + (last ? 316 : 338);
    if (!last) { button(W / 2, y, 290, 58, 'Next level', campNextLevel, { primary: true, size: 22 }); y += 68; }
    button(W / 2, y, 290, 46, 'Replay', campRetry, { dark: true, size: 17 });
    button(W / 2, y + 56, 290, 46, 'Levels', leaveToLevels, { dark: true, size: 17 });
  }
