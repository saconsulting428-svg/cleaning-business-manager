  // ---------- Campaign logic ----------
  let lvPage = 0;                                    // world shown on the level select screen
  let lvMsg = null;                                  // {s, until}: short message on the level select screen
  const campUnlocked = () => (UNLOCK_ALL ? LEVEL_COUNT : DATA.camp.unlocked);
  const campNext = () => Math.min(LEVEL_COUNT, Math.max(1, DATA.camp.cur));
  function useWorld(w) { CT = WORLDS[w].pal; applyTheme(); }
  function openLevels() {
    lvPage = Math.floor((campNext() - 1) / 20);
    useWorld(lvPage);
    setState('levels');
  }
  const menuPal = () => (DATA.menuMode === 'endless' ? null : WORLDS[Math.floor((campNext() - 1) / 20)].pal);
  function setMenuMode(levels) {
    DATA.menuMode = levels ? 'levels' : 'endless';
    if (levels && DATA.tab < 3) DATA.tab = 3;                 // Modes / Themes / Pattern only exist in Endless
    writeData(); CT = menuPal(); applyTheme();
  }
  function playSelected() { if (DATA.menuMode === 'endless') newGame(); else playCampaign(); }
  function playCampaign() { startLevel(campNext()); }
  // Fruit goes to new random places on the route every time a level starts (always cells the solution passes, so it stays solvable).
  function randomFruit(L) {
    const q = lvLayer(L.Q), cells = [], want = L.F.length;
    for (let i = 0; i < COLS * ROWS; i++) if (q[i]) cells.push(i);
    for (const gap of [3, 2, 1]) {
      const pool = cells.slice(), out = [];
      while (pool.length && out.length < want) {
        const c = pool.splice(rnd(pool.length), 1)[0], x = c % COLS, y = (c / COLS) | 0;
        if (out.every((o) => Math.max(Math.abs(o[0] - x), Math.abs(o[1] - y)) >= gap)) out.push([x, y]);
      }
      if (out.length === want) return Object.assign({}, L, { F: out });
    }
    return L;
  }


  // ---------- Campaign daily challenge (separate from the Endless one) ----------
  let cdCheck = 0;
  function cdEnsure() {
    const now = Date.now();
    if (DATA.cdaily && now - cdCheck < 4000) return DATA.cdaily;
    cdCheck = now;
    const today = dateKey(new Date());
    if (!DATA.cdaily || DATA.cdaily.date !== today) { DATA.cdaily = makeCD(today); writeData(); }
    return DATA.cdaily;
  }
  function cdAdd(id, n) {
    const d = cdEnsure();
    if (d.id !== id || d.claimed) return;
    d.progress = Math.min(d.target, d.progress + n);
    if (d.progress >= d.target) {
      d.claimed = true; addCoins(d.reward); if (G) G.dailyCoins = (G.dailyCoins | 0) + d.reward;
      showBanner('CAMPAIGN DAILY DONE!  +' + d.reward + ' coins', 'Challenge complete', '#facc15', 2200);
      sfx.win(); buzz(40);
    }
    writeData();
  }

  // ---------- adaptive difficulty (internal only, never shown) ----------
  const SK_KEY = 'snakeFruitRush.skill.v1';
  const SK_FRESH = () => ({ v: 1, lvl: 0, h: [], mech: {}, cur: null });
  const skClamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function skLoad() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(SK_KEY)); } catch (e) { d = null; }
    const s = SK_FRESH();
    if (!d || d.v !== 1 || !Array.isArray(d.h)) return s;
    s.lvl = skClamp(d.lvl | 0, -2, 2);
    s.h = d.h.filter((r) => r && isFinite(r.sc)).slice(-10).map((r) => ({ id: r.id | 0, sc: skClamp(+r.sc, 0, 1), at: skClamp(r.at | 0, 1, 99) }));
    if (d.mech && typeof d.mech === 'object') ['trap', 'door', 'gate'].forEach((k) => { s.mech[k] = skClamp(d.mech[k] | 0, 0, 9); });
    return s;
  }
  let SK = skLoad();
  function skSave() { try { localStorage.setItem(SK_KEY, JSON.stringify({ v: 1, lvl: SK.lvl, h: SK.h, mech: SK.mech })); } catch (e) { /* storage blocked: adaptation lasts for this session only */ } }
  const skProfile = () => (SK.lvl <= -1 ? 'beginner' : SK.lvl >= 1 ? 'skilled' : 'intermediate');
  const skHas = (L, k) => !!L[k] && (typeof L[k] === 'string' ? /[^0]/.test(L[k]) : L[k].length > 0);
  function skRecord(id, fails, moves, par, ms, delay) {            // called once when a level is completed
    const first = fails === 0 ? 1 : fails === 1 ? 0.5 : fails <= 3 ? 0.2 : 0;
    const eff = skClamp(par / Math.max(1, moves), 0, 1), spd = skClamp(par * delay / Math.max(1, ms), 0, 1);
    SK.h.push({ id: id, sc: 0.5 * first + 0.3 * eff + 0.2 * spd, at: fails + 1 });
    if (SK.h.length > 10) SK.h.shift();
    Object.keys(SK.mech).forEach((k) => { SK.mech[k] = Math.max(0, SK.mech[k] - 1); });
    if (SK.h.length >= 4) {                                          // ~4 levels of data first, then one small step per level
      const w = SK.h.slice(-6), avg = w.reduce((a, r) => a + r.sc, 0) / w.length;
      const target = avg < 0.35 ? -2 : avg < 0.5 ? -1 : avg > 0.84 ? 2 : avg > 0.74 ? 1 : 0;
      SK.lvl += Math.sign(target - SK.lvl);
    }
    skSave();
  }
  function skFail(id, reason) {
    if (!SK.cur || SK.cur.id !== id) SK.cur = { id: id, fails: 0, ms: 0 };
    SK.cur.fails++;
    if (SK.mech[reason] !== undefined) SK.mech[reason] = Math.min(9, SK.mech[reason] + 1);
    skSave();
  }
  // Settings for the NEXT level only (called from startLevel, never while a level runs).
  function skAdapt(L, id) {
    let e = SK.lvl;
    const last2 = SK.h.slice(-2);
    if (last2.length === 2 && last2.every((r) => r.at >= 3)) e -= 1;                       // easier breather after two hard levels (based on finished levels only: retrying never eases a level)
    e = skClamp(e, -2, 2);
    return { e: e, bias: e < 0 ? -1 : e > 0 ? 1 : 0, s2: -e * 1.5 | 0, s3: -e, d: e <= -2 ? 1.08 : e === -1 ? 1.04 : 1, ready: e <= -2 ? 500 : 0, hint: false };
  }
  function adaptiveFruit(L, bias) {                                  // layouts are drawn from the validated Q mask, so every one stays solvable by the stored route
    if (!bias) return randomFruit(L);
    let best = null, bs = 0;
    for (let i = 0; i < 6; i++) {
      const cand = randomFruit(L), sc = cand.F.reduce((a, f) => a + Math.abs(f[0] - L.s[0]) + Math.abs(f[1] - L.s[1]), 0);
      if (!best || (bias < 0 ? sc < bs : sc > bs)) { best = cand; bs = sc; }
    }
    return best;
  }
  // Fruit places are made once per level (first entry), saved, and reused on every retry / restart.
  const FRUIT_KEY = 'snakeFruitRush.fruit.v3';
  // Fruit in tight spots: of several valid random layouts (all on the stored route, never touching), keep the one whose fruit sit in the narrowest
  // gaps. More candidates on later levels, so the pull towards tight corridors grows with the level number.
  function tightness(base, F) {
    const wl = lvLayer(base.W), bl = base.B ? lvLayer(base.B) : null;
    let s = 0;
    F.forEach((f) => {
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const x = f[0] + dx, y = f[1] + dy;
        if (x < 0 || y < 0 || x >= COLS || y >= ROWS || wl[y * COLS + x] || (bl && bl[y * COLS + x])) s++;
      }
    });
    return s;
  }
  function fruitCount(id) {                                          // fruit per level: more and more as the campaign goes on
    if (id <= 5) return 3;
    if (id <= 10) return 4;
    if (id <= 20) return id <= 15 ? 4 : 5;
    if (id <= 30) return 5;
    if (id <= 40) return id <= 35 ? 5 : 6;
    if (id <= 50) return 6;
    if (id <= 60) return id <= 55 ? 6 : 7;
    if (id <= 70) return 7;
    if (id <= 80) return id <= 75 ? 7 : 8;
    return 8;
  }
  const D4V = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  function routeWins(base, F) {                                      // the stored solution must still win with this layout (same replay as the validator)
    const L2 = Object.assign({}, base, { F: F }), rt = E.makeRuntime(engineLevel(L2)), st = E.newState(rt), route = base.R;
    let status = 'ok';
    for (let k = 1; k < route.length; k++) {
      const cur = route[k], head = st.body[0], d = D4V.findIndex((v) => v[0] === (cur % COLS) - (head % COLS) && v[1] === ((cur / COLS) | 0) - ((head / COLS) | 0));
      if (d < 0) return false;
      let q, g = 0;
      do { q = E.step(rt, st, D4V[d]); g++; } while (q.status === 'wait' && g < 5);
      status = q.status;
      if (status === 'fail') return false;
      if ((base.P || []).some((pp) => (pp[1] * COLS + pp[0]) === cur)) k++;
    }
    return status === 'win';
  }
  function fruitPool(base) {                                         // route cells a fruit may sit on (never devices, bombs, portals, start lane, exit)
    const bl = base.B ? lvLayer(base.B) : null, bad = new Set(), R = base.R;
    [base.K, base.D, base.G].forEach((a) => (a || []).forEach((c) => bad.add(c[1] * COLS + c[0])));
    (base.S || []).forEach((s) => bad.add(s[1] * COLS + s[0]));
    (base.P || []).forEach((p) => { bad.add(p[1] * COLS + p[0]); bad.add(p[3] * COLS + p[2]); });
    const out = [];
    for (let k = 4; k < R.length - 2; k++) if (!bad.has(R[k]) && !(bl && bl[R[k]])) out.push(R[k]);
    return out;
  }
  function tightFruit(base, id, rf) {
    rf = rf || rnd;
    const want = fruitCount(id), pool = fruitPool(base), tries = 4 + Math.ceil(id * 0.4), R = base.R;
    for (let n = want; n >= 1; n--) {
      let best = null, bs = -1, found = 0;
      for (let i = 0; i < tries * 6 && found < tries; i++) {
        const p = pool.slice(), F = [];
        while (p.length && F.length < n) {
          const c = p.splice(rf(p.length), 1)[0], x = c % COLS, y = (c / COLS) | 0;
          if (F.every((o) => Math.max(Math.abs(o[0] - x), Math.abs(o[1] - y)) >= 2)) F.push([x, y]);
        }
        if (F.length < n || !routeWins(base, F)) continue;
        found++;
        const last = Math.max.apply(null, F.map((f) => R.indexOf(f[1] * COLS + f[0])));
        const sc = tightness(base, F) + Math.min(4, (R.length - 1 - last) / 8);   // tight gaps + a longer trip to the exit afterwards
        if (sc > bs) { bs = sc; best = F; }
      }
      if (best) return best;
    }
    return base.F;
  }
  function fruitSaved(id, base) {
    let m = {};
    try { m = JSON.parse(localStorage.getItem(FRUIT_KEY)) || {}; } catch (e) { m = {}; }
    const f = m[id], q = lvLayer(base.Q);
    const pool = new Set(fruitPool(base));
    const ok = Array.isArray(f) && f.length >= 1 && f.length <= fruitCount(id) && f.every((c) => Array.isArray(c) && c[0] >= 0 && c[0] < COLS && c[1] >= 0 && c[1] < ROWS && pool.has(c[1] * COLS + c[0]))
      && f.every((a, i) => f.every((b, j) => i === j || Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])) >= 2)) && routeWins(base, f);
    if (ok) return f;
    const F2 = tightFruit(base, id);
    m[id] = F2;
    try { localStorage.setItem(FRUIT_KEY, JSON.stringify(m)); } catch (e) { /* blocked: layout lasts for this session only */ }
    return F2;
  }


  // ---------- Coin store: free coins from ads (the daily ladder) and coin packs (coming soon) ----------
  function drawCoinStore(top) {
    const t = th(), ct = coinText(DATA.coins) + ' coins';
    drawCoin(W / 2 - ct.length * 4.4 - 12, top + 100, 10); txt(W / 2 - ct.length * 4.4 + 2, top + 100, ct, 16, t.accent, 0);
    txt(W / 2, top + 134, 'Free coins - watch ads', 14, t.btnText);
    const n = adCoinsToday(), pw = 78, x0 = W / 2 - (AD_COIN_LADDER.length * pw + (AD_COIN_LADDER.length - 1) * 4) / 2;
    AD_COIN_LADDER.forEach((v, i) => {
      const x = x0 + i * (pw + 4), done = i < n, next = i === n;
      rrect(x, top + 150, pw, 46, 12, next ? t.accent : t.panel, done ? 0.5 : 1);
      drawCoin(x + 16, top + 173, 8); txt(x + 28, top + 173, String(v), 13, next ? '#1b1b1b' : t.btnText, 0);
      if (done) { line(x + pw - 18, top + 160, x + pw - 14, top + 164, '#4ade80', 2.4); line(x + pw - 14, top + 164, x + pw - 7, top + 156, '#4ade80', 2.4); }
    });
    if (adCoinsLeft() && adAvailable()) { sheetAdBtn = true; adBtn(W / 2, top + 224, 320, 42, 'Watch ad   +' + adCoinNext() + ' coins   (' + adCoinsLeft() + ' left today)', claimAdCoins, 15); }
    else txt(W / 2, top + 224, adCoinsLeft() ? 'No ad ready right now - try again in a moment' : 'All free coins taken today - come back tomorrow!', 13, t.text, 0.5, false);
    txt(W / 2, top + 268, 'Coin packs', 14, t.btnText);
    [['Small', 500], ['Medium', 1500], ['Big', 5000]].forEach((pk, i) => {
      const cx = W / 2 + (i - 1) * 144, cy = top + 352;
      rrect(cx - 68, cy - 66, 136, 132, 16, t.panel);
      if (!uiPic(['pack_small', 'pack_medium', 'pack_big'][i], cx, cy - 31, 58, 50)) drawCoin(cx, cy - 28, 18);
      txt(cx, cy + 9, String(pk[1]), 20, t.accent);
      txt(cx, cy + 30, pk[0] + ' pack', 12, t.btnText, 0.5, false);
      rrect(cx - 50, cy + 42, 100, 20, 10, '#00000055'); txt(cx, cy + 52, 'Coming soon', 11, t.btnText);
      buttons.push({ x: cx - 68, y: cy - 66, w: 136, h: 132, fn: () => sheetToast('Coin packs are coming soon!', true) });
    });
  }

  // ---------- Progress store (goals, daily puzzle, expert clears): its own key, safe on missing / broken data ----------
  const PROG_KEY = 'snakeFruitRush.prog.v1';
  const PROG = (() => {
    let a = null;
    try { a = JSON.parse(localStorage.getItem(PROG_KEY)); } catch (e) { a = null; }
    a = a && typeof a === 'object' ? a : {};
    const o = { claimed: {}, nohelp: num(a.nohelp, 0, 1e5, 0), ice: num(a.ice, 0, 1e5, 0), expert: {}, dp: { date: '', done: false, moves: 0, stars: 0, streak: 0, last: '', best: 0, total: 0 } };
    if (a.claimed && typeof a.claimed === 'object') Object.keys(a.claimed).forEach((k) => { if (a.claimed[k] === 1 && /^[a-z0-9]{1,12}$/.test(k)) o.claimed[k] = 1; });
    if (a.expert && typeof a.expert === 'object') Object.keys(a.expert).forEach((k) => { if (/^\d{1,3}$/.test(k) && +k >= 1 && +k <= 100) o.expert[k] = 1; });
    const d = a.dp && typeof a.dp === 'object' ? a.dp : {};
    if (typeof d.date === 'string' && DATE_RE.test(d.date)) { o.dp.date = d.date; o.dp.done = d.done === true; o.dp.moves = num(d.moves, 0, 9999, 0); o.dp.stars = num(d.stars, 0, 3, 0); }
    o.dp.streak = num(d.streak, 0, 9999, 0); o.dp.best = num(d.best, 0, 9999, 0); o.dp.total = num(d.total, 0, 99999, 0);
    o.dp.last = typeof d.last === 'string' && DATE_RE.test(d.last) ? d.last : '';
    return o;
  })();
  function progSave() { try { localStorage.setItem(PROG_KEY, JSON.stringify(PROG)); } catch (e) { /* blocked: lasts for this session */ } }

  // ---------- Goals ----------
  const clearedN = () => Object.keys(DATA.camp.stars).length;
  const threeN = () => Object.keys(DATA.camp.stars).filter((k) => (DATA.camp.stars[k] | 0) >= 3).length;
  const dpStreakNow = () => (PROG.dp.last === dateKey(new Date()) || PROG.dp.last === addDays(dateKey(new Date()), -1) ? PROG.dp.streak : 0);
  const GOALS = [
    { id: 'ten', name: 'Getting good', desc: 'Clear 10 levels', t: 10, v: clearedN, pay: 30 },
    { id: 'three10', name: 'Perfectionist', desc: '3 stars on 10 levels', t: 10, v: threeN, pay: 80 },
    { id: 'nohelp5', name: 'On my own', desc: 'Clear 5 levels with no help', t: 5, v: () => PROG.nohelp, pay: 60 },
    { id: 'ice10', name: 'Ice breaker', desc: 'Clear 10 levels with ice', t: 10, v: () => PROG.ice, pay: 50 },
    { id: 'daily3', name: 'Daily habit', desc: 'Daily puzzle 3 days in a row', t: 3, v: dpStreakNow, pay: 100 },
    { id: 'daily7', name: 'Week warrior', desc: 'Daily puzzle 7 days in a row', t: 7, v: dpStreakNow, pay: 150, skin: 'neonracer' },
    { id: 'expert5', name: 'Expert', desc: 'Clear 5 levels in Expert mode', t: 5, v: () => Object.keys(PROG.expert).length, pay: 150, skin: 'obsidian' },
    { id: 'three25', name: 'Champion', desc: '3 stars on 25 levels', t: 25, v: threeN, pay: 200, skin: 'champion' }
  ];
  function goalsCheck() {
    let any = false;
    GOALS.forEach((gl) => {
      if (PROG.claimed[gl.id] || gl.v() < gl.t) return;
      PROG.claimed[gl.id] = 1; any = true;
      addCoins(gl.pay);
      if (gl.skin && DATA.skins.indexOf(gl.skin) < 0 && SKIN_BY_ID[gl.skin]) DATA.skins.push(gl.skin);
      showBanner('GOAL: ' + gl.name, '+' + gl.pay + ' coins' + (gl.skin ? '  +  new skin!' : ''), '#fbbf24', 2200);
      sfx.gold();
    });
    if (any) { progSave(); writeData(); }
  }
  function drawGoals(top) {
    const t = th();
    txt(W / 2, top + 100, 'Goals', 22, t.accent);
    GOALS.forEach((gl, i) => {
      const y = top + 140 + i * 38, done = !!PROG.claimed[gl.id], v = Math.min(gl.t, gl.v());
      rrect(BX + 10, y - 17, BW - 20, 34, 12, t.panel, 0.9);
      txt(BX + 24, y - 7, gl.name, 13, done ? t.accent : t.btnText, 0);
      txt(BX + 24, y + 9, gl.desc, 10.5, t.text, 0, false);
      if (done) {
        if (!uiPic('tick', BX + BW - 34, y, 26, 24)) { dot(BX + BW - 34, y, 11, '#22c55e'); line(BX + BW - 40, y, BX + BW - 36, y + 4, '#ffffff', 2.6); line(BX + BW - 36, y + 4, BX + BW - 29, y - 4, '#ffffff', 2.6); }
        txt(BX + BW - 64, y, 'Done', 11, t.accent, 1);
      } else {
        const bx = BX + 206, bw = 84;                                      // progress bar with the count written inside
        rrect(bx, y - 8, bw, 16, 8, t.bg);
        if (v > 0) rrect(bx, y - 8, Math.max(16, bw * v / gl.t), 16, 8, t.accent);
        txt(bx + bw / 2, y + 0.5, v + '/' + gl.t, 10, v > 0 ? '#1b1b1b' : t.text, 0.5, false);
        const rx = BX + 308;                                                // reward: coin + amount, "SKIN" as its own small tag
        if (!uiPic('icon_coins', rx, y, 18, 16)) drawCoin(rx, y, 7);
        txt(rx + 13, y + 0.5, '+' + gl.pay, 12, t.accent, 0);
        if (gl.skin) { rrect(rx + 52, y - 9, 44, 18, 9, t.accent); txt(rx + 74, y + 0.5, '+ SKIN', 9.5, '#1b1b1b', 0.5, false); }
      }
    });
  }

  // ---------- Daily puzzle: the same level and fruit for everybody on a given day ----------
  const dpToday = () => dateKey(new Date());
  const dpDone = () => PROG.dp.date === dpToday() && PROG.dp.done;
  function strHash(s) { let h = 7; for (let i = 0; i < s.length; i++) h = (Math.imul(h, 33) + s.charCodeAt(i)) >>> 0; h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; return (h ^ (h >>> 13)) >>> 0; }
  function seededRng(seed) {
    let a = seed >>> 0;
    return (n) => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return Math.floor((((t ^ (t >>> 14)) >>> 0) / 4294967296) * n); };
  }
  const dpLevelFor = (date) => 15 + (strHash(date) % 56);            // levels 15 - 70
  function startDailyPuzzle() {
    const date = dpToday(), id = dpLevelFor(date), base = LV[id - 1];
    startLevel(id, false, { daily: true, date: date, F: tightFruit(base, id, seededRng(strHash(date + '#' + id))) });
  }
  function dpComplete(C0) {
    const date = C0.opts.date || dpToday(), first = !(PROG.dp.date === date && PROG.dp.done);
    C0.dpReward = 0;
    if (first) {
      PROG.dp.streak = PROG.dp.last === addDays(date, -1) ? PROG.dp.streak + 1 : 1;
      PROG.dp.last = date; PROG.dp.total++;
      C0.dpReward = 60 + Math.min(PROG.dp.streak, 7) * 10;
      addCoins(C0.dpReward);
    }
    const better = first || C0.moves < PROG.dp.moves;
    if (better) { PROG.dp.date = date; PROG.dp.done = true; PROG.dp.moves = C0.moves; PROG.dp.stars = C0.stars; }
    if (!PROG.dp.best || C0.moves < PROG.dp.best) PROG.dp.best = C0.moves;
    C0.coins = C0.dpReward;
    progSave(); writeData(); goalsCheck();
  }
  function shareDaily() {
    const C0 = G.camp, date = C0.opts.date || dpToday();
    const text = 'Snake Fruit Rush - Daily ' + date + '\n' + '*'.repeat(C0.stars) + ' ' + C0.moves + ' moves' + (C0.helped ? '' : ' (no help)') + '\nStreak: ' + PROG.dp.streak + ' days\nCan you beat me?' + (window.SHARE_URL ? ' ' + window.SHARE_URL : '');
    const done = (msg) => { if (G) G.shareMsg = msg; };
    try {
      if (typeof window.shareText === 'function') { window.shareText(text); return; }
      if (navigator.share) { navigator.share({ text: text }).catch(() => {}); return; }
      if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(() => done('Result copied - paste it to a friend!'), () => done('Sharing is not available here.')); return; }
    } catch (e) { /* fall through */ }
    done('Sharing is not available here.');
  }
  function drawDailyWon() {
    const t = th(), C0 = G.camp, top = drawCampOverlayFrame(450);
    txt(W / 2, top + 44, 'Daily puzzle done!', 28, t.accent);
    txt(W / 2, top + 78, 'Level ' + C0.id + '  -  ' + dpToday(), 14, t.btnText, 0.5, false);
    for (let s = 0; s < 3; s++) { const x = W / 2 + (s - 1) * 56, y = top + 126; if (!uiPic(s < C0.stars ? 'star_full' : 'star_empty', x, y, 60, 56, 0xffffff, 0.55)) { starShape(x, y + 3, 26, '#000000', 0.25); starShape(x, y, 26, s < C0.stars ? '#fde047' : '#00000044'); } }
    txt(W / 2, top + 182, C0.moves + ' moves' + (C0.helped ? '' : '  -  no help'), 18, t.btnText);
    txt(W / 2, top + 212, 'Streak: ' + PROG.dp.streak + (PROG.dp.streak === 1 ? ' day' : ' days') + '   Best: ' + PROG.dp.best + ' moves', 13, t.btnText, 0.5, false);
    if (C0.dpReward) { drawCoin(W / 2 - 52, top + 244, 9); txt(W / 2 - 38, top + 244, '+' + C0.dpReward + ' coins', 16, '#fbbf24', 0); }
    else txt(W / 2, top + 244, 'Come back tomorrow for a new puzzle!', 13, t.btnText, 0.5, false);
    adBtn(W / 2, top + 296, 290, 50, 'Share result', shareDaily, 18);
    if (G.shareMsg) txt(W / 2, top + 330, G.shareMsg, 12, '#4ade80', 0.5, false);
    button(W / 2, top + 372, 290, 50, 'Home', goHome, { primary: true, size: 19 });
    drawConfetti();
  }
  // ---------- Soft background for the menu and the level map: a light centre, dark corners and a few slowly rising sparkles ----------
  let bgTex = false;
  function ensureBgTex() {
    if (bgTex || !scene) return;
    bgTex = true;
    const cv = document.createElement('canvas'); cv.width = 96; cv.height = 160;
    const cx = cv.getContext('2d'), gr = cx.createRadialGradient(48, 62, 6, 48, 82, 118);
    gr.addColorStop(0, 'rgba(255,255,255,0.13)'); gr.addColorStop(0.45, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.5)');
    cx.fillStyle = gr; cx.fillRect(0, 0, 96, 160);
    scene.textures.addCanvas('bg_vig', cv);
    const dv = document.createElement('canvas'); dv.width = 32; dv.height = 32;
    const dx = dv.getContext('2d'), dg = dx.createRadialGradient(16, 16, 0, 16, 16, 16);
    dg.addColorStop(0, 'rgba(255,255,255,0.9)'); dg.addColorStop(1, 'rgba(255,255,255,0)'); dx.fillStyle = dg; dx.fillRect(0, 0, 32, 32);
    scene.textures.addCanvas('bg_dot', dv);
  }
  function drawAmbientBg() {
    ensureBgTex();
    blitImg('bgv' + L.depth, 'bg_vig', W / 2, H / 2, W, H, 1, -2);
    if (LITE || REDUCED) return;
    for (let i = 0; i < 9; i++) {
      const sp = 0.012 + 0.012 * hh(i, 5, 1), y = H + 20 - ((anim * sp + hh(i, 5, 2) * H) % (H + 40)), x = 30 + hh(i, 5, 3) * (W - 60) + Math.sin(anim / 1800 + i) * 14;
      const a = 0.10 + 0.16 * Math.abs(Math.sin(anim / 900 + i * 2)), z = 14 + 22 * hh(i, 5, 4);
      blitImg('spk' + L.depth, 'bg_dot', x, y, z, z, a, -1.5);
    }
  }
  // ---------- Star gates: a new world opens only with enough stars (only while that world is still closed) ----------
  const GATES = { 21: 30, 41: 70, 61: 115, 81: 160 };
  const starsTotal = () => Object.keys(DATA.camp.stars).reduce((a, k) => a + (DATA.camp.stars[k] | 0), 0);
  const gateNeed = (id) => (GATES[id] && DATA.camp.unlocked <= id ? GATES[id] : 0);
  const gated = (id) => gateNeed(id) > starsTotal();
  const gateMsg = (id) => 'World ' + (Math.floor((id - 1) / 20) + 1) + ' needs ' + GATES[id] + ' stars - you have ' + starsTotal();
  function startLevel(id, showRoute, opts) {
    id = Math.min(LEVEL_COUNT, Math.max(1, id | 0));
    const daily = !!(opts && opts.daily);
    if (!daily && (id > campUnlocked() || gated(id))) return;
    const base = LV[id - 1], ad = daily ? { e: 0, bias: 0, s2: 0, s3: 0, d: 1, ready: 0, hint: false } : skAdapt(base, id);
    if (!daily) { if (!SK.cur || SK.cur.id !== id) SK.cur = { id: id, fails: 0, ms: 0 }; SK.cur.ms = 0; }
    let L = Object.assign({}, base, { F: daily ? opts.F : fruitSaved(id, base) });
    if (ad.e) L = Object.assign({}, L, { s3: Math.max(base.par, L.s3 + ad.s3), s2: Math.max(base.par + 1, L.s2 + ad.s2), d: Math.round(L.d * ad.d) });
    if (ad.hint) showRoute = true;
    const el = engineLevel(L), rt = E.makeRuntime(el), st = E.newState(rt);
    G = {
      camp: { id: id, L: L, ad: ad.e, rt: rt, st: st, ready: READY_MS + ad.ready, over: null, won: false, endT: 0, moves: 0, route: showRoute ? L.R : null, routeIdx: null, exitOpen: false, slowT: 0, shield: false, hold: false, coinMul: 1, stars: 0, coins: 0, hint: L.h || '', flash: [], iceList: [], fr: [] },
      snake: st.body.map((c) => [c % COLS, (c / COLS) | 0]), dir: st.dir, queue: [], score: 0, eaten: 0, fx: {}, combo: 0, combo_t: 0, bonus: null, power: null, gold: null,
      food: null, bombs: [], coins: 0, dailyCoins: 0, playMs: 0, adMsg: '', shareMsg: '', mode: 'classic', speed: DATA.speed
    };
    const C0 = G.camp;
    C0.opts = opts || null; C0.daily = daily; C0.expert = !!(opts && opts.expert);
    C0.hist = []; C0.paid = new Set();                       // undo history; fruit coins are paid once per fruit
    for (let i = 0; i < COLS * ROWS; i++) if (rt.ice[i]) C0.iceList.push(i);
    if (C0.route) { C0.routeIdx = new Map(); C0.route.forEach((cell, i) => C0.routeIdx.set(cell, i)); }
    rt.fruits.forEach((f, i) => C0.fr.push({ cell: f.cell, kind: FRUITS[(i + id) % FRUITS.length] }));
    popups = []; fxs = []; banner = null; prevSnake = null; acc = 0;
    adToken++; gift = null; sheetOpen = false; sheetT = 0;
    if (!daily) { DATA.camp.cur = id; writeData(); }
    useWorld(L.w);
    setState('play');
    if (!navigator.webdriver || window.__forceTips) { if (helpItems(L).some((i) => !tipsSeen.has(i.id))) { C0.help = true; togglePause(); } }   // first time a thing appears: the card opens by itself
  }
  const PORTAL_MS = 950;                            // portal-entry animation before the result screen
  const campSliding = () => !!G.camp && E.resolveDir(G.camp.rt, G.camp.st, null).forced;
  const cellOf = (i) => cellXY(i % COLS, (i / COLS) | 0);
  const campPlaying = () => G && G.camp && !G.camp.over && !G.camp.won;

  function campStep() {
    const C0 = G.camp, rt = C0.rt, st = C0.st;
    if (C0.over || C0.won) return;
    if (C0.hold) { if (!G.queue.length) return; C0.hold = false; C0.undone = false; }          // after a shield save the snake waits for a turn
    let input = null;
    if (!campSliding() && G.queue.length) input = G.queue.shift();          // on ice the player cannot steer: the turn waits in the queue
    const oldDir = st.dir, snap = { st: E.cloneState(st), eaten: G.eaten };
    const res = E.step(rt, st, input);
    if (res.status === 'fail' && C0.shield && res.reason !== 'stuck') {
      st.done = false; st.dir = oldDir; G.dir = oldDir; C0.shield = false; C0.hold = true;
      const hp = headXY(); ring(hp.x, hp.y, '#38bdf8'); burst(hp.x, hp.y, '#7dd3fc', 12);
      showBanner('SHIELD SAVED YOU!', 'now turn away', '#38bdf8', 1400);
      sfx.power(); buzz(40);
      return;
    }
    G.dir = st.dir;
    if (res.status === 'wait') return;                                      // slid safely to a stop: wait for a turn
    C0.hist.push(snap); if (C0.hist.length > 300) C0.hist.shift();
    if (res.status !== 'fail') {
      G.snake = st.body.map((c) => [c % COLS, (c / COLS) | 0]);
      C0.moves = st.moves;
      if (C0.expert && st.moves > C0.L.s3) { st.done = true; C0.over = 'moves'; C0.endT = 0; sfx.over(); buzz(50); shake(140, 0.006); return; }   // Expert: 3-star moves is the limit
      if (C0.slowT > 0) C0.slowT--;
      trailPuff();
      if (rt.ice[st.body[0]]) { const p = headXY(); if (fxs.length < MAX_FX - 6) fxs.push({ k: 0, x: p.x, y: p.y, vx: (Math.random() - 0.5) * 0.03, vy: (Math.random() - 0.5) * 0.03, r: 2.4, color: '#ffffff', life: 380, max: 380 }); }
    }
    res.events.forEach((e) => {
      const p = cellOf(e.cell);
      if (e.t === 'fruit') {
        G.eaten++;
        if (!C0.paid.has(e.cell)) { C0.paid.add(e.cell); addCoins(COIN_FRUIT * C0.coinMul); cdAdd('cfruit', 1); }
        const fk = (C0.fr.find((f) => f.cell === e.cell) || {}).kind, fc = FRUIT_COL[fk] || th().accent;
        burst(p.x, p.y, fc, 10); burst(p.x, p.y, '#ffffff', 4); ring(p.x, p.y, fc);
        popup('+1', th().accent, 30);
        sfx.eat(Math.min(G.eaten - 1, 9)); buzz(12);                       // the pop gets higher with every fruit of the level
      } else if (e.t === 'key') {
        ring(p.x, p.y, '#facc15'); burst(p.x, p.y, '#facc15', 8); popup('KEY!', '#facc15', 30);
        sfx.key(); buzz(20);
      } else if (e.t === 'door') {
        const q = cellOf(e.cell); ring(q.x, q.y, '#facc15'); burst(q.x, q.y, '#fde68a', 10); C0.flash.push({ cell: e.cell, t: 600 });
        sfx.door();
      } else if (e.t === 'switch') {
        const q = cellOf(e.cell); ring(q.x, q.y, GATE_COLS[e.gate % GATE_COLS.length]);
        const gc = rt.gates[e.gate].cells[0], gp = cellOf(gc);
        ring(gp.x, gp.y, GATE_COLS[e.gate % GATE_COLS.length]); C0.flash.push({ cell: gc, t: 600 });
        popup(e.open ? 'GATE OPEN' : 'GATE CLOSED', GATE_COLS[e.gate % GATE_COLS.length], 30);
        sfx.sw(e.open); buzz(20);
      } else if (e.t === 'portal') {
        const a = cellOf(e.from), b = cellOf(e.to);
        ring(a.x, a.y, '#c084fc'); ring(b.x, b.y, '#38bdf8'); burst(b.x, b.y, '#a5f3fc', 8);
        sfx.portal(); buzz(15);
      }
    });
    if (!C0.exitOpen && E.exitReady(rt, st)) {
      C0.exitOpen = true; C0.exitT = anim;
      const ep = cellOf(rt.exit);
      ring(ep.x, ep.y, '#4ade80'); burst(ep.x, ep.y, '#bbf7d0', 12);
      showBanner('EXIT OPEN!', 'reach the glowing exit', '#4ade80', 1100);
      sfx.yum();
    }
    if (res.status === 'win') {
      C0.won = true; C0.endT = 0;
      if (!C0.daily) adsMeta.levels++;                   // counts toward the next interstitial (shown only after the result screen)
      const moves = st.moves, L = C0.L;
      C0.stars = moves <= L.s3 ? 3 : moves <= L.s2 ? 2 : 1;
      C0.fails = SK.cur && SK.cur.id === C0.id ? SK.cur.fails : 0;
      if (C0.daily) {
        dpComplete(C0);
      } else {
        const prev = DATA.camp.stars[C0.id] | 0;
        if (C0.stars > prev) DATA.camp.stars[C0.id] = C0.stars;
        cdAdd('clevel', 1); cdAdd('cstars', C0.stars); if (C0.stars === 3) cdAdd('c3', 1); if (SK.cur && SK.cur.id === C0.id && SK.cur.fails === 0) cdAdd('cfirst', 1);
        if (SK.cur && SK.cur.id === C0.id) skRecord(C0.id, SK.cur.fails, moves, LV[C0.id - 1].par, SK.cur.ms, C0.L.d);
        SK.cur = null;
        C0.coins = (5 + 5 * C0.stars) * C0.coinMul * (C0.expert ? 3 : 1);
        addCoins(C0.coins);
        if (C0.id < LEVEL_COUNT) { DATA.camp.cur = C0.id + 1; if (DATA.camp.unlocked < C0.id + 1) DATA.camp.unlocked = C0.id + 1; }
        else DATA.camp.cur = C0.id;
        if (!C0.helped) PROG.nohelp++;
        if (skHas(C0.L, 'I')) PROG.ice++;
        if (C0.expert) PROG.expert[C0.id] = 1;
        progSave();
        writeData();
        goalsCheck();
      }
      const hp = headXY(); burst(hp.x, hp.y, 'rand', 16); ring(hp.x, hp.y, '#fde047');
      sfx.win(); buzz(40);
    } else if (res.status === 'fail') {
      C0.over = res.reason; C0.endT = 0;
      skFail(C0.id, res.reason);
      if (res.reason === 'trap') { G.boom = [res.cell % COLS, (res.cell / COLS) | 0]; sfx.boom(); buzz(80); shake(300, 0.014); }
      else {
        sfx.over(); buzz(50); shake(140, 0.006);
        const hp = headXY(); ring(hp.x, hp.y, '#f87171'); burst(hp.x, hp.y, '#f87171', 10);
        if (res.reason === 'door') { const nx = st.body[0] % COLS + st.dir[0], ny = ((st.body[0] / COLS) | 0) + st.dir[1], ni = ny * COLS + nx; C0.over = rt.gateAt[ni] >= 0 ? 'gate' : 'door'; }
      }
    }
  }
  function campTick(delta) {                         // called every frame while state is 'play' and G.camp exists
    const C0 = G.camp;
    C0.flash.forEach((f) => { f.t -= delta; });
    C0.flash = C0.flash.filter((f) => f.t > 0);
    if (C0.over || C0.won) {
      C0.endT += delta;
      if (C0.won && C0.endT > PORTAL_MS) setState('won');
      else if (C0.over && C0.endT > (C0.over === 'trap' ? 900 : 650)) setState('over');
      return;
    }
    if (C0.ready > 0) { C0.ready -= delta; acc = 0; if (C0.ready <= 0) { C0.ready = 0; sfx.click(); } return; }
    if (SK.cur) SK.cur.ms += delta;
    acc += stepClock(delta);
    let delay = stepDelay(), guardSteps = 0;
    while (state === 'play' && !C0.over && !C0.won && acc >= delay && guardSteps++ < 2) {
      acc -= delay;
      prevSnake = G.snake.map((s) => [s[0], s[1]]);
      campStep();
    }
    if (acc > delay) acc = delay;
    G.playMs += delta;
  }
  function usePower(k) {
    if (state !== 'play' || !campPlaying() || G.camp.ready > 0) return;
    if (G.camp.expert) { popup('No power-ups in Expert', '#ff5a5f', 34); sfx.err(); return; }
    const C0 = G.camp, rt = C0.rt, st = C0.st, p = PW[k];
    C0.helped = true;
    if ((k === 'shield' && C0.shield) || (k === 'coin2' && C0.coinMul > 1) || (k === 'slow' && C0.slowT > 0)) return;
    const hx = st.body[0] % COLS, hy = (st.body[0] / COLS) | 0, near = [];
    if (k === 'sweep') {
      for (let i = 0; i < COLS * ROWS; i++) if (rt.bomb[i] && Math.max(Math.abs((i % COLS) - hx), Math.abs(((i / COLS) | 0) - hy)) <= 7) near.push(i);
      if (!near.length) { popup('No bombs near', '#ff5a5f', 34); sfx.err(); return; }
    }
    if (!DATA.pw[k]) {
      if (DATA.coins < p.cost) { popup('Need ' + p.cost + ' coins', '#ff5a5f', 34); sfx.err(); return; }
      DATA.coins -= p.cost; DATA.pw[k]++;
    }
    DATA.pw[k]--; writeData();
    const hp = headXY();
    if (k === 'slow') C0.slowT = 28;
    else if (k === 'shield') C0.shield = true;
    else if (k === 'coin2') C0.coinMul = 2;
    else near.forEach((i) => { rt.bomb[i] = 0; const q = cellOf(i); burst(q.x, q.y, '#fbbf24', 8); ring(q.x, q.y, '#fbbf24'); });
    ring(hp.x, hp.y, '#38bdf8'); popup(p.name + '!', th().accent, 34);
    sfx.power(); buzz(25);
  }
  let shopMsg = null;
  function buyPower(k) {
    const p = PW[k];
    if (DATA.coins < p.cost) { shopMsg = { s: 'Need ' + (p.cost - DATA.coins) + ' more coins for ' + p.name + '!', until: anim + 2400, bad: true }; sfx.err(); buzz(40); return; }
    DATA.coins -= p.cost; DATA.pw[k] = Math.min(99, DATA.pw[k] + 1); writeData(); sfx.coin();
    shopMsg = { s: p.name + ' added!', until: anim + 1500 };
  }
  function drawShop(top) {
    const t = th();
    if (shopMsg && anim < shopMsg.until) {
      txt(W / 2, top + 96, shopMsg.s, 15, shopMsg.bad ? '#f87171' : '#4ade80');
    } else {
      const ct = coinText(DATA.coins) + ' coins', ox = ct.length * 4.4;
      drawCoin(W / 2 - ox - 12, top + 96, 10);
      txt(W / 2 - ox + 2, top + 96, ct, 15, t.accent, 0);
    }
    PW_KEYS.forEach((k, i) => {
      const p = PW[k], w = 212, h = 112, cx = W / 2 + (i % 2 ? 110 : -110), cy = top + 176 + Math.floor(i / 2) * 124, can = DATA.coins >= p.cost;
      rrect(cx - w / 2, cy - h / 2 + 3, w, h, 15, shade(t.panel, -0.3));
      rrect(cx - w / 2, cy - h / 2, w, h, 15, t.panel);
      if (!UIOK.pw_slow) dot(cx - w / 2 + 30, cy - 22, 22, t.board1);
      drawPwIcon(k, cx - w / 2 + 30, cy - 21, false, UIOK.pw_slow ? 46 : 40);
      txt(cx - w / 2 + 62, cy - 30, p.name, 16, t.btnText, 0);
      wrapText(p.desc, 18).forEach((l, j) => txt(cx - w / 2 + 62, cy - 8 + j * 15, l, 11, t.btnText, 0, false));
      txt(cx - w / 2 + 12, cy + 38, 'You have ' + (DATA.pw[k] | 0), 12, t.btnText, 0, false);
      rrect(cx + w / 2 - 74, cy + 24, 64, 28, 14, can ? t.accent : shade(t.panel, -0.25));
      drawCoin(cx + w / 2 - 60, cy + 38, 6.5);
      txt(cx + w / 2 - 50, cy + 38, String(p.cost), 13, can ? '#1b1b1b' : t.btnText, 0);
      buttons.push({ x: cx - w / 2, y: cy - h / 2, w: w, h: h, fn: () => buyPower(k) });
    });
    if (!(DATA.coins < 90 && adCoinsButton(top + 404))) {
      txt(W / 2, top + 396, 'Tap a power-up to buy it. Use them inside levels.', 12.5, t.text, 0.5, false);
      txt(W / 2, top + 420, 'In a level you can also tap its button to buy and use it.', 12.5, t.text, 0.5, false);
    }
  }
  function toggleVibe() { DATA.vibe = !DATA.vibe; writeData(); if (DATA.vibe) buzz(30); }
  function toggleTap() { DATA.tapSteer = !DATA.tapSteer; writeData(); tone(660, 0.08, 'triangle', 0.2); }
  function campRetry() { startLevel(G.camp.id, !!G.camp.route, G.camp.opts); }          // a hint bought with an ad stays for the rest of that level
  function campNextLevel() {
    if (G.camp.id < LEVEL_COUNT && gated(G.camp.id + 1)) { const m = gateMsg(G.camp.id + 1); leaveToLevels(); lvMsg = { s: m, until: anim + 5000 }; return; }
    const next = G.camp.id < LEVEL_COUNT ? () => startLevel(G.camp.id + 1) : openLevels;
    maybeInter('level', next);                       // an ad only if one is due AND ready; otherwise straight on
  }
  function leaveToLevels() { saveGame(); openLevels(); }
  function goHome() { setState('menu'); }

  // ---------- Level select + campaign drawing ----------
  function starShape(x, y, r, color, alpha) {
    const pts = [];
    for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * 0.45 : r, ang = -Math.PI / 2 + i * Math.PI / 5; pts.push({ x: x + Math.cos(ang) * rr, y: y + Math.sin(ang) * rr }); }
    g.fillStyle(C(color), alpha === undefined ? 1 : alpha);
    g.fillPoints(pts, true);
  }
  function lockIcon(x, y, s, color) {
    if (uiPic('lock', x, y, 24 * s, 24 * s, 0xffffff, 0.55)) return;
    g.lineStyle(3 * s, C(color), 1);
    g.beginPath(); g.arc(x, y - 4 * s, 6 * s, Math.PI, 0); g.strokePath();
    rrect(x - 9 * s, y - 4 * s, 18 * s, 14 * s, 4 * s, color);
    dot(x, y + 2 * s, 2 * s, '#00000066');
  }
  function worldStars(w) { let n = 0; for (let i = w * 20 + 1; i <= w * 20 + 20; i++) n += DATA.camp.stars[i] | 0; return n; }
  function worldDone(w) { let n = 0; for (let i = w * 20 + 1; i <= w * 20 + 20; i++) if (DATA.camp.stars[i]) n++; return n; }
  function drawLevels() {
    drawAmbientBg();
    const t = th(), cp = DATA.camp, w = lvPage, W0 = WORLDS[Math.min(w, WORLDS.length - 1)], un = campUnlocked(), soon = w >= WORLDS.length;
    // header
    if (slice3('btn_pill', BX + 48, 42, 102, 46, C(t.panel))) uiPic('glyph_back', BX + 22, 42, 22, 20, 0xffffff, 0.55);
    else { rrect(BX, 22, 96, 40, 20, t.panel); line(BX + 22, 42, BX + 32, 35, t.btnText, 3.4); line(BX + 22, 42, BX + 32, 49, t.btnText, 3.4); }
    txt(BX + 40, 42, 'Home', 17, t.btnText, 0);
    buttons.push({ x: BX - 6, y: 16, w: 108, h: 52, fn: goHome });
    txt(W / 2 + 20, 42, 'Levels', 32, t.accent);
    const cw = 52 + coinText(DATA.coins).length * 11;
    if (!slice3('hud_pill', W - BX - cw / 2, 42, cw + 8, 46, C(t.panel))) rrect(W - BX - cw, 22, cw, 40, 20, t.panel, 0.8);
    drawCoin(W - BX - cw + 22, 42, 11);
    txt(W - BX - cw + 40, 42, coinText(DATA.coins), 16, t.accent, 0);
    // world card
    const cy = 96, ch = 118;
    const cardPic = slice9('panel_card', W / 2, cy + ch / 2 + 2, BW + 10, ch + 12, C(t.panel), 30, 0.4);
    if (!cardPic) { rrect(BX, cy + 5, BW, ch, 24, shade(t.panel, -0.35)); rrect(BX, cy, BW, ch, 24, t.panel); }
    else useLayer(2);                                                 // what sits on the picture card is drawn one layer higher
    // world art strip
    const wl = W0.wall;
    for (let i = 0; i < 9; i++) { const bx = BX + 78 + i * 36, by = cy + ch - 22; rrect(bx, by + 1, 24, 18, 5, wl.edge); rrect(bx, by, 24, 14, 5, wl.base); rrect(bx + 2, by + 1.5, 20, 4, 2, wl.top, 0.9); }
    txt(W / 2, cy + 22, 'WORLD ' + (w + 1) + ' of 6', 12, t.text, 0.5, false);
    txt(W / 2, cy + 52, soon ? 'Coming Soon' : W0.name, soon ? 30 : 36, t.accent);
    const gw = !soon && gated(w * 20 + 1);
    txt(W / 2, cy + 82, soon ? 'A brand new world is on the way' : gw ? 'Needs ' + GATES[w * 20 + 1] + ' stars  (you have ' + starsTotal() + ')' : W0.sub, 13, gw ? '#fbbf24' : t.text, 0.5, false);
    // arrows
    [[-1, BX + 28], [1, BX + BW - 28]].forEach((a) => {
      const can = w + a[0] >= 0 && w + a[0] <= WORLDS.length;
      dot(a[1], cy + 52, 20, can ? shade(t.panel, 0.25) : shade(t.panel, -0.2), can ? 1 : 0.6);
      if (can) {
        line(a[1] - a[0] * 4, cy + 42, a[1] + a[0] * 5, cy + 52, t.btnText, 3.6);
        line(a[1] + a[0] * 5, cy + 52, a[1] - a[0] * 4, cy + 62, t.btnText, 3.6);
        buttons.push({ x: a[1] - 26, y: cy + 26, w: 52, h: 52, fn: () => { lvPage = w + a[0]; useWorld(Math.min(lvPage, WORLDS.length - 1)); sfx.click(); } });
      }
    });
    if (cardPic) useLayer(0);
    // dots
    for (let i = 0; i <= WORLDS.length; i++) {
      const x = W / 2 + (i - 2.5) * 22;
      dot(x, cy + ch + 20, i === w ? 6 : 4, i === w ? t.accent : t.panel);
      buttons.push({ x: x - 11, y: cy + ch + 8, w: 22, h: 24, fn: () => { lvPage = i; useWorld(Math.min(i, WORLDS.length - 1)); } });
    }
    if (soon) {                                      // World 6: locked, not playable
      const a = anim / 1000, cx = W / 2, my = 440;
      rrect(BX, 262, BW, 420, 28, shade(t.panel, -0.35)); rrect(BX, 256, BW, 420, 28, t.panel);
      for (let i = 0; i < 18; i++) { const sx = BX + 20 + hh(i, 6, 1) * (BW - 40), sy = 272 + hh(i, 6, 2) * 390; dot(sx, sy, 1.2 + 1.3 * hh(i, 6, 3), '#ffffff', 0.25 + 0.55 * Math.abs(Math.sin(a * 1.4 + i * 2))); }
      dot(cx, my, 78 + 4 * Math.sin(a * 2), t.accent, 0.12); dot(cx, my, 58, t.accent, 0.2);
      g.lineStyle(3, C(t.accent), 0.8); g.beginPath(); g.arc(cx, my, 46, a, a + 4.2); g.strokePath();
      g.lineStyle(2, C('#ffffff'), 0.6); g.beginPath(); g.arc(cx, my, 36, -a * 1.4, -a * 1.4 + 3); g.strokePath();
      lockIcon(cx, my - 2, 1.9, t.btnText);
      txt(cx, 548, 'WORLD 6', 34, t.accent);
      txt(cx, 586, 'COMING SOON', 22, t.btnText);
      txt(cx, 622, 'New puzzles, new mechanics.', 14, t.text, 0.5, false);
      button(W / 2, 722, 320, 54, 'Locked', null, { disabled: true, size: 20 });
      return;
    }
    // level grid
    const tile = 76, gap = 13, x0 = (W - (5 * tile + 4 * gap)) / 2, y0 = 262;
    for (let k = 0; k < 20; k++) {
      const id = w * 20 + k + 1, col = k % 5, row = (k / 5) | 0, x = x0 + col * (tile + gap), y = y0 + row * (tile + 12);
      const open = id <= un && !gated(id), st = cp.stars[id] | 0, cur = id === cp.cur && open;
      const face = !open ? shade(t.panel, -0.3) : st ? t.accent : shade(t.panel, 0.18);
      const tpic = UIOK.tile_open && UIOK.tile_locked;
      if (tpic) {
        if (cur) uiPic('tile_open', x + tile / 2, y + tile / 2 + 2, tile + 22, tile + 16, 0xffffff, 0.40, 0.55 + 0.45 * Math.sin(anim / 160));
        uiPic(open ? 'tile_open' : 'tile_locked', x + tile / 2, y + tile / 2 + 2, tile + 10, tile + 4, C(face), 0.45);
      } else {
      rrect(x, y + 5, tile, tile, 18, shade(face, -0.38), open ? 1 : 0.7);
      rrect(x, y, tile, tile, 18, face, open ? 1 : 0.85);
      }
      if (cur && !tpic) { g.lineStyle(3.5, C('#ffffff'), 0.55 + 0.45 * Math.sin(anim / 160)); g.strokeRoundedRect(x - 3, y - 3, tile + 6, tile + 6, 21); }
      if (open) {
        txt(x + tile / 2, y + (st ? 29 : 38), String(id), 28, st ? '#1b1b1b' : t.btnText);
        if (st) for (let s = 0; s < 3; s++) { if (!uiPic(s < st ? 'star_full' : 'star_empty', x + tile / 2 + (s - 1) * 19, y + 59, 19, 18, 0xffffff, 0.55)) starShape(x + tile / 2 + (s - 1) * 19, y + 59, 8.5, s < st ? '#b45309' : '#00000033'); }
        if (PROG.expert[id]) { if (!uiPic('star_full', x + tile - 12, y + 13, 16, 15, 0x9b6cff, 0.55)) starShape(x + tile - 12, y + 13, 7, '#7c3aed'); }                      // purple star = cleared in Expert mode
      } else {
        lockIcon(x + tile / 2, y + tile / 2 - 2, 1.15, shade(t.text, -0.35));
      }
      buttons.push({ x: x, y: y, w: tile, h: tile + 6, fn: () => { if (open) startLevel(id); else { lvMsg = { s: gated(id) ? gateMsg(id) : 'Clear level ' + (un) + ' to unlock this one', until: anim + 3200 }; sfx.err(); } } });
    }
    // footer
    const first = w * 20 + 1, canPlay = first <= un && !gated(first);
    let target = Math.min(un, w * 20 + 20);
    for (let i = first; i <= w * 20 + 20 && i <= un; i++) { if (!cp.stars[i]) { target = i; break; } }
    txt(W / 2, 636, worldDone(w) + ' / 20 cleared   ' + worldStars(w) + ' / 60 stars', 14, t.text, 0.5, false);
    if (canPlay) button(W / 2, 688, 320, 62, 'Play level ' + target, () => startLevel(target), { primary: true, size: 24 });
    else button(W / 2, 688, 320, 62, 'Locked', null, { disabled: true, size: 22 });
    if (lvMsg && anim < lvMsg.until) txt(W / 2, 744, lvMsg.s, 14, '#ff5a5f', 0.5, false);
    else txt(W / 2, 744, canPlay ? 'Clear a level to unlock the next one' : 'Finish world ' + w + ' to unlock', 13, t.text, 0.5, false);
  }

  // ----- tiles -----
  function floorDecor(gr, w, c, r, id) {
    const v = hh(c, r, id * 3 + w);
    if (v > 0.07) return;
    const x = BX + c * CELL + CELL / 2 + (hh(c, r, 5) - 0.5) * 8, y = BY + r * CELL + CELL / 2 + (hh(c, r, 6) - 0.5) * 8;
    const fill = (px, py, rad, col, al) => { gr.fillStyle(C(col), al); gr.fillCircle(px, py, rad); };
    if (w === 0) { [[0, -2.4], [2.4, 0], [0, 2.4], [-2.4, 0]].forEach((o) => fill(x + o[0], y + o[1], 1.7, '#ffffff', 0.85)); fill(x, y, 1.6, '#ffd23f', 1); }
    else if (w === 1) { fill(x, y, 2.2, '#c99a5b', 0.7); fill(x + 4, y + 3, 1.3, '#c99a5b', 0.7); }
    else if (w === 2) { gr.lineStyle(1.2, C('#ffffff'), 0.85); gr.lineBetween(x - 3.5, y, x + 3.5, y); gr.lineBetween(x, y - 3.5, x, y + 3.5); gr.lineBetween(x - 2.5, y - 2.5, x + 2.5, y + 2.5); gr.lineBetween(x + 2.5, y - 2.5, x - 2.5, y + 2.5); }
    else if (w === 3) { fill(x, y, 2.4, '#ff7a1a', 0.45); fill(x, y, 1.2, '#ffd166', 0.8); }
    else { gr.fillStyle(C('#a5b4fc'), 0.7); gr.fillCircle(x, y, 1.1); gr.fillStyle(C('#a5b4fc'), 0.25); gr.fillCircle(x, y, 2.6); }
  }
  function wallTile(gr, w, c, r, id) {
    const P = WORLDS[w].wall, x = BX + c * CELL, y = BY + r * CELL, v = hh(c, r, id), v2 = hh(c, r, id + 11);
    gr.fillStyle(0x000000, 0.28); gr.fillRoundedRect(x + 0.5, y + 3, CELL, CELL, 6);
    gr.fillStyle(C(P.edge), 1); gr.fillRoundedRect(x, y + 1.5, CELL, CELL - 1.5, 6);
    gr.fillStyle(C(P.base), 1); gr.fillRoundedRect(x, y, CELL, CELL - 3, 6);
    gr.fillStyle(C(P.top), 0.95); gr.fillRoundedRect(x + 2, y + 1.4, CELL - 4, 5.2, 3);
    if (w === 0) {                                              // hedge: leafy bumps
      gr.fillStyle(C(P.top), 0.9); gr.fillCircle(x + 5 + v * 3, y + 11, 3.2); gr.fillCircle(x + 15 - v2 * 3, y + 9, 3);
      gr.fillStyle(C('#1b5a28'), 0.5); gr.fillCircle(x + 11, y + 14.5, 2.6);
      if (v > 0.8) { gr.fillStyle(C('#ff6b81'), 1); gr.fillCircle(x + 7, y + 12, 1.7); }
    } else if (w === 1) {                                       // sandstone bricks
      gr.lineStyle(1.2, C(P.edge), 0.55); gr.lineBetween(x + 2, y + 10.5, x + CELL - 2, y + 10.5); gr.lineBetween(x + 6 + v * 8, y + 10.5, x + 6 + v * 8, y + CELL - 4);
      gr.fillStyle(C(P.edge), 0.35); gr.fillCircle(x + 5 + v2 * 10, y + 7.5, 1);
    } else if (w === 2) {                                       // ice crystal
      gr.lineStyle(1.6, C('#ffffff'), 0.85); gr.lineBetween(x + 5, y + 16, x + 11, y + 8); gr.lineBetween(x + 12, y + 17, x + 16, y + 11);
      gr.fillStyle(C('#ffffff'), 0.9); gr.fillCircle(x + 16.5, y + 5.5, 1.3);
    } else if (w === 3) {                                       // basalt with glowing cracks
      gr.lineStyle(1.8, C('#ff7a1a'), 0.95); gr.beginPath(); gr.moveTo(x + 4, y + 8 + v * 4); gr.lineTo(x + 10, y + 12); gr.lineTo(x + 14, y + 9); gr.lineTo(x + 19, y + 14 + v2 * 2); gr.strokePath();
      gr.lineStyle(0.8, C('#ffd166'), 0.9); gr.beginPath(); gr.moveTo(x + 10, y + 12); gr.lineTo(x + 14, y + 9); gr.strokePath();
    } else {                                                    // night stone with a glowing rune
      if (v > 0.45) { gr.lineStyle(1.5, C('#7cf5ff'), 0.9); gr.strokeCircle(x + CELL / 2, y + 10.5, 3.4); gr.fillStyle(C('#7cf5ff'), 0.9); gr.fillCircle(x + CELL / 2, y + 10.5, 1);
      } else { gr.fillStyle(C('#c4b5fd'), 0.8); gr.fillCircle(x + 5 + v2 * 12, y + 8, 1.2); }
    }
  }
  function iceTile(gr, c, r, id) {
    const x = BX + c * CELL, y = BY + r * CELL;
    gr.fillStyle(0x7dd3fc, 0.35); gr.fillRoundedRect(x + 0.5, y + 0.5, CELL - 1, CELL - 1, 4);
    gr.fillStyle(0xffffff, 0.6); gr.fillRoundedRect(x + 1.5, y + 1.5, CELL - 3, CELL - 3, 4);
    gr.lineStyle(1.2, 0x38bdf8, 0.9); gr.strokeRoundedRect(x + 1, y + 1, CELL - 2, CELL - 2, 4);
    gr.lineStyle(1.6, 0xffffff, 0.95); gr.lineBetween(x + 4, y + 8, x + 9, y + 3.5); gr.lineBetween(x + 7, y + 12, x + 15, y + 4.5);
  }
  // The board (floor, walls, ice) never changes during a level, so it is drawn once into a texture instead of being redrawn every frame.
  let boardRT = null;
  let boardKeyBaked = '';
  function bakeBoard() {
    try {
      if (!boardRT) { boardRT = scene.add.renderTexture(0, 0, W * ZOOM, H * ZOOM); boardRT.setOrigin(0, 0); boardRT.setScale(1 / ZOOM); boardRT.setDepth(boardG.depth); }
      boardRT.clear(); boardRT.setVisible(true);
      boardG.setScale(ZOOM); boardG.setVisible(true);
      boardRT.draw(boardG, 0, 0);
      boardG.setScale(1); boardG.setVisible(false);
      return true;
    } catch (e) { boardG.setScale(1); boardG.setVisible(true); if (boardRT) boardRT.setVisible(false); }
  }
  const END_FLOOR = { Midnight: 'night', Garden: 'garden', Ocean: 'ice', Sunset: 'volcano' };   // Candy keeps its flat light board
  function drawEndBoard(t) {                           // endless mode: the same glossy floor, baked once per theme
    const fl = END_FLOOR[t.name];
    if (!fl || state === 'menu' || state === 'levels' || !UIOK['floor_' + fl + '_a'] || !scene.textures.exists('ui_floor_' + fl + '_a')) return false;
    const openWalls = !!(G && modeOf().wall), key = 'end|' + fl + '|' + DATA.bg + '|' + openWalls + '|' + t.name;
    if (boardRT && boardKeyBaked === key) { boardRT.setVisible(true); boardG.setVisible(false); return true; }
    boardG.clear(); boardG.setScale(1);
    boardG.fillStyle(C(openWalls ? POWERS.wall.color : t.panel), 1);
    boardG.fillRoundedRect(BX - 7, BY - 7, BW + 14, BH + 14, 12);
    boardG.fillStyle(C(t.board1), 1);
    boardG.fillRect(BX, BY, BW, BH);
    drawPattern(boardG, DATA.bg, BX, BY, COLS, ROWS, CELL);
    if (!bakeBoard()) return false;
    boardG.clear();
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) bakePic('floor_' + fl + ((c + r) % 2 ? '_b' : '_a'), c, r);
    boardKeyBaked = key;
    return true;
  }
  function drawCampBoardFull() {
    const C0 = G.camp, rt = C0.rt, w = C0.L.w, t = th();
    const bkey = C0.id + '|' + w + '|' + JSON.stringify(t);
    if (boardRT && boardKeyBaked === bkey) { boardRT.setVisible(true); boardG.setVisible(false); return; }   // retry / restart: the baked board is reused
    boardG.clear();
    boardG.setVisible(true);
    boardG.fillStyle(C(shade(t.panel, -0.25)), 1);
    boardG.fillRoundedRect(BX - 8, BY - 5, BW + 16, BH + 17, 14);
    boardG.fillStyle(C(t.panel), 1);
    boardG.fillRoundedRect(BX - 8, BY - 8, BW + 16, BH + 16, 14);
    boardG.fillStyle(C(t.board1), 1);
    boardG.fillRect(BX, BY, BW, BH);
    drawPattern(boardG, WORLDS[w].pattern, BX, BY, COLS, ROWS, CELL);
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      const i = r * COLS + c;
      if (rt.wall[i]) continue;
      if (rt.ice[i]) iceTile(boardG, c, r, C0.id); else floorDecor(boardG, w, c, r, C0.id);
    }
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) if (rt.wall[r * COLS + c]) { if (bakePic('wall_' + WALL_KEYS[w], c, r)) wallGloss(c, r); else wallTile(boardG, w, c, r, C0.id); }
    if (bakeBoard()) { boardKeyBaked = bkey; boardG.clear(); } else boardKeyBaked = '';   // clear frees the ~46k recorded commands
  }

  // The board is recorded and baked in six small steps (one per frame) so a level start never freezes the game for one long frame.
  let boardJob = null;
  function drawCampBoard() {
    const C0 = G.camp, rt = C0.rt, w = C0.L.w, t = th();
    const bkey = C0.id + '|' + w + '|' + JSON.stringify(t);
    if (boardRT && boardKeyBaked === bkey) { boardRT.setVisible(true); boardG.setVisible(false); return; }   // retry / restart: the baked board is reused
    if (boardJob && boardJob.key === bkey && boardJob.C0 === C0) return;
    boardKeyBaked = '';
    try {
      if (!boardRT) { boardRT = scene.add.renderTexture(0, 0, W * ZOOM, H * ZOOM); boardRT.setOrigin(0, 0); boardRT.setScale(1 / ZOOM); boardRT.setDepth(boardG.depth); }
      boardRT.clear(); boardRT.setVisible(true);
    } catch (e) { boardJob = null; drawCampBoardFull(); return; }
    boardJob = { key: bkey, C0: C0, rt: rt, w: w, t: t, stage: 0 };
    boardStep();
  }
  const WALL_KEYS = ['garden', 'desert', 'ice', 'lava', 'night'], WALL_FLOOR = ['garden', 'desert', 'ice', 'volcano', 'night'];
  let bakeIm = null;
  const FLOOR_A = 0.42;                                // the floor pictures are laid softly over the board colour, so fruit and snake stay easy to see
  function bakePic(name, c, r) {                       // one picture of the sheet-8 tiles, stamped into the baked board
    if (!UIOK[name] || !scene.textures.exists('ui_' + name)) return false;
    try {
      if (!bakeIm) bakeIm = scene.make.image({ x: 0, y: 0, key: 'ui_' + name, add: false }).setOrigin(0, 0);
      bakeIm.setTexture('ui_' + name); bakeIm.setDisplaySize(CELL * ZOOM, CELL * ZOOM * 1.03); bakeIm.setAlpha(name.indexOf('floor_') === 0 ? FLOOR_A : 1);
      boardRT.draw(bakeIm, (BX + c * CELL) * ZOOM, (BY + r * CELL) * ZOOM);
      return true;
    } catch (e) { return false; }
  }
  let SNK_IMG = false;
  function snakeSegPic(pts, i, n, col) {                // one tinted picture per body piece (the cheap, fixed-colour skins)
    const ft = n - 1 - i, tint = C(col), p = pts[i];
    let name = 'snake_body', d = 22.5, ang = 0;
    if (ft === 0) { name = 'snake_tail_tip'; d = 15; const q = pts[i - 1]; ang = Math.atan2(p.y - q.y, p.x - q.x) * 57.2958 + 180; }
    else if (ft === 1) { name = 'snake_tail_2'; d = 16; }
    else if (ft === 2) { name = 'snake_tail_1'; d = 19; }
    const u = UIOK[name];
    blitImg('snkB', uiKey(name, tint), p.x, p.y, d * u.w / u.h, d, 1, 10.5, ang);
  }
  function snakeHeadPic(x, y, dx, dy, k, col) {
    const u = UIOK.snake_head;
    if (!u) return false;
    const h = 26 * k, w = h * u.w / u.h, sh = (w - h) / 2;   // the round part of the picture sits on the head position, the snout points ahead
    blitImg('snkH', uiKey('snake_head', C(col)), x + dx * sh, y + dy * sh, w, h, 1, 10.6, Math.atan2(dy, dx) * 57.2958);
    return true;
  }
  function floorGloss(c, r) {                          // every floor tile gets a tiny bevel + soft shine, so the floor looks glossy too
    const x = BX + c * CELL, y = BY + r * CELL;
    boardG.fillStyle(0xffffff, 0.16); boardG.fillRect(x, y, CELL, 1.6); boardG.fillRect(x, y, 1.6, CELL);
    boardG.fillStyle(0x000000, 0.12); boardG.fillRect(x, y + CELL - 1.6, CELL, 1.6); boardG.fillRect(x + CELL - 1.6, y, 1.6, CELL);
    boardG.fillStyle(0xffffff, 0.09); boardG.fillRoundedRect(x + 3, y + 3, CELL * 0.55, CELL * 0.3, 3);
  }
  function wallGloss(c, r) {                           // glassy shine on top of the block picture
    const x = BX + c * CELL, y = BY + r * CELL;
    boardG.fillStyle(0xffffff, 0.34); boardG.fillRoundedRect(x + 3, y + 2.2, CELL - 9, 3.6, 1.8);
    boardG.fillStyle(0xffffff, 0.75); boardG.fillCircle(x + 4.6, y + 4.2, 1.5);
    boardG.fillStyle(0x000000, 0.18); boardG.fillRoundedRect(x + 2, y + CELL - 5, CELL - 4, 3, 1.5);
  }
  function boardStep() {
    const J = boardJob;
    if (!J) return;
    if (!(G && G.camp && G.camp === J.C0 && state !== 'menu' && state !== 'levels')) { boardJob = null; return; }   // left the level: start over next time
    const rt = J.rt, w = J.w, t = J.t, C0 = J.C0, s = J.stage++;
    boardG.clear();
    if (s === 0) {
      boardG.fillStyle(C(shade(t.panel, -0.25)), 1);
      boardG.fillRoundedRect(BX - 8, BY - 5, BW + 16, BH + 17, 14);
      boardG.fillStyle(C(t.panel), 1);
      boardG.fillRoundedRect(BX - 8, BY - 8, BW + 16, BH + 16, 14);
      boardG.fillStyle(C(t.board1), 1);
      boardG.fillRect(BX, BY, BW, BH);
      drawPattern(boardG, WORLDS[w].pattern, BX, BY, COLS, ROWS, CELL);
      for (let k = 0; k < 6; k++) { boardG.lineStyle(2, 0x000000, 0.06 * (6 - k)); boardG.strokeRect(BX + 1 + k * 2, BY + 1 + k * 2, BW - 2 - k * 4, BH - 2 - k * 4); }   // soft inner shadow: the board looks deeper
    } else if (s <= 3) {
      for (let r = (s - 1) * 9; r < Math.min(ROWS, s * 9); r++) for (let c = 0; c < COLS; c++) {
        const i = r * COLS + c;
        if (rt.wall[i]) continue;
        if (rt.ice[i]) { if (!bakePic('ice_floor', c, r)) iceTile(boardG, c, r, C0.id); } else if (!bakePic('floor_' + WALL_FLOOR[w] + '_' + ((c + r) % 2 ? 'b' : 'a'), c, r)) { floorDecor(boardG, w, c, r, C0.id); floorGloss(c, r); }
      }
    } else {
      for (let r = (s - 4) * 13; r < Math.min(ROWS, (s - 3) * 13); r++) for (let c = 0; c < COLS; c++) if (rt.wall[r * COLS + c]) wallTile(boardG, w, c, r, C0.id);
    }
    try {
      boardG.setScale(ZOOM); boardG.setVisible(true);
      boardRT.draw(boardG, 0, 0);
    } catch (e) { boardG.setScale(1); boardJob = null; drawCampBoardFull(); return; }
    boardG.setScale(1); boardG.setVisible(false); boardG.clear();
    if (s >= 5) { boardKeyBaked = J.key; boardJob = null; }
  }

  // ----- dynamic items -----
  function drawKey(x, y, s) {
    const bob = Math.sin(anim / 220) * 1.5;
    y += bob;
    dot(x, y, 12 * s, '#facc15', 0.22);
    line(x - 1 * s, y + 1 * s, x + 8 * s, y + 1 * s, '#b45309', 3.6 * s);
    line(x + 4 * s, y + 1 * s, x + 4 * s, y + 5.5 * s, '#b45309', 2.6 * s); line(x + 7.5 * s, y + 1 * s, x + 7.5 * s, y + 4.5 * s, '#b45309', 2.6 * s);
    line(x - 1 * s, y + 1 * s, x + 8 * s, y + 1 * s, '#facc15', 2 * s);
    dot(x - 5 * s, y + 1 * s, 5.2 * s, '#b45309'); dot(x - 5 * s, y + 1 * s, 4 * s, '#fde047'); dot(x - 5 * s, y + 1 * s, 1.8 * s, '#b45309');
  }
  function drawDoor(x, y, open, flash) {
    if (open) {
      rrect(x - 10, y - 10, 20, 20, 5, '#facc15', 0.18 + (flash ? 0.25 : 0));
      g.lineStyle(1.6, C('#facc15'), 0.75); g.strokeRoundedRect(x - 10, y - 10, 20, 20, 5);
      return;
    }
    rrect(x - 11, y - 11 + 2, 22, 22, 5, '#5b3410');
    rrect(x - 11, y - 11, 22, 22, 5, '#a8672a');
    rrect(x - 9, y - 9, 18, 5, 3, '#d99a55', 0.8);
    line(x - 9, y + 2, x + 9, y + 2, '#6b3d12', 1.4);
    dot(x, y + 1, 4.6, '#fde047'); dot(x, y + 0.2, 1.6, '#7c4a10'); rrect(x - 0.9, y + 0.5, 1.8, 4, 0.6, '#7c4a10');
  }
  function drawGate(x, y, open, col, flash) {
    if (open) {
      rrect(x - 10, y - 10, 20, 3, 1.5, col, 0.55); rrect(x - 10, y + 7, 20, 3, 1.5, col, 0.55);
      g.fillStyle(C(col), 0.25); g.fillRoundedRect(x - 10, y - 10, 20, 20, 5);
      return;
    }
    rrect(x - 11, y - 11, 22, 22, 5, '#1f2937');
    for (let i = 0; i < 4; i++) { rrect(x - 8.5 + i * 5.6, y - 10, 3, 20, 1.5, col); rrect(x - 8.5 + i * 5.6, y - 10, 1.2, 20, 0.6, '#ffffff', 0.45); }
    rrect(x - 11, y - 3, 22, 3, 1.5, col, 0.9);
    if (flash) dot(x, y, 14, col, 0.3);
  }
  function drawSwitch(x, y, col, on) {
    if (itemPic('swP', 'switch', x, y + (on ? 1.5 : 0), on ? 15 : 18, 1, 0, C(shade(col, 0.25)))) return;
    dot(x, y, 12, col, on ? 0.12 : 0.28);
    rrect(x - 10, y - 8, 20, 17, 6, '#111827', 0.8);
    rrect(x - 10, y - 10 + (on ? 3 : 0), 20, 17 - (on ? 3 : 0), 6, '#475569');
    dot(x, y - 1 + (on ? 2 : 0), 6.2, on ? shade(col, -0.35) : col);
    if (!on) dot(x - 1.8, y - 3, 1.8, '#ffffff', 0.7);
  }
  function drawPortal(x, y, col, flip) {
    if (itemPic('portP' + (flip ? 1 : 0), flip ? 'portal_purple' : 'portal_blue', x, y, 21.5 + Math.sin(anim / 240) * 0.6)) return;
    const a = anim / 400 * (flip ? -1 : 1);
    dot(x, y, 15, col, 0.18 + 0.08 * Math.sin(anim / 240));
    dot(x, y, 11.5, '#0b1020');
    for (let i = 0; i < 3; i++) {
      g.lineStyle(2.4 - i * 0.4, C(i === 1 ? '#ffffff' : col), 0.95);
      g.beginPath(); g.arc(x, y, 10.5 - i * 3, a + i * 2.1, a + i * 2.1 + 3.2); g.strokePath();
    }
    dot(x, y, 2, '#ffffff', 0.9);
  }
  const PORTAL_COLS = [['#4ade80', '#bef264', '#14532d'], ['#fbbf24', '#fde68a', '#78350f'], ['#67e8f9', '#e0f2fe', '#0c4a6e'], ['#fb923c', '#fde047', '#7f1d1d'], ['#c084fc', '#f0abfc', '#3b0764']];
  function drawExitTile(x, y, open) {
    if (UIOK.exit_open && UIOK.exit_locked) {
      const C0 = G.camp, a = anim / 1000;
      let near = 0;
      if (open && !C0.won) { const hp = headXY(), d = Math.hypot(hp.x - x, hp.y - y) / CELL; near = d < 4 ? 1 - d / 4 : 0; }
      const ent = C0.won ? Math.min(1, C0.endT / PORTAL_MS) : 0;
      itemPic('exitP', open ? 'exit_open' : 'exit_locked', x, y, open ? 21 + Math.sin(a * 4) * 0.9 + near * 3 + ent * 14 : 21);
      return;
    }
    const C0 = G.camp, pc = PORTAL_COLS[C0.L.w] || PORTAL_COLS[0], a = anim / 1000;
    let near = 0;
    if (open && !C0.won) { const hp = headXY(), d = Math.hypot(hp.x - x, hp.y - y) / CELL; near = d < 4 ? 1 - d / 4 : 0; }
    const ent = C0.won ? Math.min(1, C0.endT / PORTAL_MS) : 0;
    if (!open) {                                                  // locked: dim, slow, broken ring
      dot(x, y, 14, '#0b0b12', 0.7);
      g.lineStyle(2, C(pc[0]), 0.4);
      for (let i = 0; i < 3; i++) { const s0 = a * 0.5 + i * 2.1; g.beginPath(); g.arc(x, y, 11.5, s0, s0 + 1.3); g.strokePath(); }
      dot(x, y, 3.2, pc[0], 0.35);
      return;
    }
    const k = 1 + 0.07 * Math.sin(a * 4) + near * 0.18 + ent * 0.5, sp = 1 + near * 1.2 + ent * 5, wake = C0.exitT === undefined ? 1 : Math.min(1, (anim - C0.exitT) / 450);
    const sc = (0.4 + 0.6 * wake) * k;                            // opens up smoothly right after the last fruit
    dot(x, y, 20 * sc, pc[0], 0.16 + 0.1 * near + 0.2 * ent);
    dot(x, y, 15.5 * sc, pc[2], 0.95);
    for (let i = 0; i < 3; i++) {                                 // swirling arcs
      g.lineStyle(2.6 - i * 0.5, C(i === 1 ? pc[1] : pc[0]), 0.95);
      const s0 = a * sp * (i % 2 ? -2.2 : 2.6) + i * 2.1, r = (13.5 - i * 3.6) * sc;
      g.beginPath(); g.arc(x, y, r, s0, s0 + 3.4 - i * 0.5); g.strokePath();
    }
    dot(x, y, 4.2 * sc, pc[1], 0.95); dot(x, y, 2 * sc, '#ffffff', 0.95);
    if (!LITE) for (let i = 0; i < 4; i++) {                      // sparks pulled into the centre
      const t2 = (a * (0.8 + near) + i / 4) % 1, an = i * 1.57 + a, r = 22 * (1 - t2);
      dot(x + Math.cos(an) * r, y + Math.sin(an) * r, 1.5, pc[1], 0.9 * t2);
    }
    if (ent > 0.55) dot(x, y, 26 * (ent - 0.55) * 2.2, '#ffffff', 0.55 * (1 - ent) + 0.15);   // soft flash as the snake goes in
  }
  function drawAmbient(w) {
    const a = anim / 1000;
    for (let i = 0; i < 14; i++) {
      const s = hh(i, w, 7), s2 = hh(i, w, 9);
      let x = BX + s * BW, y = BY + s2 * BH;
      if (w === 0) { x += Math.sin(a * 0.8 + i) * 10; y += Math.cos(a * 0.6 + i * 2) * 8; dot(x, y, 1.7, '#fffbd0', 0.45 + 0.3 * Math.sin(a * 2 + i)); }
      else if (w === 1) { x = BX + ((s * BW + a * 20 * (0.5 + s2)) % BW); y += Math.sin(a + i) * 4; dot(x, y, 1.4, '#fff1c9', 0.55); }
      else if (w === 2) { y = BY + ((s2 * BH + a * 24 * (0.6 + s)) % BH); x += Math.sin(a * 1.3 + i) * 8; dot(x, y, 1.9, '#ffffff', 0.85); }
      else if (w === 3) { y = BY + BH - ((s2 * BH + a * 28 * (0.5 + s)) % BH); x += Math.sin(a * 1.6 + i) * 6; dot(x, y, 2, '#ff9a2e', 0.5); dot(x, y, 1, '#fff2a0', 0.9); }
      else dot(x, y, 1.2 + 1.2 * s, '#c7d2fe', 0.2 + 0.55 * Math.abs(Math.sin(a * 1.5 + i * 3)));
    }
  }
  function wrapText(s, n) {
    const words = s.split(' '), out = [];
    let cur = '';
    words.forEach((w) => { if ((cur + ' ' + w).trim().length > n) { out.push(cur); cur = w; } else cur = (cur + ' ' + w).trim(); });
    if (cur) out.push(cur);
    return out;
  }
  function objective(C0) {
    const rt = C0.rt, n = rt.fruits.length;
    const parts = [];
    if (rt.keys.length) parts.push('take the key');
    if (rt.switches.length) parts.push('press the switch');
    parts.push(n === 1 ? 'eat the fruit' : 'eat all ' + n + ' fruit');
    parts.push('reach the exit');
    const s = parts.join(', then ');
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  function drawCampHud() {
    const C0 = G.camp, t = th(), rt = C0.rt, st = C0.st;
    txt(BX, 22, (C0.expert ? 'EXPERT  -  ' : C0.daily ? 'DAILY  -  ' : '') + WORLDS[C0.L.w].name.toUpperCase() + '  -  WORLD ' + (C0.L.w + 1), 11, C0.expert || C0.daily ? t.accent : t.text, 0, false);
    txt(BX, 50, 'Level ' + C0.id, 28, t.accent, 0);
    txt(BX + BW, 22, 'Moves', 12, t.text, 1, false);
    txt(BX + BW, 50, C0.expert ? C0.moves + '/' + C0.L.s3 : String(C0.moves), 28, C0.moves > C0.L.s2 || (C0.expert && C0.moves >= C0.L.s3 - 3) ? '#ff5a5f' : t.text, 1);
    // tracker: fruit, keys, exit
    const items = rt.fruits.length + rt.keys.length + 1, pit = Math.min(24, 240 / items), x0 = 284 - (items - 1) * pit / 2;   // sits between the level title and the moves counter
    let k = 0;
    rt.fruits.forEach((f, i) => {
      const x = x0 + k * pit, eaten = (st.fruitMask >> i) & 1;
      dot(x, 40, 10.5, t.panel); if (eaten) { dot(x, 40, 10.5, '#4ade80', 0.35); drawFruit(C0.fr[i].kind, x, 42, 0.62); } else { dot(x, 40, 7, t.bg, 0.55); }
      k++;
    });
    rt.keys.forEach((kk, i) => { const x = x0 + k * pit, has = (st.keyMask >> i) & 1; dot(x, 40, 10.5, t.panel); if (has) drawKey(x, 40, 0.62); else dot(x, 40, 5, '#facc15', 0.3); k++; });
    { const x = x0 + k * pit, open = C0.exitOpen; dot(x, 40, 10.5, open ? '#22c55e' : t.panel); g.fillStyle(C(open ? '#14532d' : t.text), open ? 1 : 0.5); g.fillTriangle(x - 3, 34, x - 3, 46, x + 5, 40); }
    const tip = C0.hint && G.playMs < 9000 && !C0.over && !C0.won;
    txt(W / 2, 80, tip ? C0.hint : objective(C0), 12.5, tip ? t.accent : t.text, 0.5, false);
  }
  function drawPwIcon(k, x, y, on, sz) {
    const pn = { slow: 'pw_slow', shield: 'pw_shield', sweep: 'pw_defuse', coin2: 'pw_double' }[k];
    if (pn && uiPic(pn, x, y, sz || 40, sz || 40, 0xffffff, 0.55)) return;
    if (k === 'slow') drawPower('slow', x, y, 0.95);
    else if (k === 'coin2') drawPower('double', x, y, 0.95);
    else if (k === 'shield') {
      g.fillStyle(C(on ? '#ffffff' : '#38bdf8'), 1);
      g.fillPoints([{ x: x - 10, y: y - 10 }, { x: x + 10, y: y - 10 }, { x: x + 10, y: y + 1 }, { x: x, y: y + 12 }, { x: x - 10, y: y + 1 }], true);
      g.fillStyle(C('#0c4a6e'), 0.55); g.fillPoints([{ x: x - 5, y: y - 6 }, { x: x + 5, y: y - 6 }, { x: x + 5, y: y }, { x: x, y: y + 6 }, { x: x - 5, y: y }], true);
    } else { drawBomb(x, y + 1, 0.8); line(x - 8, y + 8, x + 8, y - 8, '#4ade80', 3); }
  }
  function glyphTex(name, draw) {                    // small white pictures made once on a canvas (vibrate, tap)
    if (!scene.textures.exists('ui_' + name)) {
      const cv = document.createElement('canvas'); cv.width = cv.height = 96;
      const x = cv.getContext('2d'); x.lineCap = 'round'; x.lineJoin = 'round';
      const both = (fn) => { x.strokeStyle = '#0b1426'; x.lineWidth = 11; x.fillStyle = '#0b1426'; fn(true); x.strokeStyle = '#ffffff'; x.lineWidth = 5; x.fillStyle = '#ffffff'; fn(false); };
      draw(x, both);
      scene.textures.addCanvas('ui_' + name, cv); UIOK[name] = { w: 96, h: 96 };
    }
  }
  function toggleBtn(cx, cy, kind, on, label, fn) {
    const t = th();
    if (UIOK.btn_round) {
      glyphTex('g_vibe', (x, both) => {
        both(() => { x.beginPath(); x.roundRect(34, 20, 28, 56, 7); x.stroke(); });
        x.fillStyle = '#ffffff'; x.beginPath(); x.roundRect(34, 20, 28, 56, 7); x.fill();
        both(() => { x.beginPath(); x.arc(48, 48, 26, 2.5, 3.78); x.stroke(); x.beginPath(); x.arc(48, 48, 26, -0.64, 0.64); x.stroke(); });
      });
      glyphTex('g_tap', (x, both) => {
        both(() => { x.beginPath(); x.arc(48, 48, 10, 0, 6.3); x.fill(); x.beginPath(); x.arc(48, 48, 22, 0, 6.3); x.stroke(); });
        x.fillStyle = '#ffffff'; x.beginPath(); x.arc(48, 48, 10, 0, 6.3); x.fill();
      });
      uiPic('btn_round', cx, cy + 1, 56, 56, on ? C(t.accent) : C(shade(t.panel, -0.1)), 0.5);
      const gn = kind === 'sound' ? (DATA.sound ? 'glyph_sound_on' : 'glyph_sound_off') : kind === 'vibe' ? 'g_vibe' : 'g_tap';
      if (uiPic(gn, cx, cy + 1, 30, 30, 0xffffff, 0.6)) {
        txt(cx, cy + 42, label + (on ? ': On' : ': Off'), 11.5, t.btnText, 0.5, false);
        buttons.push({ x: cx - 40, y: cy - 30, w: 80, h: 80, fn: fn });
        return;
      }
    }
    dot(cx, cy + 3, 25, shade(t.panel, -0.3)); dot(cx, cy, 25, on ? t.accent : shade(t.panel, -0.15));
    g.fillStyle(0x000000, 0); drawIcon(kind, cx, cy, on ? '#1b1b1b' : t.btnText);
    txt(cx, cy + 40, label + (on ? '' : ' off'), 12, t.btnText, 0.5, false);
    buttons.push({ x: cx - 40, y: cy - 30, w: 80, h: 80, fn: fn });
  }
  function drawCampBottom() {
    const C0 = G.camp, t = th();
    PW_KEYS.forEach((k, i) => {
      const x = BX + i * 58, y = 688, n = DATA.pw[k] | 0, cx = x + 26;
      const on = (k === 'slow' && C0.slowT > 0) || (k === 'shield' && C0.shield) || (k === 'coin2' && C0.coinMul > 1);
      if (UIOK.btn_square) {
        slice9('btn_square', cx, y + 38, 54, 76, on ? 0x0ea5e9 : C(t.panel), 16, 0.45);
        uiPic({ slow: 'pw_slow', shield: 'pw_shield', sweep: 'pw_defuse', coin2: 'pw_double' }[k], cx, y + 19, 32, 32, 0xffffff, 0.55);
        useLayer(2);
        txt(cx, y + 43, PW[k].name, 9, t.btnText, 0.5, false);
        if (n > 0) txt(cx, y + 60, 'x' + n, 13, t.accent);
        else { uiPic('icon_coins', cx - 11, y + 60, 13, 12, 0xffffff, 12); txt(cx + 8, y + 60, String(PW[k].cost), 12, DATA.coins >= PW[k].cost ? t.accent : t.btnText); }
        useLayer(0);
      } else {
        blit('pw', stamp('st_pw_' + k + (on ? 1 : 0) + '_' + C0.L.w, () => { rrect(6, 9, 52, 52, 13, shade(t.panel, -0.3)); rrect(6, 6, 52, 52, 13, on ? '#0ea5e9' : t.panel); drawPwIcon(k, 32, 29, on); }, 64), x + 26, y + 26, 1, 5);
        useLayer(2);
        if (n > 0) { dot(x + 44, y + 8, 9.5, t.accent); txt(x + 44, y + 8, String(n), 12, '#1b1b1b'); }
        else { drawCoin(x + 14, y + 43, 5.5); txt(x + 22, y + 43, String(PW[k].cost), 11, DATA.coins >= PW[k].cost ? t.accent : t.btnText, 0); }
        useLayer(0);
      }
      buttons.push({ x: x - 3, y: y - 3, w: 58, h: 80, fn: () => usePower(k) });
    });
    txt(BX + 240, 712, '3 stars: ' + C0.L.s3 + ' moves', 11.5, t.text, 0, false);
    txt(BX + 240, 736, '2 stars: ' + C0.L.s2 + ' moves', 11.5, t.text, 0, false);
    const qx = BX + BW - 78, qy = 726;                          // "?" = what is in this level
    if (!uiPic('icon_help', qx, qy, 34, 34)) { dot(qx, qy, 15, t.panel); txt(qx, qy + 1, '?', 20, t.btnText); }
    buttons.push({ x: qx - 20, y: qy - 24, w: 40, h: 48, fn: openHelp });
    const px = BX + BW - 52, py = 700;
    if (!(uiPic('btn_square', px + 26, py + 26, 58, 56, C(t.panel), 0.45) && uiPic('glyph_pause', px + 26, py + 26, 26, 26, 0xffffff, 0.55))) {
      rrect(px, py, 52, 52, 12, t.panel);
      line(px + 19, py + 15, px + 19, py + 37, t.btnText, 6);
      line(px + 33, py + 15, px + 33, py + 37, t.btnText, 6);
    }
    buttons.push({ x: px - 6, y: py - 6, w: 64, h: 64, fn: togglePause });
  }

  // ---------- Pre-drawn stamps: fruit, bombs, keys, gates, doors and power-up buttons are drawn once into small textures and then only
  // positioned as images, instead of re-recording hundreds of Graphics commands every frame. Same pictures, far less work per frame. ----------
  const stampKeep = [], pools = {};
  // ---------- Picture assets (star coin, egg, wheel frame): embedded in the page, decoded once; until they are ready the drawn versions are used ----------
  const IMGOK = {}, UIOK = {};
  let imgStarted = false;
  function loadImages() {
    const src = window.SFR_IMG || {};
    Object.keys(src).forEach((k) => {
      const im = new Image();
      im.onload = () => { try { if (!scene.textures.exists('img_' + k)) scene.textures.addImage('img_' + k, im); IMGOK[k] = true; } catch (e) { /* keep the drawn version */ } };
      im.src = src[k];
    });
    const ui = window.SFR_UI || {};                                   // the glossy UI kit
    Object.keys(ui).forEach((k) => {
      const im = new Image();
      im.onload = () => { try { if (!scene.textures.exists('ui_' + k)) scene.textures.addImage('ui_' + k, im); UIOK[k] = { w: im.width, h: im.height }; } catch (e) { /* keep the drawn version */ } };
      im.src = ui[k];
    });
  }
  function blitImg(pool, key, x, y, w, h, alpha, depth, angle, tint, frame) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key, frame).setDepth(depth); im._k = key; im._f = frame; P.a.push(im); }
    P.n++;
    if (im._k !== key || im._f !== frame) { im.setTexture(key, frame); im._k = key; im._f = frame; }
    if (tint === undefined) { if (im._t !== undefined) { im.clearTint(); im._t = undefined; } } else if (im._t !== tint) { im.setTint(tint); im._t = tint; }
    if (im.depth !== depth) im.setDepth(depth);
    im.setPosition(x, y); im.setDisplaySize(w, h); im.setAlpha(alpha === undefined ? 1 : alpha); im.setAngle(angle || 0); im.setVisible(true);
  }
  // UI kit helpers: one picture, a 3-part stretchy button, a 9-part stretchy panel. A `tint` colours the grey-white pictures with the world
  // theme: the coloured copy is made once on a small canvas (works the same on WebGL and Canvas) and then reused.
  const UIFR = {};
  function uiKey(name, tint) {
    if (tint === undefined || tint === 0xffffff) return 'ui_' + name;
    const key = 'ui_' + name + '_' + tint.toString(16);
    if (!scene.textures.exists(key)) {
      const src = scene.textures.get('ui_' + name).getSourceImage(), cv = document.createElement('canvas');
      cv.width = src.width; cv.height = src.height;
      const cx = cv.getContext('2d');
      cx.drawImage(src, 0, 0);
      cx.globalCompositeOperation = 'multiply'; cx.fillStyle = '#' + ('000000' + tint.toString(16)).slice(-6); cx.fillRect(0, 0, cv.width, cv.height);
      cx.globalCompositeOperation = 'destination-in'; cx.drawImage(src, 0, 0);
      scene.textures.addCanvas(key, cv);
    }
    return key;
  }
  function uiPic(name, x, y, w, h, tint, dOff, alpha, angle) {
    if (!UIOK[name]) return false;
    const key = uiKey(name, tint);
    blitImg('u_' + key + L.depth, key, x, y, w, h, alpha === undefined ? 1 : alpha, L.depth + (dOff === undefined ? 0.55 : dOff), angle || 0, undefined, '__BASE');   // '__BASE' = the whole picture, even after a 3/9-slice added frames to the same texture
    return true;
  }
  function slice3(name, cx, cy, w, h, tint, dOff) {
    const u = UIOK[name];
    if (!u) return false;
    const key = uiKey(name, tint);
    if (!UIFR[key]) { const tx = scene.textures.get(key), cap = Math.round(u.h / 2); tx.add('l', 0, 0, 0, cap, u.h); tx.add('m', 0, cap, 0, u.w - 2 * cap, u.h); tx.add('r', 0, u.w - cap, 0, cap, u.h); UIFR[key] = 1; }
    const d = L.depth + (dOff === undefined ? 0.45 : dOff), dc = Math.min(h / 2, w / 2), pn = 's_' + key + L.depth;
    blitImg(pn + 'l', key, cx - w / 2 + dc / 2, cy, dc, h, 1, d, 0, undefined, 'l');
    if (w - 2 * dc > 0.5) blitImg(pn + 'm', key, cx, cy, w - 2 * dc, h, 1, d, 0, undefined, 'm');
    blitImg(pn + 'r', key, cx + w / 2 - dc / 2, cy, dc, h, 1, d, 0, undefined, 'r');
    return true;
  }
  function slice9(name, cx, cy, w, h, tint, dc, dOff) {
    const u = UIOK[name];
    if (!u) return false;
    const key = uiKey(name, tint);
    if (!UIFR[key]) {
      const tx = scene.textures.get(key), k = Math.round(Math.min(u.w, u.h) * 0.32), mw = u.w - 2 * k, mh = u.h - 2 * k;
      tx.add('tl', 0, 0, 0, k, k); tx.add('t', 0, k, 0, mw, k); tx.add('tr', 0, u.w - k, 0, k, k);
      tx.add('l', 0, 0, k, k, mh); tx.add('c', 0, k, k, mw, mh); tx.add('r', 0, u.w - k, k, k, mh);
      tx.add('bl', 0, 0, u.h - k, k, k); tx.add('b', 0, k, u.h - k, mw, k); tx.add('br', 0, u.w - k, u.h - k, k, k);
      UIFR[key] = 1;
    }
    const d = L.depth + (dOff === undefined ? 0.4 : dOff), x0 = cx - w / 2, y0 = cy - h / 2, mw = w - 2 * dc, mh = h - 2 * dc, pn = 'n_' + key + L.depth;
    [['tl', x0 + dc / 2, y0 + dc / 2, dc, dc], ['t', cx, y0 + dc / 2, mw, dc], ['tr', x0 + w - dc / 2, y0 + dc / 2, dc, dc],
     ['l', x0 + dc / 2, cy, dc, mh], ['c', cx, cy, mw, mh], ['r', x0 + w - dc / 2, cy, dc, mh],
     ['bl', x0 + dc / 2, y0 + h - dc / 2, dc, dc], ['b', cx, y0 + h - dc / 2, mw, dc], ['br', x0 + w - dc / 2, y0 + h - dc / 2, dc, dc]]
      .forEach((q) => blitImg(pn + q[0], key, q[1], q[2], q[3], q[4], 1, d, 0, undefined, q[0]));
    return true;
  }
  // ---------- Gifts: egg picture + opening animation ----------
  function eggPic(x, y, w, h, alpha, angle) {
    if (IMGOK.egg) blitImg('egg' + L.depth, 'img_egg', x, y, w, h, alpha, L.depth + 0.5, angle);
    else { g.fillStyle(0xfef3c7, alpha); g.fillEllipse(x, y + 2, w * 0.86, h * 0.98); }
  }
  function drawEggArea(x, y, p) {
    const eg = gift && gift.kind === 'egg';
    if (!eg) { eggPic(x, y + Math.sin(anim / 400) * 2, 72, 92, 1, Math.sin(anim / 700) * 3); return; }
    const ms = gift.t, open = p >= 0.7, k = open ? Math.min(1, (p - 0.7) / 0.3) : 0, rise = Math.min(1, p / 0.7);
    dot(x, y, 30 + 30 * rise, '#fde047', (0.10 + 0.30 * rise) * (open ? 1 - k * 0.7 : 1));
    if (!open) {
      const amp = 2 + 9 * Math.pow(rise, 1.6), sc = 1 + 0.08 * Math.sin(ms / 90) * rise;
      eggPic(x + Math.sin(ms / 38) * amp, y, 72 * sc, 92 * sc, 1, Math.sin(ms / 38) * (3 + 10 * rise));
      if (p > 0.45) {                                                  // cracks grow across the egg
        const cc = Math.min(1, (p - 0.45) / 0.25), pts = [[-16, -8], [-7, 2], [0, -6], [9, 4], [17, -4]], n = Math.max(2, Math.ceil(pts.length * cc));
        g.lineStyle(2.2, 0xffffff, 0.95); g.beginPath(); g.moveTo(x + pts[0][0], y + pts[0][1]);
        for (let i = 1; i < n; i++) g.lineTo(x + pts[i][0], y + pts[i][1]);
        g.strokePath();
      }
    } else {
      if (k < 0.55) eggPic(x, y, 72 * (1 + 0.5 * k), 92 * (1 + 0.5 * k), 1 - k / 0.55, 0);
      g.lineStyle(3, 0xffffff, Math.max(0, 1 - k * 1.3)); g.strokeCircle(x, y, 16 + 64 * k);
      for (let i = 0; i < 18 && k < 1; i++) {                           // sparkles flying out
        const an = i * 0.349 + hh(i, 4, 1) * 0.4, d = 12 + (30 + 52 * hh(i, 4, 2)) * k;
        dot(x + Math.cos(an) * d, y + Math.sin(an) * d + 14 * k * k, 2 + 2.2 * hh(i, 4, 3), CONFETTI[i % CONFETTI.length], 1 - k * 0.7);
      }
      const pk = k < 0.3 ? 0 : Math.min(1, (k - 0.3) / 0.7), ob = 1 + 1.70158 * Math.pow(pk - 1, 3) + 1.70158 * Math.pow(pk - 1, 2), sc = pk * ob;   // pops out with a bounce
      if (pk > 0) {
        if (gift.skin) miniSnake(SKIN_BY_ID[gift.skin], x, y);
        else if (gift.pw) { drawPwIcon(gift.pw, x, y, false); }
        else drawCoin(x, y, 26 * Math.max(0.2, sc));
      }
    }
  }
  function stamp(key, fn, size) {
    if (!scene.textures.exists(key)) {
      const S = size || 44, rt = scene.make.renderTexture({ width: S * ZOOM, height: S * ZOOM }, false), tg = scene.make.graphics({ add: false }), pg = g;
      g = tg;
      try { fn(S / 2, S / 2); } finally { g = pg; }
      tg.setScale(ZOOM); rt.draw(tg, 0, 0); rt.saveTexture(key); tg.destroy(); stampKeep.push(rt);
    }
    return key;
  }
  function blit(pool, key, x, y, alpha, depth) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key).setScale(1 / ZOOM).setDepth(depth); im._k = key; P.a.push(im); }
    P.n++;
    if (im._k !== key) { im.setTexture(key); im._k = key; }
    im.setPosition(x, y); im.setAlpha(alpha === undefined ? 1 : alpha); im.setVisible(true);
  }
  function poolsBegin() {
    if (!imgStarted) { imgStarted = true; loadImages(); }
    for (const k in pools) pools[k].n = 0;
  }
  function poolsEnd() { for (const k in pools) { const P = pools[k]; for (let i = P.n; i < P.a.length; i++) if (P.a[i]._vis !== false) { P.a[i].setVisible(false); } } }
  function withStillClock(fn) { const a0 = anim; anim = 0; try { fn(); } finally { anim = a0; } }
  const bombSt = (flick) => ['st_bomb_' + (flick ? 1 : 0), (cx, cy) => {
    const k = 0.82;
    line(cx + 4 * k, cy - 6 * k, cx + 8 * k, cy - 11 * k, '#a16207', 2.2 * k);
    dot(cx, cy + k, 8.5 * k, '#1f2937'); dot(cx - 2.8 * k, cy - 1.8 * k, 2.4 * k, '#6b7280'); rrect(cx + 1.5 * k, cy - 8.5 * k, 5 * k, 4 * k, k, '#374151');
    dot(cx + 8.5 * k, cy - 11.5 * k, (flick ? 3.2 : 2.4) * k, flick ? '#fbbf24' : '#f97316');
  }];
  function stampBomb(x, y) {
    const a = anim / 60, flick = Math.sin(a * 1.7) > 0;
    blit('bombGlow', stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 10, '#ef4444', 1)), x, y, 0.18 + 0.12 * Math.sin(a * 0.35), 4);
    if (!itemPic('bombP', 'bomb', x, y + 0.5, 20.5)) blit('bomb', stamp(...bombSt(flick)), x, y, 1, 5);
  }
  const fruitSt = (kind) => ['st_fr_' + kind, (cx, cy) => drawFruit(kind, cx, cy, 0.84)];
  const keySt = () => ['st_key', (cx, cy) => withStillClock(() => drawKey(cx, cy, 0.84))];
  const doorSt = (open, flash) => ['st_door_' + (open ? 1 : 0) + (flash ? 1 : 0), (cx, cy) => drawDoor(cx, cy, open, flash)];
  const gateSt = (open, col, flash) => ['st_gate_' + col + (open ? 1 : 0) + (flash ? 1 : 0), (cx, cy) => drawGate(cx, cy, open, col, flash)];
  function itemPic(pool, name, x, y, h, alpha, angle, tint) {   // sheet-7 pictures: always smaller than the cell, so they never touch a wall
    const u = UIOK[name];
    if (!u) return false;
    const key = uiKey(name, tint);
    blitImg(pool, key, x, y, h * u.w / u.h, h, alpha === undefined ? 1 : alpha, 5, angle || 0);
    return true;
  }
  const stampFruit = (kind, x, y) => { if (!itemPic('fruitP', 'fruit_' + kind, x, y, 20.5)) blit('fruit', stamp(...fruitSt(kind)), x, y, 1, 5); };
  const stampKey = (x, y) => { const yy = y + Math.sin(anim / 220) * 1.5; if (!itemPic('keyP', 'key', x, yy, 20.5, 1, Math.sin(anim / 500) * 6)) blit('key', stamp(...keySt()), x, yy, 1, 5); };
  const stampDoor = (x, y, open, flash) => { if (!itemPic('doorP', 'door', x, y, open ? 16 : 20, open ? 0.3 : 1)) blit('door', stamp(...doorSt(open, flash)), x, y, 1, 5); };
  const stampGate = (x, y, open, col, flash) => { if (!itemPic('gateP', 'gate', x, y, 20, open ? 0.25 : 1, 0, C(shade(col, 0.25)))) blit('gate', stamp(...gateSt(open, col, flash)), x, y, 1, 5); };
  // The stamps are made one per frame while the menu / level map is on screen, so starting a level does not have to build them.
  let warmQ = null;
  function warmStep() {
    if (state !== 'menu' && state !== 'levels') return;
    if (!warmQ) {
      warmQ = [];
      FRUITS.forEach((k) => warmQ.push(() => stamp(...fruitSt(k))));
      [true, false].forEach((f) => warmQ.push(() => stamp(...bombSt(f))));
      warmQ.push(() => stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 10, '#ef4444', 1)));
      warmQ.push(() => stamp(...keySt()));
      [[0, 0], [1, 0], [0, 1], [1, 1]].forEach((v) => warmQ.push(() => stamp(...doorSt(!!v[0], !!v[1]))));
      GATE_COLS.forEach((col) => [[0, 0], [1, 0], [0, 1], [1, 1]].forEach((v) => warmQ.push(() => stamp(...gateSt(!!v[0], col, !!v[1])))));
    }
    if (warmQ.length) warmQ.shift()();
  }
  function drawCampGame() {
    const C0 = G.camp, rt = C0.rt, st = C0.st, a = anim / 60, w = C0.L.w;
    drawCampHud();
    drawCampBottom();
    if (!LITE) drawAmbient(w);
    // sparkles on the ice
    for (let n = 0; n < C0.iceList.length && !LITE; n++) {
      if ((n * 7 + Math.floor(anim / 380)) % 11) continue;
      const i = C0.iceList[n], p = cellOf(i), s = 0.5 + 0.5 * Math.sin(anim / 120 + n);
      line(p.x - 3 * s - 1, p.y, p.x + 3 * s + 1, p.y, '#ffffff', 1.4); line(p.x, p.y - 3 * s - 1, p.x, p.y + 3 * s + 1, '#ffffff', 1.4);
    }
    if (C0.route) {                                   // hint: a trail of dots along the way to the exit
      let hi = C0.routeIdx.get(st.body[0]);
      if (hi === undefined && C0.hintMax) { let bd = 1e9; const hx = st.body[0] % COLS, hy = (st.body[0] / COLS) | 0; C0.route.forEach((rc, ri) => { const d = Math.abs(rc % COLS - hx) + Math.abs(((rc / COLS) | 0) - hy); if (d < bd) { bd = d; hi = ri; } }); }
      const from = hi === undefined ? 0 : hi + 1, pulse = anim / 170, upto = Math.min(C0.route.length, from + (C0.hintMax || 9999));
      for (let i = from; i < upto; i += LITE ? 2 : 1) { const p = cellOf(C0.route[i]); dot(p.x, p.y, 3, '#ffffff', 0.3 + 0.3 * Math.sin(pulse - i * 0.55)); }
    }
    drawExitTile(cellOf(rt.exit).x, cellOf(rt.exit).y, C0.exitOpen);
    rt.portalTo.forEach((to, i) => { if (to >= 0) { const p = cellOf(i), cols = ['#c084fc', '#38bdf8']; drawPortal(p.x, p.y, cols[(i < to) ? 0 : 1], i < to); } });
    rt.switches.forEach((s) => { const p = cellOf(s.cell); drawSwitch(p.x, p.y, GATE_COLS[s.gateIdx % GATE_COLS.length], E.gateOpen(rt, st, s.gateIdx)); });
    rt.gates.forEach((gt, gi) => gt.cells.forEach((c) => { const p = cellOf(c); stampGate(p.x, p.y, E.gateOpen(rt, st, gi), GATE_COLS[gi % GATE_COLS.length], C0.flash.some((f) => f.cell === c)); }));
    rt.doors.forEach((d) => { const p = cellOf(d.cell); stampDoor(p.x, p.y, E.doorOpen(rt, st, d), C0.flash.some((f) => f.cell === d.cell)); });
    rt.keys.forEach((k, i) => { if (!((st.keyMask >> i) & 1)) { const p = cellOf(k.cell); stampKey(p.x, p.y); } });
    for (let i = 0; i < COLS * ROWS; i++) if (rt.bomb[i]) { const b = cellOf(i); stampBomb(b.x, b.y); }
    C0.fr.forEach((f, i) => { if (!((st.fruitMask >> i) & 1)) { const p = cellOf(f.cell); stampFruit(f.kind, p.x, p.y + 1.5 * Math.sin(a * 0.4 + i)); } });
    useLayer(2);                                      // snake, effects and messages go above the stamped items
    drawSnake(snakePoints(), G.dir, null);
    if (G.boom && C0.over === 'trap') { const b = cellXY(G.boom[0], G.boom[1]); drawBoom(b.x, b.y); }
    fxs.forEach((e) => {
      const k = e.life / e.max;
      if (e.k === 1) { g.lineStyle(3 * k + 1, C(e.color), k); g.strokeCircle(e.x, e.y, e.r + (1 - k) * 26); }
      else dot(e.x, e.y, e.r * k + 0.5, e.color, k);
    });
    if (state === 'play') popups.forEach((p) => txt(p.x, p.y - (900 - p.life) * 0.03, p.s, 13, p.color));
    if (banner) {
      const k = banner.life / banner.max, grow = Math.min(1, (1 - k) * 8), alpha = Math.min(1, k * 4);
      const bw = 300 * (0.7 + 0.3 * grow), by = BY + 46 - (1 - k) * 14;
      rrect(W / 2 - bw / 2, by - 24, bw, banner.sub ? 52 : 38, 18, '#000000', 0.55 * alpha);
      txt(W / 2, by - (banner.sub ? 7 : 0), banner.s, banner.sub ? 20 : 22, banner.color);
      if (banner.sub) txt(W / 2, by + 15, banner.sub, 11, '#ffffff', 0.5, false);
    }
    // (the level tip is shown in the top line now, so nothing covers the board)
    if (C0.shield) { const p = headXY(); g.lineStyle(2.5, C('#38bdf8'), 0.75 + 0.25 * Math.sin(anim / 120)); g.strokeCircle(p.x, p.y, 17); }
    if (C0.hold && state === 'play') txt(W / 2, BY + 60, C0.undone ? 'Swipe to continue' : 'Turn now!', 22, '#38bdf8');
    if (C0.ready > 0) {
      const go = C0.ready < 380, k = go ? C0.ready / 380 : 1, bw = 190;
      rrect(W / 2 - bw / 2, BY + BH * 0.42 - 34, bw, 68, 22, '#000000', 0.55);
      txt(W / 2, BY + BH * 0.42, go ? 'GO!' : 'READY', go ? 40 + (1 - k) * 8 : 34, go ? '#4ade80' : '#ffffff');
    }
  }
  function drawCampOverlayFrame(h) {
    const t = th(), top = (H - h) / 2;
    g.fillStyle(0x000000, 0.4); g.fillRect(0, 0, W, H);
    if (!slice9('panel_card', W / 2, top + h / 2, 382, h + 20, C(t.panel), 34, 0.4)) {
      rrect(W / 2 - 186, top - 6, 372, h + 12, 26, t.bg);
      rrect(W / 2 - 180, top, 360, h, 22, t.panel);
    }
    return top;
  }

  // ---------- "How to play" card: what is in this level (opens by itself the first time a thing appears, and from the "?" button) ----------
  const TIPS_KEY = 'snakeFruitRush.tips.v1';
  const tipsSeen = (() => {
    try { const a = JSON.parse(localStorage.getItem(TIPS_KEY)); return new Set(Array.isArray(a) ? a.filter((x) => typeof x === 'string').slice(0, 20) : []); } catch (e) { return new Set(); }
  })();
  function helpItems(L) {
    const it = [
      { id: 'swipe', title: 'Swipe to turn', text: 'Swipe anywhere to turn. Walls and your own body stop you.' },
      { id: 'fruit', title: 'Eat all the fruit', text: 'The exit only opens after every fruit is eaten.' }
    ];
    if (skHas(L, 'I')) it.push({ id: 'ice', title: 'Ice', text: 'You slide and cannot turn until the ice ends.' });
    if (skHas(L, 'B')) it.push({ id: 'bomb', title: 'Bombs', text: 'Touch a bomb and the level ends. Go around!' });
    if (skHas(L, 'D')) it.push({ id: 'door', title: 'Key and door', text: 'Take the key first. Then the door opens for you.' });
    if (skHas(L, 'G')) it.push({ id: 'gate', title: 'Switch and gate', text: 'Step on the switch to open (or close) the gate of the same colour.' });
    if (skHas(L, 'P')) it.push({ id: 'portal', title: 'Portals', text: 'Enter one portal and you come out of the other.' });
    it.push({ id: 'exit', title: 'The exit', text: 'It glows when all fruit is eaten. Then go in!' });
    return it;
  }
  function drawHelpIcon(id, x, y) {
    if (id === 'swipe') { g.fillStyle(C('#ffffff'), 0.95); g.fillTriangle(x - 13, y, x - 2, y - 9, x - 2, y + 9); g.fillTriangle(x + 13, y, x + 2, y - 9, x + 2, y + 9); dot(x, y, 4, '#ffffff'); }
    else if (id === 'fruit') drawFruit('apple', x, y, 1.1);
    else if (id === 'ice') { rrect(x - 12, y - 12, 24, 24, 6, '#bfe6ff'); line(x - 7, y + 4, x + 3, y - 6, '#ffffff', 2.2); line(x - 2, y + 8, x + 8, y - 2, '#ffffff', 2.2); }
    else if (id === 'bomb') drawBomb(x, y, 1.15);
    else if (id === 'door') { drawKey(x - 12, y, 0.8); drawDoor(x + 12, y, false, false); }
    else if (id === 'gate') { drawSwitch(x - 12, y, GATE_COLS[0], false); drawGate(x + 12, y, false, GATE_COLS[0], false); }
    else if (id === 'portal') { drawPortal(x - 12, y, '#c084fc', true); drawPortal(x + 12, y, '#38bdf8', false); }
    else if (id === 'exit') drawExitTile(x, y, true);
  }
  function drawCampHelp() {
    const t = th(), C0 = G.camp, items = helpItems(C0.L), rowH = 66, h = 118 + items.length * rowH + 64, top = drawCampOverlayFrame(h);
    buttons = [];                                                      // only this card reacts
    txt(W / 2, top + 36, 'How to play', 28, t.accent);
    txt(W / 2, top + 66, 'What is in level ' + C0.id, 13, t.btnText, 0.5, false);
    items.forEach((it, i) => {
      const y = top + 108 + i * rowH;
      rrect(W / 2 - 168, y - 28, 336, rowH - 6, 14, t.bg, 0.55);
      drawHelpIcon(it.id, W / 2 - 130, y + 4);
      txt(W / 2 - 96, y - 14, it.title, 15, t.btnText, 0);
      if (!tipsSeen.has(it.id) && !uiPic('badge_new', W / 2 + 138, y - 14, 52, 32)) { rrect(W / 2 + 118, y - 23, 42, 18, 9, t.accent); txt(W / 2 + 139, y - 14, 'NEW', 10, '#1b1b1b'); }
      wrapText(it.text, 34).forEach((l, k) => txt(W / 2 - 96, y + 6 + k * 16, l, 12, t.text, 0, false));
    });
    button(W / 2, top + h - 40, 260, 52, 'Got it!', closeHelp, { primary: true, size: 20 });
  }
  const COST_UNDO = 100, COST_HINT = 60, COST_SKIP = 500;
  function canUndo() { const C0 = G && G.camp; return !!C0 && !C0.won && !C0.expert && C0.hist.length > 0; }
  function doUndo() {                                                  // back to the position before the last move (fruit, keys, gates and score come back too)
    const C0 = G.camp, snap = C0.hist.pop(), st = C0.st, s = snap.st;
    st.body = s.body.slice(); st.dir = s.dir; st.fruitMask = s.fruitMask; st.keyMask = s.keyMask; st.gateMask = s.gateMask; st.moves = s.moves; st.done = false; st.swLog = s.swLog; st.fruitLog = s.fruitLog;
    G.snake = st.body.map((c) => [c % COLS, (c / COLS) | 0]); G.dir = st.dir; G.queue = []; G.eaten = snap.eaten;
    C0.moves = st.moves; C0.over = null; C0.endT = 0; C0.exitOpen = E.exitReady(C0.rt, st); C0.hold = true; C0.undone = true;   // waits for the next swipe
    G.boom = null; prevSnake = null; acc = 0; fxs.length = 0; easeT = anim;
    sfx.click(); buzz(15);
  }
  function helpMsg(s, bad) { G.camp.helpMsg = { s: s, until: anim + 2200, bad: bad !== false }; sfx.err(); }
  function useUndo() {
    const C0 = G.camp;
    if (C0.expert) { helpMsg('Not in Expert mode'); return; }
    if (!canUndo()) { helpMsg('Nothing to undo yet'); return; }
    if (DATA.coins < COST_UNDO) { helpMsg('Need ' + (COST_UNDO - DATA.coins) + ' more coins'); return; }
    DATA.coins -= COST_UNDO; writeData(); C0.helped = true; doUndo();
    if (state === 'paused') { C0.help = false; togglePause(); } else if (state === 'over') setState('play');
  }
  function giveHint() { const C0 = G.camp; C0.helped = true; C0.route = C0.L.R; C0.routeIdx = new Map(); C0.route.forEach((cell, i) => C0.routeIdx.set(cell, i)); C0.hintMax = 12; }
  function useHint() {
    const C0 = G.camp;
    if (C0.expert) { helpMsg('Not in Expert mode'); return; }
    if (C0.route) { helpMsg('The hint is already showing', false); return; }
    if (DATA.coins < COST_HINT) { helpMsg('Need ' + (COST_HINT - DATA.coins) + ' more coins'); return; }
    DATA.coins -= COST_HINT; writeData(); giveHint(); sfx.coin(); C0.help = false; togglePause();
  }
  function adHintHere() {
    const C0 = G.camp;
    if (C0.expert) { helpMsg('Not in Expert mode'); return; }
    requestRewarded('hint', { back: 'paused', ok: () => { giveHint(); C0.help = false; togglePause(); }, fail: (m) => { helpMsg(m); } });
  }
  function useSkip() {
    const C0 = G.camp;
    if (gated(C0.id + 1)) { helpMsg(gateMsg(C0.id + 1)); return; }
    if (C0.expert || C0.daily) { helpMsg('Not in this mode'); return; }
    if (DATA.coins < COST_SKIP) { helpMsg('Need ' + (COST_SKIP - DATA.coins) + ' more coins'); return; }
    if (!C0.skipArm || anim - C0.skipArm > 3000) { C0.skipArm = anim; sfx.click(); return; }     // second tap confirms
    DATA.coins -= COST_SKIP;
    if (DATA.camp.unlocked < C0.id + 1) DATA.camp.unlocked = C0.id + 1;
    DATA.camp.cur = C0.id + 1; SK.cur = null; writeData(); sfx.coin();
    C0.help = false; startLevel(C0.id + 1);
  }
  function drawCampHelpMenu() {
    const t = th(), C0 = G.camp, frontier = !C0.daily && !C0.expert && C0.id >= DATA.camp.unlocked && C0.id < LEVEL_COUNT, adOk = !C0.route && !C0.expert && adAvailable();
    const coinAd = DATA.coins < (frontier ? COST_SKIP : COST_HINT) && adCoinsLeft() && adAvailable(), top = drawCampOverlayFrame(362 + (adOk ? 50 : 0) + (frontier ? 62 : 0) + (coinAd ? 44 : 0));
    buttons = [];
    txt(W / 2, top + 38, 'Help', 30, t.accent);
    const ct = coinText(DATA.coins) + ' coins';
    drawCoin(W / 2 - ct.length * 4.2 - 12, top + 72, 9); txt(W / 2 + 2, top + 72, ct, 15, t.accent);
    if (C0.helpMsg && anim < C0.helpMsg.until) txt(W / 2, top + 98, C0.helpMsg.s, 13, C0.helpMsg.bad ? '#ff5a5f' : '#4ade80', 0.5, false);
    let y = top + 134;
    const chip = (cx, yy, cost) => { const s = String(cost), w = 30 + s.length * 9; rrect(cx - w / 2, yy - 13, w, 26, 13, '#000000', 0.38); if (!uiPic('icon_coins', cx - w / 2 + 13, yy, 18, 16)) drawCoin(cx - w / 2 + 13, yy, 7); txt(cx + 8 - (s.length - 1) * 0.5 * 0, yy + 1, s, 14, DATA.coins >= cost ? '#ffd84a' : '#ff8a8a'); };
    const hb = (yy, label, fn, on, ic, cost) => { if (on) adBtn(W / 2, yy, 300, 50, label, fn, 17); else button(W / 2, yy, 300, 50, label, fn, { size: 17, dark: true }); if (ic) uiPic(ic, W / 2 - 126, yy, 34, 34); if (cost) chip(W / 2 + 106, yy, cost); };
    hb(y, 'Undo last move', useUndo, canUndo(), 'icon_undo', COST_UNDO); y += 60;
    hb(y, C0.route ? 'Hint is on' : 'Show next steps', useHint, !C0.route, 'icon_hint', C0.route ? 0 : COST_HINT); y += 60;
    if (adOk) { adBtn(W / 2, y - 6, 300, 38, 'Watch ad - free hint', adHintHere, 15); y += 44; }
    if (DATA.coins < (frontier ? COST_SKIP : COST_HINT) && adCoinsLeft() && adAvailable()) { adBtn(W / 2, y - 6, 300, 38, 'Watch ad:  +' + adCoinNext() + ' coins', () => claimAdCoins('paused', (m, ok) => helpMsg(m, ok !== true)), 15); y += 44; }
    if (frontier) { const armed = C0.skipArm && anim - C0.skipArm < 3000; hb(y, armed ? 'Tap again to skip level' : 'Skip level', useSkip, true, 'icon_skip', armed ? 0 : COST_SKIP); y += 60; }
    button(W / 2, y, 300, 46, 'How to play', () => { C0.help = true; C0.helpFrom = 'menu'; }, { size: 16, dark: true }); uiPic('icon_help', W / 2 - 126, y, 30, 30); y += 58;
    button(W / 2, y, 300, 50, 'Resume', () => { C0.help = false; togglePause(); }, { primary: true, size: 19 });
  }
  function openHelp() {
    if (!G || !G.camp || state !== 'play' || G.camp.over || G.camp.won) return;
    G.camp.help = 'menu'; togglePause();
  }
  function closeHelp() {                                               // "Got it!" on the how-to-play card
    const C0 = G.camp;
    helpItems(C0.L).forEach((i) => tipsSeen.add(i.id));
    try { localStorage.setItem(TIPS_KEY, JSON.stringify(Array.from(tipsSeen))); } catch (e) { /* blocked: shows again next time */ }
    if (C0.helpFrom === 'menu') { C0.helpFrom = null; C0.help = 'menu'; return; }
    C0.help = false; togglePause();
  }
  function drawCampPause() {
    const t = th(), C0 = G.camp, top = drawCampOverlayFrame(420);
    txt(W / 2, top + 38, 'Paused', 33, t.accent);
    txt(W / 2, top + 74, 'Level ' + C0.id + '  -  ' + WORLDS[C0.L.w].name, 16, t.btnText);
    toggleBtn(W / 2 - 96, top + 122, 'sound', DATA.sound, 'Sound', toggleSound);
    toggleBtn(W / 2, top + 122, 'vibe', DATA.vibe, 'Vibrate', toggleVibe);
    toggleBtn(W / 2 + 96, top + 122, 'tap', DATA.tapSteer, 'Tap to turn', toggleTap);
    button(W / 2, top + 232, 290, 56, 'Resume', togglePause, { primary: true, size: 21 });
    button(W / 2, top + 300, 290, 50, 'Restart level', campRetry, { dark: true, size: 18 });
    button(W / 2, top + 362, 290, 50, 'Levels', leaveToLevels, { dark: true, size: 18 });
  }
  function drawCampFail() {
    const t = th(), C0 = G.camp, hintOk = !C0.route && adAvailable(), undoOk = canUndo(), top = drawCampOverlayFrame((hintOk ? 366 : 300) + (undoOk ? 58 : 0));
    txt(W / 2, top + 44, C0.over === 'trap' ? 'Boom!' : 'Oops!', 34, '#ff5a5f');
    const why = C0.over === 'gate' ? 'The gate is closed - use the switch' : C0.over === 'door' ? 'The door is locked - get the key first' : (FAIL_TEXT[C0.over] || 'Try again');
    txt(W / 2, top + 88, why, 15, t.btnText);
    txt(W / 2, top + 114, 'Level ' + C0.id, 13, t.btnText, 0.5, false);
    button(W / 2, top + 176, 290, 58, 'Try again', campRetry, { primary: true, size: 22 });
    let y = top + 246;
    if (undoOk) { button(W / 2, y, 290, 50, 'Undo last move   ' + COST_UNDO, useUndo, { size: 17 }); y += 58; }
    if (C0.helpMsg && anim < C0.helpMsg.until) txt(W / 2, top + 146, C0.helpMsg.s, 12.5, '#ff5a5f', 0.5, false);
    if (hintOk) { adBtn(W / 2, y, 290, 50, 'Watch ad - get hint', adHint, 17); y += 62; }
    button(W / 2, y, 290, 50, 'Levels', leaveToLevels, { dark: true, size: 18 });
    if (G.adMsg) txt(W / 2, top + 146, G.adMsg, 12.5, '#ff5a5f', 0.5, false);
  }

  // ---------- Game feel: camera shake (off with reduced motion) ----------
  function shake(ms, k) { if (REDUCED || !scene) return; try { scene.cameras.main.shake(ms, k); } catch (e) { /* ignore */ } }
  const FRUIT_COL = { apple: '#e53935', orange: '#ff9a1f', cherry: '#d81b60', grapes: '#8e5bd6', strawberry: '#ff4d6d' };   // fruit pop colours
  function drawConfetti() {                                           // falling confetti on the "level cleared" screen (cheap: no state)
    const n = LITE ? 10 : 22;
    for (let i = 0; i < n; i++) {
      const t0 = (anim / 1000 * (0.16 + 0.2 * hh(i, 9, 2)) + hh(i, 9, 3)) % 1, x = BX + hh(i, 9, 1) * BW + Math.sin(anim / 400 + i) * 10, y = -10 + t0 * (H + 20);
      g.fillStyle(C(CONFETTI[i % CONFETTI.length]), 0.9); g.fillRect(x, y, 6, 9);
    }
  }
  function doubleCoins() {                                           // optional rewarded ad: the level reward is paid a second time
    const C0 = G.camp;
    requestRewarded('double', { back: 'won', ok: () => { C0.doubled = true; addCoins(C0.coins); sfx.coin(); }, fail: (m) => { G.adMsg = m; } });
  }
  function drawCampWon() {
    if (G.camp.daily) { drawDailyWon(); return; }
    const t = th(), C0 = G.camp, last = C0.id >= LEVEL_COUNT, canDbl = adAvailable() && !C0.doubled && C0.coins > 0, canExp = C0.stars === 3 && !C0.expert, top = drawCampOverlayFrame((last ? 430 : 512) + (canDbl ? 58 : 0) + (canExp ? 56 : 0));
    txt(W / 2, top + 44, last ? 'You did it!' : 'Level cleared!', 32, t.accent);
    txt(W / 2, top + 80, last ? 'All ' + LEVEL_COUNT + ' levels complete' : 'Level ' + C0.id + '  -  ' + WORLDS[C0.L.w].name, 15, t.btnText);
    for (let s = 0; s < 3; s++) {
      const k = Math.min(1, Math.max(0, (C0.endT - PORTAL_MS - s * 220 + 700) / 260)), got = s < C0.stars;
      const x = W / 2 + (s - 1) * 62, y = top + 140 - (s === 1 ? 8 : 0), sc = got ? 1 + 0.35 * Math.sin(Math.min(1, k) * Math.PI) : 1;
      if (!uiPic(got ? 'star_full' : 'star_empty', x, y, 68 * sc, 64 * sc, 0xffffff, 0.55)) {
        starShape(x, y + 3, 30 * sc, '#000000', 0.25);
        starShape(x, y, 30 * sc, got ? '#fde047' : '#00000044');
        if (got) starShape(x - 2, y - 3, 14 * sc, '#fffbe0', 0.6);
      }
    }
    txt(W / 2, top + 208, C0.moves + ' moves', 20, t.btnText);
    const gap3 = C0.moves - C0.L.s3, gap2 = C0.moves - C0.L.s2;
    txt(W / 2, top + 236, C0.stars < 3 ? (C0.stars < 2 ? (gap2 <= 3 ? 'So close! ' + gap2 + ' move' + (gap2 > 1 ? 's' : '') + ' more than 2 stars' : '2 stars: ' + C0.L.s2 + ' moves   3 stars: ' + C0.L.s3) : (gap3 <= 4 ? 'So close! Just ' + gap3 + ' move' + (gap3 > 1 ? 's' : '') + ' too many for 3 stars' : '3 stars: ' + C0.L.s3 + ' moves or less')) : 'Perfect run!', 13, t.btnText, 0.5, false);
    drawCoin(W / 2 - 52, top + 262, 9);
    if (!C0.wonT) C0.wonT = anim;
    txt(W / 2 - 38, top + 262, '+' + Math.round(G.coins * Math.min(1, (anim - C0.wonT) / 700)) + ' coins', 15, '#fbbf24', 0);   // counts up
    if (!last) {
      if (gated(C0.id + 1)) txt(W / 2, top + 296, gateMsg(C0.id + 1), 12.5, '#fbbf24', 0.5, false);
      else { const nx = LV[C0.id], mech = [skHas(nx, 'I') && 'ice', skHas(nx, 'B') && 'bombs', skHas(nx, 'D') && 'door', skHas(nx, 'G') && 'gate', skHas(nx, 'P') && 'portal'].filter(Boolean).slice(0, 2).join(' + ');
      txt(W / 2, top + 296, 'Next: level ' + (C0.id + 1) + '  -  ' + fruitCount(C0.id + 1) + ' fruit' + (mech ? '  -  ' + mech : ''), 13, t.btnText, 0.5, false); }
    }
    drawConfetti();
    let y = top + (last ? 316 : 338);
    if (!last) { button(W / 2, y, 290, 58, gated(C0.id + 1) ? 'Level map' : 'Next level', campNextLevel, { primary: true, size: 22 }); y += 68; }
    if (canDbl) { adBtn(W / 2, y - 6, 290, 46, 'Watch ad:  double reward  +' + C0.coins, doubleCoins, 16); y += 54; }
    if (C0.stars === 3 && !C0.expert) { button(W / 2, y, 290, 46, 'Expert mode  (x3 coins)', () => startLevel(C0.id, false, { expert: true }), { dark: true, size: 17 }); y += 56; }
    button(W / 2, y, 290, 46, 'Replay', campRetry, { dark: true, size: 17 });
    button(W / 2, y + 56, 290, 46, 'Levels', leaveToLevels, { dark: true, size: 17 });
  }
