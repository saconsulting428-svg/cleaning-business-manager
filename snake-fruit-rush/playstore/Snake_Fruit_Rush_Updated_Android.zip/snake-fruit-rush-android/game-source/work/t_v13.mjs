import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html?testads=1'); await p.waitForTimeout(1200);
// star gates: only while the next world is still closed
await p.evaluate(() => { const D = __snake.DATA; D.camp.stars = {}; for (let i = 1; i <= 20; i++) D.camp.stars[i] = 1; D.camp.unlocked = 21; D.camp.cur = 21; });
await p.evaluate(() => __snake.camp.start(21)); await p.waitForTimeout(200);
ok(await p.evaluate(() => !(__snake.camp.C && __snake.camp.C.id === 21) && __snake.state !== 'play'), 'gate: level 21 stays closed with 20 stars (needs 30)');
await p.evaluate(() => { __snake.DATA.camp.stars[1] = 3; __snake.DATA.camp.stars[2] = 3; __snake.DATA.camp.stars[3] = 3; __snake.DATA.camp.stars[4] = 3; __snake.DATA.camp.stars[5] = 3; });   // 20 + 10 = 30
await p.evaluate(() => __snake.camp.start(21)); await p.waitForTimeout(300);
ok(await p.evaluate(() => __snake.state === 'play' && __snake.camp.C.id === 21), 'gate: opens with 30 stars');
// a player who is already past the gate is not blocked again
await p.evaluate(() => { const D = __snake.DATA; D.camp.stars = {}; D.camp.unlocked = 45; __snake.camp.start(41); }); await p.waitForTimeout(300);
ok(await p.evaluate(() => __snake.state === 'play' && __snake.camp.C.id === 41), 'gate: players already past it are not blocked');
// win screen: next level gated -> "Level map"
await p.evaluate(() => { const D = __snake.DATA; D.camp.stars = {}; for (let i = 1; i <= 19; i++) D.camp.stars[i] = 1; D.camp.unlocked = 20; __snake.camp.start(20); __snake.camp.C.ready = 0; });
await p.evaluate(async () => { const S = __snake.camp, COLS = 20, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]], c0 = S.C, route = S.LV[19].R; const t0 = performance.now();
  while (performance.now() - t0 < 60000 && !c0.won && !c0.over) { const G = __snake.G, h = G.snake[0][1] * COLS + G.snake[0][0], k = route.indexOf(h); if (k >= 0 && k + 1 < route.length) { const nx = route[k + 1], d = D4.findIndex((v) => v[0] === (nx % COLS) - G.snake[0][0] && v[1] === ((nx / COLS) | 0) - G.snake[0][1]); if (d >= 0 && !(G.dir[0] === D4[d][0] && G.dir[1] === D4[d][1])) G.queue = [D4[d]]; } await new Promise((r) => setTimeout(r, 30)); } });
await p.waitForFunction(() => __snake.state === 'won', null, { timeout: 8000 }); await p.waitForTimeout(800);
await p.screenshot({ path: 'shots3/d_gate_won.png' });
await p.evaluate(() => __snake.camp.next()); await p.waitForTimeout(400);
ok(await p.evaluate(() => __snake.state === 'levels'), 'gate: "Next" on the win screen goes to the level map when the next world is closed');
await p.screenshot({ path: 'shots3/d_gate_map.png' });
// turn-now text only while playing; Undo shows "Swipe to continue"
// ads ladder in the Help menu
await p.evaluate(() => { const D = __snake.DATA; D.coins = 5; D.camp.unlocked = 100; D.adCoins = null; __snake.camp.start(9); __snake.camp.C.ready = 0; }); await p.waitForTimeout(300);
await p.evaluate(() => { __snake.camp.help.open(); }); await p.waitForTimeout(250);
await p.screenshot({ path: 'shots3/d_help.png' });
ok(await p.evaluate(() => __snake.state === 'paused' && __snake.camp.buttons.length >= 4), 'help menu opens with few coins');
console.log('errors', errs.length, errs.slice(0, 3)); console.log('pass', pass, 'fail', fail); await b.close();
