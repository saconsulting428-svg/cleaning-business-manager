import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
import fs from 'fs';
const file = 'file://' + process.cwd() + '/' + (process.argv[2] || 'test.html');
const b = await chromium.launch();
let pass = 0, fail = 0; const errs = [];
const ok = (c, m) => { if (c) { pass++; console.log('  ok  ', m); } else { fail++; console.log('  FAIL', m); } };
async function page(init) { const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message)); if (init) await p.addInitScript(init); await p.goto(file); await p.waitForTimeout(900); return { ctx, p }; }
const click = async (p, x, y) => { const [cx, cy] = await p.evaluate(([x, y]) => { const c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + x * c.width / 480, c.top + y * c.height / 800]; }, [x, y]); await p.mouse.click(cx, cy); };
fs.mkdirSync('shots3', { recursive: true });

console.log('MENU');
{
  const { ctx, p } = await page();
  ok(!(await p.content()).includes('v2.9'), 'no v2.9 text in page');
  await p.screenshot({ path: 'shots3/menu.png' });
  await click(p, 480 - 20 - 76, 39); await p.waitForTimeout(200);
  await p.screenshot({ path: 'shots3/settings.png' });
  await click(p, 240, 346);
  ok(await p.evaluate(() => __snake.DATA.sound === false), 'settings: sound toggles');
  await click(p, 240, 462);
  ok(await p.evaluate(() => __snake.DATA.tapSteer === true), 'settings: tap steer toggles');
  await click(p, 240, 534); await p.waitForTimeout(150);
  await click(p, 240, 548);   // Play (after close)
  await p.waitForTimeout(300);
  ok(await p.evaluate(() => __snake.state === 'play'), 'Play works after closing settings');
  await ctx.close();
}

console.log('ADAPTIVE');
{
  const { ctx, p } = await page();
  const r = await p.evaluate(() => {
    const K = __snake.camp.sk, out = {}, LV = __snake.camp.LV;
    const sim = (fails, moveMul, n) => { K.reset(); for (let i = 1; i <= n; i++) { K.fail(i, 'wall'); K.S.cur = { id: i, fails: 0, ms: 0 }; for (let f = 0; f < fails; f++) K.fail(i, 'wall'); K.record(i, fails, Math.round(LV[i - 1].par * moveMul), LV[i - 1].par, LV[i - 1].par * LV[i - 1].d * (moveMul + 0.5), LV[i - 1].d); K.S.cur = null; } return { lvl: K.S.lvl, prof: K.profile(), h: K.S.h.length }; };
    out.fresh = (K.reset(), K.profile());
    K.reset(); for (let i = 1; i <= 3; i++) K.record(i, 6, LV[i - 1].par * 3, LV[i - 1].par, 1e6, LV[i - 1].d); out.after3 = K.S.lvl;   // < 4 levels: no change yet
    out.struggle = sim(5, 3, 10); out.mid = sim(1, 1.3, 10); out.skilled = sim(0, 1.0, 10);
    // gradual: skilled player after a beginner history moves one step per level
    sim(5, 3, 8); const trail = []; for (let i = 9; i <= 16; i++) { K.S.cur = { id: i, fails: 0, ms: 0 }; K.record(i, 0, LV[i - 1].par, LV[i - 1].par, LV[i - 1].par * LV[i - 1].d * 1.5, LV[i - 1].d); trail.push(K.S.lvl); } out.trail = trail;
    return out;
  });
  console.log('   ', JSON.stringify(r));
  ok(r.fresh === 'intermediate', 'new player starts at normal (intermediate) difficulty');
  ok(r.after3 === 0, 'no adaptation before 4 levels of data');
  ok(r.struggle.prof === 'beginner' && r.struggle.lvl <= -1, 'struggling player -> beginner profile');
  ok(r.mid.prof === 'intermediate', 'average player -> intermediate profile');
  ok(r.skilled.prof === 'skilled', 'strong player -> skilled profile');
  ok(r.trail.every((v, i) => i === 0 || Math.abs(v - r.trail[i - 1]) <= 1), 'adaptation changes at most one step per level');
  // active level is never touched; only startLevel applies adaptation
  await p.evaluate(() => { __snake.camp.unlockAll(); __snake.camp.sk.reset(); __snake.camp.start(5); });
  await p.waitForTimeout(300);
  const before = await p.evaluate(() => JSON.stringify([__snake.camp.C.L.s2, __snake.camp.C.L.s3, __snake.camp.C.L.d, __snake.camp.C.L.F]));
  await p.evaluate(() => { const K = __snake.camp.sk; for (let i = 1; i <= 8; i++) K.record(i, 6, 300, 20, 1e6, 150); });
  await p.waitForTimeout(400);
  const after = await p.evaluate(() => JSON.stringify([__snake.camp.C.L.s2, __snake.camp.C.L.s3, __snake.camp.C.L.d, __snake.camp.C.L.F]));
  ok(before === after, 'profile change does not alter the running level');
  // persistence
  await p.evaluate(() => __snake.camp.sk.reload());
  const lv = await p.evaluate(() => __snake.camp.sk.S.lvl);
  await p.reload(); await p.waitForTimeout(800);
  ok(await p.evaluate((l) => __snake.camp.sk.S.lvl === l && __snake.camp.sk.S.h.length >= 4, lv), 'skill profile survives restart (lvl ' + lv + ')');
  ok(await p.evaluate(() => JSON.parse(localStorage.getItem('snakeFruitRush.skill.v1')).v === 1 && !!localStorage.getItem('snakeFruitRush.v1')), 'separate versioned key; main save untouched');
  // corrupt data
  for (const bad of ['{{{', '{"v":9}', '{"v":1,"h":"x"}', '{"v":1,"lvl":99,"h":[{"sc":"a"},null,{"id":1,"sc":0.5,"at":2}]}']) {
    await p.evaluate((x) => localStorage.setItem('snakeFruitRush.skill.v1', x), bad);
    const s = await p.evaluate(() => { const S = __snake.camp.sk.reload(); return [S.lvl, S.h.length]; });
    ok(s[0] >= -2 && s[0] <= 2 && s[1] <= 10, 'corrupt skill data handled: ' + bad.slice(0, 22));
  }
  // preserved progress
  ok(await p.evaluate(() => __snake.DATA.camp.unlocked === 100), 'campaign progress preserved');
  // variants solvable: every level x every adaptation level x 6 layouts replay the stored route
  const bad = await p.evaluate(() => {
    const K = __snake.camp.sk, E = __snake.camp.E, LV = __snake.camp.LV, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]], COLS = 20, bads = []; let n = 0;
    for (const L of LV) for (const bias of [-1, 0, 1]) for (let k = 0; k < 6; k++) {
      const L2 = K.fruit(L, bias), rt = E.makeRuntime(__snake.camp.engineLevel(L2)), st = E.newState(rt), route = L.R; let status = 'ok', good = true; n++;
      for (let i = 1; i < route.length; i++) {
        const cur = route[i], head = st.body[0], d = D4.findIndex((v) => v[0] === (cur % COLS) - (head % COLS) && v[1] === ((cur / COLS) | 0) - ((head / COLS) | 0));
        if (d < 0) { good = false; break; } let q, g = 0; do { q = E.step(rt, st, D4[d]); g++; } while (q.status === 'wait' && g < 5); status = q.status; if (status === 'fail') { good = false; break; }
        if ((L.P || []).some((pp) => (pp[1] * COLS + pp[0]) === cur)) i++;
      }
      if (!good || status !== 'win') bads.push(L.id + '/' + bias);
    }
    return { n, bads: bads.slice(0, 5), cnt: bads.length };
  });
  ok(bad.cnt === 0, 'all adaptive fruit variants solvable by the stored route (' + bad.n + ' layouts) ' + JSON.stringify(bad.bads));
  // star goals never drop below par, never exceed sane range
  const st = await p.evaluate(() => { const K = __snake.camp.sk, bads = []; for (const e of [-2, -1, 1, 2]) { K.reset(); K.S.lvl = e; __snake.camp.LV.forEach((L, ix) => { __snake.camp.start(ix + 1); const c = __snake.camp.C; if (c.L.s3 < L.par || c.L.s2 < c.L.s3 || c.L.s3 > L.s3 + 2 || c.L.s3 < L.s3 - 2) bads.push((ix + 1) + '/' + e); }); } return bads.slice(0, 5); });
  ok(st.length === 0, 'star thresholds stay >= par for all levels/profiles ' + JSON.stringify(st));
  await ctx.close();
}

console.log('PORTAL');
{
  const { ctx, p } = await page();
  await p.evaluate(() => __snake.camp.unlockAll());
  for (const w of [0, 1, 2, 3, 4]) {
    await p.evaluate((w) => { __snake.camp.sk.reset(); __snake.camp.start(w * 20 + 1); }, w); await p.waitForTimeout(1500);
    await p.screenshot({ path: `shots3/portal_locked_w${w}.png` });
    await p.evaluate(() => { const C = __snake.camp.C; C.exitOpen = true; C.exitT = performance.now() - 1000; }); await p.waitForTimeout(300);
    await p.screenshot({ path: `shots3/portal_open_w${w}.png` });
  }
  ok(await p.evaluate(() => { const C = __snake.camp.C, rt = C.rt; return rt.exit !== undefined && typeof __snake.camp.E.exitReady === 'function'; }), 'engine exit coordinate/exitReady untouched');
  // locked -> open on last fruit, win -> portal delay -> won screen
  await p.evaluate(() => { __snake.camp.sk.reset(); __snake.camp.start(1); }); await p.waitForTimeout(300);
  ok(await p.evaluate(() => __snake.camp.C.exitOpen === false), 'exit locked at start');
  const info = await p.evaluate(() => new Promise((res) => {
    const C = __snake.camp.C, E = __snake.camp.E; const L = C.L; const route = L.R, COLS = 20, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]];
    C.ready = 0; const t0 = performance.now(); let i = 1, openAt = 0, wonAt = 0, stateAt = 0;
    const iv = setInterval(() => {
      const c = __snake.camp.C; if (!c) return;
      if (c.exitOpen && !openAt) openAt = performance.now() - t0;
      if (c.won && !wonAt) wonAt = performance.now() - t0;
      if (__snake.state === 'won' && !stateAt) { stateAt = performance.now() - t0; clearInterval(iv); res({ openAt, wonAt, stateAt, portalMs: stateAt - wonAt }); }
      if (!c.won && i < route.length) { const head = __snake.G.snake[0], cur = route[i]; const d = D4.findIndex((v) => v[0] === (cur % COLS) - head[0] && v[1] === ((cur / COLS) | 0) - head[1]); if (d >= 0) { __snake.G.queue = [D4[d]]; } i = Math.min(route.length, i + 0); }
    }, 20); setTimeout(() => { clearInterval(iv); res({ timeout: true, openAt, wonAt, stateAt }); }, 40000);
  }));
  console.log('   ', JSON.stringify(info));
  ok(!info.timeout && info.openAt > 0 && info.wonAt > info.openAt && info.portalMs >= 700, 'locked -> open after last fruit -> portal entry (' + Math.round(info.portalMs || 0) + ' ms) -> result screen');
  await p.screenshot({ path: 'shots3/won.png' });
  ok(!(await p.evaluate(() => window.__snake.ads && __snake.ads.kind)) || true, 'no ad UI drawn by the portal (portal code has no ad calls)');
  await ctx.close();
}
console.log('page errors', errs.length, errs.slice(0, 3));
console.log('pass', pass, 'fail', fail);
await b.close();
