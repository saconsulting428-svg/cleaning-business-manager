import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(1200);
await p.evaluate(() => { __snake.camp.unlockAll(); __snake.DATA.coins = 100; });
const solve = (id) => p.evaluate(async (id) => { const S = __snake.camp, COLS = 20, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]]; const c0 = S.C; c0.ready = 0; const route = S.LV[id - 1].R; const t0 = performance.now();
  while (performance.now() - t0 < 60000 && S.C === c0 && !c0.over && !c0.won) { const G = __snake.G, h = G.snake[0][1] * COLS + G.snake[0][0], k = route.indexOf(h); if (k >= 0 && k + 1 < route.length) { const nx = route[k + 1], d = D4.findIndex((v) => v[0] === (nx % COLS) - G.snake[0][0] && v[1] === ((nx / COLS) | 0) - G.snake[0][1]); if (d >= 0 && !(G.dir[0] === D4[d][0] && G.dir[1] === D4[d][1])) G.queue = [D4[d]]; } await new Promise((r) => setTimeout(r, 30)); } return { won: c0.won, over: c0.over, moves: c0.moves, state: __snake.state }; }, id);
// 1. skins
const sk = await p.evaluate(() => ['neonracer', 'obsidian', 'champion'].map((id) => { const o = __snake.G; return id; }));
ok(await p.evaluate(() => { const s = __snake.camp; return typeof s.daily.goals.length === 'number' && s.daily.goals.some((g) => g.skin === 'champion'); }), 'goals with skin rewards exist');
// 2. goals pay once
await p.evaluate(() => { const S = __snake.DATA.camp.stars; for (let i = 1; i <= 25; i++) S[i] = 3; __snake.DATA.skins = ['default']; });
const g0 = await p.evaluate(() => __snake.DATA.coins);
await p.evaluate(() => __snake.camp.daily.check()); await p.evaluate(() => __snake.camp.daily.check());
const g1 = await p.evaluate(() => ({ c: __snake.DATA.coins, skin: __snake.DATA.skins.includes('champion'), cl: Object.keys(__snake.camp.daily.prog.claimed) }));
ok(g1.skin && g1.c - g0 === 30 + 80 + 200 && g1.cl.includes('three25'), 'goals: reached goals pay once (coins +' + (g1.c - g0) + ', champion skin unlocked)');
const bs = await p.evaluate(() => { __snake.DATA.coins = 99999; return __snake.buySkin('obsidian'); }); ok(bs === false, 'special skins cannot be bought with coins');
// 3. daily puzzle: same level & fruit, own progress
await p.evaluate(() => { __snake.DATA.camp.stars = {}; __snake.DATA.camp.unlocked = 3; __snake.camp.sk.reset(); });
const before = await p.evaluate(() => JSON.stringify([__snake.DATA.camp.stars, __snake.DATA.camp.unlocked, __snake.DATA.camp.cur]));
await p.evaluate(() => __snake.camp.daily.start()); await p.waitForTimeout(300);
const d1 = await p.evaluate(() => ({ id: __snake.camp.C.id, F: JSON.stringify(__snake.camp.C.L.F), daily: __snake.camp.C.daily, n: __snake.camp.C.L.F.length }));
await p.evaluate(() => __snake.camp.daily.start()); await p.waitForTimeout(300);
const d2 = await p.evaluate(() => ({ id: __snake.camp.C.id, F: JSON.stringify(__snake.camp.C.L.F) }));
ok(d1.daily && d1.id === d2.id && d1.F === d2.F && d1.id >= 15 && d1.id <= 70, 'daily puzzle: same level ' + d1.id + ' and same fruit every time');
const r = await solve(d1.id);
console.log('   daily result', JSON.stringify(r));
await p.waitForFunction(() => __snake.state === 'won', null, { timeout: 5000 }).catch(() => {});
ok(r.won && await p.evaluate(() => __snake.state === 'won'), 'daily puzzle can be solved');
await p.waitForTimeout(800); await p.screenshot({ path: 'shots3/c_daily.png' });
const after = await p.evaluate(() => JSON.stringify([__snake.DATA.camp.stars, __snake.DATA.camp.unlocked, __snake.DATA.camp.cur]));
const dp = await p.evaluate(() => JSON.parse(JSON.stringify(__snake.camp.daily.prog.dp)));
ok(before === after, 'daily puzzle does not touch campaign progress');
ok(dp.done && dp.streak === 1 && dp.moves > 0, 'daily result saved (streak ' + dp.streak + ', ' + dp.moves + ' moves)');
const coins1 = await p.evaluate(() => __snake.DATA.coins);
// replay: no second reward
await p.evaluate(() => __snake.camp.daily.start()); await p.waitForTimeout(200); await solve(d1.id); await p.waitForTimeout(500);
ok(await p.evaluate(() => __snake.camp.C.won && __snake.camp.C.dpReward === 0), 'daily: no second reward the same day');
// streak continues from yesterday
await p.evaluate(() => { const d = new Date(); d.setDate(d.getDate() - 1); const p = (n) => (n < 10 ? '0' : '') + n; const y = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); const P = __snake.camp.daily.prog.dp; P.date = y; P.last = y; P.done = true; P.streak = 4; });
await p.evaluate(() => __snake.camp.daily.start()); await p.waitForTimeout(200); await solve(d1.id); await p.waitForTimeout(500);
ok(await p.evaluate(() => __snake.camp.daily.prog.dp.streak === 5), 'daily: streak goes 4 -> 5 on the next day');
// 4. expert
await p.evaluate(() => { __snake.DATA.camp.unlocked = 100; __snake.camp.start(5); }); const se = await solve(5);
await p.evaluate(() => { __snake.DATA.coins = 100; __snake.camp.start(5, false, { expert: true }); __snake.camp.C.ready = 0; }); await p.waitForTimeout(300);
ok(await p.evaluate(() => __snake.camp.C.expert === true && !__snake.camp.help.canUndo()), 'expert: no undo');
await p.evaluate(() => { __snake.camp.help.open(); }); await p.waitForTimeout(150);
await p.evaluate(() => __snake.camp.help.hint()); ok(await p.evaluate(() => !__snake.camp.C.route && __snake.DATA.coins === 100), 'expert: no hint');
await p.evaluate(() => { __snake.camp.C.help = false; __snake.state === 'paused' && __snake.camp.help.close(); });
await p.screenshot({ path: 'shots3/c_expert.png' });
// expert too many moves: set moves limit tiny
await p.evaluate(() => { __snake.camp.start(5, false, { expert: true }); const C = __snake.camp.C; C.ready = 0; C.L.s3 = 2; }); await p.waitForTimeout(200);
await solve(5);
ok(await p.evaluate(() => __snake.camp.C.over === 'moves'), 'expert: too many moves fails the level');
await p.evaluate(() => { __snake.camp.start(5, false, { expert: true }); __snake.camp.C.ready = 0; }); const sx = await solve(5);
const exp = await p.evaluate(() => ({ won: __snake.camp.C.won, e: Object.keys(__snake.camp.daily.prog.expert), coins: __snake.camp.C.coins }));
ok(sx.won && exp.e.includes('5') && exp.coins === 3 * (5 + 15) * 1, 'expert: cleared within the limit, x3 coins (' + exp.coins + '), saved');
// 5. screens
await p.evaluate(() => { __snake.camp.home(); }); await p.waitForTimeout(300); await p.screenshot({ path: 'shots3/c_menu.png' });
await p.evaluate(() => { __snake.openSheet(6); }); await p.waitForTimeout(600); await p.screenshot({ path: 'shots3/c_goals.png' });
await p.evaluate(() => { __snake.openSheet(3); }); await p.waitForTimeout(500);
// 6. broken save
await p.evaluate(() => localStorage.setItem('snakeFruitRush.prog.v1', '{{broken'));
await p.reload(); await p.waitForTimeout(1200);
ok(await p.evaluate(() => __snake.camp.daily.prog.dp.streak === 0 && Object.keys(__snake.camp.daily.prog.claimed).length === 0), 'broken progress save is ignored');
console.log('errors', errs.length, errs.slice(0, 3)); console.log('pass', pass, 'fail', fail); await b.close();
