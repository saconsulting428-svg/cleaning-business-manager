import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const file = process.argv[2], lv = +process.argv[3], thr = +process.argv[4];
const b = await chromium.launch({ args: ['--enable-precise-memory-info'] }); const ctx = await b.newContext({ viewport: { width: 412, height: 800 } }); const p = await ctx.newPage();
await p.goto('file://' + process.cwd() + '/' + file); await p.waitForTimeout(1000);
const cdp = await ctx.newCDPSession(p); await p.evaluate(() => __snake.camp.unlockAll());
await cdp.send('Emulation.setCPUThrottlingRate', { rate: thr });
// level start / retry hitch
const hit = await p.evaluate((l) => new Promise((res) => { const out = []; let n = 0, last = performance.now(); const marks = {}; (function f(t) { out.push(t - last); last = t; n++; if (n === 10) { marks.s = n; __snake.camp.start(l); } if (n === 60) { marks.r = n; __snake.camp.retry(); } if (n < 110) requestAnimationFrame(f); else res({ start: Math.max(...out.slice(10, 16)).toFixed(0), retry: Math.max(...out.slice(60, 66)).toFixed(0) }); })(last); }), lv);
await p.waitForTimeout(1500);
await cdp.send('HeapProfiler.enable'); await cdp.send('HeapProfiler.startSampling', { samplingInterval: 512, includeObjectsCollectedByMajorGC: true, includeObjectsCollectedByMinorGC: true });
const r = await p.evaluate(() => new Promise((res) => {
  const sc = snakeGame.scene.scenes[0], gfx = sc.children.list.filter((o) => o.type === 'Graphics'); const dts = []; let last = performance.now(), cmd = 0, cn = 0; const t0 = last;
  (function f(t) { dts.push(t - last); last = t; if (dts.length % 10 === 0) { cmd += gfx.slice(1).reduce((a, o) => a + o.commandBuffer.length, 0); cn++; }
    if (__snake.state !== 'play') __snake.camp.retry();
    if (t - t0 < 8000) requestAnimationFrame(f); else { const s = dts.slice().sort((a, b) => a - b), q = (x) => s[Math.floor(s.length * x)].toFixed(1); res({ fps: (dts.length / 8).toFixed(0), p50: q(0.5), p95: q(0.95), p99: q(0.99), max: s[s.length - 1].toFixed(0), over50: dts.filter((d) => d > 50).length, cmdPerFrame: Math.round(cmd / cn), images: sc.children.list.filter((o) => o.type === 'Image').length }); } })(last);
}));
const { profile } = await cdp.send('HeapProfiler.stopSampling'); let tot = 0; (function w(n) { tot += n.selfSize; n.children.forEach(w); })(profile.head);
console.log(JSON.stringify({ file, lv, cpu: 'x' + thr, ...hit, ...r, allocMBperSec: (tot / 1e6 / 8).toFixed(1) }));
await b.close();
