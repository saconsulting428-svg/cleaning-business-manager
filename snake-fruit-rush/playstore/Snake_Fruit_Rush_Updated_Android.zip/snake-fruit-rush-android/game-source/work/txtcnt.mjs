import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 412, height: 800 } })).newPage();
await p.goto('file://' + process.cwd() + '/' + process.argv[2]); await p.waitForTimeout(1200);
await p.evaluate(() => { __snake.camp.unlockAll(); window.__cnt = 0; const P = Phaser.GameObjects.Text.prototype, o = P.updateText; P.updateText = function () { window.__cnt++; return o.apply(this, arguments); }; });
const step = async (name, fn) => { const c0 = await p.evaluate(() => window.__cnt); await p.evaluate(fn); await p.waitForTimeout(900); const c1 = await p.evaluate(() => window.__cnt); return name + ':' + (c1 - c0); };
const out = [];
out.push(await step('start', () => __snake.camp.start(30)));
for (let i = 1; i <= 3; i++) {
  out.push(await step('fail' + i, () => { const C = __snake.camp.C; C.ready = 0; C.over = 'wall'; C.endT = 0; }));
  out.push(await step('retry' + i, () => __snake.camp.retry()));
}
console.log(process.argv[2], 'text re-renders (900 ms after each event):', out.join('  '), ' pool', await p.evaluate(() => __snake.textPool.join(',')));
await b.close();
