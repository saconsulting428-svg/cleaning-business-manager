import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const file = 'file://' + process.cwd() + '/test.html';
const b = await chromium.launch(); let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
for (const vp of [{ width: 360, height: 640 }, { width: 412, height: 915 }]) {
  const p = await (await b.newContext({ viewport: vp })).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(file); await p.waitForTimeout(900);
  const [cx, cy] = await p.evaluate(() => { const c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + (480 - 96) * c.width / 480, c.top + 39 * c.height / 800]; });
  await p.mouse.click(cx, cy); await p.waitForTimeout(300);
  await p.screenshot({ path: `shots3/settings_${vp.width}.png` });
  ok(errs.length === 0, 'settings opens, no errors @' + vp.width);
  if (vp.width === 412) {
    const r = await p.evaluate(() => {
      const K = __snake.camp.cd, D = __snake.DATA; const d = K.ensure(); __snake.daily.ensure(); const before = JSON.stringify(D.daily);
      const id = d.id, tgt = d.target; K.add(id, tgt); const done = K.ensure().claimed, coins = D.coins;
      return { id, tgt, done, endlessUntouched: JSON.stringify(D.daily) === before && !D.daily.claimed, saved: JSON.parse(localStorage.getItem('snakeFruitRush.v1')).cdaily.claimed };
    });
    ok(r.done && r.endlessUntouched && r.saved, 'campaign daily completes alone, endless daily untouched, saved ' + JSON.stringify(r));
    await p.evaluate(() => { __snake.camp.unlockAll(); __snake.camp.start(3); }); await p.waitForTimeout(300);
    const e = await p.evaluate(() => { const d = __snake.daily.ensure(), p0 = d.progress; __snake.daily.add('fruits', 3); return [p0, d.progress]; });
    ok(e[0] === e[1], 'campaign play does not advance endless daily');
    await p.evaluate(() => { __snake.camp.home(); }); await p.waitForTimeout(300);
    await p.evaluate(() => { __snake.G = null; });
  }
}
console.log('pass', pass, 'fail', fail); await b.close();
