import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const ctx = await b.newContext({ viewport: { width: 480, height: 800 }, deviceScaleFactor: 2 }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(1500);
ok(await p.evaluate(() => !!window.SFR_IMG && ['coin', 'egg', 'wheel'].every((k) => window.snakeGame.textures.exists('img_' + k))), 'coin, egg and wheel pictures are loaded as textures');
await p.screenshot({ path: 'shots3/e_menu.png', clip: { x: 0, y: 0, width: 480, height: 110 } });
await p.evaluate(() => { __snake.DATA.coins = 1000; __snake.DATA.spinDates = []; __snake.openSheet(4); }); await p.waitForTimeout(700);
await p.screenshot({ path: 'shots3/e_gifts_idle.png', clip: { x: 0, y: 290, width: 480, height: 510 } });
await p.evaluate(() => __snake.openEgg()); 
for (const [i, ms] of [[1, 900], [2, 1000], [3, 700], [4, 600]]) { await p.waitForTimeout(ms); await p.screenshot({ path: `shots3/e_egg${i}.png`, clip: { x: 130, y: 370, width: 350, height: 200 } }); }
await p.waitForTimeout(800);
const g1 = await p.evaluate(() => ({ done: __snake.gift.done, skin: __snake.gift.skin, pw: __snake.gift.pw, val: __snake.gift.val }));
ok(g1.done, 'egg finishes: ' + JSON.stringify(g1));
await p.evaluate(() => __snake.doSpin()); await p.waitForTimeout(500); await p.screenshot({ path: 'shots3/e_spin_mid.png', clip: { x: 0, y: 370, width: 250, height: 200 } });
await p.waitForTimeout(2600); await p.screenshot({ path: 'shots3/e_gifts_done.png', clip: { x: 0, y: 290, width: 480, height: 510 } });
// prizes: many eggs give only valid things
const kinds = await p.evaluate(() => { const out = { coin: 0, pw: 0, skin: 0, bad: 0 }; for (let i = 0; i < 300; i++) { __snake.gift = null; __snake.DATA.coins = 1000; const D = __snake.DATA; D.skins = ['default']; const before = JSON.stringify(D.pw); __snake.openEgg(); const gf = __snake.gift; if (!gf) { out.bad++; continue; } if (gf.skin) out.skin++; else if (gf.pw) { out.pw++; if (!(gf.qty >= 1)) out.bad++; } else if (gf.val > 0) out.coin++; else out.bad++; gf.t = 99999; } return out; });
console.log('   300 eggs:', JSON.stringify(kinds)); ok(kinds.bad === 0 && kinds.coin > 0 && kinds.pw > 0 && kinds.skin > 0, 'egg prizes: coins, power-ups and skins all appear');
console.log('errors', errs.length, errs.slice(0, 3)); console.log('pass', pass, 'fail', fail); await b.close();
