const N=require('./levels.json');
const cnt=(s)=>{if(!s)return 0;let n=0;for(const ch of s){let v=parseInt(ch,36);while(v){n+=v&1;v>>=1}}return n};
const f=(id)=>id<=5?3:id<=10?4:id<=20?(id<=15?4:5):id<=30?5:id<=40?(id<=35?5:6):id<=50?6:id<=60?(id<=55?6:7):id<=70?7:id<=80?(id<=75?7:8):8;
const sc=N.map((l,i)=>{const R=l.R;let t=0;for(let j=2;j<R.length;j++)if(R[j]-R[j-1]!==R[j-1]-R[j-2])t++;
 const has=k=>l[k]&&l[k].length&&(typeof l[k]!=='string'||/[^0]/.test(l[k]))?1:0;const mech=has('I')+has('B')+has('K')+has('G')+has('P');
 return {id:i+1,score:Math.round(l.par*0.6+t*2+f(i+1)*4+mech*12+Math.min(typeof l.B==='string'?cnt(l.B):0,20)),par:l.par,t,mech};});
const row=(a,b)=>sc.slice(a-1,b).map(x=>x.id+':'+x.score).join(' ');
console.log(row(1,30));console.log(row(31,50));console.log(row(78,95));
const d=[];for(let i=5;i<sc.length;i++){const avg=sc.slice(i-5,i).reduce((a,x)=>a+x.score,0)/5;if(sc[i].score<avg*0.85)d.push(sc[i].id+'('+sc[i].score+' vs '+Math.round(avg)+')')}console.log('dips<85%:',d.join(' '));
