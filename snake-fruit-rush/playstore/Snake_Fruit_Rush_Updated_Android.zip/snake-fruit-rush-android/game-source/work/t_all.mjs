import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const W = +process.argv[2], NW = +process.argv[3];
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); const errs = [];
p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html?testads=1'); await p.waitForTimeout(2500);
await p.evaluate(() => { __snake.camp.unlockAll(); });
const res = [];
for (let lv = 1 + W; lv <= 100; lv += NW) {
  await p.evaluate((l) => { __snake.camp.sk && __snake.camp.sk.reset && __snake.camp.sk.reset(); __snake.camp.start(l); }, lv);
  await p.waitForTimeout(900);
  let mid = false;
  const r = await p.evaluate(() => new Promise((resolve) => {
    const C = __snake.camp.C; C.ready = 0; const route = C.L.R, COLS = 20, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]];
    let i = 1, t0 = performance.now(), steps = 0, lastHead = -1;
    const iv = setInterval(() => {
      const st = __snake.state;
      if (st === 'won') { clearInterval(iv); resolve({ ok: true, ms: Math.round(performance.now() - t0), steps }); return; }
      if (st === 'over' || st === 'dead' || st === 'gameover' || (st !== 'play' && st !== 'ready' && st !== 'won')) { clearInterval(iv); resolve({ ok: false, why: st, i, len: route.length }); return; }
      const G = __snake.G; if (!G || !G.snake) return; const h = G.snake[0], hc = h[1] * COLS + h[0];
      if (hc !== lastHead) { lastHead = hc; steps++; }
      for (let j = Math.max(0, i - 1); j < Math.min(route.length, i + 30); j++) if (route[j] === hc) { i = j + 1; break; }
      if (i < route.length) { const cur = route[i], d = D4.findIndex((v) => v[0] === (cur % COLS) - h[0] && v[1] === ((cur / COLS) | 0) - h[1]); if (d >= 0) G.queue = [D4[d]]; }
      if (performance.now() - t0 > 80000) { clearInterval(iv); resolve({ ok: false, why: 'timeout', i, len: route.length }); }
    }, 15);
  }));
  res.push([lv, r]);
  console.log(lv, JSON.stringify(r));
}
console.log('errors', errs.length, errs.slice(0, 3)); await b.close();
