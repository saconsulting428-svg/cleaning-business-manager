import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const VPS = [[480, 800], [360, 640], [412, 915], [390, 700]];
const only = process.argv[2] ? [VPS[+process.argv[2]]] : VPS;
const b = await chromium.launch();
const AUDIT = () => {
  const s = __snake.endless.scene, W = s.scale.gameSize.width, H = s.scale.gameSize.height, out = [];
  const list = s.children.list;
  const T = list.filter((o) => o.type === 'Text' && o.visible && o.alpha > 0.05 && o.text && o.parentContainer == null);
  const I = list.filter((o) => o.type === 'Image' && o.visible && o.alpha > 0.3 && o.displayWidth > 2);
  const bb = (o) => o.getBounds();
  const inter = (a, c) => Math.max(0, Math.min(a.right, c.right) - Math.max(a.left, c.left)) * Math.max(0, Math.min(a.bottom, c.bottom) - Math.max(a.top, c.top));
  T.forEach((t) => { const r = bb(t); if (r.left < -1 || r.right > W + 1 || r.top < -1 || r.bottom > H + 1) out.push('OUT ' + JSON.stringify(t.text) + ' ' + [r.left, r.top, r.right, r.bottom].map(Math.round)); });
  for (let i = 0; i < T.length; i++) for (let j = i + 1; j < T.length; j++) {
    const a = bb(T[i]), c = bb(T[j]), ar = inter(a, c);
    if (ar > 10 && !(T[i].text === T[j].text && Math.abs(a.left - c.left) < 3 && Math.abs(a.top - c.top) < 3)) out.push('TXT-OVERLAP ' + JSON.stringify(T[i].text) + ' x ' + JSON.stringify(T[j].text) + ' area ' + Math.round(ar));
  }
  T.forEach((t) => { const r = bb(t), tw = r.width * r.height; I.forEach((im) => { if (im.depth > t.depth) { const c = bb(im), ar = inter(r, c); if (ar > 12 && c.width * c.height < W * H * 0.4) out.push('COVERED ' + JSON.stringify(t.text) + ' by ' + im.texture.key + ' area ' + Math.round(ar) + ' of ' + Math.round(tw)); } }); });
  return out;
};
const results = {};
for (const [vw, vh] of only) {
  const ctx = await b.newContext({ viewport: { width: vw, height: vh } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto('file://' + process.cwd() + '/audit.html?testads=1'); await p.waitForTimeout(2500);
  await p.evaluate(() => { __snake.camp.unlockAll(); __snake.DATA.coins = 1234; const S = __snake.DATA.camp.stars; for (let i = 1; i <= 40; i++) S[i] = (i % 3) + 1; });
  const shot = async (name, pre) => {
    if (pre) await p.evaluate(pre); await p.waitForTimeout(900);
    const o = await p.evaluate(AUDIT); await p.screenshot({ path: `shots_a/${vw}x${vh}_${name}.png` });
    const key = `${vw}x${vh} ${name}`; results[key] = [...new Set(o)]; console.log(key, o.length ? '\n   ' + [...new Set(o)].slice(0, 12).join('\n   ') : 'ok');
  };
  await shot('menu_levels', () => { __snake.endless.theme(1); __snake.DATA.menuMode = 'levels'; });
  await shot('menu_endless', () => { __snake.DATA.menuMode = 'endless'; });
  await shot('menu_levels2', () => { __snake.DATA.menuMode = 'levels'; });
  await p.evaluate(() => { __snake.DATA.menuMode = 'levels'; });
  for (const t of [3, 4, 5, 6, 7]) { await p.evaluate((tt) => __snake.openSheet(tt), t); await shot('sheet' + t); }
  await p.evaluate(() => { __snake.closeSheet(); });
  await shot('settings', () => { const bt = __snake.camp.buttons.find((x) => x.y === 12 && x.h === 56); if (bt) bt.fn(); });

  await p.evaluate(() => { __snake.closeSheet && __snake.closeSheet(); });
  for (const pg of [0, 1, 2, 3, 4]) await shot('map' + pg, () => { __snake.camp.open(); });
  for (const lv of [1, 21, 41, 52, 61, 81, 92, 100]) {
    await p.evaluate((l) => { __snake.camp.start(l); }, lv);
    await shot('lv' + lv + '_ready');
    await p.evaluate(() => { __snake.camp.help.open(); }); await shot('lv' + lv + '_help');
    await p.evaluate(() => { __snake.camp.help.close(); __snake.camp.home(); });
  }
  await p.evaluate(() => { __snake.camp.start(61); }); await p.waitForTimeout(600);
  await shot('lv61_die', () => { const C = __snake.camp.C; C.ready = 0; });
  await p.waitForTimeout(4000); await shot('lv61_over');
  await p.evaluate(() => { __snake.camp.home(); });
  await shot('end_play', () => { __snake.endless.theme(0); __snake.endless.start(); });
  await p.waitForTimeout(6000); await shot('end_over');
  await p.evaluate(() => { __snake.camp.home(); });

  await p.close(); await ctx.close();
  console.log('page errors', errs.length, errs.slice(0, 3));
}
await b.close();
