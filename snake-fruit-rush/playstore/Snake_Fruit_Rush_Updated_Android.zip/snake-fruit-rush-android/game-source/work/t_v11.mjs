import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html?testads=1'); await p.waitForTimeout(1200);
await p.evaluate(() => { __snake.camp.unlockAll(); __snake.DATA.coins = 500; __snake.camp.sk.reset(); });
const run = (n) => p.evaluate(async (n) => { const S = __snake.camp, COLS = 20, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]]; const c0 = S.C; c0.ready = 0; let steps = 0;
  while (steps < n && S.C === c0 && !c0.over && !c0.won) { const route = S.LV[c0.id - 1].R, G = __snake.G, h = G.snake[0][1] * COLS + G.snake[0][0], k = route.indexOf(h); if (k >= 0 && k + 1 < route.length) { const nx = route[k + 1], d = D4.findIndex((v) => v[0] === (nx % COLS) - G.snake[0][0] && v[1] === ((nx / COLS) | 0) - G.snake[0][1]); if (d >= 0) G.queue = [D4[d]]; } const m0 = c0.moves; await new Promise((r) => setTimeout(r, 40)); if (c0.moves !== m0) steps++; } return c0.moves; }, n);
// Undo in play
await p.evaluate(() => __snake.camp.start(9)); await p.waitForTimeout(300);
const m1 = await run(12);
const co = await p.evaluate(() => __snake.DATA.coins);
await p.evaluate(() => { __snake.camp.help.open(); }); await p.waitForTimeout(200);
ok(await p.evaluate(() => __snake.state === 'paused' && __snake.camp.C.help === 'menu'), '"?" opens the Help menu');
await p.screenshot({ path: 'shots3/b_menu.png' });
await p.evaluate(() => __snake.camp.help.undo()); await p.waitForTimeout(300);
const r1 = await p.evaluate(() => ({ s: __snake.state, m: __snake.camp.C.moves, c: __snake.DATA.coins }));
ok(r1.s === 'play' && r1.m === m1 - 1 && r1.c === co - 30, 'Undo: one move back, 30 coins paid (' + m1 + ' -> ' + r1.m + ', coins ' + co + ' -> ' + r1.c + ')');
// coins for fruit not paid twice
const cA = await p.evaluate(() => { const S = __snake.camp, C = S.C; return { paid: C.paid.size, eaten: __snake.G.eaten }; });
console.log('   ', JSON.stringify(cA));
// Hint
await p.evaluate(() => { __snake.camp.help.open(); }); await p.waitForTimeout(150);
await p.evaluate(() => __snake.camp.help.hint()); await p.waitForTimeout(250);
ok(await p.evaluate((c) => __snake.state === 'play' && !!__snake.camp.C.route && __snake.camp.C.hintMax === 12 && __snake.DATA.coins === c - 40, r1.c), 'Hint: next steps shown, 40 coins paid');
await p.screenshot({ path: 'shots3/b_hint.png' });
// Skip (two taps)
await p.evaluate(() => { __snake.camp.start(9); __snake.DATA.camp.unlocked = 9; __snake.DATA.coins = 1000; __snake.camp.C.ready = 0; __snake.camp.help.open(); }); await p.waitForTimeout(150);
await p.evaluate(() => __snake.camp.help.skip()); const still = await p.evaluate(() => __snake.camp.C.id);
await p.evaluate(() => __snake.camp.help.skip()); await p.waitForTimeout(300);
const sk = await p.evaluate(() => ({ id: __snake.camp.C.id, unlocked: __snake.DATA.camp.unlocked, coins: __snake.DATA.coins }));
ok(still === 9 && sk.id === 10 && sk.unlocked >= 10 && sk.coins === 1000 - 500, 'Skip: needs a second tap, then level 10 starts, 500 coins paid');
// Undo after a fatal move
await p.evaluate(() => { __snake.camp.start(9); __snake.DATA.coins = 500; __snake.camp.C.ready = 0; }); await p.waitForTimeout(300);
await p.evaluate(async () => { const G = __snake.G, C = __snake.camp.C; for (let i = 0; i < 80 && !C.over; i++) { G.queue = [[0, -1]]; await new Promise((r) => setTimeout(r, 120)); } });
await p.waitForFunction(() => __snake.state === 'over', null, { timeout: 15000 });
const hasU = await p.evaluate(() => __snake.camp.help.canUndo());
await p.screenshot({ path: 'shots3/b_fail.png' });
await p.evaluate(() => __snake.camp.help.undo()); await p.waitForTimeout(300);
ok(hasU && await p.evaluate(() => __snake.state === 'play' && !__snake.camp.C.over), 'Undo after dying: back to play before the fatal move');
// win -> double coins ad
await p.evaluate(() => { __snake.camp.start(2); __snake.camp.C.ready = 0; }); await p.waitForTimeout(200);
await run(400);
await p.waitForFunction(() => __snake.state === 'won', null, { timeout: 30000 }); await p.waitForTimeout(900);
await p.screenshot({ path: 'shots3/b_won.png' });
const w0 = await p.evaluate(() => ({ c: __snake.DATA.coins, r: __snake.camp.C.coins }));
await p.evaluate(() => { const C = __snake.camp.C; }); 
const [cx, cy] = await p.evaluate(() => { const B = __snake.camp.buttons, bt = B[B.length - 4], c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + (bt.x + bt.w / 2) * c.width / 480, c.top + (bt.y + bt.h / 2) * c.height / 800]; });
await p.mouse.click(cx, cy); await p.waitForTimeout(5200);
const w1 = await p.evaluate(() => ({ c: __snake.DATA.coins, s: __snake.state, d: __snake.camp.C.doubled }));
console.log('   w1', JSON.stringify(w1)); await p.screenshot({ path: 'shots3/b_won2.png' }); ok(w1.s === 'won' && w1.d === true && w1.c === w0.c + w0.r, 'Win: rewarded ad pays the level reward a second time (' + w0.c + ' -> ' + w1.c + ', +' + w0.r + ')');

// B6: interstitial rules (fresh player: none; after a struggle: none; otherwise one)
await p.evaluate(() => { __snake.camp.start(9); });
const ads = await p.evaluate(() => { const A = __snake.ads, out = {}; const probe = () => { A.meta.levels = 3; A.meta.last = 0; let called = false; A.maybeInter('level', () => { called = true; }); const st = __snake.state; return { called, st }; };
  __snake.DATA.camp.stars = {}; out.fresh = probe(); if (__snake.state === 'ad') { __snake.ads.meta.last = 0; }
  return out; });
console.log('   fresh player:', JSON.stringify(ads.fresh));
ok(ads.fresh.st !== 'ad' && ads.fresh.called === true, 'B6: no interstitial before 3 levels are cleared');
await p.evaluate(() => { __snake.DATA.camp.stars = { 1: 3, 2: 3, 3: 3 }; __snake.camp.C.fails = 2; });
const hard = await p.evaluate(() => { const A = __snake.ads; A.meta.levels = 3; A.meta.last = 0; let called = false; A.maybeInter('level', () => { called = true; }); return { called, st: __snake.state }; });
ok(hard.st !== 'ad' && hard.called === true, 'B6: no interstitial right after a struggle (2+ fails)');
await p.evaluate(() => { __snake.camp.C.fails = 0; });
const norm = await p.evaluate(() => { const A = __snake.ads; A.meta.levels = 3; A.meta.last = 0; A.maybeInter('level', () => {}); return __snake.state; });
ok(norm === 'ad', 'B6: a normal level result still shows the interstitial (state ' + norm + ')');

console.log('errors', errs.length, errs.slice(0, 2)); console.log('pass', pass, 'fail', fail); await b.close();
