import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); let pass = 0, fail = 0; const errs = [];
const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const p = await (await b.newContext({ viewport: { width: 480, height: 800 } })).newPage(); p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(900);
const click = async (x, y) => { const [cx, cy] = await p.evaluate(([x, y]) => { const c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + x * c.width / 480, c.top + y * c.height / 800]; }, [x, y]); await p.mouse.click(cx, cy); };
await p.evaluate(() => __snake.camp.unlockAll());
const sp = (F) => F.every((a, i) => F.every((c, j) => i === j || Math.max(Math.abs(a[0] - c[0]), Math.abs(a[1] - c[1])) >= 2));
const r = await p.evaluate(() => {
  const out = { bad: 0, same: 0, diff: 0, n: 0 }; const LV = __snake.camp.LV;
  LV.forEach((L, i) => {
    __snake.camp.start(i + 1); const f0 = JSON.stringify(__snake.camp.C.L.F);
    for (let k = 0; k < 3; k++) { __snake.camp.retry(); if (JSON.stringify(__snake.camp.C.L.F) === f0) out.same++; else out.diff++; }
    const F = __snake.camp.C.L.F; out.n++;
    if (!F.every((a, ii) => F.every((c, j) => ii === j || Math.max(Math.abs(a[0] - c[0]), Math.abs(a[1] - c[1])) >= 2))) out.bad++;
    // route still wins: fruits all on route

  });
  return out;
});
ok(r.diff === 0 && r.same === 300, 'same fruit places on every retry (' + r.same + ' same, ' + r.diff + ' different)');
ok(r.bad === 0, 'no touching/diagonal fruit in all ' + r.n + ' levels');
const f1 = await p.evaluate(() => { __snake.camp.start(37); return JSON.stringify(__snake.camp.C.L.F); });
await p.reload(); await p.waitForTimeout(900);
const f2 = await p.evaluate(() => { __snake.camp.start(37); return JSON.stringify(__snake.camp.C.L.F); });
ok(f1 === f2, 'same fruit places after app restart');
await p.evaluate(() => { localStorage.setItem('snakeFruitRush.fruit.v1', '{{bad'); __snake.camp.start(5); });
ok(await p.evaluate(() => __snake.camp.C.L.F.length === 3), 'corrupt fruit save handled');
// Coming soon
await p.evaluate(() => { __snake.camp.home(); __snake.camp.open(); }); await p.waitForTimeout(300);
for (let i = 0; i < 5; i++) { await click(480 - 20 - 28 - 4, 148); await p.waitForTimeout(150); }
await p.screenshot({ path: 'shots3/soon.png' });
await click(240, 722); await p.waitForTimeout(200);
ok(await p.evaluate(() => __snake.state === 'levels'), 'World 6 is locked, nothing starts');
// skins
await p.evaluate(() => { __snake.camp.home(); }); await p.waitForTimeout(300); await click(100, 738); await p.waitForTimeout(500);
await p.screenshot({ path: 'shots3/skins.png' });
ok(errs.length === 0, 'no page errors ' + errs.slice(0, 2));
console.log('pass', pass, 'fail', fail); await b.close();
