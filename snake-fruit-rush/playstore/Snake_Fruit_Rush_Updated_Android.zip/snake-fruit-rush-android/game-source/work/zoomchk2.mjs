import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
for (const [w, h, d, mem, cores, lbl] of [[393, 851, 2.75, 8, 8, '1080x2400 phone, good'], [393, 851, 2.75, 2, 8, '1080x2400 phone, 3GB (reports 2)'], [360, 800, 2, 2, 8, '720x1600, 3GB'], [412, 915, 3.5, 8, 8, '1440p flagship']]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: d }); const p = await ctx.newPage();
  await p.addInitScript(([m, c]) => { Object.defineProperty(navigator, 'deviceMemory', { get: () => m }); Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => c }); }, [mem, cores]);
  await p.goto('file://' + process.cwd() + '/test.html?webgl=1'); await p.waitForTimeout(1500);
  console.log(lbl, JSON.stringify(await p.evaluate(() => ({ renderer: snakeGame.renderer.type === 2 ? 'webgl' : 'canvas', canvas: document.querySelector('canvas').width + 'x' + document.querySelector('canvas').height })))); await ctx.close();
}
await b.close();
