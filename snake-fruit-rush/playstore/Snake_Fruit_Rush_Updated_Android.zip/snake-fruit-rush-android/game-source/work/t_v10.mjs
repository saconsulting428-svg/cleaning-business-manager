import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
await p.addInitScript(() => { window.__forceTips = true; });
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(1200);
const click = async (x, y) => { const [cx, cy] = await p.evaluate(([x, y]) => { const c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + x * c.width / 480, c.top + y * c.height / 800]; }, [x, y]); await p.mouse.click(cx, cy); };
await p.evaluate(() => __snake.camp.unlockAll());
// 1. very first level: the card opens by itself and the game waits
await p.evaluate(() => __snake.camp.start(1)); await p.waitForTimeout(700);
ok(await p.evaluate(() => __snake.state === 'paused' && __snake.camp.C.help === true), 'first level: how-to-play card opens by itself');
await p.screenshot({ path: 'shots3/h_first.png' });
const mv = await p.evaluate(() => __snake.camp.C.moves); await p.waitForTimeout(800);
ok(await p.evaluate((m) => __snake.camp.C.moves === m && __snake.camp.C.ready > 0, mv), 'game does not run while the card is open');
await click(240, 800 - 140);   // Got it (approx; located by search below if wrong)
const closed = await p.evaluate(() => __snake.state);
if (closed !== 'play') { const ys = []; for (let y = 560; y < 760; y += 10) { await click(240, y); await p.waitForTimeout(150); if (await p.evaluate(() => __snake.state) === 'play') { ys.push(y); break; } } }
ok(await p.evaluate(() => __snake.state === 'play' && __snake.camp.C.help === false), 'Got it! resumes the game');
ok(await p.evaluate(() => __snake.camp.help.seen.size >= 3 && JSON.parse(localStorage.getItem('snakeFruitRush.tips.v1')).length >= 3), 'seen tips are saved');
// 2. retry / same things: no auto card again
await p.evaluate(() => __snake.camp.retry()); await p.waitForTimeout(400);
ok(await p.evaluate(() => __snake.state === 'play'), 'retry does not open the card again');
// 3. new mechanic: ice level shows card with NEW for ice only
await p.evaluate(() => __snake.camp.start(49)); await p.waitForTimeout(700);
ok(await p.evaluate(() => __snake.state === 'paused' && __snake.camp.help.items(__snake.camp.C.L).some((i) => i.id === 'ice')), 'ice level: card opens (ice is new)');
await p.screenshot({ path: 'shots3/h_ice.png' });
await p.evaluate(() => __snake.camp.help.close()); await p.waitForTimeout(200);
// 4. ? button during play, level with every mechanic
await p.evaluate(() => { __snake.camp.start(100); }); await p.waitForTimeout(500);
await p.evaluate(() => __snake.camp.help.close()); await p.waitForTimeout(300);
await click(480 - 20 - 78, 718); await p.waitForTimeout(500);
ok(await p.evaluate(() => __snake.state === 'paused' && __snake.camp.C.help === 'menu'), '"?" button opens the Help menu during play');
await p.screenshot({ path: 'shots3/h_all.png' });
await p.evaluate(() => __snake.camp.help.close()); await p.waitForTimeout(200);
ok(await p.evaluate(() => __snake.state === 'play'), 'closing resumes');
await p.screenshot({ path: 'shots3/h_play.png' });
console.log('errors', errs.length, errs.slice(0, 2)); console.log('pass', pass, 'fail', fail); await b.close();
