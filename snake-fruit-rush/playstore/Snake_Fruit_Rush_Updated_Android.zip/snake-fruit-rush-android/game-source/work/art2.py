import numpy as np, base64, io, json
from PIL import Image
IM='/tmp/claude-0/-home-user-cleaning-business-manager/bf3a6e12-153d-500c-9dc9-390f424ff5b1/images/%d.webp'
def key(path):
    a=np.asarray(Image.open(path).convert('RGB')).astype(np.float32)
    r,g,b=a[...,0],a[...,1],a[...,2]
    m=np.minimum(r,b)-g                      # how magenta
    al=np.clip(1-(m-60)/150,0,1)             # 255->0, <60 ->1
    al[(m<60)]=1
    out=a.copy(); mag=np.array([255,0,255],np.float32)
    k=(al>0.02)&(al<0.98)
    for c in range(3):
        ch=out[...,c]; ch[k]=np.clip((a[...,c][k]-(1-al[k])*mag[c])/al[k],0,255); out[...,c]=ch
    return np.dstack([out,al*255]).astype(np.uint8)
def spans(mask,gap=6):
    idx=np.where(mask)[0]; res=[]; s=p=None
    for i in idx:
        if s is None: s=p=i
        elif i-p>gap: res.append((s,p)); s=p=i
        else: p=i
    if s is not None: res.append((s,p))
    return res
def crops(rgba,rows):
    al=rgba[...,3]>40; out=[]
    for (y0,y1) in rows:
        cols=spans(al[y0:y1].any(0))
        for (x0,x1) in cols:
            sub=al[y0:y1,x0:x1+1]; ys=np.where(sub.any(1))[0]
            out.append(rgba[y0+ys[0]:y0+ys[-1]+1,x0:x1+1])
    return out
def enc(arr,maxd):
    im=Image.fromarray(arr,'RGBA'); s=maxd/max(im.size); im=im.resize((max(1,round(im.width*s)),max(1,round(im.height*s))),Image.LANCZOS)
    b=io.BytesIO(); im.save(b,'WEBP',quality=88,method=6); return 'data:image/webp;base64,'+base64.b64encode(b.getvalue()).decode(),im
sn=key(IM%50); fl=key(IM%51)
H=sn.shape[0]; al=sn[...,3]>40; rs=spans(al.any(1),20); print('snake rows',rs)
sp=crops(sn,rs); print(len(sp),[p.shape[:2] for p in sp])
names=['snake_head','snake_body','snake_body_alt','snake_tail_1','snake_tail_2','snake_tail_tip','snake_link','snake_shine']
rs2=spans((fl[...,3]>40).any(1),20); print('floor rows',rs2)
fp=crops(fl,rs2); print(len(fp),[p.shape[:2] for p in fp])
fn=[]
for row in ('a','b'):
    for w in ['garden','desert','ice','volcano','night']: fn.append('floor_%s_%s'%(w,row))
d={}; prev=Image.new('RGB',(1400,500),(70,110,70)); x=0
for nm,arr in list(zip(names,sp))+list(zip(fn,fp)):
    s,im=enc(arr,128 if nm.startswith('snake') else 96); d[nm]=s
open('assets_ui2.js','w').write('Object.assign(window.SFR_UI = window.SFR_UI || {}, '+json.dumps(d)+');\n')
# preview
pv=Image.new('RGB',(18*80,100),(70,110,70))
for i,(nm,arr) in enumerate(list(zip(names,sp))+list(zip(fn,fp))):
    im=Image.fromarray(arr,'RGBA'); im.thumbnail((76,76)); pv.paste(im,(i*80,10),im)
pv.save('shots3/art2_prev.png'); print(len(open('assets_ui2.js').read()))
