from PIL import Image, ImageDraw
import numpy as np, base64, io, json, os
S='/tmp/claude-0/-home-user-cleaning-business-manager/bf3a6e12-153d-500c-9dc9-390f424ff5b1/scratchpad/sheets/'
SHEETS={
 'sheet1_frames.png':(5,2,['btn_pill','btn_round','btn_square','panel_big','panel_card','tabbar_pill','hud_pill','tile_open','tile_locked','bar_frame']),
 'sheet2_menu_icons.png':(5,2,['icon_skins','icon_shop','icon_gifts','icon_daily','icon_goals','icon_coins','icon_help','icon_undo','icon_hint','icon_skip']),
 'sheet3_system_icons.png':(5,2,['glyph_play','glyph_retry','glyph_next','glyph_home','glyph_pause','glyph_settings','glyph_sound_on','glyph_sound_off','glyph_close','glyph_back']),
 'sheet4_badges_powerups.png':(5,2,['star_full','star_empty','lock','tick','badge_new','pw_slow','pw_shield','pw_defuse','pw_double','sparkle']),
 'sheet5_packs.png':(3,1,['pack_small','pack_medium','pack_big']),
}
MAXD={'btn_pill':300,'btn_round':200,'btn_square':220,'panel_big':320,'panel_card':320,'tabbar_pill':300,'hud_pill':260,'tile_open':200,'tile_locked':200,'bar_frame':300}
os.makedirs('ui_src',exist_ok=True)
out={}; meta={}
def process(im):
    rgb=im.convert('RGB'); H,W=rgb.size[1],rgb.size[0]
    work=rgb.copy(); mark=(255,0,255)
    for pt in ((0,0),(W-1,0),(0,H-1),(W-1,H-1)): ImageDraw.floodfill(work,pt,mark,thresh=22)
    a=np.array(work); bg=(a[...,0]==255)&(a[...,1]==0)&(a[...,2]==255)
    return np.array(rgb).astype(np.float32), bg
def components(bg, n):
    best=None
    for it in (1,2,3,4,5,6):
        bx=components_it(bg,n,it)
        if len(bx)==n and sum(1 for _ in bx)==n:
            return bx
        best=bx if best is None or abs(len(bx)-n)<abs(len(best)-n) else best
    return best
def components_it(bg, n, iters):
    """bounding boxes (x0,y0,x1,y1) of the n biggest objects, merged when parts are close together"""
    H,W=bg.shape; k=4; m=~bg
    sm=m[:H//k*k,:W//k*k].reshape(H//k,k,W//k,k).any(axis=(1,3))
    d=sm.copy()
    for _ in range(iters):
        e=d.copy(); e[1:]|=d[:-1]; e[:-1]|=d[1:]; e[:,1:]|=d[:,:-1]; e[:,:-1]|=d[:,1:]; d=e
    lab=np.zeros(d.shape,int); cur=0; hh,ww=d.shape
    for y in range(hh):
        for x in range(ww):
            if d[y,x] and lab[y,x]==0:
                cur+=1; st=[(y,x)]; lab[y,x]=cur
                while st:
                    cy,cx=st.pop()
                    for ny,nx in ((cy+1,cx),(cy-1,cx),(cy,cx+1),(cy,cx-1)):
                        if 0<=ny<hh and 0<=nx<ww and d[ny,nx] and lab[ny,nx]==0: lab[ny,nx]=cur; st.append((ny,nx))
    boxes=[]
    for i in range(1,cur+1):
        ys,xs=np.where((lab==i)&sm)
        if len(xs)<60: continue
        boxes.append((len(xs),xs.min()*k,ys.min()*k,(xs.max()+1)*k,(ys.max()+1)*k))
    boxes=sorted(boxes,reverse=True)
    if len(boxes)>n and iters<6: return [bx[1:] for bx in boxes]
    return [bx[1:] for bx in boxes[:n]]
def runs(profile, gap):
    idx=np.where(profile)[0]
    if len(idx)==0: return []
    out=[]; st=idx[0]; pv=idx[0]
    for i in idx[1:]:
        if i-pv>gap: out.append((st,pv+1)); st=i
        pv=i
    out.append((st,pv+1)); return out
def project(bg, rows, cols):
    H,W=bg.shape; m=~bg; boxes=[]
    rr=None
    for g in (40,30,24,18,14,10):
        rr=runs(m.any(axis=1),g)
        if len(rr)==rows: break
    if len(rr)!=rows:                                   # split by halves
        rr=[(int(i*H/rows),int((i+1)*H/rows)) for i in range(rows)]
    for (y0,y1) in rr:
        cr=None
        for g in (6,10,14,20,28,40):
            cr=runs(m[y0:y1].any(axis=0),g)
            if len(cr)==cols: break
        if len(cr)!=cols: print('WARN cols',len(cr),cols); cr=[(int(i*W/cols),int((i+1)*W/cols)) for i in range(cols)]
        for (x0,x1) in cr:
            ys=np.where(m[y0:y1,x0:x1].any(axis=1))[0]
            boxes.append((x0,y0+ys.min(),x1,y0+ys.max()+1))
    return boxes
for fn,(cols,rows,names) in SHEETS.items():
    rgb,bg=process(Image.open(S+fn)); H,W=bg.shape
    ordered=project(bg,rows,cols)
    for idx,name in enumerate(names):
        if idx>=len(ordered): print('MISSING',name); continue
        x0,y0,x1,y1=ordered[idx]; x0,y0=0,0
        bx0,by0,bx1,by1=ordered[idx]
        x0,y0=0,0
        bx0,by0,bx1,by1=max(0,bx0-3),max(0,by0-3),min(W,bx1+3),min(H,by1+3)
        sub=rgb[by0:by1,bx0:bx1]; sbg=bg[by0:by1,bx0:bx1]
        alpha=np.where(sbg,0.0,1.0)
        near=np.zeros_like(sbg)                                  # pixels touching the background: soft edge, no white halo
        near[1:]|=sbg[:-1]; near[:-1]|=sbg[1:]; near[:,1:]|=sbg[:,:-1]; near[:,:-1]|=sbg[:,1:]
        mn=sub.min(axis=2); soft=np.clip((255-mn)/70.0,0,1)
        alpha=np.where(near&~sbg,np.maximum(soft,0.35),alpha)
        col=np.where(alpha[...,None]>0,(sub-255*(1-alpha[...,None]))/np.maximum(alpha[...,None],0.35),sub)
        rgba=np.dstack([np.clip(col,0,255),alpha*255]).astype(np.uint8)
        im=Image.fromarray(rgba,'RGBA'); md=MAXD.get(name,180); sc=min(1,md/max(im.size)); 
        if sc<1: im=im.resize((max(1,int(im.width*sc)),max(1,int(im.height*sc))),Image.LANCZOS)
        im.save('ui_src/'+name+'.png'); buf=io.BytesIO(); im.save(buf,'WEBP',quality=88,method=4)
        out[name]='data:image/webp;base64,'+base64.b64encode(buf.getvalue()).decode(); meta[name]=(im.width,im.height,len(buf.getvalue())//1024)
for k,v in meta.items(): print(k,v)
open('assets_ui.js','w').write('window.SFR_UI = '+json.dumps(out)+';\n')
print('total KB',sum(len(v) for v in out.values())//1024)
# preview board
bd=Image.new('RGBA',(1500,700),(40,70,50,255)); x=10;y=10; rowh=0
for n in meta:
    im=Image.open('ui_src/'+n+'.png')
    if x+im.width>1490: x=10; y+=rowh+10; rowh=0
    bd.alpha_composite(im,(x,y)); x+=im.width+10; rowh=max(rowh,im.height)
bd.save('shots3/ui_preview.png')
