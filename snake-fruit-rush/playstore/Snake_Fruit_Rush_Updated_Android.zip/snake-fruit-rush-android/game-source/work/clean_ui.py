import re,base64,io,sys
import numpy as np
from PIL import Image
from collections import deque
SKIP=('btn_','panel_','tabbar','hud_pill','tile_','bar_frame','wall_','portal_','exit_','ice_floor','floor_','snake_','sparkle')
def comps(mask):
    h,w=mask.shape; lab=np.zeros((h,w),np.int32); n=0; sizes=[]
    for y in range(h):
        for x in range(w):
            if mask[y,x] and not lab[y,x]:
                n+=1; q=deque([(y,x)]); lab[y,x]=n; c=0
                while q:
                    cy,cx=q.popleft(); c+=1
                    for dy in (-1,0,1):
                        for dx in (-1,0,1):
                            ny,nx=cy+dy,cx+dx
                            if 0<=ny<h and 0<=nx<w and mask[ny,nx] and not lab[ny,nx]: lab[ny,nx]=n; q.append((ny,nx))
                sizes.append(c)
    return lab,sizes
src=open('assets_ui.js').read()
def fix(m):
    name,b64=m.group(1),m.group(2)
    if name.startswith(SKIP): return m.group(0)
    im=Image.open(io.BytesIO(base64.b64decode(b64))).convert('RGBA'); a=np.array(im)
    mask=a[...,3]>30; lab,sz=comps(mask)
    if not sz: return m.group(0)
    big=int(np.argmax(sz))+1; ys,xs=np.where(lab==big); bb=(xs.min()-3,ys.min()-3,xs.max()+3,ys.max()+3)
    keep=np.zeros_like(mask)
    removed=0
    for i,s in enumerate(sz,1):
        yy,xx=np.where(lab==i)
        inside = xx.min()>=bb[0] and xx.max()<=bb[2] and yy.min()>=bb[1] and yy.max()<=bb[3]
        if i==big or inside or s>=0.12*sz[big-1]: keep|=(lab==i)
        else: removed+=s
    if removed==0: return m.group(0)
    # also clear the soft semi-transparent fringe next to removed pieces
    dil=keep.copy()
    for _ in range(3): dil=dil|np.roll(dil,1,0)|np.roll(dil,-1,0)|np.roll(dil,1,1)|np.roll(dil,-1,1)
    a[...,3]=np.where(dil,a[...,3],0)
    ys,xs=np.where(a[...,3]>0); out=Image.fromarray(a[ys.min():ys.max()+1,xs.min():xs.max()+1],'RGBA')
    b=io.BytesIO(); out.save(b,'WEBP',quality=92,method=6)
    print('cleaned',name,im.size,'->',out.size,'removed px',removed)
    return '"%s": "data:image/webp;base64,%s"'%(name,base64.b64encode(b.getvalue()).decode())
new=re.sub(r'"([a-z_0-9]+)": "data:image/webp;base64,([^"]+)"',fix,src)
open('assets_ui.js','w').write(new)
