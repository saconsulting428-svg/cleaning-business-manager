import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const ctx = await b.newContext({ viewport: { width: 480, height: 800 } }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html?testads=1'); await p.waitForTimeout(1300);
const click = async (x, y) => { const [cx, cy] = await p.evaluate(([x, y]) => { const c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + x * c.width / 480, c.top + y * c.height / 800]; }, [x, y]); await p.mouse.click(cx, cy); };
await p.evaluate(() => { __snake.DATA.coins = 7; __snake.DATA.adCoins = null; });
await click(480 - 20 - 118 - 40, 39); await p.waitForTimeout(800);   // tap the coin pill
ok(await p.evaluate(() => __snake.DATA.tab === 7), 'tapping the coins in the menu opens the coin store');
await p.screenshot({ path: 'shots3/f_store.png' });
const [bx, by] = await p.evaluate(() => { const B = __snake.camp.buttons; const bt = B.find((q) => q.w === 320 && q.h >= 40); return bt ? [bt.x + bt.w / 2, bt.y + bt.h / 2] : null; }) || [];
ok(!!bx, 'a "Watch ad" button is on the store');
await click(bx, by); await p.waitForTimeout(5200);
ok(await p.evaluate(() => __snake.DATA.coins === 107 && __snake.ads.coinsLeft() === 4), 'first ad pays 100 and the ladder moves on (coins ' + await p.evaluate(() => __snake.DATA.coins) + ')');
await p.evaluate(() => __snake.openSheet(7)); await p.waitForTimeout(600);
await click(240, 500 - 20 + 0); // anywhere harmless
await p.screenshot({ path: 'shots3/f_store2.png' });
console.log('errors', errs.length, errs.slice(0, 3)); console.log('pass', pass, 'fail', fail); await b.close();
