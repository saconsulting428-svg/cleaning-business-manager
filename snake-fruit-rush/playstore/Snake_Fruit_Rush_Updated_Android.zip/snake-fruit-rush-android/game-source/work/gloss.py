_a = """    g.lineStyle(15, C(lineCol), 1);
    g.beginPath();
    g.moveTo(pts[n - 1].x, pts[n - 1].y);
    for (let i = n - 2; i >= 0; i--) {
      const far = Math.abs(pts[i].x - pts[i + 1].x) + Math.abs(pts[i].y - pts[i + 1].y) > CELL * 1.7;
      if (far) g.moveTo(pts[i].x, pts[i].y);     // wrapped through a wall
      else g.lineTo(pts[i].x, pts[i].y);
    }
    g.strokePath();"""
_b = """    const bodyPath = (w, col, al) => {
      g.lineStyle(w, C(col), al);
      g.beginPath();
      g.moveTo(pts[n - 1].x, pts[n - 1].y);
      for (let i = n - 2; i >= 0; i--) {
        const far = Math.abs(pts[i].x - pts[i + 1].x) + Math.abs(pts[i].y - pts[i + 1].y) > CELL * 1.7;
        if (far) g.moveTo(pts[i].x, pts[i].y);     // wrapped through a wall
        else g.lineTo(pts[i].x, pts[i].y);
      }
      g.strokePath();
    };
    bodyPath(18, shade(lineCol, -0.62), 0.85);       // dark outline
    bodyPath(15, lineCol, 1);"""
_c = """    for (let i = n - 1; i >= 1; i--) {
      const fromTail = n - 1 - i;
      const r = fromTail < 3 ? [6, 7.5, 9][fromTail] : 10.5;
      dot(pts[i].x, pts[i].y, r, segColor(sk, i, n));"""
_d = """    const segR = (i) => { const ft = n - 1 - i; return ft < 3 ? [6, 7.5, 9][ft] : 10.5; };
    for (let i = n - 1; i >= 1; i--) dot(pts[i].x, pts[i].y, segR(i) + 1.5, shade(segColor(sk, i, n), -0.6), 0.9);   // outline pass
    for (let i = n - 1; i >= 1; i--) {
      const r = segR(i);
      dot(pts[i].x, pts[i].y, r, segColor(sk, i, n));
      dot(pts[i].x - r * 0.18, pts[i].y - r * 0.2, r * 0.7, shade(segColor(sk, i, n), 0.28), 0.55);
      dot(pts[i].x - r * 0.36, pts[i].y - r * 0.42, r * 0.26, '#ffffff', 0.7);"""
for a, b in ((_a, _b), (_c, _d)):
    assert s.count(a) == 1, a[:40]
    s = s.replace(a, b, 1)
# bigger item pictures + inner shadow on the baked board
