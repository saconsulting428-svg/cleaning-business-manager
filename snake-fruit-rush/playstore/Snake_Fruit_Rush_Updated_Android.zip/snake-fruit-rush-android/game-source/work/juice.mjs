import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 480, height: 800 }, deviceScaleFactor: 1 }); const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.addInitScript(() => { try { if (!localStorage.getItem('snakeFruitRush.album.v1')) localStorage.setItem('snakeFruitRush.album.v1', JSON.stringify({ apple: 25, orange: 5, cherry: 70, grapes: 160, strawberry: 320 })); } catch (e) {} });
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(1200);
const click = async (x, y) => { const [cx, cy] = await p.evaluate(([x, y]) => { const c = document.querySelector('canvas').getBoundingClientRect(); return [c.left + x * c.width / 480, c.top + y * c.height / 800]; }, [x, y]); await p.mouse.click(cx, cy); };
await p.screenshot({ path: 'shots3/j_menu.png' });
await click(354, 738); await p.waitForTimeout(700); await p.screenshot({ path: 'shots3/j_album.png' });
await click(240, 540); await p.waitForTimeout(300);   // Done (approx)
await p.evaluate(() => { __snake.camp.unlockAll(); __snake.camp.start(9); });
await p.evaluate(() => { const S = __snake.camp, COLS = 20, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]]; window.__bot = setInterval(() => { const c = S.C; if (!c || c.won || c.over || __snake.state !== 'play') return; if (c.ready > 0) c.ready = 0; const route = S.LV[c.id - 1].R, G = __snake.G, h = G.snake[0][1] * COLS + G.snake[0][0], k = route.indexOf(h); if (k < 0 || k + 1 >= route.length) return; const n = route[k + 1], d = D4.findIndex((v) => v[0] === (n % COLS) - G.snake[0][0] && v[1] === ((n / COLS) | 0) - G.snake[0][1]); if (d >= 0 && !(G.dir[0] === D4[d][0] && G.dir[1] === D4[d][1])) G.queue = [D4[d]]; }, 25); });
await p.waitForTimeout(2200); await p.screenshot({ path: 'shots3/j_play.png' });
await p.waitForFunction(() => __snake.state === 'won', null, { timeout: 60000 }); await p.waitForTimeout(1500); await p.screenshot({ path: 'shots3/j_won.png' });
console.log('album', await p.evaluate(() => localStorage.getItem('snakeFruitRush.album.v1')), 'errors', JSON.stringify(errs));
await b.close();
