import re,sys
s=open('game.js').read()
def rep(old,new,count=1):
    global s
    assert s.count(old)>=1, 'missing: '+old[:70]
    if count==1: assert s.count(old)==1, 'multiple: '+old[:70]
    s=s.replace(old,new)
head=open('c_head.js').read(); logic=open('c_logic.js').read()
rep("  function loadData() {", head+"\n  function loadData() {")
rep("coins: 0, skin: 'default', skins: ['default'], daily: null, claimedDates: [], streak: 0, lastClaim: '', spinDates: [] };","coins: 0, skin: 'default', skins: ['default'], daily: null, claimedDates: [], streak: 0, lastClaim: '', spinDates: [], camp: null, menuMode: 'levels', vibe: true, tapSteer: false, pw: null };")
rep("    d.daily = cleanDaily(d.daily);\n    return d;","    d.daily = cleanDaily(d.daily);\n    d.menuMode = d.menuMode === 'endless' ? 'endless' : 'levels'; d.vibe = d.vibe !== false; d.tapSteer = d.tapSteer === true; d.pw = cleanPw(d.pw);\nd.camp = cleanCamp(d.camp);                                         // campaign progress: unlocked level, current level, stars per level\n    return d;")
rep("  const th = () => THEMES[DATA.theme];","  let CT = null;                      // world palette while a campaign screen is open\n  const th = () => CT || THEMES[DATA.theme];")
rep("    if (G.mode === 'ultimate') d = speedDelay","    if (G.camp) return G.camp.L.d * SPEED_MUL() * (G.camp.slowT > 0 ? 1.7 : 1);                                         // campaign: every level has its own pace\n    if (G.mode === 'ultimate') d = speedDelay")
rep("  function setState(s) {\n    state = s;","  function setState(s) {\n    state = s;\n    if (s === 'menu') CT = menuPal();")
rep("  function newGame() {\n    const mc","  function newGame() {\n    CT = null;\n    const mc")
rep("    const s = DATA.save;\n    if (!s) return;","    const s = DATA.save;\n    if (!s) return;\n    CT = null;")
rep("    if (G && (state === 'play' || state === 'paused')) DATA.save = G;","    if (G && !G.camp && (state === 'play' || state === 'paused')) DATA.save = G;")
rep("    if (G.queue.length === 1 && acc >= stepDelay() * INSTANT_TURN) {","    if (G.queue.length === 1 && acc >= stepDelay() * INSTANT_TURN && !(G.camp && (G.camp.ready > 0 || campSliding()))) {")
rep("      step();\n    }\n    return true;","      if (G.camp) campStep(); else step();\n    }\n    return true;")
rep("      if (state === 'play') {\n        acc += delta;","      if (state === 'play' && G.camp) {\n        campTick(delta);\n        popups.forEach((p) => { p.life -= delta; });\n        popups = popups.filter((p) => p.life > 0);\n      } else if (state === 'play') {\n        acc += delta;")
rep("      if (state === 'play' || state === 'over') {            // short effects fade out","      if (state === 'play' || state === 'over' || state === 'won') {            // short effects fade out")
rep("    if (!DATA.sound || !unlocked || (state !== 'play' && state !== 'menu')) { musicNext = 0; return; }","    if (!DATA.sound || !unlocked || (state !== 'play' && state !== 'menu' && state !== 'levels')) { musicNext = 0; return; }")
rep("const i = musicStep & 15, bar = (musicStep >> 4) % TUNE.length, d = musicNext - now, vol = state === 'menu' ? 0.06 : 0.08;","const i = musicStep & 15, bar = (musicStep >> 4) % TUNE.length, d = musicNext - now, vol = state === 'menu' || state === 'levels' ? 0.06 : 0.08;")
rep("  function drawBoard() {\n    const t = th();\n    boardG.clear();\n    boardG.setVisible(state !== 'menu');","  function drawBoard() {\n    const t = th();\n    if (G && G.camp && state !== 'menu' && state !== 'levels') { drawCampBoard(); return; }\n    boardG.clear();\n    boardG.setScale(1);\n    if (boardRT) boardRT.setVisible(false);\n    boardG.setVisible(state !== 'menu' && state !== 'levels');")
# draw()
rep("    if (state === 'menu') {\n      drawMenu();\n      if (sheetT > 0) { useLayer(1); drawSheet(); }\n    } else {\n      drawGame();\n      useLayer(1);\n      if (state === 'paused') {\n        drawPause();\n      } else if (state === 'over') {",
"    if (state === 'menu') {\n      drawMenu();\n      if (sheetT > 0) { useLayer(1); drawSheet(); }\n    } else if (state === 'levels') {\n      drawLevels();\n    } else {\n      if (G.camp) drawCampGame(); else drawGame();\n      useLayer(1);\n      if (state === 'paused') {\n        if (G.camp) drawCampPause(); else drawPause();\n      } else if (state === 'won') {\n        drawCampWon();\n      } else if (state === 'over' && G.camp) {\n        drawCampFail();\n      } else if (state === 'over') {")
# sfx
rep("    revive: () => [440, 660, 880].forEach((f, i) => tone(f, 0.18, 'triangle', 0.25, i * 0.09))","    revive: () => [440, 660, 880].forEach((f, i) => tone(f, 0.18, 'triangle', 0.25, i * 0.09)),\n    key: () => { tone(1047, 0.1, 'triangle', 0.25); tone(1568, 0.2, 'triangle', 0.25, 0.08); },\n    door: () => { tone(220, 0.12, 'square', 0.14); tone(330, 0.2, 'square', 0.14, 0.1); },\n    sw: (open) => { tone(open ? 520 : 400, 0.08, 'square', 0.14); tone(open ? 780 : 260, 0.16, 'square', 0.14, 0.07); },\n    portal: () => tone(300, 0.28, 'sine', 0.22, 0, 1200)")
# menu
a=s.index("    // play\n    const pw = 300")
b=s.index("    roundButton(W / 2 - 176, 738")
menu = """    // choose what to play: Levels or Endless
    const lv = DATA.menuMode !== 'endless', cp = DATA.camp, nl = campNext();
    rrect(W / 2 - 158, 453, 316, 48, 24, t.panel, 0.9);
    [['Levels', true], ['Endless', false]].forEach((o, i) => {
      const cx = W / 2 + (i ? 79 : -79), on = lv === o[1];
      if (on) rrect(cx - 75, 457, 150, 40, 20, t.accent);
      txt(cx, 478, o[0], 18, on ? '#1b1b1b' : t.btnText);
      buttons.push({ x: cx - 79, y: 453, w: 158, h: 48, fn: () => setMenuMode(o[1]) });
    });
    // play
    const hasSave = !!DATA.save, side = lv || hasSave, ph = 68, py = 548, pw = side ? 196 : 316, pcx = side ? W / 2 - 60 : W / 2;
    rrect(pcx - pw / 2, py - ph / 2 + 7, pw, ph, 34, shade(t.accent, -0.35));
    rrect(pcx - pw / 2, py - ph / 2, pw, ph, 34, t.accent);
    g.fillStyle(0x1b1b1b, 1);
    g.fillTriangle(pcx - 44, py - 14, pcx - 44, py + 14, pcx - 20, py);
    txt(pcx + 14, py - 1, 'Play', 32, '#1b1b1b');
    buttons.push({ x: pcx - pw / 2, y: py - ph / 2, w: pw, h: ph + 7, fn: playSelected });
    if (side) {
      const sx = W / 2 + 104;
      rrect(sx - 48, py - ph / 2 + 7, 96, ph, 34, shade(t.panel, -0.3));
      rrect(sx - 48, py - ph / 2, 96, ph, 34, t.panel);
      txt(sx, py - 1, lv ? 'Map' : 'Resume', lv ? 20 : 17, t.btnText);
      buttons.push({ x: sx - 48, y: py - ph / 2, w: 96, h: ph + 7, fn: lv ? openLevels : continueGame });
    }
    let totalStars = 0;
    for (let i = 1; i <= LEVEL_COUNT; i++) totalStars += cp.stars[i] | 0;
    if (lv) txt(W / 2, 604, 'Level ' + nl + '  -  ' + WORLDS[Math.floor((nl - 1) / 20)].name + '   -   ' + totalStars + ' stars', 15, t.text, 0.5, false);
    else txt(W / 2, 604, MODES[DATA.mode].name + ' mode' + (DATA.mode === 'ultimate' ? ', speed ' + DATA.speed : '') + (hasSave ? '   -   game saved' : ''), 15, t.text, 0.5, false);

"""
s=s[:a]+menu+s[b:]
# keyboard
rep("kb.on('keydown-ENTER', () => { if (state === 'menu' || state === 'over') newGame(); else if (state === 'paused') togglePause(); });",
"kb.on('keydown-ENTER', () => { if (state === 'menu') playCampaign(); else if (state === 'levels') startLevel(Math.min(campUnlocked(), lvPage * 20 + 1)); else if (state === 'won') campNextLevel(); else if (state === 'over') { if (G.camp) campRetry(); else newGame(); } else if (state === 'paused') togglePause(); });")
rep("kb.on('keydown-ESC', () => { if (state !== 'menu') goMenu(); else closeSheet(); });","kb.on('keydown-ESC', () => { if (state === 'levels') goHome(); else if (G && G.camp && state !== 'menu') leaveToLevels(); else if (state !== 'menu') goMenu(); else closeSheet(); });")
# ---- settings, touch, text, skins, shop ----
rep("  function drawIcon(kind, x, y) {\n    const t = th(), c = t.btnText;","  function drawIcon(kind, x, y, col) {\n    const t = th(), c = col || t.btnText;")
rep("    } else if (kind === 'star') {\n      g.fillStyle(C(t.accent), 1);","""    } else if (kind === 'vibe') {
      rrect(x - 6, y - 11, 12, 22, 3, c);
      rrect(x - 4, y - 8, 8, 14, 1.5, t.panel);
      [[-1, 9], [1, 9], [-1, 14], [1, 14]].forEach((o, i) => { g.lineStyle(2.2, C(c), 1); g.beginPath(); g.moveTo(x + o[0] * (i < 2 ? 9 : 14), y - 6); g.lineTo(x + o[0] * (i < 2 ? 9 : 14), y + 6); g.strokePath(); });
      if (!DATA.vibe) { line(x - 13, y + 12, x + 13, y - 12, '#ef4444', 2.8); }
    } else if (kind === 'tap') {
      dot(x - 1, y - 3, 6, c);
      rrect(x - 4, y - 3, 8, 15, 4, c);
      g.lineStyle(2, C(c), 1); g.beginPath(); g.arc(x - 1, y - 3, 10, Math.PI * 1.15, Math.PI * 1.85); g.strokePath();
      if (!DATA.tapSteer) { line(x - 12, y + 12, x + 12, y - 12, '#ef4444', 2.8); }
    } else if (kind === 'shop') {
      rrect(x - 12, y - 4, 24, 16, 4, c);
      g.lineStyle(3, C(c), 1); g.beginPath(); g.arc(x, y - 5, 7, Math.PI, 0); g.strokePath();
      dot(x, y + 4, 3.2, t.accent);
    } else if (kind === 'star') {
      g.fillStyle(C(t.accent), 1);""")
rep("try { if (DATA.sound && navigator.vibrate) navigator.vibrate(ms); }","try { if (DATA.vibe && navigator.vibrate) navigator.vibrate(ms); }")
rep("  function txt(x, y, s, size, color, originX, bold) {\n    let t = L.texts[L.n];","  const TXT_K = 1.1;                  // all text a little bigger than before\n  function txt(x, y, s, size, color, originX, bold) {\n    size = Math.round(size * TXT_K * 10) / 10;\n    let t = L.texts[L.n];")
rep("d.tab = Math.abs(d.tab | 0) % 5;","d.tab = Math.abs(d.tab | 0) % 8;")
# skins
rep("{ id: 'gold', name: 'Golden', cost: 1000, a: '#fde047', b: '#d97706', head: '#fff7c2', line: '#d97706', pattern: 'shimmer', trail: 'sparkle' }\n  ];","""{ id: 'gold', name: 'Golden', cost: 1000, a: '#fde047', b: '#d97706', head: '#fff7c2', line: '#d97706', pattern: 'shimmer', trail: 'sparkle' },
    { id: 'mint', name: 'Mint', cost: 1400, a: '#a7f3d0', b: '#34d399', head: '#ecfdf5', line: '#34d399' },
    { id: 'ocean', name: 'Ocean', cost: 1800, a: '#38bdf8', b: '#1d4ed8', head: '#bae6fd', line: '#1d4ed8', trail: 'bubble' },
    { id: 'kitty', name: 'Kitty', cost: 2200, a: '#fbbf24', b: '#f59e0b', head: '#fde68a', line: '#f59e0b', animal: 'cat' },
    { id: 'fox', name: 'Fox', cost: 2600, a: '#fb923c', b: '#c2410c', head: '#fdba74', line: '#c2410c', animal: 'fox' },
    { id: 'bunny', name: 'Bunny', cost: 3000, a: '#ffffff', b: '#fbcfe8', head: '#ffffff', line: '#f9a8d4', animal: 'bunny' },
    { id: 'neon', name: 'Neon', cost: 3500, a: '#22d3ee', b: '#a855f7', head: '#f0abfc', line: '#a855f7', pattern: 'neon', trail: 'sparkle' },
    { id: 'robot', name: 'Robo', cost: 4200, a: '#cbd5e1', b: '#64748b', head: '#e2e8f0', line: '#64748b', animal: 'robot' },
    { id: 'ninja', name: 'Ninja', cost: 5000, a: '#374151', b: '#111827', head: '#4b5563', line: '#111827', animal: 'ninja' },
    { id: 'magma', name: 'Magma', cost: 6000, a: '#fde047', b: '#dc2626', head: '#fff7ae', line: '#b91c1c', pattern: 'shimmer', trail: 'fire' },
    { id: 'phantom', name: 'Phantom', cost: 7000, a: '#e9d5ff', b: '#7c3aed', head: '#faf5ff', line: '#7c3aed', trail: 'sparkle' },
    { id: 'prism', name: 'Prism', cost: 8500, head: '#ffffff', line: '#c4b5fd', pattern: 'prism', trail: 'rainbow' },
    { id: 'emperor', name: 'Emperor', cost: 10000, a: '#fbbf24', b: '#b91c1c', head: '#fcd34d', line: '#b91c1c', animal: 'dragon', trail: 'fire' },
    { id: 'cosmic', name: 'Cosmic', cost: 12500, a: '#0ea5e9', b: '#4c1d95', head: '#e0f2fe', line: '#4c1d95', pattern: 'stars', trail: 'sparkle' },
    { id: 'diamond', name: 'Diamond', cost: 15000, a: '#bae6fd', b: '#e0f2fe', head: '#ffffff', line: '#7dd3fc', pattern: 'shimmer', trail: 'sparkle', animal: 'unicorn' },
    { id: 'royal', name: 'Royal', cost: 20000, a: '#fde047', b: '#a21caf', head: '#fff7c2', line: '#a21caf', pattern: 'shimmer', trail: 'gold', animal: 'crown' },
    { id: 'neonracer', name: 'Neon Racer', cost: 99999, special: '7-day daily streak', a: '#22d3ee', b: '#e879f9', head: '#ffffff', line: '#22d3ee', pattern: 'neon', trail: 'sparkle' },
    { id: 'obsidian', name: 'Obsidian', cost: 99999, special: '5 Expert clears', a: '#1f2937', b: '#7c3aed', head: '#f5d0fe', line: '#111827', pattern: 'shimmer', trail: 'fire', animal: 'crown' },
    { id: 'champion', name: 'Champion', cost: 99999, special: '3 stars on 25 levels', a: '#fde047', b: '#ffffff', head: '#fffbe0', line: '#f59e0b', pattern: 'shimmer', trail: 'gold', animal: 'crown' }
  ];""")
rep("    if (sk.pattern === 'rainbow') return hsl(i * 30 + anim * 0.05, 85, 56);","    if (sk.pattern === 'rainbow') return hsl(i * 30 + anim * 0.05, 85, 56);\n    if (sk.pattern === 'prism') return hsl(i * 22 + anim * 0.09, 75, 72);\n    if (sk.pattern === 'neon') return (Math.floor(anim / 220) + i) % 2 ? sk.a : sk.b;")
rep("    else if (sk.trail === 'sparkle') color = Math.random() < 0.5 ? '#fde68a' : '#ffffff';","    else if (sk.trail === 'sparkle') color = Math.random() < 0.5 ? '#fde68a' : '#ffffff';\n    else if (sk.trail === 'bubble') color = Math.random() < 0.5 ? '#7dd3fc' : '#ffffff';\n    else if (sk.trail === 'gold') color = Math.random() < 0.5 ? '#fde047' : '#f59e0b';")
rep("    if (an === 'panda') [1, -1].forEach((sd) => { const e = at([-5, 10], sd); dot(e.x, e.y, 5.2 * k, '#1f2937'); });             // ears","""    if (an === 'panda') [1, -1].forEach((sd) => { const e = at([-5, 10], sd); dot(e.x, e.y, 5.2 * k, '#1f2937'); });             // ears
    if (an === 'cat' || an === 'fox') [1, -1].forEach((sd) => {
      const p1 = at([-3, 5], sd), p2 = at([-7, 15], sd), p3 = at([5, 10], sd);
      g.fillStyle(C(an === 'fox' ? '#c2410c' : '#f59e0b'), 1); g.fillTriangle(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
      const q1 = at([-2, 7], sd), q2 = at([-5, 12.5], sd), q3 = at([2, 9.5], sd);
      g.fillStyle(C('#fbcfe8'), 1); g.fillTriangle(q1.x, q1.y, q2.x, q2.y, q3.x, q3.y);
    });
    if (an === 'bunny') [1, -1].forEach((sd) => { const a1 = at([-3, 6], sd), a2 = at([-17, 10], sd); line(a1.x, a1.y, a2.x, a2.y, '#f9a8d4', 6.4 * k); line(a1.x, a1.y, a2.x, a2.y, '#ffffff', 4 * k); });
    if (an === 'robot') { const a1 = at([-9, 0], 1), a2 = at([-17, 0], 1); line(a1.x, a1.y, a2.x, a2.y, '#94a3b8', 2.4 * k); dot(a2.x, a2.y, 3.2 * k, '#ef4444'); }""")
rep("    dot(hx, hy, 12.5 * k, headCol);\n","""    dot(hx, hy, 12.5 * k, headCol);
    if (an === 'ninja') { const b1 = at([-1.5, 12.5], 1), b2 = at([-1.5, 12.5], -1), b3 = at([-9, 16], -1); line(b1.x, b1.y, b2.x, b2.y, '#ef4444', 5 * k); line(b2.x, b2.y, b3.x, b3.y, '#ef4444', 3 * k); }
    if (an === 'crown') { [-7, 0, 7].forEach((o, i) => { const c1 = at([-9 - (i === 1 ? 3 : 0), o], 1); dot(c1.x, c1.y, 2.8 * k, '#fde047'); }); const c0 = at([-7, -9], 1), c9 = at([-7, 9], 1); line(c0.x, c0.y, c9.x, c9.y, '#fbbf24', 3.2 * k); }
""")
rep("    SKINS.forEach((sk, i) => {\n      const cx = W / 2 + ((i % 4) - 1.5)","    const pages = Math.ceil(SKINS.length / 12);\n    if (skinPage >= pages) skinPage = 0;\n    [[-1, BX + 22], [1, BX + BW - 22]].forEach((a) => {\n      dot(a[1], top + 95, 10, t.panel);\n      line(a[1] - a[0] * 2, top + 91, a[1] + a[0] * 2.5, top + 95, t.btnText, 2.2); line(a[1] + a[0] * 2.5, top + 95, a[1] - a[0] * 2, top + 99, t.btnText, 2.2);\n      buttons.push({ x: a[1] - 22, y: top + 80, w: 44, h: 30, fn: () => { skinPage = (skinPage + a[0] + pages) % pages; } });\n    });\n    txt(W / 2 + 112, top + 96, (skinPage + 1) + '/' + pages, 12, t.btnText, 0.5, false);\n    SKINS.slice(skinPage * 12, skinPage * 12 + 12).forEach((sk, i) => {\n      const cx = W / 2 + ((i % 4) - 1.5)")
rep("  let skinPick = null;","  let skinPick = null, skinPage = 0;")
rep("const locked = SKINS.filter((s) => !skinOwned(s.id));","const locked = SKINS.filter((s) => !skinOwned(s.id) && s.cost <= 1000);   // the eggs only hold the cheaper skins")
# menu
rep("    drawDailyCard(484);\n","")
rep("    rrect(W - BX - 62 - cw, 18, cw, 42, 21, t.panel, 0.7);\n    drawCoin(W - BX - 62 - cw + 24, 39, 11);\n    txt(W - BX - 62 - cw + 42, 39, coinText(DATA.coins), 16, t.accent, 0);","    rrect(W - BX - 118 - cw, 18, cw, 42, 21, t.panel, 0.7);\n    drawCoin(W - BX - 118 - cw + 24, 39, 11);\n    txt(W - BX - 118 - cw + 42, 39, coinText(DATA.coins), 16, t.accent, 0);\n    dot(W - BX - 76, 39, 22, t.panel, 0.7);\n    drawIcon('gear', W - BX - 76, 39);\n    buttons.push({ x: W - BX - 102, y: 12, w: 52, h: 56, fn: () => { settingsOpen = true; } });")
rep("    roundButton(W / 2 - 176, 738, 'modes', 'Modes', () => openSheet(0));\n    roundButton(W / 2 - 88, 738, 'themes', 'Themes', () => openSheet(1));\n    roundButton(W / 2, 738, 'background', 'Background', () => openSheet(2));\n    roundButton(W / 2 + 88, 738, 'skins', 'Skins', () => openSheet(3));\n    roundButton(W / 2 + 176, 738, 'gifts', 'Gifts', () => openSheet(4), !spinReady() ? 0 : 1);",
"    drawDailyCard(654);\n    const rb = DATA.menuMode === 'endless' ? [['modes', 'Modes', 0], ['themes', 'Themes', 1], ['background', 'Pattern', 2], ['skins', 'Skins', 3], ['shop', 'Shop', 5], ['gifts', 'Gifts', 4]] : [['skins', 'Skins', 3], ['shop', 'Shop', 5], ['gifts', 'Gifts', 4], ['cal', 'Daily', 'daily']];\n    rb.forEach((r, k) => roundButton(W / 2 + (k - (rb.length - 1) / 2) * (rb.length > 3 ? 76 : 110), 738, r[0], r[1], () => (r[2] === 'daily' ? startDailyPuzzle() : openSheet(r[2])), (r[2] === 4 && spinReady()) || (r[2] === 'daily' && !dpDone()) ? 1 : 0));")
# sheet tabs
a=s.index("    // tabs\n"); b=s.index("    if (DATA.tab === 0) {\n      MODE_KEYS")
s=s[:a]+"""    // tabs
    const tabs = DATA.menuMode === 'endless' ? [['Modes', 0], ['Themes', 1], ['Pattern', 2], ['Skins', 3], ['Shop', 5], ['Gifts', 4], ['Coins', 7]] : [['Coins', 7], ['Skins', 3], ['Shop', 5], ['Gifts', 4], ['Goals', 6]], tw = BW / tabs.length;
    rrect(BX, top + 32, BW, 46, 23, t.panel);
    tabs.forEach((tb, i) => {
      const x = BX + i * tw;
      if (DATA.tab === tb[1]) rrect(x + 2, top + 35, tw - 4, 40, 20, t.accent);
      txt(x + tw / 2, top + 55, tb[0], tabs.length > 3 ? 11.5 : 15, DATA.tab === tb[1] ? '#1b1b1b' : t.btnText);
      buttons.push({ x: x, y: top + 32, w: tw, h: 46, fn: () => { if (DATA.tab === 3 && tb[1] !== 3) skinPick = DATA.skin; DATA.tab = tb[1]; writeData(); } });
    });

"""+s[b:]
rep("        txt(W / 2, top + 316, 'Speed goes up slowly as you eat', 13, t.text, 0.5, false);\n      }","        txt(W / 2, top + 316, 'Speed goes up slowly as you eat', 13, t.text, 0.5, false);\n      }\n      button(W / 2, top + 412, 280, 40, 'Tap to turn: ' + (DATA.tapSteer ? 'On' : 'Off'), toggleTap, { size: 15 });")
rep("      txt(W / 2, top + 262, t.name, 20, t.accent);","      txt(W / 2, top + 262, t.name, 20, t.accent);")
rep("      txt(W / 2, top + 262, BACKGROUNDS[DATA.bg], 20, t.accent);","      txt(W / 2, top + 262, BACKGROUNDS[DATA.bg], 20, t.accent);")
rep("    } else if (DATA.tab === 3) {\n      drawSkinTab(top);\n    } else {","    } else if (DATA.tab === 3) {\n      drawSkinTab(top);\n    } else if (DATA.tab === 5) {\n      drawShop(top);\n    } else if (DATA.tab === 6) {\n      drawGoals(top);\n    } else if (DATA.tab === 7) {\n      drawCoinStore(top);\n    } else {")
rep("button(W / 2, top + (DATA.tab === 3 ? 450 : 410), 260, 54, 'Done'","button(W / 2, top + (DATA.tab === 3 || DATA.tab === 0 || DATA.tab === 5 || DATA.tab === 6 || DATA.tab === 7 ? 462 : 410), 260, 48, 'Done'")
# pointer handling
rep("""        touches.set(e.pointerId, { x: e.clientX, y: e.clientY, moved: false });""","""        const w0 = toWorld(e), b0 = buttons.find((q) => w0.x >= q.x && w0.x <= q.x + q.w && w0.y >= q.y && w0.y <= q.y + q.h);
        touches.set(e.pointerId, { x: e.clientX, y: e.clientY, moved: false, t: performance.now(), b: b0 ? { x: b0.x, y: b0.y } : null });""")
rep("""        if (Math.max(Math.abs(dx), Math.abs(dy)) < SWIPE_PX) return;
        turn(Math.abs(dx) > Math.abs(dy) ? [Math.sign(dx), 0] : [0, Math.sign(dy)]);""","""        const ax = Math.abs(dx), ay = Math.abs(dy), need = Math.max(SWIPE_PX, canvas.getBoundingClientRect().width * 0.04);
        if (Math.max(ax, ay) < need) return;                         // small finger wobble is not a swipe
        if (Math.min(ax, ay) > Math.max(ax, ay) * 0.8) return;       // clear diagonals wait until the direction is obvious
        turn(ax > ay ? [Math.sign(dx), 0] : [0, Math.sign(dy)]);""")
rep("""        if (b) { sfx.click(); b.fn(); }
        else if (state === 'play') tapTurn(w.x, w.y);""","""        if (b) { if (s.b && s.b.x === b.x && s.b.y === b.y) { sfx.click(); b.fn(); } }   // press and release must be on the same button
        else if (state === 'play' && DATA.tapSteer && performance.now() - s.t < 350) tapTurn(w.x, w.y);""")
rep("const SWIPE_PX = 14;","const SWIPE_PX = 20;")
rep("      delta = Math.min(delta, 100);\n      anim += delta;","      delta = Math.min(delta, 100);\n      anim += delta;\n      fpsAvg = fpsAvg * 0.97 + delta * 0.03;\n      if (!LITE && anim > 5000 && fpsAvg > 26) LITE = true;     // slow phone: switch off the decorations")
rep("  let CT = null;","  let LITE = false, fpsAvg = 16;     // LITE = slow device, skip the decorations\n  let CT = null;")

rep("    buttons.push({ x: x - 44, y: y - 36, w: 88, h: label ? 100 : 72, fn: fn });","    buttons.push({ x: x - 38, y: y - 36, w: 76, h: label ? 100 : 72, fn: fn });")
rep("    txt(BX + 42, 39, 'Best  ' + best(DATA.mode), 16, t.text, 0);","    txt(BX + 42, 39, DATA.menuMode === 'endless' ? 'Best  ' + best(DATA.mode) : 'Stars  ' + Object.keys(DATA.camp.stars).reduce((a, k) => a + DATA.camp.stars[k], 0), 16, t.text, 0);")
rep("kb.on('keydown-ENTER', () => { if (state === 'menu') playCampaign();","kb.on('keydown-ENTER', () => { if (state === 'menu') playSelected();")
rep("      demoReset();\n","      CT = menuPal();\n      demoReset();\n")
rep("      fpsAvg = fpsAvg * 0.97 + delta * 0.03;","      fpsAvg = fpsAvg * 0.97 + delta * 0.03;")
# logic insert
rep("  // ---------- Phaser scene ----------", logic+"\n  // ---------- Phaser scene ----------")
# test hook
rep("window.__snake = { get G() { return G; },","window.__snake = { camp: { start: startLevel, open: openLevels, home: goHome, retry: campRetry, next: campNextLevel, get C() { return G && G.camp; }, LV: LV, E: E, unlockAll: () => { DATA.camp.unlocked = LEVEL_COUNT; writeData(); }, engineLevel: engineLevel, randomFruit: randomFruit, get buttons() { return buttons; }, daily: { start: startDailyPuzzle, level: dpLevelFor, prog: PROG, goals: GOALS, check: goalsCheck, rng: seededRng, hash: strHash }, help: { open: openHelp, close: closeHelp, items: helpItems, undo: useUndo, canUndo: canUndo, hint: useHint, skip: useSkip, giveHint: giveHint, get seen() { return tipsSeen; } }, stepClock: stepClock, resetOwed: () => { owed = 0; }, cd: { ensure: cdEnsure, add: cdAdd, make: makeCD }, sk: { get S() { return SK; }, adapt: skAdapt, record: skRecord, fail: skFail, fruit: adaptiveFruit, profile: skProfile, reload: () => { SK = skLoad(); return SK; }, reset: () => { SK = SK_FRESH(); } }, WORLDS: WORLDS, sliding: () => campSliding() }, get CT() { return CT; }, usePower: usePower, buyPower: buyPower, PW: PW, get LITE() { return LITE; }, pts: snakePoints, get G() { return G; },")


rep("  function startGame() {","  // WebGL is tested first on a throw-away canvas (including \"software only\" WebGL, which is slower than Canvas), so a device without it\n  // simply gets Canvas instead of an error. ?canvas=1 / ?webgl=1 only force one of them for testing.\n  function pickRenderer() {\n    if (/[?&]canvas=1/.test(location.search)) return Phaser.CANVAS;\n    if (/[?&]webgl=1/.test(location.search)) return Phaser.WEBGL;\n    try {\n      const c = document.createElement('canvas');\n      const gl = c.getContext('webgl', { failIfMajorPerformanceCaveat: true }) || c.getContext('experimental-webgl', { failIfMajorPerformanceCaveat: true });\n      if (gl) { const x = gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); return Phaser.WEBGL; }\n    } catch (e) { /* fall through */ }\n    return Phaser.CANVAS;\n  }\n  function startGame() {")
# ================= movement / performance polish =================
# renderer: WebGL when the device really has a GPU, Canvas otherwise. No URL parameter needed (?canvas=1 / ?webgl=1 only force one for testing).
rep("    type: /[?&]webgl=1/.test(location.search) ? Phaser.WEBGL : Phaser.CANVAS,   // Canvas is smooth everywhere; add ?webgl=1 to compare",
    "    type: pickRenderer(),   // WebGL first when the device has a real GPU, Canvas as the safe fallback")
rep("    render: { antialias: true },","    render: { antialias: true, powerPreference: 'high-performance', failIfMajorPerformanceCaveat: !/[?&]webgl=1/.test(location.search) },   // software WebGL is slower than Canvas, so it falls back")
# resolution chosen once at launch (never changed while playing); the governor below stores a lower value for the next launch if the phone is slow
rep("  const ZOOM = 2;                    // render at 2x so it is sharp on phones",
    "  const ZOOM_KEY = 'snakeFruitRush.zoom';\n  const ZOOM = (() => { const m = /[?&]zoom=([0-9.]+)/.exec(location.search); if (m) return Math.min(3, Math.max(1, +m[1])); try { const z = parseFloat(localStorage.getItem(ZOOM_KEY)); if (z >= 1 && z <= 2) return z; } catch (e) { /* no storage */ } return 2; })();   // 2x = sharp; lower only after a slow session")
rep("const SWIPE_PX = 20; ","const SWIPE_PX = 15; ")
rep("const INSTANT_TURN = 0.25; ","const INSTANT_TURN = 0.15; ")
# reduced motion + low effects
rep("  const MAX_FX = 48;","  const REDUCED = (() => { try { return !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } })();   // fewer particles / decorations, the snake still glides\n  const MAX_FX = 48;")
rep("  function burst(x, y, color, n) {\n","  function burst(x, y, color, n) {\n    if (LITE || REDUCED) n = (n + 1) >> 1;\n")
rep("    if (!LITE) drawAmbient(w);","    if (!LITE && !REDUCED) drawAmbient(w);")
rep("    for (let n = 0; n < C0.iceList.length && !LITE; n++) {","    for (let n = 0; n < C0.iceList.length && !LITE && !REDUCED; n++) {")
rep("    popups.push({ x: Math.min(W - 60, Math.max(60, h.x))","    if (popups.length > 8) popups.shift();                      // bounded\n    popups.push({ x: Math.min(W - 60, Math.max(60, h.x))")
# no-jump early turns: the snake continues from where it is drawn right now
rep("      acc = 0;\n      prevSnake = G.snake.map((p) => [p[0], p[1]]);\n      if (G.camp) campStep(); else step();","      prevSnake = visualCells();                      // start from where the snake is drawn right now: nothing jumps\n      acc = 0;\n      if (G.camp) campStep(); else step();")
rep("  function snakePoints() {\n    const delay = stepDelay();\n    const k = state === 'play' ? Math.min(1, acc / delay) : 1;\n    return G.snake.map((cur, i) => {\n      const prev = (prevSnake && prevSnake[i]) || cur;\n      const jump = Math.abs(cur[0] - prev[0]) + Math.abs(cur[1] - prev[1]) > 1;\n      const c = jump ? cur[0] : prev[0] + (cur[0] - prev[0]) * k;\n      const r = jump ? cur[1] : prev[1] + (cur[1] - prev[1]) * k;\n      return cellXY(c, r);\n    });\n  }",
"""  // Where a segment glided from. After a wrap-around or a portal it slides in from outside the edge instead of freezing for a whole step.
  function prevOf(i) {
    const cur = G.snake[i], prev = (prevSnake && prevSnake[i]) || cur;
    if (Math.abs(cur[0] - prev[0]) + Math.abs(cur[1] - prev[1]) <= 1.95) return prev;
    let dx, dy;
    if (i === 0) { dx = G.dir[0]; dy = G.dir[1]; }
    else { const nx = G.snake[i - 1], ex = nx[0] - cur[0], ey = nx[1] - cur[1]; if (Math.abs(ex) + Math.abs(ey) !== 1) return cur; dx = ex; dy = ey; }
    return [cur[0] - dx, cur[1] - dy];
  }
  // Where every segment is drawn right now, in cell units (fractions while it glides between two cells).
  function visualCells() {
    const k = state === 'play' ? Math.min(1, acc / stepDelay()) : 1;
    return G.snake.map((cur, i) => { const prev = prevOf(i); return [prev[0] + (cur[0] - prev[0]) * k, prev[1] + (cur[1] - prev[1]) * k]; });
  }
  const ptsOut = [];                                   // reused every frame (no garbage on slow phones)
  function snakePoints() {
    const k = state === 'play' ? Math.min(1, acc / stepDelay()) : 1, n = G.snake.length;
    for (let i = 0; i < n; i++) {
      const cur = G.snake[i], prev = prevOf(i);
      const c = prev[0] + (cur[0] - prev[0]) * k, r = prev[1] + (cur[1] - prev[1]) * k;
      const p = ptsOut[i] || (ptsOut[i] = { x: 0, y: 0 });
      p.x = BX + c * CELL + CELL / 2; p.y = BY + r * CELL + CELL / 2;
    }
    ptsOut.length = n;
    return ptsOut;
  }
  // The head turns smoothly instead of snapping to the new direction.
  const edir = [1, 0];
  let easeT = 0;
  function easedDir() {
    const dt = Math.min(50, Math.max(0, anim - easeT)), f = 1 - Math.exp(-dt / 40);
    easeT = anim;
    edir[0] += (G.dir[0] - edir[0]) * f; edir[1] += (G.dir[1] - edir[1]) * f;
    const l = Math.hypot(edir[0], edir[1]) || 1;
    return [edir[0] / l, edir[1] / l];
  }""")
rep("    drawSnake(snakePoints(), G.dir, fxKeys.length ?","    drawSnake(snakePoints(), easedDir(), fxKeys.length ?")
s=s.replace("drawSnake(snakePoints(), G.dir, null);","drawSnake(snakePoints(), easedDir(), null);")
# swipes: one intended turn per swipe, dominant axis, long swipes never repeat
a=s.index("      window.addEventListener('pointermove', (e) => {"); b=s.index("      const end = (e, cancelled) => {")
s=s[:a]+"""      window.addEventListener('pointermove', (e) => {
        const s = touches.get(e.pointerId);
        if (!s || state !== 'play') return;
        const dx = e.clientX - s.x, dy = e.clientY - s.y, ax = Math.abs(dx), ay = Math.abs(dy);
        if (Math.max(ax, ay) < SWIPE_PX * (s.axis ? 1.4 : 1)) return;      // small finger wobble is not a swipe (a 2nd turn in one touch needs a clearer move)
        const axis = ax >= ay ? 'x' : 'y';                                  // diagonals follow the stronger axis
        s.moved = true;
        if (axis === s.axis) { s.x = e.clientX; s.y = e.clientY; return; }  // a long swipe in the same direction makes no extra turns
        turn(axis === 'x' ? [Math.sign(dx), 0] : [0, Math.sign(dy)]);
        s.axis = axis; s.x = e.clientX; s.y = e.clientY;
      }, { passive: true });
"""+s[b:]
# frame-time safety: never more than 2 steps in a frame, a freeze never turns into a burst of moves
rep("        acc += delta;\n        let delay = stepDelay();\n        while (state === 'play' && acc >= delay) {\n          acc -= delay;\n          prevSnake = G.snake.map((s) => [s[0], s[1]]);\n          step();\n          delay = stepDelay();\n        }",
    "        acc += Math.min(delta, 50);\n        let delay = stepDelay(), guardSteps = 0;\n        while (state === 'play' && acc >= delay && guardSteps++ < 2) {\n          acc -= delay;\n          prevSnake = G.snake.map((s) => [s[0], s[1]]);\n          step();\n          delay = stepDelay();\n        }\n        if (acc > delay) acc = delay;")
# governor: measure real frame time while playing; a slow phone gets a lower resolution at the NEXT launch (never a resize during play)
rep("      fpsAvg = fpsAvg * 0.97 + delta * 0.03;","      fpsAvg = fpsAvg * 0.97 + delta * 0.03;\n      const realDt = this._lt ? time - this._lt : 16.7;\n      this._lt = time;\n      if (state === 'play' && !govDone && realDt < 500) {\n        govT += realDt; govN++;\n        if (govT > 10000) {\n          govDone = true;\n          if (govT / govN > 27) { LITE = true; try { localStorage.setItem(ZOOM_KEY, String(Math.max(1.25, ZOOM - 0.5))); } catch (e) { /* no storage */ } }\n        }\n      }")
rep("  let LITE = false, fpsAvg = 16;","  let govT = 0, govN = 0, govDone = false;      // frame-time governor\n  let LITE = false, fpsAvg = 16;")
rep("pts: snakePoints,","pts: snakePoints, get renderer() { return scene && scene.sys.game.renderer.type === Phaser.WEBGL ? 'webgl' : 'canvas'; }, get fxCount() { return fxs.length; }, get popupCount() { return popups.length; }, get ZOOM() { return ZOOM; }, get textPool() { return layers.map((l) => l.texts.length); },")

rep("  const C = (hex) => parseInt(hex.slice(1), 16);","  const colCache = {};                              // colour strings -> numbers (parsing them every draw call is wasted work)\n  let colCount = 0;\n  const C = (hex) => { const v = colCache[hex]; if (v !== undefined) return v; if (colCount > 600) { for (const k in colCache) delete colCache[k]; colCount = 0; } colCount++; return (colCache[hex] = parseInt(hex.slice(1), 16)); };")
rep("    placeFood();\n    DATA.save = null;\n    setState('play');","    placeFood();\n    DATA.save = null;\n    prevSnake = G.snake.map((c, i) => G.snake[i + 1] || [c[0] - G.dir[0], c[1] - G.dir[1]]);   // the snake glides from the very first frame\n    setState('play');")


# ================= AdMob integration (placement + policy; the SDK lives in ads-bridge.js) =================
a=s.index("  function endAd(token, ok, msg) {"); b=s.index("  // The snake comes back in the middle")
s=s[:a]+open('adblock.js').read()+"\n"+s[b:]
rep("    if (s === 'menu') CT = menuPal();\n","    if (s === 'menu') CT = menuPal();\n    if (window.SFRAds) window.SFRAds.screen(s);            // the banner only lives on menu screens\n")
rep("        if (adLeft <= 0) revive();","        if (adLeft <= 0) endAd(adToken, true);")
rep("  function drawAd() {\n    const t = th();","  const AD_NOTE = { revive: 'You get the revive after the ad finishes', hint: 'You get the hint after the ad finishes', coins: 'You get +50 coins after the ad finishes', inter: 'Your game goes on right after' };\n  function drawAd() {\n    buttons = [];\n    const t = th();")
rep("      txt(W / 2, 410, 'You get the revive after the ad finishes', 12, t.btnText, 0.5, false);","      txt(W / 2, 410, AD_NOTE[adKind] || '', 12, t.btnText, 0.5, false);")
rep("    txt(W / 2, 326, 'TEST AD', 26, t.accent);","    txt(W / 2, 326, adKind === 'inter' ? 'TEST INTERSTITIAL' : 'TEST AD', 26, t.accent);")
rep("    } else {\n      if (G.camp) drawCampGame(); else drawGame();\n      useLayer(1);","    } else if (state === 'ad' && adJob && (adJob.back === 'menu' || adJob.back === 'levels')) {\n      if (adJob.back === 'menu') drawMenu(); else drawLevels();\n      useLayer(1);\n      drawAd();\n    } else {\n      if (G.camp) drawCampGame(); else drawGame();\n      useLayer(1);")
rep("btns.push(['Play again', newGame, canRevive","btns.push(['Play again', playAgain, canRevive")
rep("  function gameOver() {\n    DATA.save = null;","  function gameOver() {\n    adsMeta.endless++;\n    DATA.save = null;")
rep("    else button(W / 2, by, 260, 44, 'Need ' + (sk.cost - DATA.coins) + ' more coins', () => skinError('Not enough coins for ' + sk.name + '!'), { dark: true, size: 16 });","    else { button(W / 2, by, 260, 44, 'Need ' + (sk.cost - DATA.coins) + ' more coins', () => skinError('Not enough coins for ' + sk.name + '!'), { dark: true, size: 16 }); adCoinsButton(top + 432); }")
rep("    else txt(W / 2, top + 330, 'Free spin every day  -  Egg: coins or a new skin!', 12, t.text, 0.5, false);\n  }","    else txt(W / 2, top + 330, 'Free spin every day  -  Egg: coins or a new skin!', 12, t.text, 0.5, false);\n    if (DATA.coins < EGG_COST) adCoinsButton(top + 376);\n  }")
rep("    buttons = [];                                    // only the sheet reacts to taps now","    buttons = [];                                    // only the sheet reacts to taps now\n    sheetAdBtn = false;")
rep("    button(W / 2, top + (DATA.tab === 3 || DATA.tab === 0 || DATA.tab === 5 || DATA.tab === 6 || DATA.tab === 7 ? 462 : 410), 260, 48, 'Done', closeSheet, { primary: true, size: 20 });","    button(W / 2, top + (sheetAdBtn ? (DATA.tab === 3 ? 478 : DATA.tab === 4 ? 436 : 470) : (DATA.tab === 3 || DATA.tab === 0 || DATA.tab === 5 || DATA.tab === 6 || DATA.tab === 7 ? 462 : 410)), 260, 48, 'Done', closeSheet, { primary: true, size: 20 });\n    if (toast && anim < toast.until) { rrect(W / 2 - 160, top - 54, 320, 38, 19, toast.ok ? '#16a34a' : '#b91c1c'); txt(W / 2, top - 35, toast.s, 15, '#ffffff'); }")
rep("camp: null, menuMode: 'levels',","camp: null, adCoins: null, menuMode: 'levels',")
rep("    d.menuMode = d.menuMode === 'endless'","    d.adCoins = d.adCoins && typeof d.adCoins === 'object' && DATE_RE.test(d.adCoins.d) ? { d: d.adCoins.d, n: num(d.adCoins.n, 0, 99, 0) } : null;\n    d.menuMode = d.menuMode === 'endless'")
rep("window.__snake = { camp: {","window.__snake = { ads: { meta: adsMeta, claimAdCoins: claimAdCoins, adHint: adHint, maybeInter: maybeInter, playAgain: playAgain, coinsLeft: adCoinsLeft, requestRewarded: requestRewarded, get kind() { return adKind; }, get job() { return adJob; } }, camp: {")
rep("      CT = menuPal();\n      demoReset();\n","      CT = menuPal();\n      if (window.SFRAds) window.SFRAds.screen(state);\n      demoReset();\n")


rep("    } else if (kind === 'star') {\n      g.fillStyle(C(t.accent), 1);","""    } else if (kind === 'gear') {
      for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; line(x + Math.cos(an) * 6, y + Math.sin(an) * 6, x + Math.cos(an) * 10.5, y + Math.sin(an) * 10.5, c, 3.6); }
      dot(x, y, 7.6, c); dot(x, y, 3.2, t.panel);
    } else if (kind === 'star') {
      g.fillStyle(C(t.accent), 1);""")
rep("  function drawMenu() {","""  let settingsOpen = false;
  function drawSettings() {
    const t = th();
    buttons = [];
    g.fillStyle(0x000000, 0.62); g.fillRect(0, 0, W, H);
    rrect(BX + 10, 250, BW - 20, 330, 26, t.bg);
    txt(W / 2, 286, 'Settings', 24, t.accent);
    button(W / 2, 346, 250, 46, 'Sound: ' + (DATA.sound ? 'On' : 'Off'), toggleSound, { size: 17 });
    button(W / 2, 404, 250, 46, 'Vibration: ' + (DATA.vibe ? 'On' : 'Off'), toggleVibe, { size: 17 });
    button(W / 2, 462, 250, 46, 'Tap to turn: ' + (DATA.tapSteer ? 'On' : 'Off'), toggleTap, { size: 17 });
    button(W / 2, 534, 200, 44, 'Close', () => { settingsOpen = false; }, { primary: true, size: 18 });
  }
  function drawMenu() { drawMenu0(); if (settingsOpen) drawSettings(); }
  function drawMenu0() {""")
rep("else closeSheet(); });","else if (settingsOpen) settingsOpen = false; else closeSheet(); });")
# swipe: quicker second turn, smarter diagonals
rep("if (Math.max(ax, ay) < SWIPE_PX * (s.axis ? 1.4 : 1)) return;","if (Math.max(ax, ay) < SWIPE_PX * (s.axis ? 1.15 : 0.85)) return;")
rep("const axis = ax >= ay ? 'x' : 'y';                                  // diagonals follow the stronger axis","let axis = ax >= ay ? 'x' : 'y';\n        if (Math.min(ax, ay) > Math.max(ax, ay) * 0.7 && G) {              // clear diagonal: take the axis the snake is not already moving on (the useful turn)\n          const ha = G.dir[0] ? 'x' : 'y'; axis = ha === 'x' ? 'y' : 'x';\n        }")

rep("daily: null, claimedDates","daily: null, cdaily: null, claimedDates")
rep("    d.daily = cleanDaily(d.daily);","    d.daily = cleanDaily(d.daily); d.cdaily = cleanCDaily(d.cdaily);")
rep("    const d = dailyEnsure();\n    if (d.id !== id || d.claimed) return;","    const d = dailyEnsure();\n    if (d.id !== id || d.claimed || (G && G.camp)) return;      // campaign play never feeds the Endless challenge")
rep("    const t = th(), d = dailyEnsure(), type = DAILY_BY_ID[d.id], w = 440,","    const t = th(), cm = DATA.menuMode !== 'endless', d = cm ? cdEnsure() : dailyEnsure(), type = cm ? CD_BY_ID[d.id] : DAILY_BY_ID[d.id], w = 440,")
rep("(DATA.streak > 1 ? '  -  ' + DATA.streak + ' day streak' : ''), 11, t.text, 0, false);\n      return;","(!cm && DATA.streak > 1 ? '  -  ' + DATA.streak + ' day streak' : ''), 11, t.text, 0, false);\n      return;")
rep("  function drawMenu() { drawMenu0(); if (settingsOpen) drawSettings(); }","  function drawMenu() { drawMenu0(); if (settingsOpen) { for (let i = 0; i < L.n; i++) L.texts[i].setVisible(false); drawSettings(); } }")

rep("    for (const gap of [3, 2, 1]) {","    for (const gap of [3, 2]) {                 // a fruit never touches another fruit, not even diagonally")

rep("  const cellXY = (c, r) => ({ x: BX + c * CELL + CELL / 2, y: BY + r * CELL + CELL / 2 });","  const cellPool = []; for (let i = 0; i < 32; i++) cellPool.push({ x: 0, y: 0 }); let cellPi = 0;   // results are used straight away, so a small ring of objects avoids per-frame garbage\n  const cellXY = (c, r) => { const o = cellPool[cellPi++ & 31]; o.x = BX + c * CELL + CELL / 2; o.y = BY + r * CELL + CELL / 2; return o; };")
rep("  function shade(hex, f) {                          // f < 0 darker, f > 0 lighter\n","  const shadeMemo = {}; let shadeN = 0;\n  function shade(hex, f) {                          // f < 0 darker, f > 0 lighter\n    const mk = hex + '|' + f, mv = shadeMemo[mk];\n    if (mv !== undefined) return mv;\n    if (shadeN > 500) { for (const k in shadeMemo) delete shadeMemo[k]; shadeN = 0; }\n    shadeN++;\n    return (shadeMemo[mk] = shade0(hex, f));\n  }\n  function shade0(hex, f) {\n")
s=s.replace("popups = popups.filter((p) => p.life > 0);","for (let pi = popups.length - 1; pi >= 0; pi--) if (popups[pi].life <= 0) popups.splice(pi, 1);")
rep("      musicTick();\n      draw();","      musicTick();\n      poolsBegin(); draw(); poolsEnd(); boardStep(); warmStep();")
rep("layers = [0, 1].map((i) => ({ g: this.add.graphics().setDepth(i * 20 + 1), texts: [], n: 0, depth: i * 20 + 1 }));","layers = [0, 1, 2].map((i) => { const d = i === 2 ? 11 : i * 20 + 1; return { g: this.add.graphics().setDepth(d), texts: [], n: 0, depth: d }; });   // 2 = snake / effects above the stamped items")
rep("if (govT > 10000) {","if (govT > 4000) {")
rep("  function setState(s) {","  function setState(s) {\n    owed = 0;")
rep("      const n = Math.floor(c.sampleRate * dur), buf = c.createBuffer(1, n, c.sampleRate), d = buf.getChannelData(0);\n      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);","      const nk = dur + '|' + c.sampleRate, nc = noise.cache || (noise.cache = {});\n      let buf = nc[nk];\n      if (!buf) {                                  // the noise burst is made once per length and reused\n        const n = Math.floor(c.sampleRate * dur), d = (buf = nc[nk] = c.createBuffer(1, n, c.sampleRate)).getChannelData(0);\n        for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);\n      }")
rep("return 2; })();   // 2x = sharp","return lowEndDevice() ? 1.5 : 2; })();   // 2x = sharp")
rep("  const ZOOM_KEY = 'snakeFruitRush.zoom';","  const lowEndDevice = () => { try { const m = navigator.deviceMemory, n = navigator.hardwareConcurrency; return (m > 0 && m <= 2) || (n > 0 && n <= 4); } catch (e) { return false; } };   // 3 GB phones report 2 here\n  const ZOOM_KEY = 'snakeFruitRush.zoom';")

_old="    let t = L.texts[L.n];\n    if (!t) {\n      t = scene.add.text(0, 0, '', { fontFamily: FONT });\n      t.setScale(1 / ZOOM);            // text is rendered at ZOOM x size, then scaled down, so it stays sharp\n      t.setDepth(L.depth + 1);\n      L.texts.push(t);\n    }\n    L.n++;\n    const key = s + '|' + size + '|' + color + '|' + (bold === false ? 0 : 1);\n    if (t._key !== key) {\n      t.setStyle({ fontFamily: FONT, fontSize: (size * ZOOM) + 'px', color: color, fontStyle: bold === false ? '500' : '700' });\n      t.setText(s);\n      t._key = key;\n    }\n    t.setOrigin(originX === undefined ? 0.5 : originX, 0.5);\n    t.setPosition(x, y);\n    t.setVisible(true);\n  }\n"
_new="    // Every different text (string + size + colour) keeps its own Text object, so a string that is shown again is never re-drawn\n    // into a texture: opening a pop-up or changing screens no longer re-renders a dozen texts in one frame.\n    const key = s + '|' + size + '|' + color + '|' + (bold === false ? 0 : 1);\n    let e = L.byKey[key];\n    if (!e) e = L.byKey[key] = { list: [], n: 0, pn: 0 };\n    let t = e.list[e.n];\n    if (!t) {\n      t = scene.add.text(0, 0, s, { fontFamily: FONT, fontSize: (size * ZOOM) + 'px', color: color, fontStyle: bold === false ? '500' : '700' });\n      t.setScale(1 / ZOOM);            // text is rendered at ZOOM x size, then scaled down, so it stays sharp\n      t.setDepth(L.depth + 1);\n      e.list.push(t); L.texts.push(t);\n    }\n    if (e.n === 0) L.active.push(e);\n    e.n++;\n    t.setOrigin(originX === undefined ? 0.5 : originX, 0.5);\n    t.setPosition(x, y);\n    t.setVisible(true);\n  }\n  function textsBegin() {\n    layers.forEach((ly) => { ly.g.clear(); for (const e of ly.active) { e.pn = e.n; e.n = 0; } ly.prev = ly.active; ly.active = []; });\n  }\n  function textsEnd() {\n    layers.forEach((ly) => {\n      for (const e of ly.prev) for (let i = e.n; i < e.pn; i++) e.list[i].setVisible(false);\n      ly.prev = [];\n      if (ly.texts.length > 260) {                                   // keep the number of cached texts bounded: drop the ones not on screen\n        for (const k in ly.byKey) { const e = ly.byKey[k]; if (e.n === 0) { e.list.forEach((t) => t.destroy()); delete ly.byKey[k]; } }\n        ly.texts = ly.texts.filter((t) => t.scene);\n      }\n    });\n  }\n"
assert s.count(_old)==1,'txt body'
s=s.replace(_old,_new,1)
rep("    layers.forEach((ly) => { ly.g.clear(); ly.n = 0; });","    textsBegin();")
rep("    layers.forEach((ly) => { for (let i = ly.n; i < ly.texts.length; i++) ly.texts[i].setVisible(false); });","    textsEnd();")
rep("for (let i = 0; i < L.n; i++) L.texts[i].setVisible(false); drawSettings();","for (const e of L.active) for (let i = 0; i < e.n; i++) e.list[i].setVisible(false); drawSettings();")
rep("return { g: this.add.graphics().setDepth(d), texts: [], n: 0, depth: d };","return { g: this.add.graphics().setDepth(d), texts: [], n: 0, depth: d, byKey: {}, active: [], prev: [] };")

_a="const ZOOM_KEY = 'snakeFruitRush.zoom';"
assert s.count(_a)==1
s=s.replace(_a,"""const ZOOM_KEY = 'snakeFruitRush.zoom2';   // new key: an old "slow session" downgrade from earlier versions no longer keeps the picture soft
  // HD: the canvas is drawn at the phone's real pixel size (rounded up to 0.25 steps), so nothing is stretched or blurry. 3 GB phones stop at 2.25.
  const RENDERER = pickRenderer();\n  const autoZoom = () => {
    try {
      const dpr = window.devicePixelRatio || 1, sc = Math.min(window.innerWidth / 480, window.innerHeight / 800) || 1, ideal = Math.ceil(sc * dpr * 4 - 0.05) / 4;
      if (RENDERER !== Phaser.WEBGL) return lowEndDevice() ? 1.75 : 2;   // CPU (Canvas) drawing: stay moderate, the picture is still smooth\n      return lowEndDevice() ? Math.min(2.25, Math.max(1.75, ideal)) : Math.min(3, Math.max(2, ideal));   // GPU: full phone resolution
    } catch (e) { return 2; }
  };""",1)
_b="if (z >= 1 && z <= 2) return z;"
assert s.count(_b)==1
s=s.replace(_b,"if (z >= 1.75 && z <= 3) return z;",1)
_c="return lowEndDevice() ? 1.5 : 2; })();"
assert s.count(_c)==1
s=s.replace(_c,"return autoZoom(); })();",1)
_d="if (govT / govN > 27) { LITE = true; try { localStorage.setItem(ZOOM_KEY, String(Math.max(1.25, ZOOM - 0.5))); }"
assert s.count(_d)==1
s=s.replace(_d,"if (govT / govN > 36) { LITE = true; try { localStorage.setItem(ZOOM_KEY, String(Math.max(1.75, ZOOM - 0.25))); }",1)

_e="type: pickRenderer(),"
assert s.count(_e)==1
s=s.replace(_e,"type: RENDERER,",1)

_f="if (G.camp) drawCampPause(); else drawPause();"
assert s.count(_f)==1
s=s.replace(_f,"if (G.camp) { if (G.camp.help === 'menu') drawCampHelpMenu(); else if (G.camp.help) drawCampHelp(); else drawCampPause(); } else drawPause();",1)

_m="    const due = kind === 'level' ? adsMeta.levels >= INTER_EVERY_LEVELS : adsMeta.endless >= INTER_EVERY_ENDLESS;"
assert s.count(_m)==1
s=s.replace(_m,"    const early = kind === 'level' && (Object.keys(DATA.camp.stars).length < 3 || (G && G.camp && G.camp.fails >= 2));   // no ads in the first levels and none right after a struggle\n    const due = !early && (kind === 'level' ? adsMeta.levels >= INTER_EVERY_LEVELS : adsMeta.endless >= INTER_EVERY_ENDLESS);",1)

_t="      else {\n        drawCoin(cx - 14, ct + 62, 6);\n        txt(cx - 5, ct + 62, String(sk.cost), 11, DATA.coins >= sk.cost ? t.accent : t.btnText, 0);\n      }"
assert s.count(_t)==1
s=s.replace(_t,"      else if (sk.special) txt(cx, ct + 62, 'Special', 10, t.accent);\n"+_t,1)
_u="    else if (DATA.coins >= sk.cost) button(W / 2, by, 260, 44, 'Unlock for '"
assert s.count(_u)==1
s=s.replace(_u,"    else if (sk.special) button(W / 2, by, 260, 44, 'Locked: ' + sk.special, null, { disabled: true, dark: true, size: 14 });\n"+_u,1)
_v="if (!sk || skinOwned(id) || DATA.coins < sk.cost) return false;"
assert s.count(_v)==1
s=s.replace(_v,"if (!sk || sk.special || skinOwned(id) || DATA.coins < sk.cost) return false;",1)
_w="    } else if (kind === 'star') {\n      g.fillStyle(C(t.accent), 1);"
assert s.count(_w)==1
s=s.replace(_w,"    } else if (kind === 'cal') {\n      rrect(x - 13, y - 11, 26, 24, 5, c); rrect(x - 13, y - 11, 26, 8, 5, '#ef4444'); for (let q = 0; q < 6; q++) dot(x - 8 + (q % 3) * 8, y + 1 + Math.floor(q / 3) * 7, 2, t.panel);\n"+_w,1)

_a="const AD_COIN_REWARD = 50, AD_COIN_DAILY = 3;"
assert s.count(_a)==1
s=s.replace(_a,"const AD_COIN_LADDER = [100, 150, 250, 400, 600], AD_COIN_DAILY = 5;   // each ad of the day pays more than the one before\n  const adCoinNext = () => AD_COIN_LADDER[Math.min(AD_COIN_LADDER.length - 1, adCoinsToday())];",1)
_b=s[s.index("  function claimAdCoins() {"):s.index("  function adBtn(cx, cy, w, h, label, fn, size) {")]
s=s.replace(_b,"""  function claimAdCoins(back, done) {
    const say = typeof done === 'function' ? done : sheetToast;
    if (!adCoinsLeft()) { say('Daily limit reached. Come back tomorrow!', false); return; }
    const amt = adCoinNext();
    requestRewarded('coins', { back: typeof back === 'string' ? back : 'menu', ok: () => {
      DATA.adCoins = { d: adDay(), n: adCoinsToday() + 1 };
      DATA.coins = Math.min(MAX_COINS, DATA.coins + amt);
      writeData(); sfx.coin();
      say('+' + amt + ' coins!', true);                                   // nothing is opened or bought automatically
    }, fail: (m) => say(m, false) });
  }
""",1)
_c="'Watch ad   +' + AD_COIN_REWARD + ' coins   ('"
assert s.count(_c)==1
s=s.replace(_c,"'Watch ad   +' + adCoinNext() + ' coins   ('",1)

# ---- coin picture
_k="  function drawCoin(x, y, r) {\n"
assert s.count(_k)==1
s=s.replace(_k,_k+"    if (IMGOK.coin) { blitImg('coin' + L.depth, 'img_coin', x, y, r * 2.2, r * 2.2, 1, L.depth + 0.5); return; }\n",1)
# ---- settings overlay on its own layer (so picture coins stay below it)
_s="for (const e of L.active) for (let i = 0; i < e.n; i++) e.list[i].setVisible(false); drawSettings(); } }"
assert s.count(_s)==1
s=s.replace(_s,"for (const e of L.active) for (let i = 0; i < e.n; i++) e.list[i].setVisible(false); useLayer(1); drawSettings(); useLayer(0); } }",1)
# ---- gifts: durations, wheel picture, egg animation, new egg prizes
for a,b in (("const giftBusy = () => !!gift && gift.t < GIFT_MS;","const giftBusy = () => !!gift && gift.t < gift.dur;"),
            ("const p = gift ? Math.min(1, gift.t / GIFT_MS) : 1, ease","const p = gift ? Math.min(1, gift.t / gift.dur) : 1, ease"),
            ("if (!gift.done && gift.t >= GIFT_MS) {","if (!gift.done && gift.t >= gift.dur) {"),
            ("const k = Math.min(1, (gift.t - GIFT_MS) / 1200);","const k = Math.min(1, (gift.t - gift.dur) / 1200);"),
            ("gift = { kind: 'spin', idx: idx, val: val, t: 0, done: false };","gift = { kind: 'spin', idx: idx, val: val, t: 0, dur: 2400, done: false };"),
            ("(1 - ease) * 1080 :","(1 - ease) * 1440 :")):
    assert s.count(a)==1,a[:50]
    s=s.replace(a,b,1)
_e=s[s.index("    gift = { kind: 'egg', t: 0, done: false, val: 0, skin: null };"):s.index("    writeData();\n    return true;\n  }\n  function drawWheel")]
s=s.replace(_e,"""    gift = { kind: 'egg', t: 0, dur: 2800, done: false, val: 0, skin: null, pw: null, qty: 0 };
    const roll = Math.random();
    if (locked.length && roll < 0.2) {
      gift.skin = locked[rnd(locked.length)].id;
      DATA.skins.push(gift.skin);
      DATA.skin = gift.skin;
    } else if (roll < 0.45) {                                         // a power-up
      gift.pw = PW_KEYS[rnd(PW_KEYS.length)]; gift.qty = Math.random() < 0.3 ? 2 : 1;
      DATA.pw[gift.pw] = Math.min(99, DATA.pw[gift.pw] + gift.qty);
    } else {
      gift.val = EGG_COINS[pickWeighted(EGG_WEIGHTS)];
      addCoins(gift.val);
    }
""",1)
_w=s[s.index("  function drawWheel(cx, cy, r, rot) {"):s.index("  function drawGifts(top) {")]
s=s.replace(_w,"""  const WHEEL_COLS = ['#00a9fb', '#13f4f6', '#57f00e', '#c1f91c', '#fcde02', '#fa8200', '#fb4bb6', '#af21f7'];   // taken from the wheel picture
  function drawWheel(cx, cy, r, rot) {
    const img = !!IMGOK.wheel, ds = r / 163;                          // the picture is a frame with an open middle: the wedges turn underneath it
    SPIN_VALUES.forEach((v, i) => {
      const a0 = (-90 + rot + i * 45) * Math.PI / 180, a1 = a0 + Math.PI / 4;
      g.fillStyle(C(img ? WHEEL_COLS[i] : SPIN_COLORS[i]), 1);
      g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, img ? r * 1.06 : r, a0, a1, false); g.closePath(); g.fillPath();
    });
    if (img) blitImg('wheelF' + L.depth, 'img_wheel', cx + 3.3 * ds, cy + 2.9 * ds, 551 * ds, 503 * ds, 1, L.depth + 0.5);
    SPIN_VALUES.forEach((v, i) => {
      const am = (-90 + rot + (i + 0.5) * 45) * Math.PI / 180;
      txt(cx + Math.cos(am) * r * (img ? 0.74 : 0.66), cy + Math.sin(am) * r * (img ? 0.74 : 0.66), String(v), img ? 11 : 10, '#1b1b1b');
    });
    if (!img) {
      dot(cx, cy, 8, '#ffffff');
      g.fillStyle(0xffffff, 1);
      g.fillTriangle(cx - 8, cy - r - 11, cx + 8, cy - r - 11, cx, cy - r + 3);
    }
  }
""",1)
_d="    txt(lx, ct + 20, 'Daily Spin', 16, t.accent);"
assert s.count(_d)==1
s=s.replace(_d,"    txt(lx, ct + (IMGOK.wheel ? 13 : 20), 'Daily Spin', 16, t.accent);",1)
_f="drawWheel(lx, ct + 92, 50, sp ?"
assert s.count(_f)==1
s=s.replace(_f,"drawWheel(lx, ct + (IMGOK.wheel ? 90 : 92), IMGOK.wheel ? 38 : 50, sp ?",1)
_g=s[s.index("    txt(rx, ct + 20, 'Mystery Egg', 16, t.accent);"):s.index("    const afford = DATA.coins >= EGG_COST;")]
s=s.replace(_g,"    txt(rx, ct + 20, 'Mystery Egg', 16, t.accent);\n    drawEggArea(rx, ct + 92, p);\n",1)
_h="(gift.skin ? 'New skin: ' + SKIN_BY_ID[gift.skin].name + '!  Equipped' : 'You got +' + gift.val + ' coins!')"
assert s.count(_h)==1
s=s.replace(_h,"(gift.skin ? 'New skin: ' + SKIN_BY_ID[gift.skin].name + '!  Equipped' : gift.pw ? 'You got ' + PW[gift.pw].name + ' x' + gift.qty + '!' : 'You got +' + gift.val + ' coins!')",1)
_i="'Free spin every day  -  Egg: coins or a new skin!'"
assert s.count(_i)==1
s=s.replace(_i,"'Free spin every day  -  Egg: coins, power-ups or a skin!'",1)

_c="    txt(W - BX - 118 - cw + 42, 39, coinText(DATA.coins), 16, t.accent, 0);"
assert s.count(_c)==1
s=s.replace(_c,_c+"\n    buttons.push({ x: W - BX - 118 - cw, y: 12, w: cw, h: 56, fn: () => openSheet(7) });          // tap the coins: coin store",1)

def _rp(old,new):
    global s
    assert s.count(old)==1,old[:70]
    s=s.replace(old,new,1)
_rp("    const r = Math.min(20, h / 2);\n    if (o.primary) rrect(cx - w / 2, cy - h / 2 + 5, w, h, r, shade(fill, -0.3));   // 3D base\n    rrect(cx - w / 2, cy - h / 2, w, h, r, fill);",
    "    const r = Math.min(20, h / 2);\n    if (!slice3('btn_pill', cx, cy + 1, w + 6, h + 8, C(fill))) {\n      if (o.primary) rrect(cx - w / 2, cy - h / 2 + 5, w, h, r, shade(fill, -0.3));   // 3D base\n      rrect(cx - w / 2, cy - h / 2, w, h, r, fill);\n    }")
_rp("    rrect(cx - w / 2, cy - h / 2 + 3, w, h, h / 2, shade(t.panel, -0.3));\n    rrect(cx - w / 2, cy - h / 2, w, h, h / 2, shade(t.panel, 0.2));",
    "    if (!slice3('btn_pill', cx, cy + 1, w + 6, h + 8, C(shade(t.panel, 0.2)))) {\n      rrect(cx - w / 2, cy - h / 2 + 3, w, h, h / 2, shade(t.panel, -0.3));\n      rrect(cx - w / 2, cy - h / 2, w, h, h / 2, shade(t.panel, 0.2));\n    }")
_rp("    dot(x, y + 4, 31, shade(t.panel, -0.3));\n    dot(x, y, 31, t.panel);\n    drawIcon(kind, x, y);",
    "    const ICO = { skins: 'icon_skins', shop: 'icon_shop', gifts: 'icon_gifts', cal: 'icon_daily' }[kind];\n    if (ICO && UIOK[ICO] && uiPic('btn_round', x, y + 1, 76, 76, C(t.panel), 0.45)) uiPic(ICO, x, y - 1, 48, 48);\n    else {\n      dot(x, y + 4, 31, shade(t.panel, -0.3));\n      dot(x, y, 31, t.panel);\n      drawIcon(kind, x, y);\n    }")
_rp("    dot(W - BX - 76, 39, 22, t.panel, 0.7);\n    drawIcon('gear', W - BX - 76, 39);","    if (UIOK.glyph_settings && uiPic('btn_round', W - BX - 76, 40, 52, 52, C(t.panel), 0.45)) uiPic('glyph_settings', W - BX - 76, 39, 30, 30, 0xffffff, 0.55);\n    else { dot(W - BX - 76, 39, 22, t.panel, 0.7); drawIcon('gear', W - BX - 76, 39); }")
_rp("    dot(W - BX - 24, 39, 22, t.panel, 0.7);\n    drawIcon('sound', W - BX - 26, 39);","    if (UIOK.glyph_sound_on && uiPic('btn_round', W - BX - 24, 40, 52, 52, C(t.panel), 0.45)) uiPic(DATA.sound ? 'glyph_sound_on' : 'glyph_sound_off', W - BX - 25, 39, 30, 30, 0xffffff, 0.55);\n    else { dot(W - BX - 24, 39, 22, t.panel, 0.7); drawIcon('sound', W - BX - 26, 39); }")
_rp("    rrect(BX, top + 32, BW, 46, 23, t.panel);\n    tabs.forEach((tb, i) => {\n      const x = BX + i * tw;\n      if (DATA.tab === tb[1]) rrect(x + 2, top + 35, tw - 4, 40, 20, t.accent);",
    "    if (!slice3('tabbar_pill', W / 2, top + 55, BW + 8, 52, C(t.panel), 0.45)) rrect(BX, top + 32, BW, 46, 23, t.panel);\n    tabs.forEach((tb, i) => {\n      const x = BX + i * tw;\n      if (DATA.tab === tb[1] && !slice3('btn_pill', x + tw / 2, top + 55, tw - 2, 46, C(t.accent), 0.5)) rrect(x + 2, top + 35, tw - 4, 40, 20, t.accent);")
_rp("    { id: 'neonracer',","    { id: 'candy', name: 'Candy', cost: 550, a: '#f9a8d4', b: '#ffffff', head: '#f472b6', line: '#f472b6', trail: 'sparkle' },\n    { id: 'jungle', name: 'Jungle', cost: 650, a: '#4ade80', b: '#166534', head: '#86efac', line: '#166534', trail: 'sparkle' },\n    { id: 'wave', name: 'Ocean Wave', cost: 800, a: '#38bdf8', b: '#0e7490', head: '#67e8f9', line: '#0e7490', trail: 'bubble' },\n    { id: 'nightneon', name: 'Night Neon', cost: 2600, a: '#c084fc', b: '#22d3ee', head: '#f5d0fe', line: '#7c3aed', pattern: 'neon', trail: 'sparkle' },\n    { id: 'neonracer',")

open('game.camp.js','w').write(s)
print('patched', len(s))
