import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); const p = await (await b.newContext()).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(800);
let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? '  ok  ' : '  FAIL', m); };
const r = await p.evaluate(() => {
  const S = __snake.camp, out = {};
  const run = (frames) => { S.resetOwed(); let sumD = 0, sumI = 0, maxI = 0; frames.forEach((d) => { d = Math.min(d, 100); const i = S.stepClock(d); sumD += d; sumI += i; maxI = Math.max(maxI, i); }); for (let k = 0; k < 200; k++) { const i = S.stepClock(16.7); sumD += 16.7; sumI += i; maxI = Math.max(maxI, i); } return { drift: +(sumI - sumD).toFixed(2), maxI: +maxI.toFixed(1) }; };
  const steady = Array(300).fill(16.7), spikes = [], stall = [];
  for (let i = 0; i < 300; i++) spikes.push(i % 40 === 0 ? 120 : 16.7);
  for (let i = 0; i < 120; i++) stall.push(i % 3 ? 33 : 66);
  out.steady = run(steady); out.spikes = run(spikes); out.stall = run(stall); out.huge = run([5000, 16.7, 16.7]);
  return out;
});
console.log(JSON.stringify(r));
ok(Math.abs(r.steady.drift) < 0.5 && r.steady.maxI <= 16.8, 'steady 60 fps: step clock = real time exactly');
ok(Math.abs(r.spikes.drift) <= 400 && r.spikes.maxI <= 62.5, 'frame spikes: never more than 62.5 ms of movement per frame (<=1 step at the fastest level pace of 120 ms)');
ok(r.stall.maxI <= 62.5, '30 fps stalls: no jumps');
ok(r.huge.maxI <= 62.5, 'a 5 s freeze does not cause a catch-up burst');
// average speed over a long run with periodic 100 ms hitches equals real time (drift only the bounded debt)
ok(Math.abs(r.spikes.drift) < 1, 'after hitches, all lost time is paid back gradually (drift ' + r.spikes.drift + ' ms)');
console.log('page errors', errs.length); console.log('pass', pass, 'fail', fail); await b.close();
