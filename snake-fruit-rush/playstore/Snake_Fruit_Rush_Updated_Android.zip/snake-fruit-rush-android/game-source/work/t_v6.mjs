import { createRequire } from 'module'; const { chromium } = createRequire('/opt/node22/lib/node_modules/')('playwright');
const b = await chromium.launch(); const p = await b.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
await p.goto('file://' + process.cwd() + '/test.html'); await p.waitForTimeout(900);
const r = await p.evaluate(() => {
  const S = __snake.camp, E = S.E, D4 = [[0, -1], [1, 0], [0, 1], [-1, 0]], COLS = 20, out = { bad: [], tight: [], rnd: [], same: 0, n: 0 };
  S.unlockAll(); localStorage.removeItem('snakeFruitRush.fruit.v3');
  const dec = (s) => { const a = new Uint8Array(520); if (!s) return a; for (let y = 0; y < 26; y++) { const m = parseInt(s.slice(y * 4, y * 4 + 4), 36) ; } return a; };
  S.LV.forEach((base, i) => {
    S.start(i + 1); const C = S.C, L = C.L, F = L.F.map((f) => f.slice()); out.n++;
    // engine replay of the stored route with this layout
    const rt = E.makeRuntime(S.engineLevel(L)), st = E.newState(rt), route = base.R; let status = 'ok', good = true;
    for (let k = 1; k < route.length; k++) {
      const cur = route[k], head = st.body[0], d = D4.findIndex((v) => v[0] === (cur % COLS) - (head % COLS) && v[1] === ((cur / COLS) | 0) - ((head / COLS) | 0));
      if (d < 0) { good = false; break; } let q, g = 0; do { q = E.step(rt, st, D4[d]); g++; } while (q.status === 'wait' && g < 5); status = q.status; if (status === 'fail') { good = false; break; }
      if ((base.P || []).some((pp) => (pp[1] * COLS + pp[0]) === cur)) k++;
    }
    const want = (id => id <= 5 ? 3 : id <= 10 ? 4 : id <= 20 ? (id <= 15 ? 4 : 5) : id <= 30 ? 5 : id <= 40 ? (id <= 35 ? 5 : 6) : id <= 50 ? 6 : id <= 60 ? (id <= 55 ? 6 : 7) : id <= 70 ? 7 : id <= 80 ? (id <= 75 ? 7 : 8) : 8)(i + 1); out.cnt = out.cnt || []; out.cnt.push(F.length); if (F.length !== want) out.wrong = (out.wrong || []).concat([(i + 1) + ':' + F.length + '/' + want]);
    const sp = F.every((a, ii) => F.every((c, j) => ii === j || Math.max(Math.abs(a[0] - c[0]), Math.abs(a[1] - c[1])) >= 2));
    const onRoute = F.every((f) => route.includes(f[1] * COLS + f[0]));
    if (!good || status !== 'win' || !sp || !onRoute || F.length < 1) out.bad.push(i + 1);
    // same after retries
    for (let k = 0; k < 2; k++) { S.retry(); if (JSON.stringify(S.C.L.F) === JSON.stringify(F)) out.same++; }
    // tightness: new vs plain random
    const W = rt.walls || null;
    const tight = (FF) => { let s = 0; FF.forEach((f) => { for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; const x = f[0] + dx, y = f[1] + dy; const c = y * COLS + x; if (x < 0 || y < 0 || x >= COLS || y >= 26 || rt.wall[c]) s++; } }); return s / FF.length; };
    out.tight.push(+tight(F).toFixed(2)); let t0 = 0; for (let k = 0; k < 20; k++) t0 += tight(S.randomFruit(base).F); out.rnd.push(+(t0 / 20).toFixed(2));
  });
  return out;
});
const avg = (a, s, e) => (a.slice(s, e).reduce((x, y) => x + y, 0) / (e - s)).toFixed(2);
console.log('wrong fruit counts:', JSON.stringify(r.wrong || []), 'counts by band:', [[0,5],[5,10],[10,20],[20,30],[30,40],[40,50],[50,60],[60,70],[70,80],[80,100]].map(([s,e])=>Math.min(...r.cnt.slice(s,e))+'-'+Math.max(...r.cnt.slice(s,e))).join(' '));
console.log('levels', r.n, 'unsolvable/invalid:', JSON.stringify(r.bad), 'same-after-retry', r.same, '/200');
for (const [s, e] of [[0, 20], [20, 40], [40, 60], [60, 80], [80, 100]]) console.log(`levels ${s + 1}-${e}: blocked neighbours per fruit  new ${avg(r.tight, s, e)}  vs random ${avg(r.rnd, s, e)}`);
console.log('page errors', errs.length); await b.close();
