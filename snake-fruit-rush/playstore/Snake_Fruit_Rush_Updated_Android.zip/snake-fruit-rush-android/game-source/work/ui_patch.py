c=open('c_logic.js').read(); p=open('patch.py').read(); b=open('build.sh').read()
def C(x,y):
    global c
    assert x in c,x[:90]; c=c.replace(x,y,1)
b=b.replace("  cat assets.js\n  echo '</script>'","  cat assets.js\n  echo '</script>'\n  echo '<script>'\n  cat assets_ui.js\n  echo '</script>'",1)
assert 'assets_ui.js' in b; open('build.sh','w').write(b)
# ---- helpers
C("""      im.src = src[k];
    });
  }""","""      im.src = src[k];
    });
    const ui = window.SFR_UI || {};                                   // the glossy UI kit
    Object.keys(ui).forEach((k) => {
      const im = new Image();
      im.onload = () => { try { if (!scene.textures.exists('ui_' + k)) scene.textures.addImage('ui_' + k, im); UIOK[k] = { w: im.width, h: im.height }; } catch (e) { /* keep the drawn version */ } };
      im.src = ui[k];
    });
  }""")
C("  const IMGOK = {};","  const IMGOK = {}, UIOK = {};")
C("""  function blitImg(pool, key, x, y, w, h, alpha, depth, angle) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key).setDepth(depth); im._k = key; P.a.push(im); }
    P.n++;
    if (im._k !== key) { im.setTexture(key); im._k = key; }""","""  function blitImg(pool, key, x, y, w, h, alpha, depth, angle, tint, frame) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key, frame).setDepth(depth); im._k = key; im._f = frame; P.a.push(im); }
    P.n++;
    if (im._k !== key || im._f !== frame) { im.setTexture(key, frame); im._k = key; im._f = frame; }
    if (tint === undefined) { if (im._t !== undefined) { im.clearTint(); im._t = undefined; } } else if (im._t !== tint) { im.setTint(tint); im._t = tint; }""")
C("  // ---------- Gifts: egg picture + opening animation ----------","""  // UI kit helpers: one picture, a 3-part stretchy button, a 9-part stretchy panel. `tint` colours the grey-white pictures with the world theme.
  function uiPic(name, x, y, w, h, tint, dOff, alpha, angle) {
    if (!UIOK[name]) return false;
    blitImg('u_' + name + L.depth, 'ui_' + name, x, y, w, h, alpha === undefined ? 1 : alpha, L.depth + (dOff === undefined ? 0.55 : dOff), angle || 0, tint);
    return true;
  }
  function slice3(name, cx, cy, w, h, tint, dOff) {
    const u = UIOK[name];
    if (!u) return false;
    const key = 'ui_' + name;
    if (!u.cap) { const tx = scene.textures.get(key), cap = Math.round(u.h / 2); tx.add('l', 0, 0, 0, cap, u.h); tx.add('m', 0, cap, 0, u.w - 2 * cap, u.h); tx.add('r', 0, u.w - cap, 0, cap, u.h); u.cap = cap; }
    const d = L.depth + (dOff === undefined ? 0.45 : dOff), dc = Math.min(h / 2, w / 2), pn = 's_' + name + L.depth;
    blitImg(pn + 'l', key, cx - w / 2 + dc / 2, cy, dc, h, 1, d, 0, tint, 'l');
    if (w - 2 * dc > 0.5) blitImg(pn + 'm', key, cx, cy, w - 2 * dc, h, 1, d, 0, tint, 'm');
    blitImg(pn + 'r', key, cx + w / 2 - dc / 2, cy, dc, h, 1, d, 0, tint, 'r');
    return true;
  }
  function slice9(name, cx, cy, w, h, tint, dc, dOff) {
    const u = UIOK[name];
    if (!u) return false;
    const key = 'ui_' + name;
    if (!u.c9) {
      const tx = scene.textures.get(key), k = Math.round(Math.min(u.w, u.h) * 0.32), mw = u.w - 2 * k, mh = u.h - 2 * k;
      tx.add('tl', 0, 0, 0, k, k); tx.add('t', 0, k, 0, mw, k); tx.add('tr', 0, u.w - k, 0, k, k);
      tx.add('l', 0, 0, k, k, mh); tx.add('c', 0, k, k, mw, mh); tx.add('r', 0, u.w - k, k, k, mh);
      tx.add('bl', 0, 0, u.h - k, k, k); tx.add('b', 0, k, u.h - k, mw, k); tx.add('br', 0, u.w - k, u.h - k, k, k);
      u.c9 = k;
    }
    const d = L.depth + (dOff === undefined ? 0.4 : dOff), x0 = cx - w / 2, y0 = cy - h / 2, mw = w - 2 * dc, mh = h - 2 * dc, pn = 'n_' + name + L.depth;
    [['tl', x0 + dc / 2, y0 + dc / 2, dc, dc], ['t', cx, y0 + dc / 2, mw, dc], ['tr', x0 + w - dc / 2, y0 + dc / 2, dc, dc],
     ['l', x0 + dc / 2, cy, dc, mh], ['c', cx, cy, mw, mh], ['r', x0 + w - dc / 2, cy, dc, mh],
     ['bl', x0 + dc / 2, y0 + h - dc / 2, dc, dc], ['b', cx, y0 + h - dc / 2, mw, dc], ['br', x0 + w - dc / 2, y0 + h - dc / 2, dc, dc]]
      .forEach((q) => blitImg(pn + q[0], key, q[1], q[2], q[3], q[4], 1, d, 0, tint, q[0]));
    return true;
  }
  // ---------- Gifts: egg picture + opening animation ----------""")
# ---- panels, lock, power-up icons
C("    rrect(W / 2 - 186, top - 6, 372, h + 12, 26, t.bg);\n    rrect(W / 2 - 180, top, 360, h, 22, t.panel);","    if (!slice9('panel_card', W / 2, top + h / 2, 382, h + 20, C(t.panel), 34, 0.4)) {\n      rrect(W / 2 - 186, top - 6, 372, h + 12, 26, t.bg);\n      rrect(W / 2 - 180, top, 360, h, 22, t.panel);\n    }")
C("  function lockIcon(x, y, s, color) {\n","  function lockIcon(x, y, s, color) {\n    if (uiPic('lock', x, y, 24 * s, 24 * s, 0xffffff, 0.55)) return;\n")
C("  function drawPwIcon(k, x, y, on) {\n","  function drawPwIcon(k, x, y, on) {\n    const pn = { slow: 'pw_slow', shield: 'pw_shield', sweep: 'pw_defuse', coin2: 'pw_double' }[k];\n    if (pn && uiPic(pn, x, y, 40, 40, 0xffffff, 0.55)) return;\n")
# ---- bottom bar
C("      blit('pw', stamp('st_pw_'","      if (UIOK.btn_square) { uiPic('btn_square', x + 26, y + 26, 58, 56, on ? 0x0ea5e9 : C(t.panel), 0.45); drawPwIcon(k, x + 26, y + 24, on); }\n      else blit('pw', stamp('st_pw_'")
C("    rrect(px, py, 52, 52, 12, t.panel);\n    line(px + 19, py + 15, px + 19, py + 37, t.btnText, 6);\n    line(px + 33, py + 15, px + 33, py + 37, t.btnText, 6);","    if (!(uiPic('btn_square', px + 26, py + 26, 58, 56, C(t.panel), 0.45) && uiPic('glyph_pause', px + 26, py + 26, 26, 26, 0xffffff, 0.55))) {\n      rrect(px, py, 52, 52, 12, t.panel);\n      line(px + 19, py + 15, px + 19, py + 37, t.btnText, 6);\n      line(px + 33, py + 15, px + 33, py + 37, t.btnText, 6);\n    }")
C("    dot(qx, qy, 15, t.panel); txt(qx, qy + 1, '?', 20, t.btnText);","    if (!uiPic('icon_help', qx, qy, 34, 34)) { dot(qx, qy, 15, t.panel); txt(qx, qy + 1, '?', 20, t.btnText); }")
# ---- win stars
C("      starShape(x, y + 3, 30 * sc, '#000000', 0.25);\n      starShape(x, y, 30 * sc, got ? '#fde047' : '#00000044');\n      if (got) starShape(x - 2, y - 3, 14 * sc, '#fffbe0', 0.6);","      if (!uiPic(got ? 'star_full' : 'star_empty', x, y, 68 * sc, 64 * sc, 0xffffff, 0.55)) {\n        starShape(x, y + 3, 30 * sc, '#000000', 0.25);\n        starShape(x, y, 30 * sc, got ? '#fde047' : '#00000044');\n        if (got) starShape(x - 2, y - 3, 14 * sc, '#fffbe0', 0.6);\n      }")
C("starShape(x, y + 3, 26, '#000000', 0.25); starShape(x, y, 26, s < C0.stars ? '#fde047' : '#00000044'); }","if (!uiPic(s < C0.stars ? 'star_full' : 'star_empty', x, y, 60, 56, 0xffffff, 0.55)) { starShape(x, y + 3, 26, '#000000', 0.25); starShape(x, y, 26, s < C0.stars ? '#fde047' : '#00000044'); } }")
# ---- coin packs, NEW badge, tick
C("      drawCoin(cx, cy - 26, 20);","      if (!uiPic(['pack_small', 'pack_medium', 'pack_big'][i], cx, cy - 22, 66, 58)) drawCoin(cx, cy - 26, 20);")
C("      if (!tipsSeen.has(it.id)) { rrect(W / 2 + 118, y - 23, 42, 18, 9, t.accent); txt(W / 2 + 139, y - 14, 'NEW', 10, '#1b1b1b'); }","      if (!tipsSeen.has(it.id) && !uiPic('badge_new', W / 2 + 138, y - 14, 52, 32)) { rrect(W / 2 + 118, y - 23, 42, 18, 9, t.accent); txt(W / 2 + 139, y - 14, 'NEW', 10, '#1b1b1b'); }")
C("      if (done) { dot(BX + BW - 34, y, 11, '#22c55e'); line(BX + BW - 40, y, BX + BW - 36, y + 4, '#ffffff', 2.6); line(BX + BW - 36, y + 4, BX + BW - 29, y - 4, '#ffffff', 2.6); }","      if (done) { if (!uiPic('tick', BX + BW - 34, y, 26, 24)) { dot(BX + BW - 34, y, 11, '#22c55e'); line(BX + BW - 40, y, BX + BW - 36, y + 4, '#ffffff', 2.6); line(BX + BW - 36, y + 4, BX + BW - 29, y - 4, '#ffffff', 2.6); } }")
# ---- help menu icons
C("    const hb = (yy, label, fn, on) => { if (on) adBtn(W / 2, yy, 300, 50, label, fn, 17); else button(W / 2, yy, 300, 50, label, fn, { size: 17, dark: true }); };","    const hb = (yy, label, fn, on, ic) => { if (on) adBtn(W / 2, yy, 300, 50, label, fn, 17); else button(W / 2, yy, 300, 50, label, fn, { size: 17, dark: true }); if (ic) uiPic(ic, W / 2 - 126, yy, 34, 34); };")
C("hb(y, 'Undo last move   ' + COST_UNDO, useUndo, canUndo()); y += 60;","hb(y, 'Undo last move   ' + COST_UNDO, useUndo, canUndo(), 'icon_undo'); y += 60;")
C("hb(y, C0.route ? 'Hint is on' : 'Show next steps   ' + COST_HINT, useHint, !C0.route); y += 60;","hb(y, C0.route ? 'Hint is on' : 'Show next steps   ' + COST_HINT, useHint, !C0.route, 'icon_hint'); y += 60;")
# ---- level tiles
C("      rrect(x, y + 5, tile, tile, 18, shade(face, -0.38), open ? 1 : 0.7);\n      rrect(x, y, tile, tile, 18, face, open ? 1 : 0.85);","      const tpic = UIOK.tile_open && UIOK.tile_locked;\n      if (tpic) {\n        if (cur) uiPic('tile_open', x + tile / 2, y + tile / 2 + 2, tile + 22, tile + 16, 0xffffff, 0.40, 0.55 + 0.45 * Math.sin(anim / 160));\n        uiPic(open ? 'tile_open' : 'tile_locked', x + tile / 2, y + tile / 2 + 2, tile + 10, tile + 4, C(face), 0.45);\n      } else {\n      rrect(x, y + 5, tile, tile, 18, shade(face, -0.38), open ? 1 : 0.7);\n      rrect(x, y, tile, tile, 18, face, open ? 1 : 0.85);\n      }")
C("      if (cur) { g.lineStyle(3.5, C('#ffffff'), 0.55 + 0.45 * Math.sin(anim / 160)); g.strokeRoundedRect(x - 3, y - 3, tile + 6, tile + 6, 21); }","      if (cur && !tpic) { g.lineStyle(3.5, C('#ffffff'), 0.55 + 0.45 * Math.sin(anim / 160)); g.strokeRoundedRect(x - 3, y - 3, tile + 6, tile + 6, 21); }")
C("        if (st) for (let s = 0; s < 3; s++) starShape(x + tile / 2 + (s - 1) * 19, y + 59, 8.5, s < st ? '#b45309' : '#00000033');\n        if (PROG.expert[id]) starShape(x + tile - 12, y + 13, 7, '#7c3aed');","        if (st) for (let s = 0; s < 3; s++) { if (!uiPic(s < st ? 'star_full' : 'star_empty', x + tile / 2 + (s - 1) * 19, y + 59, 19, 18, 0xffffff, 0.55)) starShape(x + tile / 2 + (s - 1) * 19, y + 59, 8.5, s < st ? '#b45309' : '#00000033'); }\n        if (PROG.expert[id]) { if (!uiPic('star_full', x + tile - 12, y + 13, 16, 15, 0x9b6cff, 0.55)) starShape(x + tile - 12, y + 13, 7, '#7c3aed'); }")
# ---- items: more room inside their cell (no touching the neighbouring blocks)
C("  const fruitSt = (kind) => ['st_fr_' + kind, (cx, cy) => drawFruit(kind, cx, cy, 1.1)];","  const fruitSt = (kind) => ['st_fr_' + kind, (cx, cy) => drawFruit(kind, cx, cy, 0.84)];")
C("  const keySt = () => ['st_key', (cx, cy) => withStillClock(() => drawKey(cx, cy, 1))];","  const keySt = () => ['st_key', (cx, cy) => withStillClock(() => drawKey(cx, cy, 0.84))];")
old_b=c[c.index("  const bombSt = (flick) =>"):c.index("  function stampBomb(x, y) {")]
c=c.replace(old_b,"""  const bombSt = (flick) => ['st_bomb_' + (flick ? 1 : 0), (cx, cy) => {
    const k = 0.82;
    line(cx + 4 * k, cy - 6 * k, cx + 8 * k, cy - 11 * k, '#a16207', 2.2 * k);
    dot(cx, cy + k, 8.5 * k, '#1f2937'); dot(cx - 2.8 * k, cy - 1.8 * k, 2.4 * k, '#6b7280'); rrect(cx + 1.5 * k, cy - 8.5 * k, 5 * k, 4 * k, k, '#374151');
    dot(cx + 8.5 * k, cy - 11.5 * k, (flick ? 3.2 : 2.4) * k, flick ? '#fbbf24' : '#f97316');
  }];
""",1)
C("(cx, cy) => dot(cx, cy + 1, 13, '#ef4444', 1)), x, y, 0.18","(cx, cy) => dot(cx, cy + 1, 10, '#ef4444', 1)), x, y, 0.18")
C("warmQ.push(() => stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 13, '#ef4444', 1)));","warmQ.push(() => stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 10, '#ef4444', 1)));")
open('c_logic.js','w').write(c)
# ---- patch.py extras
extra=r'''
def _rp(old,new):
    global s
    assert s.count(old)==1,old[:70]
    s=s.replace(old,new,1)
_rp("    const r = Math.min(20, h / 2);\n    if (o.primary) rrect(cx - w / 2, cy - h / 2 + 5, w, h, r, shade(fill, -0.3));   // 3D base\n    rrect(cx - w / 2, cy - h / 2, w, h, r, fill);",
    "    const r = Math.min(20, h / 2);\n    if (!slice3('btn_pill', cx, cy + 1, w + 6, h + 8, C(fill))) {\n      if (o.primary) rrect(cx - w / 2, cy - h / 2 + 5, w, h, r, shade(fill, -0.3));   // 3D base\n      rrect(cx - w / 2, cy - h / 2, w, h, r, fill);\n    }")
_rp("    rrect(cx - w / 2, cy - h / 2 + 3, w, h, h / 2, shade(t.panel, -0.3));\n    rrect(cx - w / 2, cy - h / 2, w, h, h / 2, shade(t.panel, 0.2));",
    "    if (!slice3('btn_pill', cx, cy + 1, w + 6, h + 8, C(shade(t.panel, 0.2)))) {\n      rrect(cx - w / 2, cy - h / 2 + 3, w, h, h / 2, shade(t.panel, -0.3));\n      rrect(cx - w / 2, cy - h / 2, w, h, h / 2, shade(t.panel, 0.2));\n    }")
_rp("    dot(x, y + 4, 31, shade(t.panel, -0.3));\n    dot(x, y, 31, t.panel);\n    drawIcon(kind, x, y);",
    "    const ICO = { skins: 'icon_skins', shop: 'icon_shop', gifts: 'icon_gifts', cal: 'icon_daily' }[kind];\n    if (ICO && UIOK[ICO] && uiPic('btn_round', x, y + 1, 76, 76, C(t.panel), 0.45)) uiPic(ICO, x, y - 1, 48, 48);\n    else {\n      dot(x, y + 4, 31, shade(t.panel, -0.3));\n      dot(x, y, 31, t.panel);\n      drawIcon(kind, x, y);\n    }")
_rp("    dot(W - BX - 76, 39, 22, t.panel, 0.7);\n    drawIcon('gear', W - BX - 76, 39);","    if (UIOK.glyph_settings && uiPic('btn_round', W - BX - 76, 40, 52, 52, C(t.panel), 0.45)) uiPic('glyph_settings', W - BX - 76, 39, 30, 30, 0xffffff, 0.55);\n    else { dot(W - BX - 76, 39, 22, t.panel, 0.7); drawIcon('gear', W - BX - 76, 39); }")
_rp("    dot(W - BX - 24, 39, 22, t.panel, 0.7);\n    drawIcon('sound', W - BX - 26, 39);","    if (UIOK.glyph_sound_on && uiPic('btn_round', W - BX - 24, 40, 52, 52, C(t.panel), 0.45)) uiPic(DATA.sound ? 'glyph_sound_on' : 'glyph_sound_off', W - BX - 25, 39, 30, 30, 0xffffff, 0.55);\n    else { dot(W - BX - 24, 39, 22, t.panel, 0.7); drawIcon('sound', W - BX - 26, 39); }")
_rp("    rrect(BX, top + 32, BW, 46, 23, t.panel);\n    tabs.forEach((tb, i) => {\n      const x = BX + i * tw;\n      if (DATA.tab === tb[1]) rrect(x + 2, top + 35, tw - 4, 40, 20, t.accent);",
    "    if (!slice3('tabbar_pill', W / 2, top + 55, BW + 8, 52, C(t.panel), 0.45)) rrect(BX, top + 32, BW, 46, 23, t.panel);\n    tabs.forEach((tb, i) => {\n      const x = BX + i * tw;\n      if (DATA.tab === tb[1] && !slice3('btn_pill', x + tw / 2, top + 55, tw - 2, 46, C(t.accent), 0.5)) rrect(x + 2, top + 35, tw - 4, 40, 20, t.accent);")
_rp("    { id: 'neonracer',","    { id: 'candy', name: 'Candy', cost: 550, a: '#f9a8d4', b: '#ffffff', head: '#f472b6', line: '#f472b6', trail: 'sparkle' },\n    { id: 'jungle', name: 'Jungle', cost: 650, a: '#4ade80', b: '#166534', head: '#86efac', line: '#166534', trail: 'sparkle' },\n    { id: 'wave', name: 'Ocean Wave', cost: 800, a: '#38bdf8', b: '#0e7490', head: '#67e8f9', line: '#0e7490', trail: 'bubble' },\n    { id: 'nightneon', name: 'Night Neon', cost: 2600, a: '#c084fc', b: '#22d3ee', head: '#f5d0fe', line: '#7c3aed', pattern: 'neon', trail: 'sparkle' },\n    { id: 'neonracer',")
'''
p=p.replace("\nopen('game.camp.js','w').write(s)",extra+"\nopen('game.camp.js','w').write(s)",1)
open('patch.py','w').write(p)
