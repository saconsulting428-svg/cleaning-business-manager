# Keep the JavaScript bridge methods that the game calls.
-keepclassmembers class com.snakefruitrush.game.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
