package com.snakefruitrush.game

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Hosts the game (assets/index.html) in a WebView and gives it three things:
 *   window.showRewardedAd()  -> Promise<boolean>  (true ONLY after the user earned the reward)
 *   window.isRewardedAdReady() -> boolean
 *   window.shareText(text)   -> opens the Android share sheet
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var rewardedAd: RewardedAd? = null
    private var loading = false

    companion object {
        // Google's TEST rewarded ad unit. Replace with your own rewarded ad unit id before release.
        private const val REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        loadRewardedAd()

        webView = WebView(this)
        webView.setBackgroundColor(Color.parseColor("#0F1220"))
        setContentView(webView)
        hideSystemBars()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true                       // localStorage = saved coins, skins, high scores
            mediaPlaybackRequiresUserGesture = false       // lets the game's sound start
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = false
        }
        webView.overScrollMode = View.OVER_SCROLL_NEVER

        // Serves assets/ over https://appassets.androidplatform.net so localStorage works normally.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true  // stay inside the game

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(BRIDGE_JS, null)
            }
        }
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun hideSystemBars() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    private fun loadRewardedAd() {
        if (loading || rewardedAd != null) return
        loading = true
        RewardedAd.load(this, REWARDED_UNIT_ID, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad; loading = false }
            override fun onAdFailedToLoad(error: LoadAdError) { rewardedAd = null; loading = false }
        })
    }

    private fun resolveAd(id: Int, ok: Boolean) {
        webView.post { webView.evaluateJavascript("window.__adResult($id, $ok)", null) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isRewardedAdReady(): Boolean = rewardedAd != null

        @JavascriptInterface
        fun showRewardedAd(id: Int) {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) { resolveAd(id, false); loadRewardedAd(); return@runOnUiThread }
                var earned = false
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        rewardedAd = null
                        resolveAd(id, earned)            // true only if the reward callback fired
                        loadRewardedAd()
                    }
                    override fun onAdFailedToShowFullScreenContent(error: AdError) {
                        rewardedAd = null
                        resolveAd(id, false)
                        loadRewardedAd()
                    }
                }
                ad.show(this@MainActivity) { earned = true }   // user earned the reward
            }
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                startActivity(Intent.createChooser(send, null))
            }
        }
    }

    override fun onPause() { webView.onPause(); super.onPause() }        // stops sound in the background
    override fun onResume() { super.onResume(); webView.onResume(); hideSystemBars() }
    override fun onDestroy() { webView.destroy(); super.onDestroy() }
}

private const val BRIDGE_JS = """
(function () {
  if (window.__bridgeReady) return; window.__bridgeReady = true;
  window.__adResolvers = {}; window.__adSeq = 0;
  window.showRewardedAd = function () {
    return new Promise(function (resolve) {
      var id = ++window.__adSeq; window.__adResolvers[id] = resolve; AndroidBridge.showRewardedAd(id);
    });
  };
  window.isRewardedAdReady = function () { return AndroidBridge.isRewardedAdReady(); };
  window.__adResult = function (id, ok) { var r = window.__adResolvers[id]; if (r) { delete window.__adResolvers[id]; r(ok === true); } };
  window.shareText = function (t) { AndroidBridge.share(t); };
})();
"""
