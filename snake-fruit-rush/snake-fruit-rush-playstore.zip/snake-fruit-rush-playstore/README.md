# Snake Fruit Rush - Google Play package

```
game/index.html                 the finished game (single file, works offline)
android-app/                    Android Studio project that wraps the game + AdMob rewarded ads + share
graphics/icon-512.png           Play Store icon (512x512)
graphics/feature-graphic-1024x500.png
graphics/screenshots/           6 phone screenshots (1080x1920)
store-listing/listing.md        title, short + full description, category
store-listing/data-safety-and-content-rating.md
privacy-policy.html             template - fill in your name / email, host it, paste the link
```

## What is NOT included (only you can do these)
- A signed **.aab** file. It must be built on a computer with Android Studio and signed with YOUR key.
- Your Google Play developer account, your AdMob account, and your own AdMob IDs.
- The Android project was written but **not built or run here** (no Android SDK in my environment). Expect to fix small Gradle/version issues when you first open it.

## Steps
1. **Install Android Studio**, choose *Open* and select the `android-app` folder. Let it sync (it will download Gradle and offer to create the Gradle wrapper).
2. **Pick your own package name** (applicationId in `app/build.gradle.kts`, e.g. `com.yourname.snakefruitrush`). It can never change after the first upload. If you rename it, also rename the folder/package in `MainActivity.kt` and `namespace`.
3. **Run it on a real phone** (USB debugging) and test: touch, sound, skins, daily challenge, game over, Share, Revive (test ad).
4. **AdMob**: create an AdMob app + a *Rewarded* ad unit. Replace
   - `ca-app-pub-3940256099942544~3347511713` in `AndroidManifest.xml` (App ID)
   - `ca-app-pub-3940256099942544/5224354917` in `MainActivity.kt` (rewarded unit)
   The values in the project are Google's TEST ids. **Never click your own real ads.** Before release also add Google's consent (UMP) flow if you serve users in the EEA/UK.
5. **Build the release**: *Build > Generate Signed App Bundle / APK > Android App Bundle*. Create a keystore and **back it up safely** (use Play App Signing). Increase `versionCode` for every new upload.
6. **Google Play Console** ($25 one-time): create the app, fill the store listing from `store-listing/`, upload icon, feature graphic and screenshots, add the privacy-policy link, answer Data safety + content rating + target audience, upload the .aab.
7. **Testing rule for new accounts**: new personal developer accounts must usually run a *closed test* with about 12 testers for 14 days before production access. Check the current requirement in Play Console.
8. Release, then watch retention and reviews.

## Remember
- Keep `window.showRewardedAd` as is: it resolves true only after AdMob's reward callback. The game never revives without it.
- The game works in a normal browser too; open `game/index.html`.
