# Google Play store listing (copy and paste)

## App name (max 30 characters)
Snake Fruit Rush

## Short description (max 80 characters)
Cute snake arcade: eat fruits, build combos, dodge bombs, unlock skins!

## Full description (max 4000 characters)
Snake Fruit Rush is a fast, colourful twist on the classic snake game. Swipe or tap to steer your snake, gobble up juicy fruits, and chase a sky-high score!

🍎 WHAT MAKES IT FUN
• Eat the BIG fruit to start a COMBO – the longer your chain, the bigger your points
• Catch the rare GOLDEN fruit for a huge score and bonus coins
• Grab power-ups: Slow, Ghost, Magnet, No Walls and 2x points
• Close call! Dodge a bomb at the last second for a bonus

🎮 4 GAME MODES
• Classic – walls and tail are deadly
• No walls – wrap around the screen
• Ghost – pass through yourself
• Ultimate – bombs, no walls, your own speed

🎁 REWARDS EVERY DAY
• A new Daily Challenge every day, with coins and a streak bonus
• Free Daily Spin
• Mystery Egg – win coins or a brand-new skin

🐍 COLLECT SKINS
Unlock cute snakes: Lava, Frost, Berry, Bee, Panda, Galaxy, Rainbow, Dragon, Unicorn and Golden – some with sparkly trails!

🎨 MAKE IT YOURS
5 colourful themes and 5 board backgrounds.

✔ One-finger controls (swipe or tap)
✔ Short rounds – perfect for a quick break
✔ Works offline
✔ Optional rewarded video: watch an ad to revive and keep your run going

Can you beat your best score? Download Snake Fruit Rush and find out!

## Category
Game > Arcade  (tags: Casual, Arcade, Single player)

## Contact details (required)
Email: YOUR_EMAIL@example.com
Privacy policy URL: (host privacy-policy.html publicly, then paste the link here)

## Keywords to use naturally in the description
snake game, snake, fruit, arcade, offline snake, classic snake, casual game, combo, skins
