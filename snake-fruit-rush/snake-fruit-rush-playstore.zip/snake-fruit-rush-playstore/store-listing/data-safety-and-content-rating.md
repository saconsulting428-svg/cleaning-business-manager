# Answers for Play Console forms (check each one against the current form before submitting)

## Data safety
The game itself has no accounts, login or server. Everything is saved on the phone.
The AdMob SDK (ads) collects data, so you must declare it:

| Question | Suggested answer |
|---|---|
| Does the app collect or share user data? | Yes (through Google AdMob) |
| Data type | "Device or other IDs" (advertising ID); AdMob may also collect approximate location, app interactions and diagnostics - follow Google's AdMob data-disclosure guide |
| Collected / shared | Collected and shared with a third party (Google AdMob) |
| Purpose | Advertising, analytics |
| Is it optional for the user? | No (ads are part of the app) |
| Data encrypted in transit? | Yes |
| Can users ask for deletion? | Not applicable - the app stores nothing on your servers |

Google's guide: search "AdMob Play Data safety" and copy exactly what it lists for the SDK version you ship.

## Content rating (IARC questionnaire)
- Violence: none (a cartoon bomb explosion is the only effect; answer honestly "cartoon / fantasy" if asked)
- Sexual content, profanity, drugs, gambling: none
- In-app purchases: none yet
- User-generated content / chat: none
- Expected result: Everyone / PEGI 3

## Target audience and Families policy  (IMPORTANT)
- If you pick an age group that includes children under 13, the app falls under Google's Families Policy:
  only Families-certified ad networks and child-directed ad settings are allowed, and extra rules apply.
- Simplest path: choose target audience **13+ (or 18+ if unsure)**, even if kids may also like the game.
- If you really want to target children, set AdMob "tag for child-directed treatment" = true and read the Families policy first.

## Ads declaration
Contains ads: **Yes**.

## Permissions used
INTERNET, ACCESS_NETWORK_STATE (ads), VIBRATE. No dangerous permissions.
