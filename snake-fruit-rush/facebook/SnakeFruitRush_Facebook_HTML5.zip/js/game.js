// =====================================================================
//  SNAKE - FRUIT RUSH   (Phaser 3)
//  Controls: swipe / tap / mouse click, Arrow keys or WASD
//            Space = pause, Enter = play, C = continue, T = theme, B = background, Esc = menu
//  High score, theme, sound and the saved game are kept in localStorage.
// =====================================================================
(function () {
  'use strict';

  // ---------- Settings ----------
  const W = 480, H = 800;            // logical screen (portrait)
  const lowEndDevice = () => { try { const m = navigator.deviceMemory, n = navigator.hardwareConcurrency; return (m > 0 && m <= 2) || (n > 0 && n <= 4); } catch (e) { return false; } };   // 3 GB phones report 2 here
  const ZOOM_KEY = 'snakeFruitRush.zoom2';   // new key: an old "slow session" downgrade from earlier versions no longer keeps the picture soft
  // HD: the canvas is drawn at the phone's real pixel size (rounded up to 0.25 steps), so nothing is stretched or blurry. 3 GB phones stop at 2.25.
  const RENDERER = pickRenderer();
  const autoZoom = () => {
    try {
      const dpr = window.devicePixelRatio || 1, sc = Math.min(window.innerWidth / 480, window.innerHeight / 800) || 1, ideal = Math.ceil(sc * dpr * 4 - 0.05) / 4;
      if (RENDERER !== Phaser.WEBGL) return lowEndDevice() ? 1.75 : 2;   // CPU (Canvas) drawing: stay moderate, the picture is still smooth
      return lowEndDevice() ? Math.min(2.25, Math.max(1.75, ideal)) : Math.min(3, Math.max(2, ideal));   // GPU: full phone resolution
    } catch (e) { return 2; }
  };
  const ZOOM = (() => { const m = /[?&]zoom=([0-9.]+)/.exec(location.search); if (m) return Math.min(3, Math.max(1, +m[1])); try { const z = parseFloat(localStorage.getItem(ZOOM_KEY)); if (z >= 1.75 && z <= 3) return z; } catch (e) { /* no storage */ } return autoZoom(); })();   // 2x = sharp; lower only after a slow session
  const CELL = 22, COLS = 20, ROWS = 26;
  const BX = 20, BY = 104;           // board top-left
  const BW = COLS * CELL, BH = ROWS * CELL;

  const FRUIT_POINTS = 10;
  const BONUS_POINTS = 50;
  const BONUS_EVERY = 5;             // big fruit after every 5 fruits
  const BONUS_TICKS = 55;            // big fruit stays this many steps
  const START_DELAY = 150;           // ms per step at the start (lower = faster)
  const MIN_DELAY = 72;              // fastest the snake gets on its own
  const SPEEDUP_FRUITS = 45;         // bigger = speed goes up more slowly
  const SWIPE_PX = 15;               // finger movement (screen px) that counts as a swipe
  const INSTANT_TURN = 0.15;         // turn right away if the snake is this far into its step

  const MODES = {
    classic: { name: 'Classic', desc: 'Walls and your body are deadly' },
    walls: { name: 'No walls', desc: 'Go through the walls', wall: true },
    ghost: { name: 'Ghost', desc: 'Pass through yourself', ghost: true },
    ultimate: { name: 'Ultimate', desc: 'Bombs! No walls, ghost, own speed', wall: true, ghost: true, bombs: true }
  };
  const MODE_KEYS = Object.keys(MODES);
  const BOMBS = 6;                   // bombs on the board in Ultimate mode
  const BOMB_SAFE = 4;               // bombs never appear this close to the snake's head
  const DEMO = { x0: 31, y0: 87, cols: 19, rows: 11, ms: 140 };   // the little self-playing snake on the home screen
  const speedDelay = (level) => 214 - level * 16;   // Ultimate speed 1 (slow, 198 ms) .. 10 (fast, 54 ms)

  const COMBO_TICKS = 45;            // eat the next fruit within this many steps
  const COMBO_POWER_EVERY = 3;       // ability icon on every 3rd combo
  const POWER_ITEM_TICKS = 85;       // ability icon stays on the board
  const POWER_TICKS = 110;           // ability lasts this many steps
  const MAGNET_RANGE = 5;
  const SLOW_FACTOR = 1.7;
  const REVIVES_PER_GAME = 1;        // how many times an ad can revive the snake in one game
  const TEST_AD_MS = 5000;           // length of the developer test ad (only with ?testads=1 in the URL)
  const AD_TIMEOUT_MS = 90000;       // give up on a rewarded ad that never answers
  const TEST_ADS = /[?&]testads=1/.test(location.search);
  const COIN_FRUIT = 1, COIN_BONUS = 5, COIN_GOLD = 25;   // coins for a fruit / big fruit / golden fruit
  const GOLD_POINTS = 100;           // golden fruit score (before multipliers)
  const GOLD_TICKS = 45;             // golden fruit stays this many steps
  const NEAR_POINTS = 20;            // close call bonus (Ultimate mode)
  const MAX_COINS = 999999;
  const BACKGROUNDS = ['Plain', 'Dots', 'Grid', 'Stripes', 'Plus'];

  const STORAGE_KEY = 'snakeFruitRush.v1';
  const FONT = 'Fredoka, Verdana, "Trebuchet MS", sans-serif';

  const THEMES = [
    { name: 'Midnight', bg: '#0f1220', board1: '#171b2e', board2: '#1d2340', head: '#86ff74', a: '#4ade80', b: '#22c55e', text: '#e5e7eb', accent: '#facc15', panel: '#2a3157', btnText: '#ffffff' },
    { name: 'Garden', bg: '#173622', board1: '#a7d948', board2: '#9bcf3f', head: '#3566d6', a: '#4f83f1', b: '#3f73e0', text: '#f0fdf4', accent: '#fde047', panel: '#2a6a45', btnText: '#ffffff' },
    { name: 'Ocean', bg: '#06283d', board1: '#0b3a57', board2: '#0f4466', head: '#ffe08a', a: '#ffb703', b: '#fb8500', text: '#e0f2fe', accent: '#5eead4', panel: '#14608f', btnText: '#ffffff' },
    { name: 'Sunset', bg: '#2b1331', board1: '#44203f', board2: '#4e2749', head: '#fff09a', a: '#ff9f1c', b: '#ff6b35', text: '#ffe8d6', accent: '#ff5d8f', panel: '#73305f', btnText: '#ffffff' },
    { name: 'Candy', bg: '#ffd9e8', board1: '#fff5f9', board2: '#ffe6f0', head: '#7c3aed', a: '#a78bfa', b: '#8b5cf6', text: '#4a2545', accent: '#ec4899', panel: '#f472b6', btnText: '#ffffff' }
  ];

  const POWERS = {
    slow: { name: 'SLOW', color: '#38bdf8' },
    ghost: { name: 'GHOST', color: '#a78bfa' },
    magnet: { name: 'MAGNET', color: '#ef4444' },
    wall: { name: 'NO WALLS', color: '#14b8a6' },
    double: { name: '2X', color: '#f59e0b' }
  };
  const POWER_KEYS = Object.keys(POWERS);
  const FRUITS = ['apple', 'orange', 'cherry', 'grapes', 'strawberry'];

  // Snake skins. 'default' follows the theme and is always free.
  const SKINS = [
    { id: 'default', name: 'Classic', cost: 0 },
    { id: 'lava', name: 'Lava', cost: 120, a: '#ff7a1a', b: '#e11d2e', head: '#ffd166', line: '#e11d2e' },
    { id: 'ice', name: 'Frost', cost: 120, a: '#bae6fd', b: '#38bdf8', head: '#ffffff', line: '#38bdf8' },
    { id: 'berry', name: 'Berry', cost: 200, a: '#f472b6', b: '#a21caf', head: '#fde68a', line: '#a21caf' },
    { id: 'bee', name: 'Bee', cost: 300, a: '#facc15', b: '#6b4423', head: '#facc15', line: '#6b4423' },
    { id: 'panda', name: 'Panda', cost: 350, a: '#ffffff', b: '#374151', head: '#ffffff', line: '#9ca3af', animal: 'panda' },
    { id: 'galaxy', name: 'Galaxy', cost: 450, a: '#6d28d9', b: '#312e81', head: '#c4b5fd', line: '#312e81', pattern: 'stars', trail: 'sparkle' },
    { id: 'rainbow', name: 'Rainbow', cost: 600, head: '#ffffff', line: '#a78bfa', pattern: 'rainbow', trail: 'rainbow' },
    { id: 'dragon', name: 'Dragon', cost: 700, a: '#4ade80', b: '#15803d', head: '#22c55e', line: '#15803d', animal: 'dragon', trail: 'fire' },
    { id: 'unicorn', name: 'Unicorn', cost: 900, a: '#fbcfe8', b: '#c4b5fd', head: '#ffffff', line: '#c4b5fd', animal: 'unicorn', trail: 'rainbow' },
    { id: 'gold', name: 'Golden', cost: 1000, a: '#fde047', b: '#d97706', head: '#fff7c2', line: '#d97706', pattern: 'shimmer', trail: 'sparkle' },
    { id: 'mint', name: 'Mint', cost: 1400, a: '#a7f3d0', b: '#34d399', head: '#ecfdf5', line: '#34d399' },
    { id: 'ocean', name: 'Ocean', cost: 1800, a: '#38bdf8', b: '#1d4ed8', head: '#bae6fd', line: '#1d4ed8', trail: 'bubble' },
    { id: 'kitty', name: 'Kitty', cost: 2200, a: '#fbbf24', b: '#f59e0b', head: '#fde68a', line: '#f59e0b', animal: 'cat' },
    { id: 'fox', name: 'Fox', cost: 2600, a: '#fb923c', b: '#c2410c', head: '#fdba74', line: '#c2410c', animal: 'fox' },
    { id: 'bunny', name: 'Bunny', cost: 3000, a: '#ffffff', b: '#fbcfe8', head: '#ffffff', line: '#f9a8d4', animal: 'bunny' },
    { id: 'neon', name: 'Neon', cost: 3500, a: '#22d3ee', b: '#a855f7', head: '#f0abfc', line: '#a855f7', pattern: 'neon', trail: 'sparkle' },
    { id: 'robot', name: 'Robo', cost: 4200, a: '#cbd5e1', b: '#64748b', head: '#e2e8f0', line: '#64748b', animal: 'robot' },
    { id: 'ninja', name: 'Ninja', cost: 5000, a: '#374151', b: '#111827', head: '#4b5563', line: '#111827', animal: 'ninja' },
    { id: 'magma', name: 'Magma', cost: 6000, a: '#fde047', b: '#dc2626', head: '#fff7ae', line: '#b91c1c', pattern: 'shimmer', trail: 'fire' },
    { id: 'phantom', name: 'Phantom', cost: 7000, a: '#e9d5ff', b: '#7c3aed', head: '#faf5ff', line: '#7c3aed', trail: 'sparkle' },
    { id: 'prism', name: 'Prism', cost: 8500, head: '#ffffff', line: '#c4b5fd', pattern: 'prism', trail: 'rainbow' },
    { id: 'emperor', name: 'Emperor', cost: 10000, a: '#fbbf24', b: '#b91c1c', head: '#fcd34d', line: '#b91c1c', animal: 'dragon', trail: 'fire' },
    { id: 'cosmic', name: 'Cosmic', cost: 12500, a: '#0ea5e9', b: '#4c1d95', head: '#e0f2fe', line: '#4c1d95', pattern: 'stars', trail: 'sparkle' },
    { id: 'diamond', name: 'Diamond', cost: 15000, a: '#bae6fd', b: '#e0f2fe', head: '#ffffff', line: '#7dd3fc', pattern: 'shimmer', trail: 'sparkle', animal: 'unicorn' },
    { id: 'royal', name: 'Royal', cost: 20000, a: '#fde047', b: '#a21caf', head: '#fff7c2', line: '#a21caf', pattern: 'shimmer', trail: 'gold', animal: 'crown' },
    { id: 'candy', name: 'Candy', cost: 550, a: '#f9a8d4', b: '#ffffff', head: '#f472b6', line: '#f472b6', trail: 'sparkle' },
    { id: 'jungle', name: 'Jungle', cost: 650, a: '#4ade80', b: '#166534', head: '#86efac', line: '#166534', trail: 'sparkle' },
    { id: 'wave', name: 'Ocean Wave', cost: 800, a: '#38bdf8', b: '#0e7490', head: '#67e8f9', line: '#0e7490', trail: 'bubble' },
    { id: 'nightneon', name: 'Night Neon', cost: 2600, a: '#c084fc', b: '#22d3ee', head: '#f5d0fe', line: '#7c3aed', pattern: 'neon', trail: 'sparkle' },
    { id: 'neonracer', name: 'Neon Racer', cost: 99999, special: '7-day daily streak', a: '#22d3ee', b: '#e879f9', head: '#ffffff', line: '#22d3ee', pattern: 'neon', trail: 'sparkle' },
    { id: 'obsidian', name: 'Obsidian', cost: 99999, special: '5 Expert clears', a: '#1f2937', b: '#7c3aed', head: '#f5d0fe', line: '#111827', pattern: 'shimmer', trail: 'fire', animal: 'crown' },
    { id: 'champion', name: 'Champion', cost: 99999, special: '3 stars on 25 levels', a: '#fde047', b: '#ffffff', head: '#fffbe0', line: '#f59e0b', pattern: 'shimmer', trail: 'gold', animal: 'crown' }
  ];
  const SKIN_BY_ID = {};
  SKINS.forEach((s) => { SKIN_BY_ID[s.id] = s; });

  // Daily challenges. One is picked from the date, so everybody gets the same one each day.
  const DAILY_TYPES = [
    { id: 'fruits', text: (n) => 'Eat ' + n + ' fruits', sub: 'across all games today', targets: [25, 40, 60], rewards: [40, 60, 90] },
    { id: 'score', text: (n) => 'Score ' + n + ' points', sub: 'in a single game', targets: [250, 400, 600], rewards: [40, 60, 90] },
    { id: 'survive', text: (n) => 'Survive ' + n + ' seconds', sub: 'in a single game', targets: [45, 75, 110], rewards: [40, 60, 90] },
    { id: 'bonus', text: (n) => 'Eat ' + n + ' big fruits', sub: 'across all games today', targets: [3, 5, 8], rewards: [40, 60, 90] },
    { id: 'golden', text: (n) => 'Catch ' + n + ' golden fruit', sub: 'across all games today', targets: [1, 2, 3], rewards: [50, 80, 120] },
    { id: 'combo', text: (n) => 'Reach combo x' + n, sub: 'in a single game', targets: [4, 6, 9], rewards: [40, 60, 90] },
    { id: 'ultimate', text: (n) => 'Dodge bombs: eat ' + n + ' fruits', sub: 'in Ultimate mode', targets: [12, 20, 30], rewards: [50, 80, 120] }
  ];
  const DAILY_BY_ID = {};
  DAILY_TYPES.forEach((d) => { DAILY_BY_ID[d.id] = d; });
  const STREAK_BONUS = 5, STREAK_MAX = 6;   // +5 coins per streak day, up to +30

  // ---------- Local storage ----------
  const num = (v, lo, hi, dflt) => {                 // safe integer from untrusted saved data
    v = Math.floor(Number(v));
    return isFinite(v) ? Math.min(hi, Math.max(lo, v)) : dflt;
  };
  const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
  function dateKey(d) {
    const p = (n) => (n < 10 ? '0' : '') + n;
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function addDays(key, n) {
    const a = key.split('-');
    return dateKey(new Date(+a[0], +a[1] - 1, +a[2] + n));
  }
  // Deterministic challenge for a date: same date -> same challenge.
  function makeDaily(date) {
    let h = 0;
    for (let i = 0; i < date.length; i++) h = (Math.imul(h, 31) + date.charCodeAt(i)) >>> 0;
    h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 3266489909) >>> 0;
    h = (h ^ (h >>> 16)) >>> 0;
    const type = DAILY_TYPES[h % DAILY_TYPES.length], tier = (h >>> 8) % 3;
    return { date: date, id: type.id, target: type.targets[tier], reward: type.rewards[tier], progress: 0, claimed: false };
  }
  function cleanDaily(d) {
    if (!d || typeof d !== 'object' || !DATE_RE.test(d.date) || !DAILY_BY_ID[d.id]) return null;
    const ref = makeDaily(d.date);
    if (ref.id !== d.id) return null;                                  // does not match the generator: ignore the save
    ref.progress = num(d.progress, 0, 1e7, 0);                         // target and reward always come from the generator
    ref.claimed = d.claimed === true;
    return ref;
  }


  // ---------- Campaign: 100 levels in 5 worlds (the level data and rules engine are embedded above) ----------
  const E = window.SFREngine, LV = window.SFR_LEVELS || [];
  const LEVEL_COUNT = LV.length;
  const UNLOCK_ALL = /[?&]unlock=1/.test(location.search);        // testing: all levels open (not saved)
  const READY_MS = 1100;
  const SPEED_MUL = () => (window.__speedMul > 0 ? window.__speedMul : 1);
  const WORLDS = [
    { name: 'Garden', sub: 'Walls, fruit and the exit', pattern: 3, pal: { bg: '#123a22', board1: '#b5e061', board2: '#a9d655', panel: '#2d7a4a', accent: '#ffd23f', text: '#f0fdf4', btnText: '#ffffff', head: '#2f6bff', a: '#5b8cff', b: '#3f73e0' },
      wall: { base: '#2f8f3a', top: '#6bdc62', edge: '#1b5a28' } },
    { name: 'Desert', sub: 'Winding canyons and dead ends', pattern: 1, pal: { bg: '#3a2210', board1: '#f4dca4', board2: '#eed199', panel: '#a35e2c', accent: '#ffb703', text: '#fff4e0', btnText: '#ffffff', head: '#12806f', a: '#26b59c', b: '#1a9680' },
      wall: { base: '#c4783f', top: '#eaa86a', edge: '#82481f' } },
    { name: 'Ice', sub: 'Slippery floors. Plan your stops!', pattern: 2, pal: { bg: '#0a2a4d', board1: '#c3e6f7', board2: '#b8dff3', panel: '#2f6fb3', accent: '#7dd3fc', text: '#e6f6ff', btnText: '#ffffff', head: '#ff7a59', a: '#ff9470', b: '#f4693f' },
      wall: { base: '#3f78c4', top: '#a9dcff', edge: '#244f8c' } },
    { name: 'Volcano', sub: 'Bombs! Steer around the danger', pattern: 4, pal: { bg: '#2a0c0c', board1: '#47292b', board2: '#4f2e30', panel: '#8a3420', accent: '#ffb020', text: '#ffe8d6', btnText: '#ffffff', head: '#fff09a', a: '#ffd166', b: '#ff9f1c' },
      wall: { base: '#2e2433', top: '#5d4a66', edge: '#150f19' } },
    { name: 'Night', sub: 'Keys, gates, switches and portals', pattern: 2, pal: { bg: '#090920', board1: '#1c2044', board2: '#222850', panel: '#40408a', accent: '#c4b5fd', text: '#e0e7ff', btnText: '#ffffff', head: '#9dff7a', a: '#4ade80', b: '#22c55e' },
      wall: { base: '#3b3880', top: '#7a76d6', edge: '#1c1a47' } }
  ];
  const GATE_COLS = ['#f97316', '#22d3ee', '#a3e635', '#f472b6'];
  const FAIL_TEXT = { wall: 'You hit a wall', body: 'You hit your own body', trap: 'Boom! You hit a bomb', door: 'That way is closed', stuck: 'Stuck on the ice', moves: 'Too many moves for Expert' };
  const hh = (a, b, s) => {                                           // tiny deterministic hash 0..1 (for tile decoration)
    let h = Math.imul(a + 1, 73856093) ^ Math.imul(b + 1, 19349663) ^ Math.imul(s + 1, 83492791);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  const lvLayer = (str) => {
    const a = new Uint8Array(COLS * ROWS);
    if (!str) return a;
    for (let y = 0; y < ROWS; y++) {
      let m = 0;
      for (let k = 0; k < 4; k++) m = (m << 5) | parseInt(str[y * 4 + k], 32);
      for (let x = 0; x < COLS; x++) if ((m >> x) & 1) a[y * COLS + x] = 1;
    }
    return a;
  };
  function engineLevel(L) {
    const walls = [], ice = [], items = [], devices = [], w = lvLayer(L.W), ic = lvLayer(L.I), bm = lvLayer(L.B);
    for (let i = 0; i < COLS * ROWS; i++) {
      const c = [i % COLS, (i / COLS) | 0];
      if (w[i]) walls.push(c);
      if (ic[i]) ice.push(c);
      if (bm[i]) items.push({ type: 'bomb', cell: c });
    }
    L.F.forEach((c) => items.push({ type: 'fruit', cell: c, species: 'apple', required: true }));
    (L.K || []).forEach((c, i) => items.push({ type: 'key', cell: c, id: 'k' + i }));
    (L.D || []).forEach((c, i) => devices.push({ type: 'door', cell: c, id: 'k' + i }));
    (L.G || []).forEach((c, i) => devices.push({ type: 'gate', cell: c, id: 'g' + i, startOpen: false }));
    (L.S || []).forEach((s, i) => devices.push({ type: 'switch', cell: [s[0], s[1]], id: 's' + i, gate: 'g' + s[2] }));
    (L.P || []).forEach((p) => devices.push({ type: 'portal', cells: [[p[0], p[1]], [p[2], p[3]]] }));
    return { board: { cols: COLS, rows: ROWS, walls: walls, ice: ice }, snake: { head: [L.s[0], L.s[1]], direction: ['up', 'right', 'down', 'left'][L.s[2]], length: 3 },
      items: items, devices: devices, exit: { cell: L.E }, starRules: { two: { type: 'complete' }, three: [] } };
  }
  function cleanCamp(c) {
    const o = { unlocked: 1, cur: 1, stars: {} };
    if (c && typeof c === 'object') {
      o.unlocked = num(c.unlocked, 1, Math.max(1, LEVEL_COUNT), 1);
      if (c.stars && typeof c.stars === 'object') {
        Object.keys(c.stars).forEach((k) => {
          const id = k | 0, s = num(c.stars[k], 0, 3, 0);
          if (id >= 1 && id <= LEVEL_COUNT && s > 0) { o.stars[id] = s; if (id + 1 > o.unlocked) o.unlocked = Math.min(LEVEL_COUNT, id + 1); }
        });
      }
      o.cur = num(c.cur, 1, o.unlocked, o.unlocked);
    }
    return o;
  }
  // Power-ups that can be bought with coins and used inside levels.
  const PW = {
    slow: { name: 'Slow-Mo', cost: 60, desc: 'Snake moves slower for a while' },
    shield: { name: 'Shield', cost: 90, desc: 'Saves you from one crash' },
    sweep: { name: 'Defuse', cost: 80, desc: 'Removes bombs near you' },
    coin2: { name: '2x Coins', cost: 70, desc: 'Double coins in this level' }
  };
  const PW_KEYS = Object.keys(PW);
  function cleanPw(p) {
    const o = {};
    PW_KEYS.forEach((k) => { o[k] = num(p && p[k], 0, 99, 0); });
    return o;
  }

  // ---------- Campaign daily challenge definitions (needed while the save is loaded) ----------
  const CD_TYPES = [
    { id: 'clevel', text: (n) => 'Complete ' + n + ' levels', sub: 'in the campaign today', targets: [2, 3, 4] },
    { id: 'cstars', text: (n) => 'Earn ' + n + ' stars', sub: 'in the campaign today', targets: [4, 7, 10] },
    { id: 'cfruit', text: (n) => 'Eat ' + n + ' fruits in levels', sub: 'in the campaign today', targets: [20, 35, 50] },
    { id: 'c3', text: (n) => 'Get 3 stars on ' + n + (n > 1 ? ' levels' : ' level'), sub: 'in the campaign today', targets: [1, 2, 3] },
    { id: 'cfirst', text: (n) => 'Clear ' + n + (n > 1 ? ' levels' : ' level') + ' first try', sub: 'no failed attempt', targets: [1, 2, 3] }
  ];
  const CD_BY_ID = {}, CD_REWARD = [50, 75, 110];
  CD_TYPES.forEach((d) => { CD_BY_ID[d.id] = d; });
  function cdBuild(date, id, t) { return { date: date, id: id, t: t, target: CD_BY_ID[id].targets[t], reward: CD_REWARD[t], progress: 0, claimed: false }; }
  function makeCD(date) {
    let h = 7;
    for (let i = 0; i < date.length; i++) h = (Math.imul(h, 33) + date.charCodeAt(i)) >>> 0;
    h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; h = (h ^ (h >>> 13)) >>> 0;
    const un = DATA.camp ? DATA.camp.unlocked : 1;                       // difficulty follows campaign progress
    return cdBuild(date, CD_TYPES[h % CD_TYPES.length].id, un <= 12 ? 0 : un <= 40 ? 1 : 2);
  }
  function cleanCDaily(d) {
    if (!d || typeof d !== 'object' || !DATE_RE.test(d.date) || !CD_BY_ID[d.id]) return null;
    const r = cdBuild(d.date, d.id, num(d.t, 0, 2, 0));
    r.progress = num(d.progress, 0, 1e7, 0); r.claimed = d.claimed === true;
    return r;
  }

  // Frame-time smoothing for the snake's step clock: a long frame never lets the snake jump more than ~50 ms ahead, and the time
  // it did not get is paid back slowly (at most +25% for a few frames), so the average speed is exactly the same as before.
  let owed = 0;
  function stepClock(delta) {
    const inc = Math.min(delta, 50);
    owed = Math.min(400, owed + delta - inc);
    const pay = Math.min(owed, inc * 0.25);
    owed -= pay;
    return inc + pay;
  }

  function loadData() {
    const d = { high: 0, highs: {}, mode: 'classic', speed: 5, tab: 0, theme: 0, bg: 0, sound: true, save: null,
      coins: 0, skin: 'default', skins: ['default'], daily: null, cdaily: null, claimedDates: [], streak: 0, lastClaim: '', spinDates: [], camp: null, adCoins: null, menuMode: 'levels', vibe: true, tapSteer: false, pw: null };
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      if (saved && typeof saved === 'object') Object.assign(d, saved);
    } catch (e) { /* no storage or broken data: use defaults */ }
    if (!d.highs || typeof d.highs !== 'object') d.highs = {};
    if (d.highs.classic === undefined) d.highs.classic = d.high | 0;   // old single high score
    if (!MODES[d.mode]) d.mode = 'classic';
    d.speed = Math.min(10, Math.max(1, d.speed | 0 || 5));
    d.tab = Math.abs(d.tab | 0) % 8;
    d.theme = Math.abs(d.theme | 0) % THEMES.length;
    d.bg = Math.abs(d.bg | 0) % BACKGROUNDS.length;
    // coins + skins
    d.coins = num(d.coins, 0, MAX_COINS, 0);
    const owned = Array.isArray(d.skins) ? d.skins.filter((id, i, a) => typeof id === 'string' && SKIN_BY_ID[id] && a.indexOf(id) === i) : [];
    if (owned.indexOf('default') < 0) owned.unshift('default');
    d.skins = owned;
    if (typeof d.skin !== 'string' || owned.indexOf(d.skin) < 0) d.skin = 'default';   // locked skins cannot be selected
    // daily challenge
    d.claimedDates = Array.isArray(d.claimedDates) ? d.claimedDates.filter((x) => typeof x === 'string' && DATE_RE.test(x)).slice(-120) : [];
    d.streak = num(d.streak, 0, 100000, 0);
    d.lastClaim = typeof d.lastClaim === 'string' && DATE_RE.test(d.lastClaim) ? d.lastClaim : '';
    d.spinDates = Array.isArray(d.spinDates) ? d.spinDates.filter((x) => typeof x === 'string' && DATE_RE.test(x)).slice(-60) : [];
    d.daily = cleanDaily(d.daily); d.cdaily = cleanCDaily(d.cdaily);
    d.adCoins = d.adCoins && typeof d.adCoins === 'object' && DATE_RE.test(d.adCoins.d) ? { d: d.adCoins.d, n: num(d.adCoins.n, 0, 99, 0) } : null;
    d.menuMode = d.menuMode === 'endless' ? 'endless' : 'levels'; d.vibe = d.vibe !== false; d.tapSteer = d.tapSteer === true; d.pw = cleanPw(d.pw);
d.camp = cleanCamp(d.camp);                                         // campaign progress: unlocked level, current level, stars per level
    return d;
  }
  function writeData() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(DATA)); } catch (e) { /* no storage */ }
  }

  const DATA = loadData();
  let state = 'menu';                // menu / play / paused / over / ad
  let adLeft = 0;                    // ms left of the placeholder ad (-1 = waiting for a real ad)
  let G = null;                      // running game
  let prevSnake = null;              // snake before the last step (for smooth movement)
  let acc = 0;                       // ms since the last step
  let anim = 0;                      // animation clock (ms)
  let buttons = [];                  // {x, y, w, h, fn} for taps
  let popups = [];                   // {x, y, s, color, life}
  let scene, g, boardG, layers = [], L = null;   // two drawing layers: 0 = game/menu, 1 = overlays on top
  let sheetOpen = false, sheetT = 0;              // home screen settings sheet
  let demo = null;
  let fxs = [];                      // short visual effects: sparks and rings {k, x, y, vx, vy, r, color, life, max}
  let banner = null;                 // big message over the board {s, sub, color, life}
  let adToken = 0, adTimer = 0;      // identifies the running rewarded-ad request
  let dailyCheck = 0;                // last time the date was checked (ms)

  let govT = 0, govN = 0, govDone = false;      // frame-time governor
  let LITE = false, fpsAvg = 16;     // LITE = slow device, skip the decorations
  let CT = null;                      // world palette while a campaign screen is open
  const th = () => CT || THEMES[DATA.theme];
  const colCache = {};                              // colour strings -> numbers (parsing them every draw call is wasted work)
  let colCount = 0;
  const C = (hex) => { const v = colCache[hex]; if (v !== undefined) return v; if (colCount > 600) { for (const k in colCache) delete colCache[k]; colCount = 0; } colCount++; return (colCache[hex] = parseInt(hex.slice(1), 16)); };
  const cellPool = []; for (let i = 0; i < 32; i++) cellPool.push({ x: 0, y: 0 }); let cellPi = 0;   // results are used straight away, so a small ring of objects avoids per-frame garbage
  const cellXY = (c, r) => { const o = cellPool[cellPi++ & 31]; o.x = BX + c * CELL + CELL / 2; o.y = BY + r * CELL + CELL / 2; return o; };
  const rnd = (n) => Math.floor(Math.random() * n);
  const modeOf = () => MODES[(G && G.mode) || 'classic'];
  const has = (k) => !!(G.fx[k] || modeOf()[k]);          // ability from a power-up or from the game mode
  const best = (m) => DATA.highs[m] | 0;
  const shadeMemo = {}; let shadeN = 0;
  function shade(hex, f) {                          // f < 0 darker, f > 0 lighter
    const mk = hex + '|' + f, mv = shadeMemo[mk];
    if (mv !== undefined) return mv;
    if (shadeN > 500) { for (const k in shadeMemo) delete shadeMemo[k]; shadeN = 0; }
    shadeN++;
    return (shadeMemo[mk] = shade0(hex, f));
  }
  function shade0(hex, f) {
    const n = C(hex), m = f < 0 ? 0 : 255, a = Math.abs(f);
    const ch = (v) => Math.round(v + (m - v) * a);
    return '#' + ((1 << 24) | (ch(n >> 16) << 16) | (ch((n >> 8) & 255) << 8) | ch(n & 255)).toString(16).slice(1);
  }

  function hsl(h, s2, l) {
    h = ((h % 360) + 360) % 360; s2 /= 100; l /= 100;
    const k = (n) => (n + h / 30) % 12, a = s2 * Math.min(l, 1 - l);
    const f = (n) => Math.round(255 * (l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)))));
    return '#' + ((1 << 24) | (f(0) << 16) | (f(8) << 8) | f(4)).toString(16).slice(1);
  }

  // ---------- Coins, skins and the daily challenge ----------
  const coinText = (n) => (n >= 10000 ? Math.floor(n / 1000) + 'k' : String(n));
  function addCoins(n) {
    n = n | 0;
    if (n <= 0) return;
    DATA.coins = Math.min(MAX_COINS, DATA.coins + n);
    if (G) G.coins = (G.coins | 0) + n;
  }
  const skinOwned = (id) => DATA.skins.indexOf(id) >= 0;
  const activeSkin = () => SKIN_BY_ID[DATA.skin] || SKINS[0];
  function selectSkin(id) {
    if (!SKIN_BY_ID[id] || !skinOwned(id)) return false;        // a locked skin can never be selected
    DATA.skin = id;
    writeData();
    return true;
  }
  function buySkin(id) {
    const sk = SKIN_BY_ID[id];
    if (!sk || sk.special || skinOwned(id) || DATA.coins < sk.cost) return false;
    DATA.coins -= sk.cost;
    DATA.skins.push(id);
    DATA.skin = id;
    writeData();
    sfx.coin();
    return true;
  }

  // Makes sure DATA.daily is today's challenge (also after midnight or when the clock changes).
  function dailyEnsure(force) {
    const now = Date.now();
    if (!force && DATA.daily && now - dailyCheck < 4000) return DATA.daily;
    dailyCheck = now;
    const today = dateKey(new Date());
    if (!DATA.daily || DATA.daily.date !== today) {
      DATA.daily = makeDaily(today);
      if (DATA.claimedDates.indexOf(today) >= 0) {              // already rewarded for this date (e.g. clock moved back)
        DATA.daily.claimed = true;
        DATA.daily.progress = DATA.daily.target;
      }
      writeData();
    }
    return DATA.daily;
  }
  function dailyText() {
    const d = dailyEnsure();
    return DAILY_BY_ID[d.id].text(d.target);
  }
  // kind: the objective id. add: progress is added up; max: progress keeps the best value.
  function dailyAdd(id, n) { dailyUpdate(id, n, false); }
  function dailyMax(id, v) { dailyUpdate(id, v, true); }
  function dailyUpdate(id, v, isMax) {
    const d = dailyEnsure();
    if (d.id !== id || d.claimed || (G && G.camp)) return;      // campaign play never feeds the Endless challenge
    if (id === 'ultimate' && (!G || G.mode !== 'ultimate')) return;
    d.progress = Math.min(d.target, isMax ? Math.max(d.progress, v) : d.progress + v);
    if (d.progress >= d.target) claimDaily();
  }
  // The reward is paid at most once per date: the flag and the date list are saved before anything else happens.
  function claimDaily() {
    const d = DATA.daily;
    if (!d || d.claimed || d.progress < d.target || DATA.claimedDates.indexOf(d.date) >= 0) return;
    d.claimed = true;
    DATA.claimedDates.push(d.date);
    if (DATA.claimedDates.length > 120) DATA.claimedDates.shift();
    DATA.streak = DATA.lastClaim && addDays(DATA.lastClaim, 1) === d.date ? DATA.streak + 1 : 1;
    DATA.lastClaim = d.date;
    const bonus = Math.min(DATA.streak - 1, STREAK_MAX) * STREAK_BONUS, total = d.reward + bonus;
    addCoins(total);
    if (G) G.dailyCoins = (G.dailyCoins | 0) + total;
    writeData();
    showBanner('DAILY DONE!  +' + total + ' coins', DATA.streak > 1 ? DATA.streak + ' day streak' : 'Challenge complete', '#facc15', 2200);
    if (G) { const h = cellXY(G.snake[0][0], G.snake[0][1]); burst(h.x, h.y, 'rand', 16); }
    sfx.win();
    buzz(40);
  }

  // ---------- Short effects (kept small and cheap for low-end phones) ----------
  const REDUCED = (() => { try { return !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } })();   // fewer particles / decorations, the snake still glides
  const MAX_FX = 48;
  const CONFETTI = ['#f87171', '#fbbf24', '#4ade80', '#38bdf8', '#c084fc', '#f472b6'];
  function burst(x, y, color, n) {
    if (LITE || REDUCED) n = (n + 1) >> 1;
    for (let i = 0; i < n && fxs.length < MAX_FX; i++) {
      const a = Math.random() * 6.283, v = 0.05 + Math.random() * 0.08;
      fxs.push({ k: 0, x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, r: 2 + Math.random() * 2, color: color === 'rand' ? CONFETTI[rnd(CONFETTI.length)] : color, life: 420, max: 420 });
    }
  }
  // Little puffs behind the tail: skin trails (rainbow, fire, sparkle) and a sparkle while a combo is running.
  function trailPuff() {
    const sk = activeSkin(), t = G.snake[G.snake.length - 1];
    let color = null;
    if (sk.trail === 'rainbow') color = hsl(anim * 0.35, 90, 60);
    else if (sk.trail === 'fire') color = Math.random() < 0.5 ? '#f97316' : '#fbbf24';
    else if (sk.trail === 'sparkle') color = Math.random() < 0.5 ? '#fde68a' : '#ffffff';
    else if (sk.trail === 'bubble') color = Math.random() < 0.5 ? '#7dd3fc' : '#ffffff';
    else if (sk.trail === 'gold') color = Math.random() < 0.5 ? '#fde047' : '#f59e0b';
    else if (G.combo >= 3) color = th().accent;
    if (!color || fxs.length >= MAX_FX - 8) return;
    const p = cellXY(t[0], t[1]);
    fxs.push({ k: 0, x: p.x + (Math.random() - 0.5) * 6, y: p.y + (Math.random() - 0.5) * 6, vx: (Math.random() - 0.5) * 0.02, vy: (Math.random() - 0.5) * 0.02, r: 3.2, color: color, life: 520, max: 520 });
  }
  function ring(x, y, color) {
    if (fxs.length < MAX_FX) fxs.push({ k: 1, x: x, y: y, vx: 0, vy: 0, r: 14, color: color, life: 380, max: 380 });
  }
  function showBanner(s, sub, color, ms) { banner = { s: s, sub: sub || '', color: color, life: ms || 1100, max: ms || 1100 }; }

  // ---------- Sound + vibration ----------
  let actx = null, master = null, unlocked = false;
  // The browser only allows sound after a tap/key, so audio starts on the first touch.
  function audio() {
    if (!unlocked) return null;
    try {
      if (!actx) {
        actx = new (window.AudioContext || window.webkitAudioContext)();
        master = actx.createGain();
        master.gain.value = 0.9;
        master.connect(actx.destination);
      }
      if (actx.state === 'suspended') actx.resume();
      return actx;
    } catch (e) { return null; }
  }
  function unlockAudio() { if (!unlocked) { unlocked = true; audio(); } }
  // One note: frequency (Hz), length (s), wave, volume, delay (s), optional glide target (Hz).
  function tone(freq, dur, type, vol, delay, slide) {
    if (!DATA.sound) return;
    const c = audio();
    if (!c) return;
    try {
      const o = c.createOscillator(), gn = c.createGain(), t = c.currentTime + (delay || 0);
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
      gn.gain.setValueAtTime(0.0001, t);
      gn.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.01);
      gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(gn); gn.connect(master);
      o.start(t); o.stop(t + dur + 0.03);
    } catch (e) { /* no audio */ }
  }
  function noise(dur, vol) {
    if (!DATA.sound) return;
    const c = audio();
    if (!c) return;
    try {
      const nk = dur + '|' + c.sampleRate, nc = noise.cache || (noise.cache = {});
      let buf = nc[nk];
      if (!buf) {                                  // the noise burst is made once per length and reused
        const n = Math.floor(c.sampleRate * dur), d = (buf = nc[nk] = c.createBuffer(1, n, c.sampleRate)).getChannelData(0);
        for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
      }
      const src = c.createBufferSource(), gn = c.createGain();
      src.buffer = buf; gn.gain.value = vol;
      src.connect(gn); gn.connect(master);
      src.start();
    } catch (e) { /* no audio */ }
  }
  // Cute sound effects
  const sfx = {
    click: () => tone(540, 0.05, 'triangle', 0.12),
    eat: (combo) => { const f = 460 + Math.min(combo, 10) * 40; tone(f, 0.1, 'sine', 0.3, 0, f * 1.7); },       // "pop"
    yum: () => { tone(660, 0.1, 'triangle', 0.25); tone(880, 0.16, 'triangle', 0.25, 0.08); },
    gold: () => [784, 988, 1175, 1568].forEach((f, i) => tone(f, 0.15, 'triangle', 0.25, i * 0.07)),
    combo: (n) => { tone(520 + n * 35, 0.1, 'triangle', 0.22); tone(780 + n * 35, 0.14, 'triangle', 0.22, 0.09); },
    power: () => tone(380, 0.25, 'square', 0.14, 0, 1000),
    coin: () => { tone(988, 0.08, 'square', 0.12); tone(1319, 0.22, 'square', 0.12, 0.07); },
    win: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.2, 'triangle', 0.25, i * 0.1)),
    over: () => tone(440, 0.55, 'triangle', 0.28, 0, 160),
    boom: () => { noise(0.5, 0.4); tone(130, 0.5, 'sawtooth', 0.28, 0, 40); },
    near: () => tone(300, 0.14, 'square', 0.12, 0, 750),
    err: () => { tone(230, 0.13, 'square', 0.14); tone(170, 0.2, 'square', 0.14, 0.1); },
    revive: () => [440, 660, 880].forEach((f, i) => tone(f, 0.18, 'triangle', 0.25, i * 0.09)),
    key: () => { tone(1047, 0.1, 'triangle', 0.25); tone(1568, 0.2, 'triangle', 0.25, 0.08); },
    door: () => { tone(220, 0.12, 'square', 0.14); tone(330, 0.2, 'square', 0.14, 0.1); },
    sw: (open) => { tone(open ? 520 : 400, 0.08, 'square', 0.14); tone(open ? 780 : 260, 0.16, 'square', 0.14, 0.07); },
    portal: () => tone(300, 0.28, 'sine', 0.22, 0, 1200)
  };
  // Happy background tune (pentatonic, so every note fits). Notes are scheduled a little ahead of time
  // from the game loop - there are no timers, so nothing keeps playing after a pause, game over or Home.
  const TUNE = [
    [0, 4, 7, 9, 7, 4, 7, 4, 2, 5, 9, 12, 9, 5, 9, 5],
    [0, 4, 7, 12, 9, 7, 4, 7, 5, 9, 12, 9, 7, 4, 2, 4],
    [4, 7, 9, 7, 4, 2, 4, 0, 5, 9, 7, 5, 4, 2, 0, 2],
    [0, 7, 4, 7, 9, 7, 12, 9, 7, 4, 7, 2, 4, 0, 4, 7]
  ];
  const BASS = [0, -3, -7, -5];
  const MUSIC_STEP = 0.19;
  let musicNext = 0, musicStep = 0;
  function musicTick() {
    if (!DATA.sound || !unlocked || (state !== 'play' && state !== 'menu' && state !== 'levels')) { musicNext = 0; return; }
    const c = audio();
    if (!c || c.state !== 'running') return;
    const now = c.currentTime;
    if (musicNext < now) musicNext = now + 0.05;
    while (musicNext < now + 0.3) {
      const i = musicStep & 15, bar = (musicStep >> 4) % TUNE.length, d = musicNext - now, vol = state === 'menu' || state === 'levels' ? 0.06 : 0.08;
      tone(261.63 * Math.pow(2, TUNE[bar][i] / 12), 0.24, 'triangle', vol, d);
      if (i % 4 === 0) tone(130.81 * Math.pow(2, BASS[i >> 2] / 12), 0.6, 'sine', vol * 1.3, d);
      musicStep++; musicNext += MUSIC_STEP;
    }
  }

  function buzz(ms) {
    try { if (DATA.vibe && navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignore */ }
  }

  // ---------- Drawing helpers ----------
  function dot(x, y, r, color, alpha) {
    g.fillStyle(C(color), alpha === undefined ? 1 : alpha);
    g.fillCircle(x, y, r);
  }
  function line(x1, y1, x2, y2, color, width) {
    g.lineStyle(width, C(color), 1);
    g.lineBetween(x1, y1, x2, y2);
  }
  function rrect(x, y, w, h, r, color, alpha) {
    g.fillStyle(C(color), alpha === undefined ? 1 : alpha);
    g.fillRoundedRect(x, y, w, h, r);
  }
  // Text objects are pooled and reused every frame.
  const TXT_K = 1.1;                  // all text a little bigger than before
  function txt(x, y, s, size, color, originX, bold) {
    size = Math.round(size * TXT_K * 10) / 10;
    // Every different text (string + size + colour) keeps its own Text object, so a string that is shown again is never re-drawn
    // into a texture: opening a pop-up or changing screens no longer re-renders a dozen texts in one frame.
    const key = s + '|' + size + '|' + color + '|' + (bold === false ? 0 : 1);
    let e = L.byKey[key];
    if (!e) e = L.byKey[key] = { list: [], n: 0, pn: 0 };
    let t = e.list[e.n];
    if (!t) {
      t = scene.add.text(0, 0, s, { fontFamily: FONT, fontSize: (size * ZOOM) + 'px', color: color, fontStyle: bold === false ? '500' : '700' });
      t.setScale(1 / ZOOM);            // text is rendered at ZOOM x size, then scaled down, so it stays sharp
      t.setDepth(L.depth + 1);
      e.list.push(t); L.texts.push(t);
    }
    if (e.n === 0) L.active.push(e);
    e.n++;
    t.setOrigin(originX === undefined ? 0.5 : originX, 0.5);
    t.setPosition(x, y);
    t.setVisible(true);
  }
  function textsBegin() {
    layers.forEach((ly) => { ly.g.clear(); for (const e of ly.active) { e.pn = e.n; e.n = 0; } ly.prev = ly.active; ly.active = []; });
  }
  function textsEnd() {
    layers.forEach((ly) => {
      for (const e of ly.prev) for (let i = e.n; i < e.pn; i++) e.list[i].setVisible(false);
      ly.prev = [];
      if (ly.texts.length > 260) {                                   // keep the number of cached texts bounded: drop the ones not on screen
        for (const k in ly.byKey) { const e = ly.byKey[k]; if (e.n === 0) { e.list.forEach((t) => t.destroy()); delete ly.byKey[k]; } }
        ly.texts = ly.texts.filter((t) => t.scene);
      }
    });
  }
  function button(cx, cy, w, h, label, fn, opts) {
    const t = th(), o = opts || {};
    let fill = o.primary ? t.accent : t.panel;
    let labelColor = o.primary ? '#1b1b1b' : t.btnText;
    if (o.disabled) { fill = t.board2; labelColor = t.panel; }
    if (o.dark) { fill = t.bg; labelColor = t.text; }
    const r = Math.min(20, h / 2);
    if (!slice3('btn_pill', cx, cy + 1, w + 6, h + 8, C(fill))) {
      if (o.primary) rrect(cx - w / 2, cy - h / 2 + 5, w, h, r, shade(fill, -0.3));   // 3D base
      rrect(cx - w / 2, cy - h / 2, w, h, r, fill);
    }
    txt(cx, cy, label, o.size || 18, labelColor);
    if (!o.disabled && fn) buttons.push({ x: cx - w / 2, y: cy - h / 2, w: w, h: h, fn: fn });
  }

  function useLayer(i) { L = layers[i]; g = L.g; }

  // ---------- Fruits ----------
  function drawFruit(kind, x, y, s) {
    const d = (dx, dy, r, col) => dot(x + dx * s, y - dy * s, r * s, col);
    const l = (x1, y1, x2, y2, col, w) => line(x + x1 * s, y - y1 * s, x + x2 * s, y - y2 * s, col, w * s);
    if (kind === 'apple') {
      l(0, 6, 2, 12, '#7a4a21', 2);
      d(5, 11, 3, '#4caf50');
      d(0, 0, 9, '#e53935');
      d(-4, 4, 2.5, '#ff8a80');
    } else if (kind === 'orange') {
      d(0, 0, 9, '#ff9a1f');
      d(-4, 4, 2.5, '#ffd08a');
      d(1, 9, 3, '#3fa34d');
    } else if (kind === 'cherry') {
      l(1, 11, -5, -2, '#3fa34d', 2);
      l(1, 11, 5, -3, '#3fa34d', 2);
      d(-5, -4, 5.5, '#c2185b');
      d(5, -5, 5.5, '#d81b60');
      d(-7, -2, 1.5, '#ff9ec4');
      d(3, -3, 1.5, '#ff9ec4');
    } else if (kind === 'grapes') {
      l(0, 6, 1, 12, '#7a4a21', 2);
      d(4, 10, 2.5, '#4caf50');
      [[-5, 4], [0, 4], [5, 4], [-2.5, -1], [2.5, -1], [0, -6]].forEach((p) => {
        d(p[0], p[1], 4, '#8e44ad');
        d(p[0] - 1, p[1] + 1, 1.25, '#d7a8f0');
      });
    } else { // strawberry
      d(0, 2, 8, '#ef233c');
      d(0, -4, 5.5, '#ef233c');
      [[-3, 3], [3, 2], [0, -1], [-2, -5], [3, -4]].forEach((p) => d(p[0], p[1], 1, '#ffe066'));
      [[-4, 8], [0, 9.5], [4, 8]].forEach((p) => d(p[0], p[1], 3, '#3fa34d'));
    }
  }

  function drawCoin(x, y, r) {
    if (IMGOK.coin) { blitImg('coin' + L.depth, 'img_coin', x, y, r * 2.2, r * 2.2, 1, L.depth + 0.5); return; }
    dot(x, y, r, '#b45309');
    dot(x, y, r * 0.84, '#fbbf24');
    dot(x - r * 0.2, y - r * 0.2, r * 0.3, '#fde68a');
  }
  // Golden fruit: a shiny gold apple with a pulsing glow and a shrinking timer ring.
  function drawGolden(x, y, s, frac) {
    const a = anim / 60;
    dot(x, y, (21 + 3 * Math.sin(a * 0.7)) * s, '#fde047', 0.28);
    line(x, y - 8 * s, x + 3 * s, y - 14 * s, '#7a4a21', 2 * s);
    dot(x + 5 * s, y - 12 * s, 3 * s, '#facc15');
    dot(x, y, 10 * s, '#d97706');
    dot(x, y, 9 * s, '#fbbf24');
    dot(x - 3.5 * s, y - 3.5 * s, 3 * s, '#fff3b0');
    const tw = Math.sin(a * 1.3) > 0.4;                                  // little twinkle
    if (tw) { line(x + 11 * s, y - 6 * s, x + 15 * s, y - 6 * s, '#ffffff', 1.6 * s); line(x + 13 * s, y - 8 * s, x + 13 * s, y - 4 * s, '#ffffff', 1.6 * s); }
    if (frac < 1) {                                                      // time left
      g.lineStyle(2.5, C('#fde047'), 1);
      g.beginPath(); g.arc(x, y, 14 * s, -Math.PI / 2, -Math.PI / 2 + 6.283 * Math.max(0.02, frac)); g.strokePath();
    }
  }

  // ---------- Ability icons ----------
  function drawPower(kind, x, y, s) {
    const col = POWERS[kind].color;
    dot(x, y, 12 * s, '#ffffff');
    dot(x, y, 10.5 * s, col);
    if (kind === 'slow') {                       // clock
      dot(x, y, 6.5 * s, '#ffffff');
      line(x, y, x, y - 4.5 * s, '#1f2937', 2 * s);
      line(x, y, x + 3.5 * s, y, '#1f2937', 2 * s);
    } else if (kind === 'ghost') {
      dot(x, y - 2 * s, 5.6 * s, '#ffffff');
      g.fillStyle(0xffffff, 1);
      g.fillRect(x - 5.6 * s, y - 2 * s, 11.2 * s, 5 * s);
      [-3.7, 0, 3.7].forEach((dx) => dot(x + dx * s, y + 3 * s, 1.9 * s, '#ffffff'));
      dot(x - 2.2 * s, y - 2 * s, 1.4 * s, '#1f2937');
      dot(x + 2.2 * s, y - 2 * s, 1.4 * s, '#1f2937');
    } else if (kind === 'magnet') {              // U-shaped magnet
      line(x - 4.5 * s, y - 5.5 * s, x - 4.5 * s, y + 4.5 * s, '#ffffff', 3.4 * s);
      line(x + 4.5 * s, y - 5.5 * s, x + 4.5 * s, y + 4.5 * s, '#ffffff', 3.4 * s);
      line(x - 6.2 * s, y + 4 * s, x + 6.2 * s, y + 4 * s, '#ffffff', 3.4 * s);
    } else if (kind === 'wall') {                // portal
      dot(x, y, 7 * s, '#ffffff');
      dot(x, y, 4.8 * s, col);
      dot(x, y, 2.2 * s, '#ffffff');
    } else {                                     // double points
      txt(x, y, 'x2', Math.round(10 * s), '#ffffff');
    }
  }

  // ---------- Bomb ----------
  function drawBomb(x, y, s) {
    const a = anim / 60;
    dot(x, y + 1, 13 * s, '#ef4444', 0.18 + 0.12 * Math.sin(a * 0.35));   // warning glow
    line(x + 4 * s, y - 6 * s, x + 8 * s, y - 11 * s, '#a16207', 2.2 * s);  // fuse
    dot(x, y + 1, 8.5 * s, '#1f2937');
    dot(x - 2.8 * s, y - 1.8 * s, 2.4 * s, '#6b7280');
    rrect(x + 1.5 * s, y - 8.5 * s, 5 * s, 4 * s, 1 * s, '#374151');
    const flick = Math.sin(a * 1.7) > 0;
    dot(x + 8.5 * s, y - 11.5 * s, (flick ? 3.2 : 2.4) * s, flick ? '#fbbf24' : '#f97316');
  }
  function drawBoom(x, y) {
    for (let i = 0; i < 10; i++) {
      const ang = i * Math.PI / 5, r = 26;
      dot(x + Math.cos(ang) * r, y + Math.sin(ang) * r, 8, i % 2 ? '#f97316' : '#fbbf24');
    }
    dot(x, y, 22, '#f97316');
    dot(x, y, 14, '#fde68a');
  }

  // ---------- Snake ----------
  // Colour of body segment i (0 = head) for a skin. The default skin follows the theme.
  function segColor(sk, i, n) {
    const t = th();
    if (sk.id === 'default') return i % 2 ? t.a : t.b;
    if (sk.pattern === 'rainbow') return hsl(i * 30 + anim * 0.05, 85, 56);
    if (sk.pattern === 'prism') return hsl(i * 22 + anim * 0.09, 75, 72);
    if (sk.pattern === 'neon') return (Math.floor(anim / 220) + i) % 2 ? sk.a : sk.b;
    if (sk.pattern === 'shimmer' && Math.floor(anim / 70) % (n + 8) === i) return '#ffffff';
    return i % 2 ? sk.a : sk.b;
  }
  function drawSnake(pts, dir, ringColor, skin) {
    const t = th(), n = pts.length, sk = skin || activeSkin();
    const lineCol = sk.id === 'default' ? t.b : sk.line, headCol = sk.id === 'default' ? t.head : sk.head;
    // body line, so the snake looks like one continuous shape
    const bodyPath = (w, col, al) => {
      g.lineStyle(w, C(col), al);
      g.beginPath();
      g.moveTo(pts[n - 1].x, pts[n - 1].y);
      for (let i = n - 2; i >= 0; i--) {
        const far = Math.abs(pts[i].x - pts[i + 1].x) + Math.abs(pts[i].y - pts[i + 1].y) > CELL * 1.7;
        if (far) g.moveTo(pts[i].x, pts[i].y);     // wrapped through a wall
        else g.lineTo(pts[i].x, pts[i].y);
      }
      g.strokePath();
    };
    const img0 = !LITE && n <= 40 && L === layers[2] && !!UIOK.snake_body && !['rainbow', 'prism', 'neon', 'shimmer'].includes(sk.pattern);
    if (img0) { useLayer(0); bodyPath(14, lineCol, 1); useLayer(2); }      // the filler under the pictures goes to the lowest layer so the pictures stay on top
    else { if (n <= 40) bodyPath(18, shade(lineCol, -0.62), 0.85); bodyPath(15, lineCol, 1); }
    // tail gets thinner
    const segR = (i) => { const ft = n - 1 - i; return ft < 3 ? [6, 7.5, 9][ft] : 10.5; };
    const gloss = !LITE && n <= 40;                  // a very long snake skips the shine: it keeps the frame rate up
    const imgMode = img0;   // pictures of the snake (sheet 10), tinted with the skin colours
    if (gloss && !imgMode) for (let i = n - 1; i >= 1; i--) dot(pts[i].x, pts[i].y, segR(i) + 1.5, shade(segColor(sk, i, n), -0.6), 0.9);   // outline pass
    for (let i = n - 1; i >= 1; i--) {
      const r = segR(i);
      if (imgMode) { snakeSegPic(pts, i, n, segColor(sk, i, n)); if (sk.pattern === 'stars' && i % 3 === 0) dot(pts[i].x + 2, pts[i].y - 2, 1.8, '#ffffff'); continue; }
      dot(pts[i].x, pts[i].y, r, segColor(sk, i, n));
      if (gloss) {
        dot(pts[i].x - r * 0.18, pts[i].y - r * 0.2, r * 0.7, shade(segColor(sk, i, n), 0.28), 0.55);
        dot(pts[i].x - r * 0.36, pts[i].y - r * 0.42, r * 0.26, '#ffffff', 0.7);
      }
      if (sk.pattern === 'stars' && i % 3 === 0) dot(pts[i].x + 2, pts[i].y - 2, 1.8, '#ffffff');
    }
    SNK_IMG = imgMode; drawHead(sk, pts[0].x, pts[0].y, dir[0], dir[1], 1, headCol, ringColor); SNK_IMG = false;
  }
  // Cute head: big shiny eyes, rosy cheeks, and the animal extras of a skin. k = size (1 in the game).
  function drawHead(sk, hx, hy, dx, dy, k, headCol, ringColor) {
    const px = -dy, py = dx, an = sk.animal;
    const at = (f, sd) => ({ x: hx + f[0] * k * dx + f[1] * k * px * sd, y: hy + f[0] * k * dy + f[1] * k * py * sd });
    if (an !== 'unicorn') line(hx + 10 * k * dx, hy + 10 * k * dy, hx + 19 * k * dx, hy + 19 * k * dy, '#ff4d6d', 3 * k);   // tongue
    if (an === 'panda') [1, -1].forEach((sd) => { const e = at([-5, 10], sd); dot(e.x, e.y, 5.2 * k, '#1f2937'); });             // ears
    if (an === 'cat' || an === 'fox') [1, -1].forEach((sd) => {
      const p1 = at([-3, 5], sd), p2 = at([-7, 15], sd), p3 = at([5, 10], sd);
      g.fillStyle(C(an === 'fox' ? '#c2410c' : '#f59e0b'), 1); g.fillTriangle(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
      const q1 = at([-2, 7], sd), q2 = at([-5, 12.5], sd), q3 = at([2, 9.5], sd);
      g.fillStyle(C('#fbcfe8'), 1); g.fillTriangle(q1.x, q1.y, q2.x, q2.y, q3.x, q3.y);
    });
    if (an === 'bunny') [1, -1].forEach((sd) => { const a1 = at([-3, 6], sd), a2 = at([-17, 10], sd); line(a1.x, a1.y, a2.x, a2.y, '#f9a8d4', 6.4 * k); line(a1.x, a1.y, a2.x, a2.y, '#ffffff', 4 * k); });
    if (an === 'robot') { const a1 = at([-9, 0], 1), a2 = at([-17, 0], 1); line(a1.x, a1.y, a2.x, a2.y, '#94a3b8', 2.4 * k); dot(a2.x, a2.y, 3.2 * k, '#ef4444'); }
    if (an === 'dragon') [1, -1].forEach((sd) => { const a1 = at([-2, 8], sd), a2 = at([-11, 13], sd); line(a1.x, a1.y, a2.x, a2.y, '#f59e0b', 4.2 * k); });   // horns
    if (ringColor) dot(hx, hy, 16 * k, ringColor);
    if (!(SNK_IMG && !ringColor && snakeHeadPic(hx, hy, dx, dy, k, headCol))) dot(hx, hy, 12.5 * k, headCol);
    if (an === 'ninja') { const b1 = at([-1.5, 12.5], 1), b2 = at([-1.5, 12.5], -1), b3 = at([-9, 16], -1); line(b1.x, b1.y, b2.x, b2.y, '#ef4444', 5 * k); line(b2.x, b2.y, b3.x, b3.y, '#ef4444', 3 * k); }
    if (an === 'crown') { [-7, 0, 7].forEach((o, i) => { const c1 = at([-9 - (i === 1 ? 3 : 0), o], 1); dot(c1.x, c1.y, 2.8 * k, '#fde047'); }); const c0 = at([-7, -9], 1), c9 = at([-7, 9], 1); line(c0.x, c0.y, c9.x, c9.y, '#fbbf24', 3.2 * k); }
    if (an === 'panda') [1, -1].forEach((sd) => { const e = at([4.5, 6.2], sd); dot(e.x, e.y, 5.9 * k, '#1f2937'); });         // eye patches
    if (an === 'unicorn') {                                                                                                     // horn + mane
      line(hx + 7 * k * dx, hy + 7 * k * dy, hx + 18 * k * dx, hy + 18 * k * dy, '#fcd34d', 4.6 * k);
      line(hx + 12 * k * dx, hy + 12 * k * dy, hx + 18 * k * dx, hy + 18 * k * dy, '#f59e0b', 2.4 * k);
      const m = at([-6, 0], 1); dot(m.x, m.y, 3.6 * k, '#f472b6');
    }
    [1, -1].forEach((sd) => {
      const e = at([4.5, 6.2], sd), c = at([1, 10], sd);
      if (an !== 'panda') dot(c.x, c.y, 2.3 * k, '#ff8fab', 0.7);                                                              // cheek
      dot(e.x, e.y, 4.9 * k, '#ffffff');
      dot(e.x + 1.7 * k * dx, e.y + 1.7 * k * dy, 2.6 * k, '#111111');
      dot(e.x + 0.4 * k * dx - 0.9 * k * px * sd, e.y + 0.4 * k * dy - 0.9 * k * py * sd, 1 * k, '#ffffff');                     // shine
    });
  }
  // Small horizontal snake used to preview a skin (head on the right).
  function miniSnake(sk, cx, cy) {
    const t = th(), n = 5, lineCol = sk.id === 'default' ? t.b : sk.line, headCol = sk.id === 'default' ? t.head : sk.head;
    line(cx - 22, cy, cx + 18, cy, lineCol, 11);
    for (let i = n - 1; i >= 1; i--) dot(cx + 18 - i * 10, cy, i === n - 1 ? 4.5 : 7, segColor(sk, i, n));
    drawHead(sk, cx + 18, cy, 1, 0, 0.72, headCol, null);
  }

  // Where a segment glided from. After a wrap-around or a portal it slides in from outside the edge instead of freezing for a whole step.
  function prevOf(i) {
    const cur = G.snake[i], prev = (prevSnake && prevSnake[i]) || cur;
    if (Math.abs(cur[0] - prev[0]) + Math.abs(cur[1] - prev[1]) <= 1.95) return prev;
    let dx, dy;
    if (i === 0) { dx = G.dir[0]; dy = G.dir[1]; }
    else { const nx = G.snake[i - 1], ex = nx[0] - cur[0], ey = nx[1] - cur[1]; if (Math.abs(ex) + Math.abs(ey) !== 1) return cur; dx = ex; dy = ey; }
    return [cur[0] - dx, cur[1] - dy];
  }
  // Where every segment is drawn right now, in cell units (fractions while it glides between two cells).
  function visualCells() {
    const k = state === 'play' ? Math.min(1, acc / stepDelay()) : 1;
    return G.snake.map((cur, i) => { const prev = prevOf(i); return [prev[0] + (cur[0] - prev[0]) * k, prev[1] + (cur[1] - prev[1]) * k]; });
  }
  const ptsOut = [];                                   // reused every frame (no garbage on slow phones)
  function snakePoints() {
    const k = state === 'play' ? Math.min(1, acc / stepDelay()) : 1, n = G.snake.length;
    for (let i = 0; i < n; i++) {
      const cur = G.snake[i], prev = prevOf(i);
      const c = prev[0] + (cur[0] - prev[0]) * k, r = prev[1] + (cur[1] - prev[1]) * k;
      const p = ptsOut[i] || (ptsOut[i] = { x: 0, y: 0 });
      p.x = BX + c * CELL + CELL / 2; p.y = BY + r * CELL + CELL / 2;
    }
    ptsOut.length = n;
    return ptsOut;
  }
  // The head turns smoothly instead of snapping to the new direction.
  const edir = [1, 0];
  let easeT = 0;
  function easedDir() {
    const dt = Math.min(50, Math.max(0, anim - easeT)), f = 1 - Math.exp(-dt / 40);
    easeT = anim;
    edir[0] += (G.dir[0] - edir[0]) * f; edir[1] += (G.dir[1] - edir[1]) * f;
    const l = Math.hypot(edir[0], edir[1]) || 1;
    return [edir[0] / l, edir[1] / l];
  }

  // ---------- Screens ----------
  // Theme and background pickers (used in the menu and in the pause screen).
  function themePicker(cy, sp, r) {
    const t = th();
    THEMES.forEach((theme, i) => {
      const x = W / 2 + (i - 2) * sp;
      if (i === DATA.theme) dot(x, cy, r + 5, t.accent);
      dot(x, cy, r, theme.board1);
      dot(x, cy, r * 0.45, theme.a);
      buttons.push({ x: x - sp / 2, y: cy - r - 8, w: sp, h: 2 * r + 16, fn: () => setTheme(i) });
    });
  }
  function bgPicker(cy, sp, size) {
    const t = th();
    BACKGROUNDS.forEach((name, i) => {
      const x = W / 2 + (i - 2) * sp - size / 2, y = cy - size / 2;
      if (i === DATA.bg) rrect(x - 5, y - 5, size + 10, size + 10, 10, t.accent);
      rrect(x - 1, y - 1, size + 2, size + 2, 6, t.bg);
      g.fillStyle(C(t.board1), 1);
      g.fillRect(x, y, size, size);
      drawPattern(g, i, x, y, 4, 4, size / 4);
      buttons.push({ x: x - (sp - size) / 2, y: y - 8, w: sp, h: size + 16, fn: () => setBackground(i) });
    });
  }

  // ---------- Home screen ----------
  function demoReset() {
    demo = { snake: [[9, 5], [8, 5], [7, 5], [6, 5], [5, 5], [4, 5], [3, 5], [2, 5]], dir: [1, 0], prev: null, acc: 0, food: [14, 3], kind: 0 };
  }
  function demoStep() {
    const d = demo, h = d.snake[0];
    const wrap = (c, r) => [(c + DEMO.cols) % DEMO.cols, (r + DEMO.rows) % DEMO.rows];
    const dist = (p, q) => {
      const dx = Math.abs(p[0] - q[0]), dy = Math.abs(p[1] - q[1]);
      return Math.min(dx, DEMO.cols - dx) + Math.min(dy, DEMO.rows - dy);
    };
    let pick = null, bestD = 1e9;
    [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach((o) => {
      if (o[0] === -d.dir[0] && o[1] === -d.dir[1]) return;
      const n = wrap(h[0] + o[0], h[1] + o[1]);
      if (d.snake.slice(0, -1).some((p) => p[0] === n[0] && p[1] === n[1])) return;
      const v = dist(n, d.food) + Math.random() * 0.9;
      if (v < bestD) { bestD = v; pick = o; }
    });
    if (!pick) { demoReset(); return; }
    d.prev = d.snake.map((p) => [p[0], p[1]]);
    d.dir = pick;
    const n = wrap(h[0] + pick[0], h[1] + pick[1]);
    d.snake.unshift(n);
    if (n[0] === d.food[0] && n[1] === d.food[1]) {
      if (d.snake.length > 15) d.snake.pop();
      d.kind = (d.kind + 1) % FRUITS.length;
      do { d.food = [rnd(DEMO.cols), rnd(DEMO.rows)]; } while (d.snake.some((p) => p[0] === d.food[0] && p[1] === d.food[1]));
    } else {
      d.snake.pop();
    }
  }
  function demoXY(c, r) { return { x: DEMO.x0 + (c + 0.5) * CELL, y: DEMO.y0 + (r + 0.5) * CELL }; }

  function drawDemo() {
    const t = th(), d = demo, k = Math.min(1, d.acc / DEMO.ms);
    const w = DEMO.cols * CELL, h = DEMO.rows * CELL;
    rrect(DEMO.x0 - 7, DEMO.y0 - 7, w + 14, h + 14, 28, t.panel);
    rrect(DEMO.x0, DEMO.y0, w, h, 22, t.board1);
    drawPattern(g, DATA.bg, DEMO.x0, DEMO.y0, DEMO.cols, DEMO.rows, CELL);
    const f = demoXY(d.food[0], d.food[1]);
    drawFruit(FRUITS[d.kind], f.x, f.y + 1.5 * Math.sin(anim / 150), 1.15);
    const pts = d.snake.map((cur, i) => {
      const prev = (d.prev && d.prev[i]) || cur;
      const jump = Math.abs(cur[0] - prev[0]) + Math.abs(cur[1] - prev[1]) > 1;
      return jump ? demoXY(cur[0], cur[1]) : demoXY(prev[0] + (cur[0] - prev[0]) * k, prev[1] + (cur[1] - prev[1]) * k);
    });
    drawSnake(pts, d.dir, null);
  }

  // small icons for the home screen buttons
  function drawIcon(kind, x, y, col) {
    const t = th(), c = col || t.btnText;
    if (kind === 'modes') {
      [[-7, -7], [7, -7], [-7, 7], [7, 7]].forEach((p, i) => rrect(x + p[0] - 5.5, y + p[1] - 5.5, 11, 11, 3, i === 0 ? t.accent : c));
    } else if (kind === 'themes') {
      dot(x, y, 14, c);
      [t.accent, t.a, t.head].forEach((col, i) => {
        const ang = -Math.PI / 2 + i * 2.1;
        dot(x + Math.cos(ang) * 7, y + Math.sin(ang) * 7, 3.6, col);
      });
      dot(x + 5, y + 6, 3, t.panel);
    } else if (kind === 'background') {
      rrect(x - 13, y - 13, 26, 26, 6, c);
      rrect(x - 10, y - 10, 20, 20, 4, t.panel);
      [-3.5, 3.5].forEach((o) => {
        line(x + o, y - 10, x + o, y + 10, c, 1.6);
        line(x - 10, y + o, x + 10, y + o, c, 1.6);
      });
    } else if (kind === 'sound') {
      rrect(x - 11, y - 5, 7, 10, 2, c);
      g.fillStyle(C(c), 1);
      g.fillTriangle(x - 6, y - 5, x + 2, y - 11, x + 2, y + 11);
      g.fillTriangle(x - 6, y - 5, x - 6, y + 5, x + 2, y + 11);
      if (DATA.sound) {
        g.lineStyle(2.4, C(c), 1);
        g.beginPath(); g.arc(x + 2, y, 7, -0.8, 0.8); g.strokePath();
        g.beginPath(); g.arc(x + 2, y, 12, -0.8, 0.8); g.strokePath();
      } else {
        line(x + 6, y - 6, x + 14, y + 6, '#ef4444', 2.6);
        line(x + 14, y - 6, x + 6, y + 6, '#ef4444', 2.6);
      }
    } else if (kind === 'skins') {
      [-9, -1, 7].forEach((o, i) => dot(x + o, y + 5 - i * 5, 5, i === 2 ? t.accent : c));
      dot(x + 9, y - 6, 2, '#111111');
    } else if (kind === 'gifts') {
      rrect(x - 12, y - 4, 24, 16, 3, c);
      rrect(x - 14, y - 10, 28, 8, 3, c);
      rrect(x - 3, y - 10, 6, 22, 1, t.accent);
      dot(x - 6, y - 14, 4, t.accent); dot(x + 6, y - 14, 4, t.accent);
    } else if (kind === 'vibe') {
      rrect(x - 6, y - 11, 12, 22, 3, c);
      rrect(x - 4, y - 8, 8, 14, 1.5, t.panel);
      [[-1, 9], [1, 9], [-1, 14], [1, 14]].forEach((o, i) => { g.lineStyle(2.2, C(c), 1); g.beginPath(); g.moveTo(x + o[0] * (i < 2 ? 9 : 14), y - 6); g.lineTo(x + o[0] * (i < 2 ? 9 : 14), y + 6); g.strokePath(); });
      if (!DATA.vibe) { line(x - 13, y + 12, x + 13, y - 12, '#ef4444', 2.8); }
    } else if (kind === 'tap') {
      dot(x - 1, y - 3, 6, c);
      rrect(x - 4, y - 3, 8, 15, 4, c);
      g.lineStyle(2, C(c), 1); g.beginPath(); g.arc(x - 1, y - 3, 10, Math.PI * 1.15, Math.PI * 1.85); g.strokePath();
      if (!DATA.tapSteer) { line(x - 12, y + 12, x + 12, y - 12, '#ef4444', 2.8); }
    } else if (kind === 'shop') {
      rrect(x - 12, y - 4, 24, 16, 4, c);
      g.lineStyle(3, C(c), 1); g.beginPath(); g.arc(x, y - 5, 7, Math.PI, 0); g.strokePath();
      dot(x, y + 4, 3.2, t.accent);
    } else if (kind === 'gear') {
      for (let i = 0; i < 8; i++) { const an = i * Math.PI / 4; line(x + Math.cos(an) * 6, y + Math.sin(an) * 6, x + Math.cos(an) * 10.5, y + Math.sin(an) * 10.5, c, 3.6); }
      dot(x, y, 7.6, c); dot(x, y, 3.2, t.panel);
    } else if (kind === 'cal') {
      rrect(x - 13, y - 11, 26, 24, 5, c); rrect(x - 13, y - 11, 26, 8, 5, '#ef4444'); for (let q = 0; q < 6; q++) dot(x - 8 + (q % 3) * 8, y + 1 + Math.floor(q / 3) * 7, 2, t.panel);
    } else if (kind === 'star') {
      g.fillStyle(C(t.accent), 1);
      const pts = [];
      for (let i = 0; i < 10; i++) {
        const r = i % 2 ? 4 : 9, ang = -Math.PI / 2 + i * Math.PI / 5;
        pts.push({ x: x + Math.cos(ang) * r, y: y + Math.sin(ang) * r });
      }
      g.fillPoints(pts, true);
    }
  }
  function roundButton(x, y, kind, label, fn, badge) {
    const t = th();
    const ICO = { skins: 'icon_skins', shop: 'icon_shop', gifts: 'icon_gifts', cal: 'icon_daily' }[kind];
    if (ICO && UIOK[ICO] && uiPic('btn_round', x, y + 1, 76, 76, C(t.panel), 0.45)) uiPic(ICO, x, y - 1, 48, 48);
    else {
      dot(x, y + 4, 31, shade(t.panel, -0.3));
      dot(x, y, 31, t.panel);
      drawIcon(kind, x, y);
    }
    if (label) txt(x, y + 47, label, 13, t.text, 0.5, false);
    if (badge) { dot(x + 22, y - 22, 9, '#ef4444'); txt(x + 22, y - 22, '!', 12, '#ffffff'); }       // something new to collect
    buttons.push({ x: x - 38, y: y - 36, w: 76, h: label ? 100 : 72, fn: fn });
  }
  function openSheet(tab) { DATA.tab = tab; sheetOpen = true; skinPick = null; skinErr = null; }

  // Daily challenge card on the home screen: objective, progress and reward.
  function drawDailyCard(cy) {
    const pic = slice9('panel_card', W / 2, cy, 446, 64, C(th().panel), 22, 0.4);
    if (pic) useLayer(2);
    drawDailyCard0(cy, pic);
    useLayer(0);
  }
  function drawDailyCard0(cy, pic) {
    const t = th(), cm = DATA.menuMode !== 'endless', d = cm ? cdEnsure() : dailyEnsure(), type = cm ? CD_BY_ID[d.id] : DAILY_BY_ID[d.id], w = 440, h = 56, x = W / 2 - w / 2;
    const frac = Math.min(1, d.progress / d.target);
    if (!pic) rrect(x, cy - h / 2, w, h, 16, t.panel, 0.9);
    if (d.claimed) {
      dot(x + 28, cy, 14, '#22c55e');
      line(x + 21, cy, x + 26, cy + 5, '#ffffff', 3.4); line(x + 26, cy + 5, x + 35, cy - 5, '#ffffff', 3.4);
      txt(x + 52, cy - 12, 'Daily done: ' + type.text(d.target), 14, t.text, 0);
      txt(x + 52, cy + 12, 'New challenge tomorrow' + (!cm && DATA.streak > 1 ? '  -  ' + DATA.streak + ' day streak' : ''), 11, t.text, 0, false);
      return;
    }
    dot(x + 28, cy, 14, t.accent);
    txt(x + 28, cy + 1, '!', 20, '#1b1b1b');
    txt(x + 52, cy - 14, type.text(d.target), 14, t.text, 0);
    txt(x + 52, cy + 3, type.sub, 10, t.text, 0, false);
    rrect(x + 52, cy + 14, 250, 8, 4, t.bg);
    if (frac > 0) rrect(x + 52, cy + 14, Math.max(8, 250 * frac), 8, 4, t.accent);
    txt(x + 312, cy + 18, d.progress + '/' + d.target, 11, t.text, 0, false);
    drawCoin(x + w - 66, cy, 11);
    txt(x + w - 48, cy, '+' + d.reward, 16, t.accent, 0);
  }

  let settingsOpen = false;
  function drawSettings() {
    const t = th();
    buttons = [];
    g.fillStyle(0x000000, 0.62); g.fillRect(0, 0, W, H);
    rrect(BX + 10, 250, BW - 20, 330, 26, t.bg);
    txt(W / 2, 286, 'Settings', 24, t.accent);
    button(W / 2, 346, 250, 46, 'Sound: ' + (DATA.sound ? 'On' : 'Off'), toggleSound, { size: 17 });
    button(W / 2, 404, 250, 46, 'Vibration: ' + (DATA.vibe ? 'On' : 'Off'), toggleVibe, { size: 17 });
    button(W / 2, 462, 250, 46, 'Tap to turn: ' + (DATA.tapSteer ? 'On' : 'Off'), toggleTap, { size: 17 });
    button(W / 2, 534, 200, 44, 'Close', () => { settingsOpen = false; }, { primary: true, size: 18 });
  }
  function drawMenu() { drawMenu0(); if (settingsOpen) { for (const e of L.active) for (let i = 0; i < e.n; i++) e.list[i].setVisible(false); useLayer(1); drawSettings(); useLayer(0); } }
  function drawMenu0() {
    drawAmbientBg();
    const t = th();
    // top bar: best score + coins + sound
    const spw = 104 + String(best(DATA.mode)).length * 11;
    if (!(slice3('hud_pill', BX + spw / 2, 39, spw + 6, 46, C(t.panel), 0.45) && uiPic('star_full', BX + 24, 39, 34, 32))) { rrect(BX, 18, spw, 42, 21, t.panel, 0.7); drawIcon('star', BX + 24, 39); }
    txt(BX + 42, 39, DATA.menuMode === 'endless' ? 'Best  ' + best(DATA.mode) : 'Stars  ' + Object.keys(DATA.camp.stars).reduce((a, k) => a + DATA.camp.stars[k], 0), 16, t.text, 0);
    const cw = 52 + coinText(DATA.coins).length * 11;
    if (!slice3('hud_pill', W - BX - 118 - cw / 2, 39, cw + 6, 46, C(t.panel), 0.45)) rrect(W - BX - 118 - cw, 18, cw, 42, 21, t.panel, 0.7);
    drawCoin(W - BX - 118 - cw + 24, 39, 11);
    txt(W - BX - 118 - cw + 42, 39, coinText(DATA.coins), 16, t.accent, 0);
    buttons.push({ x: W - BX - 118 - cw, y: 12, w: cw, h: 56, fn: () => openSheet(7) });          // tap the coins: coin store
    if (UIOK.glyph_settings && uiPic('btn_round', W - BX - 76, 40, 52, 52, C(t.panel), 0.45)) uiPic('glyph_settings', W - BX - 76, 39, 30, 30, 0xffffff, 0.55);
    else { dot(W - BX - 76, 39, 22, t.panel, 0.7); drawIcon('gear', W - BX - 76, 39); }
    buttons.push({ x: W - BX - 102, y: 12, w: 52, h: 56, fn: () => { settingsOpen = true; } });
    if (UIOK.glyph_sound_on && uiPic('btn_round', W - BX - 24, 40, 52, 52, C(t.panel), 0.45)) uiPic(DATA.sound ? 'glyph_sound_on' : 'glyph_sound_off', W - BX - 25, 39, 30, 30, 0xffffff, 0.55);
    else { dot(W - BX - 24, 39, 22, t.panel, 0.7); drawIcon('sound', W - BX - 26, 39); }
    buttons.push({ x: W - BX - 54, y: 12, w: 58, h: 56, fn: toggleSound });

    // live preview of the game
    drawDemo();

    // logo
    txt(W / 2, 386, 'Snake', 92, shade(t.accent, -0.45));
    txt(W / 2, 380, 'Snake', 92, t.accent);
    txt(W / 2, 436, 'Fruit Rush', 24, t.text);


    // choose what to play: Levels or Endless
    const lv = DATA.menuMode !== 'endless', cp = DATA.camp, nl = campNext();
    rrect(W / 2 - 158, 453, 316, 48, 24, t.panel, 0.9);
    [['Levels', true], ['Endless', false]].forEach((o, i) => {
      const cx = W / 2 + (i ? 79 : -79), on = lv === o[1];
      if (on) rrect(cx - 75, 457, 150, 40, 20, t.accent);
      txt(cx, 478, o[0], 18, on ? '#1b1b1b' : t.btnText);
      buttons.push({ x: cx - 79, y: 453, w: 158, h: 48, fn: () => setMenuMode(o[1]) });
    });
    // play
    const hasSave = !!DATA.save, side = lv || hasSave, ph = 68, py = 548, pw = side ? 196 : 316, pcx = side ? W / 2 - 60 : W / 2;
    rrect(pcx - pw / 2, py - ph / 2 + 7, pw, ph, 34, shade(t.accent, -0.35));
    rrect(pcx - pw / 2, py - ph / 2, pw, ph, 34, t.accent);
    g.fillStyle(0x1b1b1b, 1);
    g.fillTriangle(pcx - 44, py - 14, pcx - 44, py + 14, pcx - 20, py);
    txt(pcx + 14, py - 1, 'Play', 32, '#1b1b1b');
    buttons.push({ x: pcx - pw / 2, y: py - ph / 2, w: pw, h: ph + 7, fn: playSelected });
    if (side) {
      const sx = W / 2 + 104;
      rrect(sx - 48, py - ph / 2 + 7, 96, ph, 34, shade(t.panel, -0.3));
      rrect(sx - 48, py - ph / 2, 96, ph, 34, t.panel);
      txt(sx, py - 1, lv ? 'Map' : 'Resume', lv ? 20 : 17, t.btnText);
      buttons.push({ x: sx - 48, y: py - ph / 2, w: 96, h: ph + 7, fn: lv ? openLevels : continueGame });
    }
    let totalStars = 0;
    for (let i = 1; i <= LEVEL_COUNT; i++) totalStars += cp.stars[i] | 0;
    if (lv) txt(W / 2, 604, 'Level ' + nl + '  -  ' + WORLDS[Math.floor((nl - 1) / 20)].name + '   -   ' + totalStars + ' stars', 15, t.text, 0.5, false);
    else txt(W / 2, 604, MODES[DATA.mode].name + ' mode' + (DATA.mode === 'ultimate' ? ', speed ' + DATA.speed : '') + (hasSave ? '   -   game saved' : ''), 15, t.text, 0.5, false);

    drawDailyCard(654);
    const rb = DATA.menuMode === 'endless' ? [['modes', 'Modes', 0], ['themes', 'Themes', 1], ['background', 'Pattern', 2], ['skins', 'Skins', 3], ['shop', 'Shop', 5], ['gifts', 'Gifts', 4]] : [['skins', 'Skins', 3], ['shop', 'Shop', 5], ['gifts', 'Gifts', 4], ['cal', 'Daily', 'daily']];
    rb.forEach((r, k) => roundButton(W / 2 + (k - (rb.length - 1) / 2) * (rb.length > 3 ? 76 : 110), 738, r[0], r[1], () => (r[2] === 'daily' ? startDailyPuzzle() : openSheet(r[2])), (r[2] === 4 && spinReady()) || (r[2] === 'daily' && !dpDone()) ? 1 : 0));
  }

  // Skin picker: tap a skin to look at it, then Equip or Unlock.
  let skinPick = null, skinPage = 0;
  let skinErr = null;                                  // {s, until}: short error message in the skin tab
  function skinError(msg) { skinErr = { s: msg, until: anim + 2600 }; sfx.err(); buzz(40); }
  // Closing the sheet while a locked skin is picked is an error: say so and go back to the skin in use.
  function closeSheet() {
    if (DATA.tab === 3 && skinPick && SKIN_BY_ID[skinPick] && !skinOwned(skinPick)) {
      skinPick = DATA.skin;
      skinError('Skin is locked! Back to ' + activeSkin().name + '.');
      return;
    }
    sheetOpen = false;
  }
  function drawSkinTab(top) {
    const t = th(), cw = 104, ch = 74, gap = 6;
    if (!skinPick || !SKIN_BY_ID[skinPick]) skinPick = DATA.skin;
    if (skinErr && anim < skinErr.until) {
      txt(W / 2, top + 96, skinErr.s, 15, '#f87171');
    } else {
      const ct = coinText(DATA.coins) + ' coins', ox = String(ct).length * 4;
      drawCoin(W / 2 - ox - 12, top + 96, 10);
      txt(W / 2 - ox + 2, top + 96, ct, 15, t.accent, 0);
    }
    const pages = Math.ceil(SKINS.length / 12);
    if (skinPage >= pages) skinPage = 0;
    [[-1, BX + 22], [1, BX + BW - 22]].forEach((a) => {
      dot(a[1], top + 95, 10, t.panel);
      line(a[1] - a[0] * 2, top + 91, a[1] + a[0] * 2.5, top + 95, t.btnText, 2.2); line(a[1] + a[0] * 2.5, top + 95, a[1] - a[0] * 2, top + 99, t.btnText, 2.2);
      buttons.push({ x: a[1] - 22, y: top + 80, w: 44, h: 30, fn: () => { skinPage = (skinPage + a[0] + pages) % pages; } });
    });
    txt(W / 2 + 112, top + 96, (skinPage + 1) + '/' + pages, 12, t.btnText, 0.5, false);
    SKINS.slice(skinPage * 12, skinPage * 12 + 12).forEach((sk, i) => {
      const cx = W / 2 + ((i % 4) - 1.5) * (cw + gap), cy = top + 148 + Math.floor(i / 4) * (ch + gap), ct = cy - ch / 2;
      const owned = skinOwned(sk.id), sel = skinPick === sk.id;
      if (sel) rrect(cx - cw / 2 - 3, ct - 3, cw + 6, ch + 6, 16, skinErr && anim < skinErr.until && !owned ? '#f87171' : t.accent);
      rrect(cx - cw / 2, ct, cw, ch, 13, t.panel);
      rrect(cx - cw / 2 + 5, ct + 4, cw - 10, 30, 9, t.board1);
      miniSnake(sk, cx, ct + 19);
      txt(cx, ct + 46, sk.name, 12, t.btnText);
      if (DATA.skin === sk.id) txt(cx, ct + 62, 'Equipped', 10, t.accent);
      else if (owned) txt(cx, ct + 62, 'Owned', 10, t.btnText, 0.5, false);
      else if (sk.special) txt(cx, ct + 62, 'Special', 10, t.accent);
      else {
        drawCoin(cx - 14, ct + 62, 6);
        txt(cx - 5, ct + 62, String(sk.cost), 11, DATA.coins >= sk.cost ? t.accent : t.btnText, 0);
      }
      buttons.push({ x: cx - cw / 2, y: ct, w: cw, h: ch, fn: () => { skinPick = sk.id; } });
    });
    const sk = SKIN_BY_ID[skinPick], by = top + 384;
    if (DATA.skin === sk.id) button(W / 2, by, 260, 44, 'Equipped', null, { disabled: true, dark: true, size: 17 });
    else if (skinOwned(sk.id)) button(W / 2, by, 260, 44, 'Equip ' + sk.name, () => selectSkin(sk.id), { primary: true, size: 17 });
    else if (sk.special) button(W / 2, by, 260, 44, 'Locked: ' + sk.special, null, { disabled: true, dark: true, size: 14 });
    else if (DATA.coins >= sk.cost) button(W / 2, by, 260, 44, 'Unlock for ' + sk.cost + ' coins', () => buySkin(sk.id), { primary: true, size: 17 });
    else { button(W / 2, by, 260, 44, 'Need ' + (sk.cost - DATA.coins) + ' more coins', () => skinError('Not enough coins for ' + sk.name + '!'), { dark: true, size: 16 }); adCoinsButton(top + 432); }
  }

  // ---------- Gifts: daily spin + mystery egg ----------
  const SPIN_VALUES = [10, 20, 15, 40, 10, 25, 60, 150];       // wedges, clockwise from the top
  const SPIN_WEIGHTS = [20, 16, 18, 10, 20, 12, 3, 1];
  const SPIN_COLORS = ['#f87171', '#fbbf24', '#4ade80', '#38bdf8', '#c084fc', '#f472b6', '#fb923c', '#facc15'];
  const EGG_COST = 100;
  const EGG_COINS = [40, 60, 80, 120, 200, 300], EGG_WEIGHTS = [30, 25, 20, 12, 8, 5];
  const EGG_SKIN_CHANCE = 0.3;
  const GIFT_MS = 1600;
  let gift = null;                                     // {kind, idx, val, skin, t, done} the last spin / egg result
  const pickWeighted = (w) => {
    let r = Math.random() * w.reduce((a, b) => a + b, 0);
    for (let i = 0; i < w.length; i++) { r -= w[i]; if (r < 0) return i; }
    return w.length - 1;
  };
  const giftBusy = () => !!gift && gift.t < gift.dur;
  const spinReady = () => DATA.spinDates.indexOf(dateKey(new Date())) < 0;
  // The prize is decided, paid and saved the moment the button is tapped; the animation only shows it.
  function doSpin() {
    if (giftBusy() || !spinReady()) return false;
    const idx = pickWeighted(SPIN_WEIGHTS), val = SPIN_VALUES[idx];
    DATA.spinDates.push(dateKey(new Date()));
    if (DATA.spinDates.length > 60) DATA.spinDates.shift();
    addCoins(val);
    writeData();
    gift = { kind: 'spin', idx: idx, val: val, t: 0, dur: 2400, done: false };
    return true;
  }
  function openEgg() {
    if (giftBusy()) return false;
    if (DATA.coins < EGG_COST) { skinError('Need ' + (EGG_COST - DATA.coins) + ' more coins for the egg!'); return false; }
    DATA.coins -= EGG_COST;
    const locked = SKINS.filter((s) => !skinOwned(s.id) && s.cost <= 1000);   // the eggs only hold the cheaper skins
    gift = { kind: 'egg', t: 0, dur: 2800, done: false, val: 0, skin: null, pw: null, qty: 0 };
    const roll = Math.random();
    if (locked.length && roll < 0.2) {
      gift.skin = locked[rnd(locked.length)].id;
      DATA.skins.push(gift.skin);
      DATA.skin = gift.skin;
    } else if (roll < 0.45) {                                         // a power-up
      gift.pw = PW_KEYS[rnd(PW_KEYS.length)]; gift.qty = Math.random() < 0.3 ? 2 : 1;
      DATA.pw[gift.pw] = Math.min(99, DATA.pw[gift.pw] + gift.qty);
    } else {
      gift.val = EGG_COINS[pickWeighted(EGG_WEIGHTS)];
      addCoins(gift.val);
    }
    writeData();
    return true;
  }
  const WHEEL_COLS = ['#00a9fb', '#13f4f6', '#57f00e', '#c1f91c', '#fcde02', '#fa8200', '#fb4bb6', '#af21f7'];   // taken from the wheel picture
  function drawWheel(cx, cy, r, rot) {
    const img = !!IMGOK.wheel, ds = r / 163;                          // the picture is a frame with an open middle: the wedges turn underneath it
    SPIN_VALUES.forEach((v, i) => {
      const a0 = (-90 + rot + i * 45) * Math.PI / 180, a1 = a0 + Math.PI / 4;
      g.fillStyle(C(img ? WHEEL_COLS[i] : SPIN_COLORS[i]), 1);
      g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, img ? r * 1.06 : r, a0, a1, false); g.closePath(); g.fillPath();
    });
    if (img) blitImg('wheelF' + L.depth, 'img_wheel', cx + 3.3 * ds, cy + 2.9 * ds, 551 * ds, 503 * ds, 1, L.depth + 0.5);
    SPIN_VALUES.forEach((v, i) => {
      const am = (-90 + rot + (i + 0.5) * 45) * Math.PI / 180;
      txt(cx + Math.cos(am) * r * (img ? 0.74 : 0.66), cy + Math.sin(am) * r * (img ? 0.74 : 0.66), String(v), img ? 11 : 10, '#1b1b1b');
    });
    if (!img) {
      dot(cx, cy, 8, '#ffffff');
      g.fillStyle(0xffffff, 1);
      g.fillTriangle(cx - 8, cy - r - 11, cx + 8, cy - r - 11, cx, cy - r + 3);
    }
  }
  function drawGifts(top) {
    const t = th(), lx = W / 2 - 112, rx = W / 2 + 112, cw = 212, ct = top + 100, chh = 206;
    rrect(lx - cw / 2, ct, cw, chh, 16, t.panel);
    rrect(rx - cw / 2, ct, cw, chh, 16, t.panel);
    const p = gift ? Math.min(1, gift.t / gift.dur) : 1, ease = 1 - Math.pow(1 - p, 3);
    // --- daily spin
    txt(lx, ct + (IMGOK.wheel ? 13 : 20), 'Daily Spin', 16, t.accent);
    const ready = spinReady(), sp = gift && gift.kind === 'spin';
    drawWheel(lx, ct + (IMGOK.wheel ? 90 : 92), IMGOK.wheel ? 38 : 50, sp ? -(gift.idx + 0.5) * 45 + (1 - ease) * 1440 : (ready ? anim / 30 : 0));
    if (ready) button(lx, ct + 176, 176, 40, 'SPIN!', doSpin, { primary: true, size: 18 });
    else button(lx, ct + 176, 176, 40, 'Come back tomorrow', null, { dark: true, disabled: true, size: 13 });
    // --- mystery egg
    txt(rx, ct + 20, 'Mystery Egg', 16, t.accent);
    drawEggArea(rx, ct + 92, p);
    const afford = DATA.coins >= EGG_COST;
    button(rx, ct + 176, 176, 40, 'Open egg  (' + EGG_COST + ')', openEgg, afford ? { primary: true, size: 16 } : { dark: true, size: 14 });
    // --- result
    if (skinErr && anim < skinErr.until) txt(W / 2, top + 330, skinErr.s, 15, '#f87171');
    else if (gift && gift.done) {
      const msg = gift.kind === 'spin' ? 'You won +' + gift.val + ' coins!' : (gift.skin ? 'New skin: ' + SKIN_BY_ID[gift.skin].name + '!  Equipped' : gift.pw ? 'You got ' + PW[gift.pw].name + ' x' + gift.qty + '!' : 'You got +' + gift.val + ' coins!');
      txt(W / 2, top + 330, msg, 18, t.accent);
      for (let i = 0; i < 12; i++) {                              // confetti
        const k = Math.min(1, (gift.t - gift.dur) / 1200);
        if (k < 1) dot(W / 2 + Math.sin(i * 7.3) * 190, top + 290 + (i % 4) * 8 + k * 60 * (0.6 + (i % 3) * 0.3), 3.2, CONFETTI[i % 6], 1 - k);
      }
    } else if (gift) txt(W / 2, top + 330, '...', 18, t.text);
    else txt(W / 2, top + 330, 'Free spin every day  -  Egg: coins, power-ups or a skin!', 12, t.text, 0.5, false);
    if (DATA.coins < EGG_COST) adCoinsButton(top + 376);
  }

  // Settings sheet that slides up over the home screen.
  function drawSheet() {
    const t = th(), e = 1 - Math.pow(1 - sheetT, 3), sh = 500, top = H - sh * e;
    g.fillStyle(0x000000, 0.45 * e);
    g.fillRect(0, 0, W, H);
    rrect(0, top - 3, W, sh + 40, 30, t.panel);
    rrect(0, top, W, sh + 40, 30, t.bg);
    rrect(W / 2 - 24, top + 12, 48, 5, 3, t.panel);
    if (sheetT < 0.98) return;
    buttons = [];                                    // only the sheet reacts to taps now
    sheetAdBtn = false;

    // tabs
    const tabs = DATA.menuMode === 'endless' ? [['Modes', 0], ['Themes', 1], ['Pattern', 2], ['Skins', 3], ['Shop', 5], ['Gifts', 4], ['Coins', 7]] : [['Coins', 7], ['Skins', 3], ['Shop', 5], ['Gifts', 4], ['Goals', 6]], tw = BW / tabs.length;
    if (!slice3('tabbar_pill', W / 2, top + 55, BW + 8, 52, C(t.panel), 0.45)) rrect(BX, top + 32, BW, 46, 23, t.panel);
    tabs.forEach((tb, i) => {
      const x = BX + i * tw;
      if (DATA.tab === tb[1] && !slice3('btn_pill', x + tw / 2, top + 55, tw - 2, 46, C(t.accent), 0.5)) rrect(x + 2, top + 35, tw - 4, 40, 20, t.accent);
      txt(x + tw / 2, top + 55, tb[0], tabs.length > 3 ? 11.5 : 15, DATA.tab === tb[1] ? '#1b1b1b' : t.btnText);
      buttons.push({ x: x, y: top + 32, w: tw, h: 46, fn: () => { if (DATA.tab === 3 && tb[1] !== 3) skinPick = DATA.skin; DATA.tab = tb[1]; writeData(); } });
    });

    if (DATA.tab === 0) {
      MODE_KEYS.forEach((k, i) => {
        const w = 212, h = 74, cx = W / 2 + (i % 2 ? 110 : -110), cy = top + 142 + Math.floor(i / 2) * 86;
        const sel = DATA.mode === k;
        if (sel) rrect(cx - w / 2 - 4, cy - h / 2 - 4, w + 8, h + 8, 18, t.accent);
        rrect(cx - w / 2, cy - h / 2, w, h, 15, t.panel);
        txt(cx, cy - 17, MODES[k].name, 18, sel ? t.accent : t.btnText);
        txt(cx, cy + 4, MODES[k].desc, 10, t.btnText, 0.5, false);
        txt(cx, cy + 22, 'Best ' + best(k), 11, t.btnText, 0.5, false);
        buttons.push({ x: cx - w / 2, y: cy - h / 2, w: w, h: h, fn: () => setMode(k) });
      });
      if (DATA.mode === 'ultimate') {
        txt(W / 2, top + 296, 'Speed ' + DATA.speed, 15, t.text);
        button(W / 2 - 122, top + 330, 56, 46, '-', () => setSpeed(DATA.speed - 1), { size: 26 });
        button(W / 2 + 122, top + 330, 56, 46, '+', () => setSpeed(DATA.speed + 1), { size: 26 });
        for (let i = 0; i < 10; i++) rrect(W / 2 - 74 + i * 15, top + 320, 11, 20, 3, i < DATA.speed ? t.accent : t.panel);
      } else {
        txt(W / 2, top + 316, 'Speed goes up slowly as you eat', 13, t.text, 0.5, false);
      }
      button(W / 2, top + 412, 280, 40, 'Tap to turn: ' + (DATA.tapSteer ? 'On' : 'Off'), toggleTap, { size: 15 });
    } else if (DATA.tab === 1) {
      themePicker(top + 190, 80, 28);
      txt(W / 2, top + 262, t.name, 20, t.accent);
    } else if (DATA.tab === 2) {
      bgPicker(top + 190, 80, 54);
      txt(W / 2, top + 262, BACKGROUNDS[DATA.bg], 20, t.accent);
    } else if (DATA.tab === 3) {
      drawSkinTab(top);
    } else if (DATA.tab === 5) {
      drawShop(top);
    } else if (DATA.tab === 6) {
      drawGoals(top);
    } else if (DATA.tab === 7) {
      drawCoinStore(top);
    } else {
      drawGifts(top);
    }
    button(W / 2, top + (sheetAdBtn ? (DATA.tab === 3 ? 478 : DATA.tab === 4 ? 436 : 470) : (DATA.tab === 3 || DATA.tab === 0 || DATA.tab === 5 || DATA.tab === 6 || DATA.tab === 7 ? 462 : 410)), 260, 48, 'Done', closeSheet, { primary: true, size: 20 });
    if (toast && anim < toast.until) { rrect(W / 2 - 160, top - 54, 320, 38, 19, toast.ok ? '#16a34a' : '#b91c1c'); txt(W / 2, top - 35, toast.s, 15, '#ffffff'); }
    buttons.push({ x: 0, y: 0, w: W, h: top, fn: closeSheet });   // tap above the sheet closes it
  }

  // Board background pattern. Used for the board itself and for the menu previews.
  function drawPattern(gr, kind, x, y, cols, rows, step) {
    const t = th();
    gr.fillStyle(C(kind === 3 ? t.board2 : t.panel), kind === 3 ? 1 : 0.6);
    if (kind === 1) {                                        // dots
      for (let c = 0; c < cols; c++) for (let r = 0; r < rows; r++) gr.fillCircle(x + (c + 0.5) * step, y + (r + 0.5) * step, step * 0.1);
    } else if (kind === 2) {                                 // grid
      const w = Math.max(1, step * 0.07);
      for (let c = 1; c < cols; c++) gr.fillRect(x + c * step - w / 2, y, w, rows * step);
      for (let r = 1; r < rows; r++) gr.fillRect(x, y + r * step - w / 2, cols * step, w);
    } else if (kind === 3) {                                 // stripes
      for (let c = 0; c < cols; c += 2) gr.fillRect(x + c * step, y, step, rows * step);
    } else if (kind === 4) {                                 // plus signs
      const l = step * 0.22, w = Math.max(1, step * 0.1);
      for (let c = 1; c < cols; c += 2) for (let r = 1; r < rows; r += 2) {
        const px = x + c * step, py = y + r * step;
        gr.fillRect(px - l, py - w / 2, 2 * l, w);
        gr.fillRect(px - w / 2, py - l, w, 2 * l);
      }
    }
  }

  // The board never changes during play, so it is drawn once on its own layer.
  function drawBoard() {
    const t = th();
    if (G && G.camp && state !== 'menu' && state !== 'levels') { drawCampBoard(); return; }
    if (drawEndBoard(t)) return;
    boardG.clear();
    boardG.setScale(1);
    if (boardRT) boardRT.setVisible(false);
    boardG.setVisible(state !== 'menu' && state !== 'levels');
    const openWalls = state !== 'menu' && G && modeOf().wall;
    boardG.fillStyle(C(openWalls ? POWERS.wall.color : t.panel), 1);   // teal frame = walls are open
    boardG.fillRoundedRect(BX - 7, BY - 7, BW + 14, BH + 14, 12);
    boardG.fillStyle(C(t.board1), 1);
    boardG.fillRect(BX, BY, BW, BH);
    drawPattern(boardG, DATA.bg, BX, BY, COLS, ROWS, CELL);
  }

  function drawHud() {
    const t = th();
    txt(BX, 26, 'Score', 12, t.text, 0, false);
    txt(BX, 56, String(G.score), 28, t.accent, 0);
    txt(BX + BW, 26, 'Best in ' + modeOf().name.toLowerCase(), 12, t.text, 1, false);
    txt(BX + BW, 56, String(best(G.mode)), 28, t.text, 1);

    if (G.bonus) {                                // big fruit timer
      txt(W / 2, 28, 'BONUS +' + BONUS_POINTS, 13, t.accent);
      line(W / 2 - 60, 58, W / 2 + 60, 58, t.panel, 8);
      line(W / 2 - 60, 58, W / 2 - 60 + 120 * G.bonus[3] / BONUS_TICKS, 58, t.accent, 8);
    } else {
      txt(W / 2, 28, 'Big fruit in ' + (BONUS_EVERY - G.eaten % BONUS_EVERY), 12, t.text, 0.5, false);
      for (let i = 0; i < BONUS_EVERY; i++) {
        dot(W / 2 - 36 + i * 18, 58, 5, i < G.eaten % BONUS_EVERY ? t.accent : t.panel);
      }
    }
  }

  function drawBottomBar() {
    const t = th();
    if (G.combo > 0) {
      txt(BX, 708, 'COMBO x' + G.combo, 20, t.accent, 0);
      txt(BX + 128, 710, (1 + 0.5 * G.combo) + 'x pts', 11, t.text, 0, false);
      line(BX + 3, 734, BX + 163, 734, t.panel, 7);
      line(BX + 3, 734, BX + 3 + 160 * G.combo_t / COMBO_TICKS, 734, t.accent, 7);
    } else {
      txt(BX, 706, 'COMBO', 14, t.text, 0);
      txt(BX, 728, 'eat the big fruit to start', 11, t.text, 0, false);
    }
    // coins earned in this game + daily challenge progress
    const d = dailyEnsure();
    drawCoin(BX + 214, 707, 8);
    txt(BX + 227, 707, String(G.coins | 0), 14, t.accent, 0);
    if (d.claimed) {
      txt(BX + 206, 731, 'Daily done!', 11, '#4ade80', 0);
    } else {
      txt(BX + 206, 731, 'Daily ' + d.progress + '/' + d.target, 11, t.text, 0, false);
    }
    // active abilities, each with its own timer
    let x = BX + 14;
    Object.keys(G.fx).forEach((kind) => {
      drawPower(kind, x, 766, 1);
      txt(x + 16, 766, POWERS[kind].name, 9, t.text, 0);
      line(x - 12, 787, x + 60, 787, t.panel, 5);
      line(x - 12, 787, x - 12 + 72 * Math.min(1, G.fx[kind] / POWER_TICKS), 787, POWERS[kind].color, 5);
      x += 88;
    });
    // pause button
    const px = BX + BW - 52, py = 692;
    rrect(px, py, 52, 52, 12, t.panel);
    line(px + 19, py + 15, px + 19, py + 37, t.btnText, 6);
    line(px + 33, py + 15, px + 33, py + 37, t.btnText, 6);
    buttons.push({ x: px - 6, y: py - 6, w: 64, h: 64, fn: togglePause });
  }

  function drawGame() {
    const a = anim / 60;
    drawHud();
    drawBottomBar();
    if (G.power && state === 'play') {
      const p = cellXY(G.power[0], G.power[1]);
      dot(p.x, p.y, 18 + 2.5 * Math.sin(a * 0.6), POWERS[G.power[2]].color);
      dot(p.x, p.y, 14.5, th().board1);
      drawPower(G.power[2], p.x, p.y, 1.15);
    }
    (G.bombs || []).forEach((p) => { const b = cellXY(p[0], p[1]); if (UIOK.bomb) stampBomb(b.x, b.y); else drawBomb(b.x, b.y, 1); });
    const f = cellXY(G.food[0], G.food[1]);
    if (!itemPic('fruitE', 'fruit_' + G.food[2], f.x, f.y + 1.5 * Math.sin(a * 0.4), 23)) drawFruit(G.food[2], f.x, f.y + 1.5 * Math.sin(a * 0.4), 1.1);
    if (G.gold) {
      const q = cellXY(G.gold[0], G.gold[1]);
      drawGolden(q.x, q.y, 1.1, G.gold[2] / GOLD_TICKS);
    }
    if (G.bonus) {
      const b = cellXY(G.bonus[0], G.bonus[1]);
      dot(b.x, b.y, 27 + 3 * Math.sin(a * 0.6), th().accent);
      dot(b.x, b.y, 23, th().board1);
      if (!itemPic('fruitB', 'fruit_' + G.bonus[2], b.x, b.y, 42)) drawFruit(G.bonus[2], b.x, b.y, 2.2);
    }
    const fxKeys = Object.keys(G.fx);
    useLayer(2);                                    // snake pictures, face and effects go above the stamped items
    drawSnake(snakePoints(), easedDir(), fxKeys.length ? POWERS[fxKeys[0]].color : null);
    if (G.boom && state !== 'play') { const b = cellXY(G.boom[0], G.boom[1]); drawBoom(b.x, b.y); }
    fxs.forEach((e) => {
      const k = e.life / e.max;
      if (e.k === 1) { g.lineStyle(3 * k + 1, C(e.color), k); g.strokeCircle(e.x, e.y, e.r + (1 - k) * 26); }
      else dot(e.x, e.y, e.r * k + 0.5, e.color, k);
    });
    if (state === 'play') {
      popups.forEach((p) => txt(p.x, p.y - (900 - p.life) * 0.03, p.s, 13, p.color));
    }
    if (banner) {                                  // big message: combo level, golden fruit, daily done
      const k = banner.life / banner.max, grow = Math.min(1, (1 - k) * 8), alpha = Math.min(1, k * 4);
      const bw = 300 * (0.7 + 0.3 * grow), by = BY + 46 - (1 - k) * 14;
      rrect(W / 2 - bw / 2, by - 24, bw, banner.sub ? 52 : 38, 18, '#000000', 0.55 * alpha);
      txt(W / 2, by - (banner.sub ? 7 : 0) , banner.s, banner.sub ? 20 : 22, banner.color);
      if (banner.sub) txt(W / 2, by + 15, banner.sub, 11, '#ffffff', 0.5, false);
    }
    useLayer(0);
  }

  // btns = [[label, fn, options], ...]   lines = [[text, color], ...] shown under the score
  function drawOverlay(title, sub, btns, lines) {
    const t = th(), ls = lines || [], extra = ls.length * 26, h = 150 + extra + btns.length * 70, top = (H - h) / 2;
    g.fillStyle(0x000000, 0.35);
    g.fillRect(0, 0, W, H);
    rrect(W / 2 - 186, top - 6, 372, h + 12, 24, t.bg);
    rrect(W / 2 - 180, top, 360, h, 20, t.panel);
    txt(W / 2, top + 50, title, 34, t.accent);
    txt(W / 2, top + 98, sub, 15, t.btnText);
    ls.forEach((l, i) => txt(W / 2, top + 130 + i * 26, l[0], 14, l[1] || t.btnText, 0.5, false));
    btns.forEach((b, i) => button(W / 2, top + 162 + extra + i * 70, 290, 56, b[0], b[1], b[2]));
  }

  function drawPause() {
    const t = th(), h = 420, top = (H - h) / 2;
    g.fillStyle(0x000000, 0.35);
    g.fillRect(0, 0, W, H);
    rrect(W / 2 - 186, top - 6, 372, h + 12, 24, t.bg);
    rrect(W / 2 - 180, top, 360, h, 20, t.panel);
    txt(W / 2, top + 40, G.just_revived ? 'Revived!' : 'Paused', 32, t.accent);
    txt(W / 2, top + 78, modeOf().name + ' mode, score ' + G.score, 15, t.btnText);
    txt(W / 2, top + 114, 'Theme', 13, t.btnText, 0.5, false);
    themePicker(top + 146, 58, 18);
    txt(W / 2, top + 190, 'Background', 13, t.btnText, 0.5, false);
    bgPicker(top + 226, 58, 36);
    button(W / 2, top + 300, 290, 54, G.just_revived ? 'Go' : 'Resume', togglePause, { primary: true, size: 20 });
    button(W / 2, top + 368, 290, 54, 'Home', goMenu, { dark: true, size: 20 });
  }

  // Shown while a rewarded ad is requested. The real ad is drawn by the app on top of the game.
  const AD_NOTE = { revive: 'You get the revive after the ad finishes', hint: 'You get the hint after the ad finishes', coins: 'You get +50 coins after the ad finishes', inter: 'Your game goes on right after' };
  function drawAd() {
    buttons = [];
    const t = th();
    g.fillStyle(0x000000, 0.8);
    g.fillRect(0, 0, W, H);
    rrect(W / 2 - 180, 280, 360, 240, 20, t.panel);
    if (adLeft < 0) {
      txt(W / 2, 380, 'Loading ad...', 20, t.btnText);
      txt(W / 2, 410, AD_NOTE[adKind] || '', 12, t.btnText, 0.5, false);
      button(W / 2, 470, 200, 44, 'Cancel', cancelAd, { dark: true, size: 16 });
      return;
    }
    txt(W / 2, 326, adKind === 'inter' ? 'TEST INTERSTITIAL' : 'TEST AD', 26, t.accent);
    txt(W / 2, 366, 'Developer test mode (?testads=1), not a real ad', 12, t.btnText, 0.5, false);
    txt(W / 2, 426, String(Math.ceil(adLeft / 1000)), 54, t.btnText);
    line(W / 2 - 130, 486, W / 2 + 130, 486, t.bg, 8);
    line(W / 2 - 130, 486, W / 2 - 130 + 260 * (1 - adLeft / TEST_AD_MS), 486, t.accent, 8);
  }

  function draw() {
    textsBegin();
    buttons = [];
    useLayer(0);
    if (state === 'menu') {
      drawMenu();
      if (sheetT > 0) { useLayer(1); drawSheet(); }
    } else if (state === 'levels') {
      drawLevels();
    } else if (state === 'ad' && adJob && (adJob.back === 'menu' || adJob.back === 'levels')) {
      if (adJob.back === 'menu') drawMenu(); else drawLevels();
      useLayer(1);
      drawAd();
    } else {
      if (G.camp) drawCampGame(); else drawGame();
      useLayer(1);
      if (state === 'paused') {
        if (G.camp) { if (G.camp.help === 'menu') drawCampHelpMenu(); else if (G.camp.help) drawCampHelp(); else drawCampPause(); } else drawPause();
      } else if (state === 'won') {
        drawCampWon();
      } else if (state === 'over' && G.camp) {
        drawCampFail();
      } else if (state === 'over') {
        const btns = [], lines = [];
        const canRevive = (G.revives || 0) < REVIVES_PER_GAME && adAvailable();
        if (canRevive) btns.push(['Revive (watch ad)', watchAd, { primary: true, size: 19 }]);
        btns.push(['Play again', playAgain, canRevive ? { dark: true } : { primary: true }]);
        btns.push(['Share score', shareScore, { dark: true }]);
        btns.push(['Home', goMenu, { dark: true }]);
        lines.push(['+' + (G.coins | 0) + ' coins this game  (total ' + DATA.coins + ')', '#fbbf24']);
        const dd = dailyEnsure();
        if (G.dailyCoins) lines.push(['Daily challenge complete! +' + G.dailyCoins + ' coins', '#4ade80']);
        else if (!dd.claimed) lines.push(['Daily: ' + dailyText() + '  ' + dd.progress + '/' + dd.target]);
        if (G.adMsg) lines.push([G.adMsg, '#fca5a5']);
        if (G.shareMsg) lines.push([G.shareMsg, '#86efac']);
        drawOverlay(G.boom ? 'Boom!' : 'Game over', 'Score ' + G.score + (G.new_high ? ', new best!' : ''), btns, lines);
      } else if (state === 'ad') {
        drawAd();
      }
    }
    textsEnd();
  }

  // ---------- Game logic ----------
  // opts.head: keep this far from the snake's head, opts.bombR: keep this far from bombs
  function freeCell(margin, opts) {
    const o = opts || {}, head = G.snake[0];
    const taken = new Set(G.snake.map((p) => p[0] + ',' + p[1]));
    if (G.food) taken.add(G.food[0] + ',' + G.food[1]);
    if (G.power) taken.add(G.power[0] + ',' + G.power[1]);
    if (G.gold) taken.add(G.gold[0] + ',' + G.gold[1]);
    if (G.bonus) {
      for (let dc = -1; dc <= 1; dc++) for (let dr = -1; dr <= 1; dr++) taken.add((G.bonus[0] + dc) + ',' + (G.bonus[1] + dr));
    }
    const bombs = G.bombs || [];
    for (let tries = 0; tries < 5000; tries++) {
      const c = margin + rnd(COLS - 2 * margin), r = margin + rnd(ROWS - 2 * margin);
      if (taken.has(c + ',' + r)) continue;
      if (o.head && Math.max(Math.abs(c - head[0]), Math.abs(r - head[1])) < o.head) continue;
      if (bombs.some((p) => Math.max(Math.abs(c - p[0]), Math.abs(r - p[1])) <= (o.bombR || 0))) continue;
      return [c, r];
    }
    return [margin, margin];
  }
  // Ultimate mode: bombs in random places, never right in front of the snake.
  function placeBombs() {
    G.bombs = [];
    if (!modeOf().bombs) return;
    for (let i = 0; i < BOMBS; i++) G.bombs.push(freeCell(1, { head: BOMB_SAFE, bombR: 1 }));
  }
  const isBomb = (c, r) => (G.bombs || []).some((p) => p[0] === c && p[1] === r);
  function placeFood() {
    const p = freeCell(0, { bombR: 0 });
    G.food = [p[0], p[1], FRUITS[rnd(FRUITS.length)]];
  }
  function stepDelay() {
    if (!G) return START_DELAY;
    let d;
    if (G.camp) return G.camp.L.d * SPEED_MUL() * (G.camp.slowT > 0 ? 1.7 : 1);                                         // campaign: every level has its own pace
    if (G.mode === 'ultimate') d = speedDelay(G.speed || DATA.speed);                  // fixed speed chosen by the player
    else d = MIN_DELAY + (START_DELAY - MIN_DELAY) * Math.exp(-G.eaten / SPEEDUP_FRUITS);   // speeds up gently
    if (G.fx.slow) d *= SLOW_FACTOR;
    return d;
  }

  function setState(s) {
    owed = 0;
    state = s;
    if (s === 'menu') CT = menuPal();
    if (window.SFRAds) window.SFRAds.screen(s);            // the banner only lives on menu screens
    applyTheme();
  }
  function applyTheme() {
    const bg = th().bg;
    document.body.style.backgroundColor = bg;
    if (scene) { scene.cameras.main.setBackgroundColor(bg); drawBoard(); }
  }

  function newGame() {
    CT = null;
    const mc = COLS >> 1, mr = ROWS >> 1;
    G = {
      snake: [[mc, mr], [mc - 1, mr], [mc - 2, mr]],
      dir: [1, 0], queue: [], score: 0, eaten: 0, food: null, bonus: null, new_high: false,
      grow: 0, combo: 0, combo_t: 0, power: null, fx: {},
      gold: null, nextGold: 8 + rnd(6), coins: 0, dailyCoins: 0, playMs: 0, adMsg: '', shareMsg: '',
      mode: DATA.mode, speed: DATA.speed
    };
    popups = []; fxs = []; banner = null; prevSnake = null; acc = 0;
    adToken++;                                 // forget any ad request from the previous game
    gift = null;
    dailyEnsure(true);
    sheetOpen = false; sheetT = 0;
    placeBombs();
    placeFood();
    DATA.save = null;
    prevSnake = G.snake.map((c, i) => G.snake[i + 1] || [c[0] - G.dir[0], c[1] - G.dir[1]]);   // the snake glides from the very first frame
    setState('play');
  }

  function continueGame() {
    const s = DATA.save;
    if (!s) return;
    CT = null;
    const ok = s.snake && s.food && s.snake.concat([s.food]).every((p) => p[0] >= 0 && p[0] < COLS && p[1] >= 0 && p[1] < ROWS);
    if (!ok) { DATA.save = null; newGame(); return; }
    G = s;
    G.queue = [];
    G.fx = G.fx || {};
    G.mode = MODES[G.mode] ? G.mode : 'classic';
    // saves from older versions (or damaged ones) may miss the new fields
    G.coins = num(G.coins, 0, MAX_COINS, 0); G.dailyCoins = num(G.dailyCoins, 0, MAX_COINS, 0);
    G.playMs = num(G.playMs, 0, 1e9, 0); G.nextGold = num(G.nextGold, 0, 1e7, (G.eaten | 0) + 10);
    G.adMsg = ''; G.shareMsg = '';
    if (!Array.isArray(G.gold) || G.gold.length < 3) G.gold = null;
    if (!Array.isArray(G.snake) || !G.snake.length || !Array.isArray(G.dir)) { DATA.save = null; newGame(); return; }
    if (modeOf().bombs && !G.bombs) placeBombs();
    sheetOpen = false; sheetT = 0;
    G.just_revived = false;
    popups = []; fxs = []; banner = null; prevSnake = null; acc = 0;
    adToken++;
    dailyEnsure(true);
    setState('paused');              // does not start moving until the player resumes
  }

  function saveGame() {
    if (G && !G.camp && (state === 'play' || state === 'paused')) DATA.save = G;
    writeData();
  }
  function goMenu() { saveGame(); setState('menu'); }
  function gameOver() {
    adsMeta.endless++;
    DATA.save = null;
    G.adMsg = '';
    dailyEnsure();
    writeData();
    if (!G.boom) sfx.over();
    buzz(120);
    setState('over');
  }

  // ---------- Share ----------
  // The app can provide window.shareText(text) (e.g. an Android share sheet). Otherwise the browser's
  // share sheet is used, then the clipboard, then a WhatsApp link.
  function shareScore() {
    const text = 'I scored ' + G.score + ' in Snake Fruit Rush! Can you beat me?' + (window.SHARE_URL ? ' ' + window.SHARE_URL : '');
    const done = (msg) => { if (G) G.shareMsg = msg; };
    try {
      if (typeof window.shareText === 'function') { window.shareText(text); return; }
      if (navigator.share) { navigator.share({ text: text }).catch(() => {}); return; }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => done('Score copied - paste it to a friend!'), () => window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank'));
        return;
      }
      window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank');
    } catch (e) { done('Sharing is not available here.'); }
  }

  // ---------- Revive (rewarded ad) ----------
  // The real ad comes from the app (AdMob in the Android wrapper). It must define
  //   window.showRewardedAd = () => Promise<boolean>
  // that resolves true ONLY after the user-earned-reward callback fired, and false if the ad
  // failed, was not filled or was closed early. Optionally window.isRewardedAdReady() -> boolean.
  // The snake is revived only when the promise resolves with exactly true. Nothing is granted for a tap.
  // Without the hook no revive button is shown. For desktop testing, ?testads=1 uses a 5 s test countdown.
  function adAvailable() {
    if (typeof window.showRewardedAd === 'function') {
      try { return typeof window.isRewardedAdReady === 'function' ? window.isRewardedAdReady() !== false : true; } catch (e) { return true; }
    }
    return TEST_ADS;
  }
  // ---------- Ads (the SDK is in the bridge script; everything here is only about WHEN to offer or show an ad) ----------
  const INTER_EVERY_LEVELS = 3;      // interstitial after about every 3 completed levels (campaign)
  const INTER_EVERY_ENDLESS = 2;     // ... and after every 2nd Endless game over, when the player chooses Play again
  const INTER_COOLDOWN_MS = 90000;   // never two ads (of any kind) closer than this
  const AD_COIN_LADDER = [100, 150, 250, 400, 600], AD_COIN_DAILY = 5;   // each ad of the day pays more than the one before
  const adCoinNext = () => AD_COIN_LADDER[Math.min(AD_COIN_LADDER.length - 1, adCoinsToday())];
  const INTER_FAILSAFE_MS = 30000;
  const adsMeta = { last: Date.now(), levels: 0, endless: 0 };      // session counters only; the first ad can come after a cooldown, never at launch
  let adJob = null, adKind = 'revive';
  let toast = null;                  // {s, ok, until}: short message above the settings sheet
  const SFRAds = () => window.SFRAds;
  const rewardedAvailable = () => adAvailable();
  const interAvailable = () => !!(SFRAds() && SFRAds().interReady());
  const adDay = () => dateKey(new Date());
  const adCoinsToday = () => (DATA.adCoins && DATA.adCoins.d === adDay() ? DATA.adCoins.n : 0);
  const adCoinsLeft = () => Math.max(0, AD_COIN_DAILY - adCoinsToday());
  function sheetToast(s, ok) { toast = { s: s, ok: ok, until: anim + 2600 }; }
  function adStart(kind, job) {      // common start: the game shows its own waiting screen; the real ad covers it
    const token = ++adToken;
    adJob = job; adKind = kind;
    state = 'ad';
    if (SFRAds()) SFRAds().screen('ad');
    return token;
  }
  function endAd(token, ok, msg) {
    if (token !== adToken || state !== 'ad') return;     // cancelled, restarted or answered twice
    adToken++;
    clearTimeout(adTimer);
    const job = adJob; adJob = null;
    adsMeta.last = Date.now();                           // every ad restarts the cooldown
    if (job && job.inter) { setState(job.back); if (job.done) job.done(); return; }
    if (ok === true) {                                   // the reward is granted here and nowhere else
      if (job && job.ok) { setState(job.back); job.ok(); } else { G.adMsg = ''; revive(); }
      return;
    }
    const m = msg || 'Ad not available. Try again later.';
    if (job && job.fail) { setState(job.back); job.fail(m); return; }
    G.adMsg = m;
    setState('over');                                    // normal game-over / restart flow still works
  }
  function cancelAd() { endAd(adToken, false, 'Ad cancelled.'); }
  function requestRewarded(kind, job) {                  // job = {back, ok(), fail(msg)} - null job = Endless revive
    if (state === 'ad' || !adAvailable()) return false;
    const token = adStart(kind, job);
    G && (G.adMsg = G.adMsg || '');
    if (typeof window.showRewardedAd === 'function') {
      adLeft = -1;
      adTimer = setTimeout(() => endAd(token, false, 'Ad took too long.'), AD_TIMEOUT_MS);
      let p;
      try { p = Promise.resolve(window.showRewardedAd()); } catch (e) { p = Promise.reject(e); }
      p.then((ok) => endAd(token, ok === true), () => endAd(token, false));
    } else {
      adLeft = TEST_AD_MS;
    }
    return true;
  }
  function watchAd() {                                   // Endless revive (existing button)
    if (state !== 'over' || (G.revives || 0) >= REVIVES_PER_GAME || !adAvailable()) return;
    G.adMsg = '';
    requestRewarded('revive', null);
  }
  function runInter(done, back) {
    if (state === 'ad') { done(); return; }
    const token = adStart('inter', { inter: true, back: back || state, done: done });
    if (SFRAds() && SFRAds().native) {
      adLeft = -1;
      adTimer = setTimeout(() => endAd(token, true), INTER_FAILSAFE_MS);
      SFRAds().showInter().then(() => endAd(token, true), () => endAd(token, true));
    } else adLeft = 3000;                                // ?testads=1 desktop simulation
  }
  // kind: 'level' | 'endless'. Calls done() right away when no ad is due - the game never waits for an ad that is not there.
  function maybeInter(kind, done) {
    const early = kind === 'level' && (Object.keys(DATA.camp.stars).length < 3 || (G && G.camp && G.camp.fails >= 2));   // no ads in the first levels and none right after a struggle
    const due = !early && (kind === 'level' ? adsMeta.levels >= INTER_EVERY_LEVELS : adsMeta.endless >= INTER_EVERY_ENDLESS);
    if (state !== 'ad' && due && Date.now() - adsMeta.last >= INTER_COOLDOWN_MS && interAvailable()) {
      if (kind === 'level') adsMeta.levels = 0; else adsMeta.endless = 0;
      runInter(done);
      return;
    }
    done();
  }
  function playAgain() { maybeInter('endless', newGame); }
  function claimAdCoins(back, done) {
    const say = typeof done === 'function' ? done : sheetToast;
    if (!adCoinsLeft()) { say('Daily limit reached. Come back tomorrow!', false); return; }
    const amt = adCoinNext();
    requestRewarded('coins', { back: typeof back === 'string' ? back : 'menu', ok: () => {
      DATA.adCoins = { d: adDay(), n: adCoinsToday() + 1 };
      DATA.coins = Math.min(MAX_COINS, DATA.coins + amt);
      writeData(); sfx.coin();
      say('+' + amt + ' coins!', true);                                   // nothing is opened or bought automatically
    }, fail: (m) => say(m, false) });
  }
  function adBtn(cx, cy, w, h, label, fn, size) {                        // optional-ad button: a lighter pill so it stands out from the panel
    const t = th();
    if (!slice3('btn_pill', cx, cy + 1, w + 6, h + 8, C(shade(t.panel, 0.2)))) {
      rrect(cx - w / 2, cy - h / 2 + 3, w, h, h / 2, shade(t.panel, -0.3));
      rrect(cx - w / 2, cy - h / 2, w, h, h / 2, shade(t.panel, 0.2));
    }
    txt(cx, cy, label, size || 15, t.btnText);
    buttons.push({ x: cx - w / 2, y: cy - h / 2, w: w, h: h + 3, fn: fn });
  }
  let sheetAdBtn = false;
  function adCoinsButton(cy, w) {                                       // optional button, only when ads can really be shown
    if (!adCoinsLeft() || !adAvailable()) return false;
    sheetAdBtn = true;
    adBtn(W / 2, cy, w || 320, 38, 'Watch ad   +' + adCoinNext() + ' coins   (' + adCoinsLeft() + ' left today)', claimAdCoins, 14);
    return true;
  }
  function adHint() {                                                   // optional, from the level-failed screen
    if (!G || !G.camp) return;
    requestRewarded('hint', { back: 'over', ok: () => startLevel(G.camp.id, true), fail: (m) => { G.adMsg = m; } });
  }

  // The snake comes back in the middle of the board with its score and length.
  function revive() {
    const mc = COLS >> 1, mr = ROWS >> 1, len = G.snake.length;
    G.revives = (G.revives || 0) + 1;
    G.snake = [[mc, mr], [mc - 1, mr], [mc - 2, mr]];
    G.grow = Math.max(0, len - 3);     // grows back to its old length as it moves
    G.dir = [1, 0];
    G.queue = [];
    G.combo = 0; G.combo_t = 0;
    G.fx = { ghost: 25 };              // a few safe steps while it grows back
    G.just_revived = true;
    G.boom = null;
    G.gold = null;
    placeBombs();                      // fresh bombs, away from the middle
    popups = []; fxs = []; banner = null; prevSnake = null; acc = 0;
    if (G.bonus && Math.abs(G.bonus[0] - mc) <= 2 && Math.abs(G.bonus[1] - mr) <= 2) G.bonus = null;
    sfx.revive();
    setState('paused');                // waits for the player to press GO
    saveGame();
  }

  function popup(s, color, dy) {
    const h = cellXY(G.snake[0][0], G.snake[0][1]);
    if (popups.length > 8) popups.shift();                      // bounded
    popups.push({ x: Math.min(W - 60, Math.max(60, h.x)), y: h.y - 20 - (dy || 0), s: s, color: color || th().accent, life: 900 });
  }

  function addScore(points) {
    if (G.fx.double) points *= 2;
    points = Math.floor(points * (1 + 0.5 * G.combo));
    G.score += points;
    popup('+' + points, th().text, 0);
    if (G.score > best(G.mode)) { DATA.highs[G.mode] = G.score; G.new_high = true; }
    dailyMax('score', G.score);
  }
  function headXY() { return cellXY(G.snake[0][0], G.snake[0][1]); }

  const COMBO_TIERS = { 3: 'NICE!', 5: 'GREAT!', 8: 'AWESOME!', 12: 'UNSTOPPABLE!', 16: 'LEGENDARY!' };
  function bumpCombo() {
    G.combo += 1;
    G.combo_t = COMBO_TICKS;
    popup('COMBO x' + G.combo, th().accent, 18);
    dailyMax('combo', G.combo);
    const tier = COMBO_TIERS[G.combo];
    if (tier) {                                           // short, clear reward for a combo milestone
      const h = headXY();
      showBanner(tier + '  x' + G.combo, (1 + 0.5 * G.combo) + 'x points', th().accent, 1000);
      ring(h.x, h.y, th().accent); burst(h.x, h.y, 'rand', 10);
      sfx.combo(G.combo);
    }
    if (G.combo % COMBO_POWER_EVERY === 0 && !G.power) {
      const p = freeCell(0);
      const pool = POWER_KEYS.filter((k) => !modeOf()[k]);      // no 'No Walls' icon in a no-walls mode, etc.
      G.power = [p[0], p[1], pool[rnd(pool.length)], POWER_ITEM_TICKS];
    }
  }

  function eatAtHead() {
    const hc = G.snake[0][0], hr = G.snake[0][1];
    if (hc === G.food[0] && hr === G.food[1]) {             // fruit
      G.eaten += 1;
      G.grow += 1;
      if (G.combo > 0) bumpCombo();                         // combo only starts with the big fruit
      addScore(FRUIT_POINTS);
      addCoins(COIN_FRUIT);
      dailyAdd('fruits', 1); dailyAdd('ultimate', 1);
      const fp = headXY(); burst(fp.x, fp.y, 'rand', 6);
      sfx.eat(G.combo);
      buzz(12);
      placeFood();
      if (G.eaten % BONUS_EVERY === 0 && !G.bonus) {
        const p = freeCell(1, { bombR: 1 });
        G.bonus = [p[0], p[1], FRUITS[rnd(FRUITS.length)], BONUS_TICKS];
      }
      if (G.eaten >= G.nextGold && !G.gold) {               // golden fruit: rare, short-lived, worth a lot
        const p = freeCell(1, { bombR: 1 });
        G.gold = [p[0], p[1], GOLD_TICKS];
        G.nextGold = G.eaten + 10 + rnd(8);
        showBanner('GOLDEN FRUIT!', 'grab it fast', '#fde047', 900);
        tone(1000, 0.12, 'triangle', 0.2);
      }
    }
    if (G.bonus && Math.abs(hc - G.bonus[0]) <= 1 && Math.abs(hr - G.bonus[1]) <= 1) {   // big fruit
      G.bonus = null;
      G.grow += 1;
      if (modeOf().bombs) placeBombs();                     // bombs move after every big fruit
      bumpCombo();
      addScore(BONUS_POINTS);
      addCoins(COIN_BONUS);
      dailyAdd('bonus', 1); dailyAdd('fruits', 1); dailyAdd('ultimate', 1);
      const bp = headXY(); burst(bp.x, bp.y, 'rand', 12); ring(bp.x, bp.y, th().accent);
      sfx.yum();
      buzz(30);
    }
    if (G.gold && hc === G.gold[0] && hr === G.gold[1]) {   // golden fruit
      G.gold = null;
      G.grow += 1;
      if (G.combo > 0) bumpCombo();
      addScore(GOLD_POINTS);
      addCoins(COIN_GOLD);
      dailyAdd('golden', 1); dailyAdd('fruits', 1); dailyAdd('ultimate', 1);
      const gp = headXY(); burst(gp.x, gp.y, 'rand', 16); ring(gp.x, gp.y, '#fde047');
      showBanner('GOLDEN!  +' + GOLD_POINTS + ' +' + COIN_GOLD + ' coins', '', '#fde047', 1000);
      sfx.gold();
      buzz(40);
    }
    if (G.power && hc === G.power[0] && hr === G.power[1]) {   // ability icon
      const kind = G.power[2];
      G.power = null;
      G.fx[kind] = POWER_TICKS;
      popup(POWERS[kind].name + '!', POWERS[kind].color, 36);
      const pp = headXY(); ring(pp.x, pp.y, POWERS[kind].color); burst(pp.x, pp.y, POWERS[kind].color, 8);
      showBanner(POWERS[kind].name + '!', 'power-up active', POWERS[kind].color, 800);
      sfx.power();
      buzz(30);
    }
  }

  function magnetPull() {
    const hc = G.snake[0][0], hr = G.snake[0][1];
    [G.food, G.bonus, G.power, G.gold].forEach((item) => {
      if (item && Math.max(Math.abs(item[0] - hc), Math.abs(item[1] - hr)) <= MAGNET_RANGE) {
        const nc = item[0] + Math.sign(hc - item[0]), nr = item[1] + Math.sign(hr - item[1]);
        if (!isBomb(nc, nr)) { item[0] = nc; item[1] = nr; }            // fruit never lands on a bomb
      }
    });
  }

  function step() {
    const oldDir = G.dir;
    if (G.queue.length) G.dir = G.queue.shift();
    // close call: a bomb was right in front of the head and the player turned away just in time
    if (G.bombs && G.bombs.length && !same(oldDir, G.dir)) {
      let bc = G.snake[0][0] + oldDir[0], br = G.snake[0][1] + oldDir[1];
      if (has('wall')) { bc = (bc + COLS) % COLS; br = (br + ROWS) % ROWS; }
      if (isBomb(bc, br)) G.near = true;
    }
    let nc = G.snake[0][0] + G.dir[0], nr = G.snake[0][1] + G.dir[1];

    // 1. wall (NO WALLS: come out on the other side)
    if (nc < 0 || nc >= COLS || nr < 0 || nr >= ROWS) {
      if (has('wall')) { nc = (nc + COLS) % COLS; nr = (nr + ROWS) % ROWS; }
      else return gameOver();
    }
    // 2. bomb (Ultimate mode) - even a ghost snake explodes
    if (isBomb(nc, nr)) {
      G.boom = [nc, nr];
      sfx.boom();
      return gameOver();
    }
    // 3. own body (GHOST: pass through)
    const growing = G.grow > 0;
    const body = growing ? G.snake : G.snake.slice(0, -1);
    if (!has('ghost') && body.some((s) => s[0] === nc && s[1] === nr)) return gameOver();

    G.snake.unshift([nc, nr]);
    if (growing) G.grow -= 1; else G.snake.pop();
    trailPuff();
    if (G.near) {
      G.near = false;
      G.score += NEAR_POINTS;
      if (G.score > best(G.mode)) { DATA.highs[G.mode] = G.score; G.new_high = true; }
      dailyMax('score', G.score);
      const np = headXY();
      popup('CLOSE CALL! +' + NEAR_POINTS, '#f87171', 18);
      ring(np.x, np.y, '#f87171');
      sfx.near();
    }

    // 3. food / abilities
    eatAtHead();
    if (G.fx.magnet) { magnetPull(); eatAtHead(); }

    // 4. timers
    if (G.bonus && --G.bonus[3] <= 0) G.bonus = null;
    if (G.power && --G.power[3] <= 0) G.power = null;
    if (G.gold && --G.gold[2] <= 0) G.gold = null;
    if (G.combo > 0 && --G.combo_t <= 0) G.combo = 0;
    Object.keys(G.fx).forEach((k) => { if (--G.fx[k] <= 0) delete G.fx[k]; });
  }

  // ---------- Input ----------
  const opposite = (a, b) => a[0] === -b[0] && a[1] === -b[1];
  const same = (a, b) => a[0] === b[0] && a[1] === b[1];

  function turn(d) {
    if (state !== 'play') return false;
    const last = G.queue.length ? G.queue[G.queue.length - 1] : G.dir;
    if (same(d, last) || opposite(d, last) || G.queue.length >= 2) return false;
    G.queue.push(d);
    // Respond right away: if the snake is already part-way into its step, take the turn now
    // instead of waiting for the next step.
    if (G.queue.length === 1 && acc >= stepDelay() * INSTANT_TURN && !(G.camp && (G.camp.ready > 0 || campSliding()))) {
      prevSnake = visualCells();                      // start from where the snake is drawn right now: nothing jumps
      acc = 0;
      if (G.camp) campStep(); else step();
    }
    return true;
  }
  // Tap: the snake turns towards the tapped point.
  function tapTurn(x, y) {
    const h = cellXY(G.snake[0][0], G.snake[0][1]);
    const dx = x - h.x, dy = y - h.y;
    const horiz = [dx > 0 ? 1 : -1, 0], vert = [0, dy > 0 ? 1 : -1];
    const order = Math.abs(dx) > Math.abs(dy) ? [horiz, vert] : [vert, horiz];
    if (!turn(order[0])) turn(order[1]);        // cannot go straight or reverse, so try the other axis
  }
  function togglePause() {
    if (state === 'play') { saveGame(); setState('paused'); }
    else if (state === 'paused') { acc = 0; prevSnake = null; G.just_revived = false; setState('play'); }
  }
  function setTheme(i) {
    DATA.theme = (i + THEMES.length) % THEMES.length;
    writeData();
    applyTheme();
  }
  function setBackground(i) {
    DATA.bg = (i + BACKGROUNDS.length) % BACKGROUNDS.length;
    writeData();
    drawBoard();
  }
  function setMode(k) {
    DATA.mode = k;
    writeData();
  }
  function setSpeed(v) {
    DATA.speed = Math.min(10, Math.max(1, v));
    writeData();
  }
  function toggleSound() {
    DATA.sound = !DATA.sound;
    writeData();
    tone(660, 0.1, 'triangle', 0.25);
  }

  // ---------- Campaign logic ----------
  let lvPage = 0;                                    // world shown on the level select screen
  let lvMsg = null;                                  // {s, until}: short message on the level select screen
  const campUnlocked = () => (UNLOCK_ALL ? LEVEL_COUNT : DATA.camp.unlocked);
  const campNext = () => Math.min(LEVEL_COUNT, Math.max(1, DATA.camp.cur));
  function useWorld(w) { CT = WORLDS[w].pal; applyTheme(); }
  function openLevels() {
    lvPage = Math.floor((campNext() - 1) / 20);
    useWorld(lvPage);
    setState('levels');
  }
  const menuPal = () => (DATA.menuMode === 'endless' ? null : WORLDS[Math.floor((campNext() - 1) / 20)].pal);
  function setMenuMode(levels) {
    DATA.menuMode = levels ? 'levels' : 'endless';
    if (levels && DATA.tab < 3) DATA.tab = 3;                 // Modes / Themes / Pattern only exist in Endless
    writeData(); CT = menuPal(); applyTheme();
  }
  function playSelected() { if (DATA.menuMode === 'endless') newGame(); else playCampaign(); }
  function playCampaign() { startLevel(campNext()); }
  // Fruit goes to new random places on the route every time a level starts (always cells the solution passes, so it stays solvable).
  function randomFruit(L) {
    const q = lvLayer(L.Q), cells = [], want = L.F.length;
    for (let i = 0; i < COLS * ROWS; i++) if (q[i]) cells.push(i);
    for (const gap of [3, 2]) {                 // a fruit never touches another fruit, not even diagonally
      const pool = cells.slice(), out = [];
      while (pool.length && out.length < want) {
        const c = pool.splice(rnd(pool.length), 1)[0], x = c % COLS, y = (c / COLS) | 0;
        if (out.every((o) => Math.max(Math.abs(o[0] - x), Math.abs(o[1] - y)) >= gap)) out.push([x, y]);
      }
      if (out.length === want) return Object.assign({}, L, { F: out });
    }
    return L;
  }


  // ---------- Campaign daily challenge (separate from the Endless one) ----------
  let cdCheck = 0;
  function cdEnsure() {
    const now = Date.now();
    if (DATA.cdaily && now - cdCheck < 4000) return DATA.cdaily;
    cdCheck = now;
    const today = dateKey(new Date());
    if (!DATA.cdaily || DATA.cdaily.date !== today) { DATA.cdaily = makeCD(today); writeData(); }
    return DATA.cdaily;
  }
  function cdAdd(id, n) {
    const d = cdEnsure();
    if (d.id !== id || d.claimed) return;
    d.progress = Math.min(d.target, d.progress + n);
    if (d.progress >= d.target) {
      d.claimed = true; addCoins(d.reward); if (G) G.dailyCoins = (G.dailyCoins | 0) + d.reward;
      showBanner('CAMPAIGN DAILY DONE!  +' + d.reward + ' coins', 'Challenge complete', '#facc15', 2200);
      sfx.win(); buzz(40);
    }
    writeData();
  }

  // ---------- adaptive difficulty (internal only, never shown) ----------
  const SK_KEY = 'snakeFruitRush.skill.v1';
  const SK_FRESH = () => ({ v: 1, lvl: 0, h: [], mech: {}, cur: null });
  const skClamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function skLoad() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(SK_KEY)); } catch (e) { d = null; }
    const s = SK_FRESH();
    if (!d || d.v !== 1 || !Array.isArray(d.h)) return s;
    s.lvl = skClamp(d.lvl | 0, -2, 2);
    s.h = d.h.filter((r) => r && isFinite(r.sc)).slice(-10).map((r) => ({ id: r.id | 0, sc: skClamp(+r.sc, 0, 1), at: skClamp(r.at | 0, 1, 99) }));
    if (d.mech && typeof d.mech === 'object') ['trap', 'door', 'gate'].forEach((k) => { s.mech[k] = skClamp(d.mech[k] | 0, 0, 9); });
    return s;
  }
  let SK = skLoad();
  function skSave() { try { localStorage.setItem(SK_KEY, JSON.stringify({ v: 1, lvl: SK.lvl, h: SK.h, mech: SK.mech })); } catch (e) { /* storage blocked: adaptation lasts for this session only */ } }
  const skProfile = () => (SK.lvl <= -1 ? 'beginner' : SK.lvl >= 1 ? 'skilled' : 'intermediate');
  const skHas = (L, k) => !!L[k] && (typeof L[k] === 'string' ? /[^0]/.test(L[k]) : L[k].length > 0);
  function skRecord(id, fails, moves, par, ms, delay) {            // called once when a level is completed
    const first = fails === 0 ? 1 : fails === 1 ? 0.5 : fails <= 3 ? 0.2 : 0;
    const eff = skClamp(par / Math.max(1, moves), 0, 1), spd = skClamp(par * delay / Math.max(1, ms), 0, 1);
    SK.h.push({ id: id, sc: 0.5 * first + 0.3 * eff + 0.2 * spd, at: fails + 1 });
    if (SK.h.length > 10) SK.h.shift();
    Object.keys(SK.mech).forEach((k) => { SK.mech[k] = Math.max(0, SK.mech[k] - 1); });
    if (SK.h.length >= 4) {                                          // ~4 levels of data first, then one small step per level
      const w = SK.h.slice(-6), avg = w.reduce((a, r) => a + r.sc, 0) / w.length;
      const target = avg < 0.35 ? -2 : avg < 0.5 ? -1 : avg > 0.84 ? 2 : avg > 0.74 ? 1 : 0;
      SK.lvl += Math.sign(target - SK.lvl);
    }
    skSave();
  }
  function skFail(id, reason) {
    if (!SK.cur || SK.cur.id !== id) SK.cur = { id: id, fails: 0, ms: 0 };
    SK.cur.fails++;
    if (SK.mech[reason] !== undefined) SK.mech[reason] = Math.min(9, SK.mech[reason] + 1);
    skSave();
  }
  // Settings for the NEXT level only (called from startLevel, never while a level runs).
  function skAdapt(L, id) {
    let e = SK.lvl;
    const last2 = SK.h.slice(-2);
    if (last2.length === 2 && last2.every((r) => r.at >= 3)) e -= 1;                       // easier breather after two hard levels (based on finished levels only: retrying never eases a level)
    e = skClamp(e, -2, 2);
    return { e: e, bias: e < 0 ? -1 : e > 0 ? 1 : 0, s2: -e * 1.5 | 0, s3: -e, d: e <= -2 ? 1.08 : e === -1 ? 1.04 : 1, ready: e <= -2 ? 500 : 0, hint: false };
  }
  function adaptiveFruit(L, bias) {                                  // layouts are drawn from the validated Q mask, so every one stays solvable by the stored route
    if (!bias) return randomFruit(L);
    let best = null, bs = 0;
    for (let i = 0; i < 6; i++) {
      const cand = randomFruit(L), sc = cand.F.reduce((a, f) => a + Math.abs(f[0] - L.s[0]) + Math.abs(f[1] - L.s[1]), 0);
      if (!best || (bias < 0 ? sc < bs : sc > bs)) { best = cand; bs = sc; }
    }
    return best;
  }
  // Fruit places are made once per level (first entry), saved, and reused on every retry / restart.
  const FRUIT_KEY = 'snakeFruitRush.fruit.v3';
  // Fruit in tight spots: of several valid random layouts (all on the stored route, never touching), keep the one whose fruit sit in the narrowest
  // gaps. More candidates on later levels, so the pull towards tight corridors grows with the level number.
  function tightness(base, F) {
    const wl = lvLayer(base.W), bl = base.B ? lvLayer(base.B) : null;
    let s = 0;
    F.forEach((f) => {
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const x = f[0] + dx, y = f[1] + dy;
        if (x < 0 || y < 0 || x >= COLS || y >= ROWS || wl[y * COLS + x] || (bl && bl[y * COLS + x])) s++;
      }
    });
    return s;
  }
  function fruitCount(id) {                                          // fruit per level: more and more as the campaign goes on
    if (id <= 5) return 3;
    if (id <= 10) return 4;
    if (id <= 20) return id <= 15 ? 4 : 5;
    if (id <= 30) return 5;
    if (id <= 40) return id <= 35 ? 5 : 6;
    if (id <= 50) return 6;
    if (id <= 60) return id <= 55 ? 6 : 7;
    if (id <= 70) return 7;
    if (id <= 80) return id <= 75 ? 7 : 8;
    return 8;
  }
  const D4V = [[0, -1], [1, 0], [0, 1], [-1, 0]];
  function routeWins(base, F) {                                      // the stored solution must still win with this layout (same replay as the validator)
    const L2 = Object.assign({}, base, { F: F }), rt = E.makeRuntime(engineLevel(L2)), st = E.newState(rt), route = base.R;
    let status = 'ok';
    for (let k = 1; k < route.length; k++) {
      const cur = route[k], head = st.body[0], d = D4V.findIndex((v) => v[0] === (cur % COLS) - (head % COLS) && v[1] === ((cur / COLS) | 0) - ((head / COLS) | 0));
      if (d < 0) return false;
      let q, g = 0;
      do { q = E.step(rt, st, D4V[d]); g++; } while (q.status === 'wait' && g < 5);
      status = q.status;
      if (status === 'fail') return false;
      if ((base.P || []).some((pp) => (pp[1] * COLS + pp[0]) === cur)) k++;
    }
    return status === 'win';
  }
  function fruitPool(base) {                                         // route cells a fruit may sit on (never devices, bombs, portals, start lane, exit)
    const bl = base.B ? lvLayer(base.B) : null, bad = new Set(), R = base.R;
    [base.K, base.D, base.G].forEach((a) => (a || []).forEach((c) => bad.add(c[1] * COLS + c[0])));
    (base.S || []).forEach((s) => bad.add(s[1] * COLS + s[0]));
    (base.P || []).forEach((p) => { bad.add(p[1] * COLS + p[0]); bad.add(p[3] * COLS + p[2]); });
    const out = [];
    for (let k = 4; k < R.length - 2; k++) if (!bad.has(R[k]) && !(bl && bl[R[k]])) out.push(R[k]);
    return out;
  }
  function tightFruit(base, id, rf) {
    rf = rf || rnd;
    const want = fruitCount(id), pool = fruitPool(base), tries = 4 + Math.ceil(id * 0.4), R = base.R;
    for (let n = want; n >= 1; n--) {
      let best = null, bs = -1, found = 0;
      for (let i = 0; i < tries * 6 && found < tries; i++) {
        const p = pool.slice(), F = [];
        while (p.length && F.length < n) {
          const c = p.splice(rf(p.length), 1)[0], x = c % COLS, y = (c / COLS) | 0;
          if (F.every((o) => Math.max(Math.abs(o[0] - x), Math.abs(o[1] - y)) >= 2)) F.push([x, y]);
        }
        if (F.length < n || !routeWins(base, F)) continue;
        found++;
        const last = Math.max.apply(null, F.map((f) => R.indexOf(f[1] * COLS + f[0])));
        const sc = tightness(base, F) + Math.min(4, (R.length - 1 - last) / 8);   // tight gaps + a longer trip to the exit afterwards
        if (sc > bs) { bs = sc; best = F; }
      }
      if (best) return best;
    }
    return base.F;
  }
  function fruitSaved(id, base) {
    let m = {};
    try { m = JSON.parse(localStorage.getItem(FRUIT_KEY)) || {}; } catch (e) { m = {}; }
    const f = m[id], q = lvLayer(base.Q);
    const pool = new Set(fruitPool(base));
    const ok = Array.isArray(f) && f.length >= 1 && f.length <= fruitCount(id) && f.every((c) => Array.isArray(c) && c[0] >= 0 && c[0] < COLS && c[1] >= 0 && c[1] < ROWS && pool.has(c[1] * COLS + c[0]))
      && f.every((a, i) => f.every((b, j) => i === j || Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])) >= 2)) && routeWins(base, f);
    if (ok) return f;
    const F2 = tightFruit(base, id);
    m[id] = F2;
    try { localStorage.setItem(FRUIT_KEY, JSON.stringify(m)); } catch (e) { /* blocked: layout lasts for this session only */ }
    return F2;
  }


  // ---------- Coin store: free coins from ads (the daily ladder) and coin packs (coming soon) ----------
  function drawCoinStore(top) {
    const t = th(), ct = coinText(DATA.coins) + ' coins';
    drawCoin(W / 2 - ct.length * 4.4 - 12, top + 100, 10); txt(W / 2 - ct.length * 4.4 + 2, top + 100, ct, 16, t.accent, 0);
    txt(W / 2, top + 134, 'Free coins - watch ads', 14, t.btnText);
    const n = adCoinsToday(), pw = 78, x0 = W / 2 - (AD_COIN_LADDER.length * pw + (AD_COIN_LADDER.length - 1) * 4) / 2;
    AD_COIN_LADDER.forEach((v, i) => {
      const x = x0 + i * (pw + 4), done = i < n, next = i === n;
      rrect(x, top + 150, pw, 46, 12, next ? t.accent : t.panel, done ? 0.5 : 1);
      drawCoin(x + 16, top + 173, 8); txt(x + 28, top + 173, String(v), 13, next ? '#1b1b1b' : t.btnText, 0);
      if (done) { line(x + pw - 18, top + 160, x + pw - 14, top + 164, '#4ade80', 2.4); line(x + pw - 14, top + 164, x + pw - 7, top + 156, '#4ade80', 2.4); }
    });
    if (adCoinsLeft() && adAvailable()) { sheetAdBtn = true; adBtn(W / 2, top + 224, 320, 42, 'Watch ad   +' + adCoinNext() + ' coins   (' + adCoinsLeft() + ' left today)', claimAdCoins, 15); }
    else txt(W / 2, top + 224, adCoinsLeft() ? 'No ad ready right now - try again in a moment' : 'All free coins taken today - come back tomorrow!', 13, t.text, 0.5, false);
    txt(W / 2, top + 268, 'Coin packs', 14, t.btnText);
    [['Small', 500], ['Medium', 1500], ['Big', 5000]].forEach((pk, i) => {
      const cx = W / 2 + (i - 1) * 144, cy = top + 352;
      rrect(cx - 68, cy - 66, 136, 132, 16, t.panel);
      if (!uiPic(['pack_small', 'pack_medium', 'pack_big'][i], cx, cy - 31, 58, 50)) drawCoin(cx, cy - 28, 18);
      txt(cx, cy + 9, String(pk[1]), 20, t.accent);
      txt(cx, cy + 30, pk[0] + ' pack', 12, t.btnText, 0.5, false);
      rrect(cx - 50, cy + 42, 100, 20, 10, '#00000055'); txt(cx, cy + 52, 'Coming soon', 11, t.btnText);
      buttons.push({ x: cx - 68, y: cy - 66, w: 136, h: 132, fn: () => sheetToast('Coin packs are coming soon!', true) });
    });
  }

  // ---------- Progress store (goals, daily puzzle, expert clears): its own key, safe on missing / broken data ----------
  const PROG_KEY = 'snakeFruitRush.prog.v1';
  const PROG = (() => {
    let a = null;
    try { a = JSON.parse(localStorage.getItem(PROG_KEY)); } catch (e) { a = null; }
    a = a && typeof a === 'object' ? a : {};
    const o = { claimed: {}, nohelp: num(a.nohelp, 0, 1e5, 0), ice: num(a.ice, 0, 1e5, 0), expert: {}, dp: { date: '', done: false, moves: 0, stars: 0, streak: 0, last: '', best: 0, total: 0 } };
    if (a.claimed && typeof a.claimed === 'object') Object.keys(a.claimed).forEach((k) => { if (a.claimed[k] === 1 && /^[a-z0-9]{1,12}$/.test(k)) o.claimed[k] = 1; });
    if (a.expert && typeof a.expert === 'object') Object.keys(a.expert).forEach((k) => { if (/^\d{1,3}$/.test(k) && +k >= 1 && +k <= 100) o.expert[k] = 1; });
    const d = a.dp && typeof a.dp === 'object' ? a.dp : {};
    if (typeof d.date === 'string' && DATE_RE.test(d.date)) { o.dp.date = d.date; o.dp.done = d.done === true; o.dp.moves = num(d.moves, 0, 9999, 0); o.dp.stars = num(d.stars, 0, 3, 0); }
    o.dp.streak = num(d.streak, 0, 9999, 0); o.dp.best = num(d.best, 0, 9999, 0); o.dp.total = num(d.total, 0, 99999, 0);
    o.dp.last = typeof d.last === 'string' && DATE_RE.test(d.last) ? d.last : '';
    return o;
  })();
  function progSave() { try { localStorage.setItem(PROG_KEY, JSON.stringify(PROG)); } catch (e) { /* blocked: lasts for this session */ } }

  // ---------- Goals ----------
  const clearedN = () => Object.keys(DATA.camp.stars).length;
  const threeN = () => Object.keys(DATA.camp.stars).filter((k) => (DATA.camp.stars[k] | 0) >= 3).length;
  const dpStreakNow = () => (PROG.dp.last === dateKey(new Date()) || PROG.dp.last === addDays(dateKey(new Date()), -1) ? PROG.dp.streak : 0);
  const GOALS = [
    { id: 'ten', name: 'Getting good', desc: 'Clear 10 levels', t: 10, v: clearedN, pay: 30 },
    { id: 'three10', name: 'Perfectionist', desc: '3 stars on 10 levels', t: 10, v: threeN, pay: 80 },
    { id: 'nohelp5', name: 'On my own', desc: 'Clear 5 levels with no help', t: 5, v: () => PROG.nohelp, pay: 60 },
    { id: 'ice10', name: 'Ice breaker', desc: 'Clear 10 levels with ice', t: 10, v: () => PROG.ice, pay: 50 },
    { id: 'daily3', name: 'Daily habit', desc: 'Daily puzzle 3 days in a row', t: 3, v: dpStreakNow, pay: 100 },
    { id: 'daily7', name: 'Week warrior', desc: 'Daily puzzle 7 days in a row', t: 7, v: dpStreakNow, pay: 150, skin: 'neonracer' },
    { id: 'expert5', name: 'Expert', desc: 'Clear 5 levels in Expert mode', t: 5, v: () => Object.keys(PROG.expert).length, pay: 150, skin: 'obsidian' },
    { id: 'three25', name: 'Champion', desc: '3 stars on 25 levels', t: 25, v: threeN, pay: 200, skin: 'champion' }
  ];
  function goalsCheck() {
    let any = false;
    GOALS.forEach((gl) => {
      if (PROG.claimed[gl.id] || gl.v() < gl.t) return;
      PROG.claimed[gl.id] = 1; any = true;
      addCoins(gl.pay);
      if (gl.skin && DATA.skins.indexOf(gl.skin) < 0 && SKIN_BY_ID[gl.skin]) DATA.skins.push(gl.skin);
      showBanner('GOAL: ' + gl.name, '+' + gl.pay + ' coins' + (gl.skin ? '  +  new skin!' : ''), '#fbbf24', 2200);
      sfx.gold();
    });
    if (any) { progSave(); writeData(); }
  }
  function drawGoals(top) {
    const t = th();
    txt(W / 2, top + 100, 'Goals', 22, t.accent);
    GOALS.forEach((gl, i) => {
      const y = top + 140 + i * 38, done = !!PROG.claimed[gl.id], v = Math.min(gl.t, gl.v());
      rrect(BX + 10, y - 17, BW - 20, 34, 12, t.panel, 0.9);
      txt(BX + 24, y - 7, gl.name, 13, done ? t.accent : t.btnText, 0);
      txt(BX + 24, y + 9, gl.desc, 10.5, t.text, 0, false);
      if (done) {
        if (!uiPic('tick', BX + BW - 34, y, 26, 24)) { dot(BX + BW - 34, y, 11, '#22c55e'); line(BX + BW - 40, y, BX + BW - 36, y + 4, '#ffffff', 2.6); line(BX + BW - 36, y + 4, BX + BW - 29, y - 4, '#ffffff', 2.6); }
        txt(BX + BW - 64, y, 'Done', 11, t.accent, 1);
      } else {
        const bx = BX + 206, bw = 84;                                      // progress bar with the count written inside
        rrect(bx, y - 8, bw, 16, 8, t.bg);
        if (v > 0) rrect(bx, y - 8, Math.max(16, bw * v / gl.t), 16, 8, t.accent);
        txt(bx + bw / 2, y + 0.5, v + '/' + gl.t, 10, v > 0 ? '#1b1b1b' : t.text, 0.5, false);
        const rx = BX + 308;                                                // reward: coin + amount, "SKIN" as its own small tag
        if (!uiPic('icon_coins', rx, y, 18, 16)) drawCoin(rx, y, 7);
        txt(rx + 13, y + 0.5, '+' + gl.pay, 12, t.accent, 0);
        if (gl.skin) { rrect(rx + 52, y - 9, 44, 18, 9, t.accent); txt(rx + 74, y + 0.5, '+ SKIN', 9.5, '#1b1b1b', 0.5, false); }
      }
    });
  }

  // ---------- Daily puzzle: the same level and fruit for everybody on a given day ----------
  const dpToday = () => dateKey(new Date());
  const dpDone = () => PROG.dp.date === dpToday() && PROG.dp.done;
  function strHash(s) { let h = 7; for (let i = 0; i < s.length; i++) h = (Math.imul(h, 33) + s.charCodeAt(i)) >>> 0; h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; return (h ^ (h >>> 13)) >>> 0; }
  function seededRng(seed) {
    let a = seed >>> 0;
    return (n) => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return Math.floor((((t ^ (t >>> 14)) >>> 0) / 4294967296) * n); };
  }
  const dpLevelFor = (date) => 15 + (strHash(date) % 56);            // levels 15 - 70
  function startDailyPuzzle() {
    const date = dpToday(), id = dpLevelFor(date), base = LV[id - 1];
    startLevel(id, false, { daily: true, date: date, F: tightFruit(base, id, seededRng(strHash(date + '#' + id))) });
  }
  function dpComplete(C0) {
    const date = C0.opts.date || dpToday(), first = !(PROG.dp.date === date && PROG.dp.done);
    C0.dpReward = 0;
    if (first) {
      PROG.dp.streak = PROG.dp.last === addDays(date, -1) ? PROG.dp.streak + 1 : 1;
      PROG.dp.last = date; PROG.dp.total++;
      C0.dpReward = 60 + Math.min(PROG.dp.streak, 7) * 10;
      addCoins(C0.dpReward);
    }
    const better = first || C0.moves < PROG.dp.moves;
    if (better) { PROG.dp.date = date; PROG.dp.done = true; PROG.dp.moves = C0.moves; PROG.dp.stars = C0.stars; }
    if (!PROG.dp.best || C0.moves < PROG.dp.best) PROG.dp.best = C0.moves;
    C0.coins = C0.dpReward;
    progSave(); writeData(); goalsCheck();
  }
  function shareDaily() {
    const C0 = G.camp, date = C0.opts.date || dpToday();
    const text = 'Snake Fruit Rush - Daily ' + date + '\n' + '*'.repeat(C0.stars) + ' ' + C0.moves + ' moves' + (C0.helped ? '' : ' (no help)') + '\nStreak: ' + PROG.dp.streak + ' days\nCan you beat me?' + (window.SHARE_URL ? ' ' + window.SHARE_URL : '');
    const done = (msg) => { if (G) G.shareMsg = msg; };
    try {
      if (typeof window.shareText === 'function') { window.shareText(text); return; }
      if (navigator.share) { navigator.share({ text: text }).catch(() => {}); return; }
      if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(() => done('Result copied - paste it to a friend!'), () => done('Sharing is not available here.')); return; }
    } catch (e) { /* fall through */ }
    done('Sharing is not available here.');
  }
  function drawDailyWon() {
    const t = th(), C0 = G.camp, top = drawCampOverlayFrame(450);
    txt(W / 2, top + 44, 'Daily puzzle done!', 28, t.accent);
    txt(W / 2, top + 78, 'Level ' + C0.id + '  -  ' + dpToday(), 14, t.btnText, 0.5, false);
    for (let s = 0; s < 3; s++) { const x = W / 2 + (s - 1) * 56, y = top + 126; if (!uiPic(s < C0.stars ? 'star_full' : 'star_empty', x, y, 60, 56, 0xffffff, 0.55)) { starShape(x, y + 3, 26, '#000000', 0.25); starShape(x, y, 26, s < C0.stars ? '#fde047' : '#00000044'); } }
    txt(W / 2, top + 182, C0.moves + ' moves' + (C0.helped ? '' : '  -  no help'), 18, t.btnText);
    txt(W / 2, top + 212, 'Streak: ' + PROG.dp.streak + (PROG.dp.streak === 1 ? ' day' : ' days') + '   Best: ' + PROG.dp.best + ' moves', 13, t.btnText, 0.5, false);
    if (C0.dpReward) { drawCoin(W / 2 - 52, top + 244, 9); txt(W / 2 - 38, top + 244, '+' + C0.dpReward + ' coins', 16, '#fbbf24', 0); }
    else txt(W / 2, top + 244, 'Come back tomorrow for a new puzzle!', 13, t.btnText, 0.5, false);
    adBtn(W / 2, top + 296, 290, 50, 'Share result', shareDaily, 18);
    if (G.shareMsg) txt(W / 2, top + 330, G.shareMsg, 12, '#4ade80', 0.5, false);
    button(W / 2, top + 372, 290, 50, 'Home', goHome, { primary: true, size: 19 });
    drawConfetti();
  }
  // ---------- Soft background for the menu and the level map: a light centre, dark corners and a few slowly rising sparkles ----------
  let bgTex = false;
  function ensureBgTex() {
    if (bgTex || !scene) return;
    bgTex = true;
    const cv = document.createElement('canvas'); cv.width = 96; cv.height = 160;
    const cx = cv.getContext('2d'), gr = cx.createRadialGradient(48, 62, 6, 48, 82, 118);
    gr.addColorStop(0, 'rgba(255,255,255,0.13)'); gr.addColorStop(0.45, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.5)');
    cx.fillStyle = gr; cx.fillRect(0, 0, 96, 160);
    scene.textures.addCanvas('bg_vig', cv);
    const dv = document.createElement('canvas'); dv.width = 32; dv.height = 32;
    const dx = dv.getContext('2d'), dg = dx.createRadialGradient(16, 16, 0, 16, 16, 16);
    dg.addColorStop(0, 'rgba(255,255,255,0.9)'); dg.addColorStop(1, 'rgba(255,255,255,0)'); dx.fillStyle = dg; dx.fillRect(0, 0, 32, 32);
    scene.textures.addCanvas('bg_dot', dv);
  }
  function drawAmbientBg() {
    ensureBgTex();
    blitImg('bgv' + L.depth, 'bg_vig', W / 2, H / 2, W, H, 1, -2);
    if (LITE || REDUCED) return;
    for (let i = 0; i < 9; i++) {
      const sp = 0.012 + 0.012 * hh(i, 5, 1), y = H + 20 - ((anim * sp + hh(i, 5, 2) * H) % (H + 40)), x = 30 + hh(i, 5, 3) * (W - 60) + Math.sin(anim / 1800 + i) * 14;
      const a = 0.10 + 0.16 * Math.abs(Math.sin(anim / 900 + i * 2)), z = 14 + 22 * hh(i, 5, 4);
      blitImg('spk' + L.depth, 'bg_dot', x, y, z, z, a, -1.5);
    }
  }
  // ---------- Star gates: a new world opens only with enough stars (only while that world is still closed) ----------
  const GATES = { 21: 30, 41: 70, 61: 115, 81: 160 };
  const starsTotal = () => Object.keys(DATA.camp.stars).reduce((a, k) => a + (DATA.camp.stars[k] | 0), 0);
  const gateNeed = (id) => (GATES[id] && DATA.camp.unlocked <= id ? GATES[id] : 0);
  const gated = (id) => gateNeed(id) > starsTotal();
  const gateMsg = (id) => 'World ' + (Math.floor((id - 1) / 20) + 1) + ' needs ' + GATES[id] + ' stars - you have ' + starsTotal();
  function startLevel(id, showRoute, opts) {
    id = Math.min(LEVEL_COUNT, Math.max(1, id | 0));
    const daily = !!(opts && opts.daily);
    if (!daily && (id > campUnlocked() || gated(id))) return;
    const base = LV[id - 1], ad = daily ? { e: 0, bias: 0, s2: 0, s3: 0, d: 1, ready: 0, hint: false } : skAdapt(base, id);
    if (!daily) { if (!SK.cur || SK.cur.id !== id) SK.cur = { id: id, fails: 0, ms: 0 }; SK.cur.ms = 0; }
    let L = Object.assign({}, base, { F: daily ? opts.F : fruitSaved(id, base) });
    if (ad.e) L = Object.assign({}, L, { s3: Math.max(base.par, L.s3 + ad.s3), s2: Math.max(base.par + 1, L.s2 + ad.s2), d: Math.round(L.d * ad.d) });
    if (ad.hint) showRoute = true;
    const el = engineLevel(L), rt = E.makeRuntime(el), st = E.newState(rt);
    G = {
      camp: { id: id, L: L, ad: ad.e, rt: rt, st: st, ready: READY_MS + ad.ready, over: null, won: false, endT: 0, moves: 0, route: showRoute ? L.R : null, routeIdx: null, exitOpen: false, slowT: 0, shield: false, hold: false, coinMul: 1, stars: 0, coins: 0, hint: L.h || '', flash: [], iceList: [], fr: [] },
      snake: st.body.map((c) => [c % COLS, (c / COLS) | 0]), dir: st.dir, queue: [], score: 0, eaten: 0, fx: {}, combo: 0, combo_t: 0, bonus: null, power: null, gold: null,
      food: null, bombs: [], coins: 0, dailyCoins: 0, playMs: 0, adMsg: '', shareMsg: '', mode: 'classic', speed: DATA.speed
    };
    const C0 = G.camp;
    C0.opts = opts || null; C0.daily = daily; C0.expert = !!(opts && opts.expert);
    C0.hist = []; C0.paid = new Set();                       // undo history; fruit coins are paid once per fruit
    for (let i = 0; i < COLS * ROWS; i++) if (rt.ice[i]) C0.iceList.push(i);
    if (C0.route) { C0.routeIdx = new Map(); C0.route.forEach((cell, i) => C0.routeIdx.set(cell, i)); }
    rt.fruits.forEach((f, i) => C0.fr.push({ cell: f.cell, kind: FRUITS[(i + id) % FRUITS.length] }));
    popups = []; fxs = []; banner = null; prevSnake = null; acc = 0;
    adToken++; gift = null; sheetOpen = false; sheetT = 0;
    if (!daily) { DATA.camp.cur = id; writeData(); }
    useWorld(L.w);
    setState('play');
    if (!navigator.webdriver || window.__forceTips) { if (helpItems(L).some((i) => !tipsSeen.has(i.id))) { C0.help = true; togglePause(); } }   // first time a thing appears: the card opens by itself
  }
  const PORTAL_MS = 950;                            // portal-entry animation before the result screen
  const campSliding = () => !!G.camp && E.resolveDir(G.camp.rt, G.camp.st, null).forced;
  const cellOf = (i) => cellXY(i % COLS, (i / COLS) | 0);
  const campPlaying = () => G && G.camp && !G.camp.over && !G.camp.won;

  function campStep() {
    const C0 = G.camp, rt = C0.rt, st = C0.st;
    if (C0.over || C0.won) return;
    if (C0.hold) { if (!G.queue.length) return; C0.hold = false; C0.undone = false; }          // after a shield save the snake waits for a turn
    let input = null;
    if (!campSliding() && G.queue.length) input = G.queue.shift();          // on ice the player cannot steer: the turn waits in the queue
    const oldDir = st.dir, snap = { st: E.cloneState(st), eaten: G.eaten };
    const res = E.step(rt, st, input);
    if (res.status === 'fail' && C0.shield && res.reason !== 'stuck') {
      st.done = false; st.dir = oldDir; G.dir = oldDir; C0.shield = false; C0.hold = true;
      const hp = headXY(); ring(hp.x, hp.y, '#38bdf8'); burst(hp.x, hp.y, '#7dd3fc', 12);
      showBanner('SHIELD SAVED YOU!', 'now turn away', '#38bdf8', 1400);
      sfx.power(); buzz(40);
      return;
    }
    G.dir = st.dir;
    if (res.status === 'wait') return;                                      // slid safely to a stop: wait for a turn
    C0.hist.push(snap); if (C0.hist.length > 300) C0.hist.shift();
    if (res.status !== 'fail') {
      G.snake = st.body.map((c) => [c % COLS, (c / COLS) | 0]);
      C0.moves = st.moves;
      if (C0.expert && st.moves > C0.L.s3) { st.done = true; C0.over = 'moves'; C0.endT = 0; sfx.over(); buzz(50); shake(140, 0.006); return; }   // Expert: 3-star moves is the limit
      if (C0.slowT > 0) C0.slowT--;
      trailPuff();
      if (rt.ice[st.body[0]]) { const p = headXY(); if (fxs.length < MAX_FX - 6) fxs.push({ k: 0, x: p.x, y: p.y, vx: (Math.random() - 0.5) * 0.03, vy: (Math.random() - 0.5) * 0.03, r: 2.4, color: '#ffffff', life: 380, max: 380 }); }
    }
    res.events.forEach((e) => {
      const p = cellOf(e.cell);
      if (e.t === 'fruit') {
        G.eaten++;
        if (!C0.paid.has(e.cell)) { C0.paid.add(e.cell); addCoins(COIN_FRUIT * C0.coinMul); cdAdd('cfruit', 1); }
        const fk = (C0.fr.find((f) => f.cell === e.cell) || {}).kind, fc = FRUIT_COL[fk] || th().accent;
        burst(p.x, p.y, fc, 10); burst(p.x, p.y, '#ffffff', 4); ring(p.x, p.y, fc);
        popup('+1', th().accent, 30);
        sfx.eat(Math.min(G.eaten - 1, 9)); buzz(12);                       // the pop gets higher with every fruit of the level
      } else if (e.t === 'key') {
        ring(p.x, p.y, '#facc15'); burst(p.x, p.y, '#facc15', 8); popup('KEY!', '#facc15', 30);
        sfx.key(); buzz(20);
      } else if (e.t === 'door') {
        const q = cellOf(e.cell); ring(q.x, q.y, '#facc15'); burst(q.x, q.y, '#fde68a', 10); C0.flash.push({ cell: e.cell, t: 600 });
        sfx.door();
      } else if (e.t === 'switch') {
        const q = cellOf(e.cell); ring(q.x, q.y, GATE_COLS[e.gate % GATE_COLS.length]);
        const gc = rt.gates[e.gate].cells[0], gp = cellOf(gc);
        ring(gp.x, gp.y, GATE_COLS[e.gate % GATE_COLS.length]); C0.flash.push({ cell: gc, t: 600 });
        popup(e.open ? 'GATE OPEN' : 'GATE CLOSED', GATE_COLS[e.gate % GATE_COLS.length], 30);
        sfx.sw(e.open); buzz(20);
      } else if (e.t === 'portal') {
        const a = cellOf(e.from), b = cellOf(e.to);
        ring(a.x, a.y, '#c084fc'); ring(b.x, b.y, '#38bdf8'); burst(b.x, b.y, '#a5f3fc', 8);
        sfx.portal(); buzz(15);
      }
    });
    if (!C0.exitOpen && E.exitReady(rt, st)) {
      C0.exitOpen = true; C0.exitT = anim;
      const ep = cellOf(rt.exit);
      ring(ep.x, ep.y, '#4ade80'); burst(ep.x, ep.y, '#bbf7d0', 12);
      showBanner('EXIT OPEN!', 'reach the glowing exit', '#4ade80', 1100);
      sfx.yum();
    }
    if (res.status === 'win') {
      C0.won = true; C0.endT = 0;
      if (!C0.daily) adsMeta.levels++;                   // counts toward the next interstitial (shown only after the result screen)
      const moves = st.moves, L = C0.L;
      C0.stars = moves <= L.s3 ? 3 : moves <= L.s2 ? 2 : 1;
      C0.fails = SK.cur && SK.cur.id === C0.id ? SK.cur.fails : 0;
      if (C0.daily) {
        dpComplete(C0);
      } else {
        const prev = DATA.camp.stars[C0.id] | 0;
        if (C0.stars > prev) DATA.camp.stars[C0.id] = C0.stars;
        cdAdd('clevel', 1); cdAdd('cstars', C0.stars); if (C0.stars === 3) cdAdd('c3', 1); if (SK.cur && SK.cur.id === C0.id && SK.cur.fails === 0) cdAdd('cfirst', 1);
        if (SK.cur && SK.cur.id === C0.id) skRecord(C0.id, SK.cur.fails, moves, LV[C0.id - 1].par, SK.cur.ms, C0.L.d);
        SK.cur = null;
        C0.coins = (5 + 5 * C0.stars) * C0.coinMul * (C0.expert ? 3 : 1);
        addCoins(C0.coins);
        if (C0.id < LEVEL_COUNT) { DATA.camp.cur = C0.id + 1; if (DATA.camp.unlocked < C0.id + 1) DATA.camp.unlocked = C0.id + 1; }
        else DATA.camp.cur = C0.id;
        if (!C0.helped) PROG.nohelp++;
        if (skHas(C0.L, 'I')) PROG.ice++;
        if (C0.expert) PROG.expert[C0.id] = 1;
        progSave();
        writeData();
        goalsCheck();
      }
      const hp = headXY(); burst(hp.x, hp.y, 'rand', 16); ring(hp.x, hp.y, '#fde047');
      sfx.win(); buzz(40);
    } else if (res.status === 'fail') {
      C0.over = res.reason; C0.endT = 0;
      skFail(C0.id, res.reason);
      if (res.reason === 'trap') { G.boom = [res.cell % COLS, (res.cell / COLS) | 0]; sfx.boom(); buzz(80); shake(300, 0.014); }
      else {
        sfx.over(); buzz(50); shake(140, 0.006);
        const hp = headXY(); ring(hp.x, hp.y, '#f87171'); burst(hp.x, hp.y, '#f87171', 10);
        if (res.reason === 'door') { const nx = st.body[0] % COLS + st.dir[0], ny = ((st.body[0] / COLS) | 0) + st.dir[1], ni = ny * COLS + nx; C0.over = rt.gateAt[ni] >= 0 ? 'gate' : 'door'; }
      }
    }
  }
  function campTick(delta) {                         // called every frame while state is 'play' and G.camp exists
    const C0 = G.camp;
    C0.flash.forEach((f) => { f.t -= delta; });
    C0.flash = C0.flash.filter((f) => f.t > 0);
    if (C0.over || C0.won) {
      C0.endT += delta;
      if (C0.won && C0.endT > PORTAL_MS) setState('won');
      else if (C0.over && C0.endT > (C0.over === 'trap' ? 900 : 650)) setState('over');
      return;
    }
    if (C0.ready > 0) { C0.ready -= delta; acc = 0; if (C0.ready <= 0) { C0.ready = 0; sfx.click(); } return; }
    if (SK.cur) SK.cur.ms += delta;
    acc += stepClock(delta);
    let delay = stepDelay(), guardSteps = 0;
    while (state === 'play' && !C0.over && !C0.won && acc >= delay && guardSteps++ < 2) {
      acc -= delay;
      prevSnake = G.snake.map((s) => [s[0], s[1]]);
      campStep();
    }
    if (acc > delay) acc = delay;
    G.playMs += delta;
  }
  function usePower(k) {
    if (state !== 'play' || !campPlaying() || G.camp.ready > 0) return;
    if (G.camp.expert) { popup('No power-ups in Expert', '#ff5a5f', 34); sfx.err(); return; }
    const C0 = G.camp, rt = C0.rt, st = C0.st, p = PW[k];
    C0.helped = true;
    if ((k === 'shield' && C0.shield) || (k === 'coin2' && C0.coinMul > 1) || (k === 'slow' && C0.slowT > 0)) return;
    const hx = st.body[0] % COLS, hy = (st.body[0] / COLS) | 0, near = [];
    if (k === 'sweep') {
      for (let i = 0; i < COLS * ROWS; i++) if (rt.bomb[i] && Math.max(Math.abs((i % COLS) - hx), Math.abs(((i / COLS) | 0) - hy)) <= 7) near.push(i);
      if (!near.length) { popup('No bombs near', '#ff5a5f', 34); sfx.err(); return; }
    }
    if (!DATA.pw[k]) {
      if (DATA.coins < p.cost) { popup('Need ' + p.cost + ' coins', '#ff5a5f', 34); sfx.err(); return; }
      DATA.coins -= p.cost; DATA.pw[k]++;
    }
    DATA.pw[k]--; writeData();
    const hp = headXY();
    if (k === 'slow') C0.slowT = 28;
    else if (k === 'shield') C0.shield = true;
    else if (k === 'coin2') C0.coinMul = 2;
    else near.forEach((i) => { rt.bomb[i] = 0; const q = cellOf(i); burst(q.x, q.y, '#fbbf24', 8); ring(q.x, q.y, '#fbbf24'); });
    ring(hp.x, hp.y, '#38bdf8'); popup(p.name + '!', th().accent, 34);
    sfx.power(); buzz(25);
  }
  let shopMsg = null;
  function buyPower(k) {
    const p = PW[k];
    if (DATA.coins < p.cost) { shopMsg = { s: 'Need ' + (p.cost - DATA.coins) + ' more coins for ' + p.name + '!', until: anim + 2400, bad: true }; sfx.err(); buzz(40); return; }
    DATA.coins -= p.cost; DATA.pw[k] = Math.min(99, DATA.pw[k] + 1); writeData(); sfx.coin();
    shopMsg = { s: p.name + ' added!', until: anim + 1500 };
  }
  function drawShop(top) {
    const t = th();
    if (shopMsg && anim < shopMsg.until) {
      txt(W / 2, top + 96, shopMsg.s, 15, shopMsg.bad ? '#f87171' : '#4ade80');
    } else {
      const ct = coinText(DATA.coins) + ' coins', ox = ct.length * 4.4;
      drawCoin(W / 2 - ox - 12, top + 96, 10);
      txt(W / 2 - ox + 2, top + 96, ct, 15, t.accent, 0);
    }
    PW_KEYS.forEach((k, i) => {
      const p = PW[k], w = 212, h = 112, cx = W / 2 + (i % 2 ? 110 : -110), cy = top + 176 + Math.floor(i / 2) * 124, can = DATA.coins >= p.cost;
      rrect(cx - w / 2, cy - h / 2 + 3, w, h, 15, shade(t.panel, -0.3));
      rrect(cx - w / 2, cy - h / 2, w, h, 15, t.panel);
      if (!UIOK.pw_slow) dot(cx - w / 2 + 30, cy - 22, 22, t.board1);
      drawPwIcon(k, cx - w / 2 + 30, cy - 21, false, UIOK.pw_slow ? 46 : 40);
      txt(cx - w / 2 + 62, cy - 30, p.name, 16, t.btnText, 0);
      wrapText(p.desc, 18).forEach((l, j) => txt(cx - w / 2 + 62, cy - 8 + j * 15, l, 11, t.btnText, 0, false));
      txt(cx - w / 2 + 12, cy + 38, 'You have ' + (DATA.pw[k] | 0), 12, t.btnText, 0, false);
      rrect(cx + w / 2 - 74, cy + 24, 64, 28, 14, can ? t.accent : shade(t.panel, -0.25));
      drawCoin(cx + w / 2 - 60, cy + 38, 6.5);
      txt(cx + w / 2 - 50, cy + 38, String(p.cost), 13, can ? '#1b1b1b' : t.btnText, 0);
      buttons.push({ x: cx - w / 2, y: cy - h / 2, w: w, h: h, fn: () => buyPower(k) });
    });
    if (!(DATA.coins < 90 && adCoinsButton(top + 404))) {
      txt(W / 2, top + 396, 'Tap a power-up to buy it. Use them inside levels.', 12.5, t.text, 0.5, false);
      txt(W / 2, top + 420, 'In a level you can also tap its button to buy and use it.', 12.5, t.text, 0.5, false);
    }
  }
  function toggleVibe() { DATA.vibe = !DATA.vibe; writeData(); if (DATA.vibe) buzz(30); }
  function toggleTap() { DATA.tapSteer = !DATA.tapSteer; writeData(); tone(660, 0.08, 'triangle', 0.2); }
  function campRetry() { startLevel(G.camp.id, !!G.camp.route, G.camp.opts); }          // a hint bought with an ad stays for the rest of that level
  function campNextLevel() {
    if (G.camp.id < LEVEL_COUNT && gated(G.camp.id + 1)) { const m = gateMsg(G.camp.id + 1); leaveToLevels(); lvMsg = { s: m, until: anim + 5000 }; return; }
    const next = G.camp.id < LEVEL_COUNT ? () => startLevel(G.camp.id + 1) : openLevels;
    maybeInter('level', next);                       // an ad only if one is due AND ready; otherwise straight on
  }
  function leaveToLevels() { saveGame(); openLevels(); }
  function goHome() { setState('menu'); }

  // ---------- Level select + campaign drawing ----------
  function starShape(x, y, r, color, alpha) {
    const pts = [];
    for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * 0.45 : r, ang = -Math.PI / 2 + i * Math.PI / 5; pts.push({ x: x + Math.cos(ang) * rr, y: y + Math.sin(ang) * rr }); }
    g.fillStyle(C(color), alpha === undefined ? 1 : alpha);
    g.fillPoints(pts, true);
  }
  function lockIcon(x, y, s, color) {
    if (uiPic('lock', x, y, 24 * s, 24 * s, 0xffffff, 0.55)) return;
    g.lineStyle(3 * s, C(color), 1);
    g.beginPath(); g.arc(x, y - 4 * s, 6 * s, Math.PI, 0); g.strokePath();
    rrect(x - 9 * s, y - 4 * s, 18 * s, 14 * s, 4 * s, color);
    dot(x, y + 2 * s, 2 * s, '#00000066');
  }
  function worldStars(w) { let n = 0; for (let i = w * 20 + 1; i <= w * 20 + 20; i++) n += DATA.camp.stars[i] | 0; return n; }
  function worldDone(w) { let n = 0; for (let i = w * 20 + 1; i <= w * 20 + 20; i++) if (DATA.camp.stars[i]) n++; return n; }
  function drawLevels() {
    drawAmbientBg();
    const t = th(), cp = DATA.camp, w = lvPage, W0 = WORLDS[Math.min(w, WORLDS.length - 1)], un = campUnlocked(), soon = w >= WORLDS.length;
    // header
    if (slice3('btn_pill', BX + 48, 42, 102, 46, C(t.panel))) uiPic('glyph_back', BX + 22, 42, 22, 20, 0xffffff, 0.55);
    else { rrect(BX, 22, 96, 40, 20, t.panel); line(BX + 22, 42, BX + 32, 35, t.btnText, 3.4); line(BX + 22, 42, BX + 32, 49, t.btnText, 3.4); }
    txt(BX + 40, 42, 'Home', 17, t.btnText, 0);
    buttons.push({ x: BX - 6, y: 16, w: 108, h: 52, fn: goHome });
    txt(W / 2 + 20, 42, 'Levels', 32, t.accent);
    const cw = 52 + coinText(DATA.coins).length * 11;
    if (!slice3('hud_pill', W - BX - cw / 2, 42, cw + 8, 46, C(t.panel))) rrect(W - BX - cw, 22, cw, 40, 20, t.panel, 0.8);
    drawCoin(W - BX - cw + 22, 42, 11);
    txt(W - BX - cw + 40, 42, coinText(DATA.coins), 16, t.accent, 0);
    // world card
    const cy = 96, ch = 118;
    const cardPic = slice9('panel_card', W / 2, cy + ch / 2 + 2, BW + 10, ch + 12, C(t.panel), 30, 0.4);
    if (!cardPic) { rrect(BX, cy + 5, BW, ch, 24, shade(t.panel, -0.35)); rrect(BX, cy, BW, ch, 24, t.panel); }
    else useLayer(2);                                                 // what sits on the picture card is drawn one layer higher
    // world art strip
    const wl = W0.wall;
    for (let i = 0; i < 9; i++) { const bx = BX + 78 + i * 36, by = cy + ch - 22; rrect(bx, by + 1, 24, 18, 5, wl.edge); rrect(bx, by, 24, 14, 5, wl.base); rrect(bx + 2, by + 1.5, 20, 4, 2, wl.top, 0.9); }
    txt(W / 2, cy + 22, 'WORLD ' + (w + 1) + ' of 6', 12, t.text, 0.5, false);
    txt(W / 2, cy + 52, soon ? 'Coming Soon' : W0.name, soon ? 30 : 36, t.accent);
    const gw = !soon && gated(w * 20 + 1);
    txt(W / 2, cy + 82, soon ? 'A brand new world is on the way' : gw ? 'Needs ' + GATES[w * 20 + 1] + ' stars  (you have ' + starsTotal() + ')' : W0.sub, 13, gw ? '#fbbf24' : t.text, 0.5, false);
    // arrows
    [[-1, BX + 28], [1, BX + BW - 28]].forEach((a) => {
      const can = w + a[0] >= 0 && w + a[0] <= WORLDS.length;
      dot(a[1], cy + 52, 20, can ? shade(t.panel, 0.25) : shade(t.panel, -0.2), can ? 1 : 0.6);
      if (can) {
        line(a[1] - a[0] * 4, cy + 42, a[1] + a[0] * 5, cy + 52, t.btnText, 3.6);
        line(a[1] + a[0] * 5, cy + 52, a[1] - a[0] * 4, cy + 62, t.btnText, 3.6);
        buttons.push({ x: a[1] - 26, y: cy + 26, w: 52, h: 52, fn: () => { lvPage = w + a[0]; useWorld(Math.min(lvPage, WORLDS.length - 1)); sfx.click(); } });
      }
    });
    if (cardPic) useLayer(0);
    // dots
    for (let i = 0; i <= WORLDS.length; i++) {
      const x = W / 2 + (i - 2.5) * 22;
      dot(x, cy + ch + 20, i === w ? 6 : 4, i === w ? t.accent : t.panel);
      buttons.push({ x: x - 11, y: cy + ch + 8, w: 22, h: 24, fn: () => { lvPage = i; useWorld(Math.min(i, WORLDS.length - 1)); } });
    }
    if (soon) {                                      // World 6: locked, not playable
      const a = anim / 1000, cx = W / 2, my = 440;
      rrect(BX, 262, BW, 420, 28, shade(t.panel, -0.35)); rrect(BX, 256, BW, 420, 28, t.panel);
      for (let i = 0; i < 18; i++) { const sx = BX + 20 + hh(i, 6, 1) * (BW - 40), sy = 272 + hh(i, 6, 2) * 390; dot(sx, sy, 1.2 + 1.3 * hh(i, 6, 3), '#ffffff', 0.25 + 0.55 * Math.abs(Math.sin(a * 1.4 + i * 2))); }
      dot(cx, my, 78 + 4 * Math.sin(a * 2), t.accent, 0.12); dot(cx, my, 58, t.accent, 0.2);
      g.lineStyle(3, C(t.accent), 0.8); g.beginPath(); g.arc(cx, my, 46, a, a + 4.2); g.strokePath();
      g.lineStyle(2, C('#ffffff'), 0.6); g.beginPath(); g.arc(cx, my, 36, -a * 1.4, -a * 1.4 + 3); g.strokePath();
      lockIcon(cx, my - 2, 1.9, t.btnText);
      txt(cx, 548, 'WORLD 6', 34, t.accent);
      txt(cx, 586, 'COMING SOON', 22, t.btnText);
      txt(cx, 622, 'New puzzles, new mechanics.', 14, t.text, 0.5, false);
      button(W / 2, 722, 320, 54, 'Locked', null, { disabled: true, size: 20 });
      return;
    }
    // level grid
    const tile = 76, gap = 13, x0 = (W - (5 * tile + 4 * gap)) / 2, y0 = 262;
    for (let k = 0; k < 20; k++) {
      const id = w * 20 + k + 1, col = k % 5, row = (k / 5) | 0, x = x0 + col * (tile + gap), y = y0 + row * (tile + 12);
      const open = id <= un && !gated(id), st = cp.stars[id] | 0, cur = id === cp.cur && open;
      const face = !open ? shade(t.panel, -0.3) : st ? t.accent : shade(t.panel, 0.18);
      const tpic = UIOK.tile_open && UIOK.tile_locked;
      if (tpic) {
        if (cur) uiPic('tile_open', x + tile / 2, y + tile / 2 + 2, tile + 22, tile + 16, 0xffffff, 0.40, 0.55 + 0.45 * Math.sin(anim / 160));
        uiPic(open ? 'tile_open' : 'tile_locked', x + tile / 2, y + tile / 2 + 2, tile + 10, tile + 4, C(face), 0.45);
      } else {
      rrect(x, y + 5, tile, tile, 18, shade(face, -0.38), open ? 1 : 0.7);
      rrect(x, y, tile, tile, 18, face, open ? 1 : 0.85);
      }
      if (cur && !tpic) { g.lineStyle(3.5, C('#ffffff'), 0.55 + 0.45 * Math.sin(anim / 160)); g.strokeRoundedRect(x - 3, y - 3, tile + 6, tile + 6, 21); }
      if (open) {
        txt(x + tile / 2, y + (st ? 29 : 38), String(id), 28, st ? '#1b1b1b' : t.btnText);
        if (st) for (let s = 0; s < 3; s++) { if (!uiPic(s < st ? 'star_full' : 'star_empty', x + tile / 2 + (s - 1) * 19, y + 59, 19, 18, 0xffffff, 0.55)) starShape(x + tile / 2 + (s - 1) * 19, y + 59, 8.5, s < st ? '#b45309' : '#00000033'); }
        if (PROG.expert[id]) { if (!uiPic('star_full', x + tile - 12, y + 13, 16, 15, 0x9b6cff, 0.55)) starShape(x + tile - 12, y + 13, 7, '#7c3aed'); }                      // purple star = cleared in Expert mode
      } else {
        lockIcon(x + tile / 2, y + tile / 2 - 2, 1.15, shade(t.text, -0.35));
      }
      buttons.push({ x: x, y: y, w: tile, h: tile + 6, fn: () => { if (open) startLevel(id); else { lvMsg = { s: gated(id) ? gateMsg(id) : 'Clear level ' + (un) + ' to unlock this one', until: anim + 3200 }; sfx.err(); } } });
    }
    // footer
    const first = w * 20 + 1, canPlay = first <= un && !gated(first);
    let target = Math.min(un, w * 20 + 20);
    for (let i = first; i <= w * 20 + 20 && i <= un; i++) { if (!cp.stars[i]) { target = i; break; } }
    txt(W / 2, 636, worldDone(w) + ' / 20 cleared   ' + worldStars(w) + ' / 60 stars', 14, t.text, 0.5, false);
    if (canPlay) button(W / 2, 688, 320, 62, 'Play level ' + target, () => startLevel(target), { primary: true, size: 24 });
    else button(W / 2, 688, 320, 62, 'Locked', null, { disabled: true, size: 22 });
    if (lvMsg && anim < lvMsg.until) txt(W / 2, 744, lvMsg.s, 14, '#ff5a5f', 0.5, false);
    else txt(W / 2, 744, canPlay ? 'Clear a level to unlock the next one' : 'Finish world ' + w + ' to unlock', 13, t.text, 0.5, false);
  }

  // ----- tiles -----
  function floorDecor(gr, w, c, r, id) {
    const v = hh(c, r, id * 3 + w);
    if (v > 0.07) return;
    const x = BX + c * CELL + CELL / 2 + (hh(c, r, 5) - 0.5) * 8, y = BY + r * CELL + CELL / 2 + (hh(c, r, 6) - 0.5) * 8;
    const fill = (px, py, rad, col, al) => { gr.fillStyle(C(col), al); gr.fillCircle(px, py, rad); };
    if (w === 0) { [[0, -2.4], [2.4, 0], [0, 2.4], [-2.4, 0]].forEach((o) => fill(x + o[0], y + o[1], 1.7, '#ffffff', 0.85)); fill(x, y, 1.6, '#ffd23f', 1); }
    else if (w === 1) { fill(x, y, 2.2, '#c99a5b', 0.7); fill(x + 4, y + 3, 1.3, '#c99a5b', 0.7); }
    else if (w === 2) { gr.lineStyle(1.2, C('#ffffff'), 0.85); gr.lineBetween(x - 3.5, y, x + 3.5, y); gr.lineBetween(x, y - 3.5, x, y + 3.5); gr.lineBetween(x - 2.5, y - 2.5, x + 2.5, y + 2.5); gr.lineBetween(x + 2.5, y - 2.5, x - 2.5, y + 2.5); }
    else if (w === 3) { fill(x, y, 2.4, '#ff7a1a', 0.45); fill(x, y, 1.2, '#ffd166', 0.8); }
    else { gr.fillStyle(C('#a5b4fc'), 0.7); gr.fillCircle(x, y, 1.1); gr.fillStyle(C('#a5b4fc'), 0.25); gr.fillCircle(x, y, 2.6); }
  }
  function wallTile(gr, w, c, r, id) {
    const P = WORLDS[w].wall, x = BX + c * CELL, y = BY + r * CELL, v = hh(c, r, id), v2 = hh(c, r, id + 11);
    gr.fillStyle(0x000000, 0.28); gr.fillRoundedRect(x + 0.5, y + 3, CELL, CELL, 6);
    gr.fillStyle(C(P.edge), 1); gr.fillRoundedRect(x, y + 1.5, CELL, CELL - 1.5, 6);
    gr.fillStyle(C(P.base), 1); gr.fillRoundedRect(x, y, CELL, CELL - 3, 6);
    gr.fillStyle(C(P.top), 0.95); gr.fillRoundedRect(x + 2, y + 1.4, CELL - 4, 5.2, 3);
    if (w === 0) {                                              // hedge: leafy bumps
      gr.fillStyle(C(P.top), 0.9); gr.fillCircle(x + 5 + v * 3, y + 11, 3.2); gr.fillCircle(x + 15 - v2 * 3, y + 9, 3);
      gr.fillStyle(C('#1b5a28'), 0.5); gr.fillCircle(x + 11, y + 14.5, 2.6);
      if (v > 0.8) { gr.fillStyle(C('#ff6b81'), 1); gr.fillCircle(x + 7, y + 12, 1.7); }
    } else if (w === 1) {                                       // sandstone bricks
      gr.lineStyle(1.2, C(P.edge), 0.55); gr.lineBetween(x + 2, y + 10.5, x + CELL - 2, y + 10.5); gr.lineBetween(x + 6 + v * 8, y + 10.5, x + 6 + v * 8, y + CELL - 4);
      gr.fillStyle(C(P.edge), 0.35); gr.fillCircle(x + 5 + v2 * 10, y + 7.5, 1);
    } else if (w === 2) {                                       // ice crystal
      gr.lineStyle(1.6, C('#ffffff'), 0.85); gr.lineBetween(x + 5, y + 16, x + 11, y + 8); gr.lineBetween(x + 12, y + 17, x + 16, y + 11);
      gr.fillStyle(C('#ffffff'), 0.9); gr.fillCircle(x + 16.5, y + 5.5, 1.3);
    } else if (w === 3) {                                       // basalt with glowing cracks
      gr.lineStyle(1.8, C('#ff7a1a'), 0.95); gr.beginPath(); gr.moveTo(x + 4, y + 8 + v * 4); gr.lineTo(x + 10, y + 12); gr.lineTo(x + 14, y + 9); gr.lineTo(x + 19, y + 14 + v2 * 2); gr.strokePath();
      gr.lineStyle(0.8, C('#ffd166'), 0.9); gr.beginPath(); gr.moveTo(x + 10, y + 12); gr.lineTo(x + 14, y + 9); gr.strokePath();
    } else {                                                    // night stone with a glowing rune
      if (v > 0.45) { gr.lineStyle(1.5, C('#7cf5ff'), 0.9); gr.strokeCircle(x + CELL / 2, y + 10.5, 3.4); gr.fillStyle(C('#7cf5ff'), 0.9); gr.fillCircle(x + CELL / 2, y + 10.5, 1);
      } else { gr.fillStyle(C('#c4b5fd'), 0.8); gr.fillCircle(x + 5 + v2 * 12, y + 8, 1.2); }
    }
  }
  function iceTile(gr, c, r, id) {
    const x = BX + c * CELL, y = BY + r * CELL;
    gr.fillStyle(0x7dd3fc, 0.35); gr.fillRoundedRect(x + 0.5, y + 0.5, CELL - 1, CELL - 1, 4);
    gr.fillStyle(0xffffff, 0.6); gr.fillRoundedRect(x + 1.5, y + 1.5, CELL - 3, CELL - 3, 4);
    gr.lineStyle(1.2, 0x38bdf8, 0.9); gr.strokeRoundedRect(x + 1, y + 1, CELL - 2, CELL - 2, 4);
    gr.lineStyle(1.6, 0xffffff, 0.95); gr.lineBetween(x + 4, y + 8, x + 9, y + 3.5); gr.lineBetween(x + 7, y + 12, x + 15, y + 4.5);
  }
  // The board (floor, walls, ice) never changes during a level, so it is drawn once into a texture instead of being redrawn every frame.
  let boardRT = null;
  let boardKeyBaked = '';
  function bakeBoard() {
    try {
      if (!boardRT) { boardRT = scene.add.renderTexture(0, 0, W * ZOOM, H * ZOOM); boardRT.setOrigin(0, 0); boardRT.setScale(1 / ZOOM); boardRT.setDepth(boardG.depth); }
      boardRT.clear(); boardRT.setVisible(true);
      boardG.setScale(ZOOM); boardG.setVisible(true);
      boardRT.draw(boardG, 0, 0);
      boardG.setScale(1); boardG.setVisible(false);
      return true;
    } catch (e) { boardG.setScale(1); boardG.setVisible(true); if (boardRT) boardRT.setVisible(false); }
  }
  const END_FLOOR = { Midnight: 'night', Garden: 'garden', Ocean: 'ice', Sunset: 'volcano' };   // Candy keeps its flat light board
  function drawEndBoard(t) {                           // endless mode: the same glossy floor, baked once per theme
    const fl = END_FLOOR[t.name];
    if (!fl || state === 'menu' || state === 'levels' || !UIOK['floor_' + fl + '_a'] || !scene.textures.exists('ui_floor_' + fl + '_a')) return false;
    const openWalls = !!(G && modeOf().wall), key = 'end|' + fl + '|' + DATA.bg + '|' + openWalls + '|' + t.name;
    if (boardRT && boardKeyBaked === key) { boardRT.setVisible(true); boardG.setVisible(false); return true; }
    boardG.clear(); boardG.setScale(1);
    boardG.fillStyle(C(openWalls ? POWERS.wall.color : t.panel), 1);
    boardG.fillRoundedRect(BX - 7, BY - 7, BW + 14, BH + 14, 12);
    boardG.fillStyle(C(t.board1), 1);
    boardG.fillRect(BX, BY, BW, BH);
    drawPattern(boardG, DATA.bg, BX, BY, COLS, ROWS, CELL);
    if (!bakeBoard()) return false;
    boardG.clear();
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) bakePic('floor_' + fl + ((c + r) % 2 ? '_b' : '_a'), c, r);
    boardKeyBaked = key;
    return true;
  }
  function drawCampBoardFull() {
    const C0 = G.camp, rt = C0.rt, w = C0.L.w, t = th();
    const bkey = C0.id + '|' + w + '|' + JSON.stringify(t);
    if (boardRT && boardKeyBaked === bkey) { boardRT.setVisible(true); boardG.setVisible(false); return; }   // retry / restart: the baked board is reused
    boardG.clear();
    boardG.setVisible(true);
    boardG.fillStyle(C(shade(t.panel, -0.25)), 1);
    boardG.fillRoundedRect(BX - 8, BY - 5, BW + 16, BH + 17, 14);
    boardG.fillStyle(C(t.panel), 1);
    boardG.fillRoundedRect(BX - 8, BY - 8, BW + 16, BH + 16, 14);
    boardG.fillStyle(C(t.board1), 1);
    boardG.fillRect(BX, BY, BW, BH);
    drawPattern(boardG, WORLDS[w].pattern, BX, BY, COLS, ROWS, CELL);
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      const i = r * COLS + c;
      if (rt.wall[i]) continue;
      if (rt.ice[i]) iceTile(boardG, c, r, C0.id); else floorDecor(boardG, w, c, r, C0.id);
    }
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) if (rt.wall[r * COLS + c]) { if (bakePic('wall_' + WALL_KEYS[w], c, r)) wallGloss(c, r); else wallTile(boardG, w, c, r, C0.id); }
    if (bakeBoard()) { boardKeyBaked = bkey; boardG.clear(); } else boardKeyBaked = '';   // clear frees the ~46k recorded commands
  }

  // The board is recorded and baked in six small steps (one per frame) so a level start never freezes the game for one long frame.
  let boardJob = null;
  function drawCampBoard() {
    const C0 = G.camp, rt = C0.rt, w = C0.L.w, t = th();
    const bkey = C0.id + '|' + w + '|' + JSON.stringify(t);
    if (boardRT && boardKeyBaked === bkey) { boardRT.setVisible(true); boardG.setVisible(false); return; }   // retry / restart: the baked board is reused
    if (boardJob && boardJob.key === bkey && boardJob.C0 === C0) return;
    boardKeyBaked = '';
    try {
      if (!boardRT) { boardRT = scene.add.renderTexture(0, 0, W * ZOOM, H * ZOOM); boardRT.setOrigin(0, 0); boardRT.setScale(1 / ZOOM); boardRT.setDepth(boardG.depth); }
      boardRT.clear(); boardRT.setVisible(true);
    } catch (e) { boardJob = null; drawCampBoardFull(); return; }
    boardJob = { key: bkey, C0: C0, rt: rt, w: w, t: t, stage: 0 };
    boardStep();
  }
  const WALL_KEYS = ['garden', 'desert', 'ice', 'lava', 'night'], WALL_FLOOR = ['garden', 'desert', 'ice', 'volcano', 'night'];
  let bakeIm = null;
  const FLOOR_A = 0.42;                                // the floor pictures are laid softly over the board colour, so fruit and snake stay easy to see
  function bakePic(name, c, r) {                       // one picture of the sheet-8 tiles, stamped into the baked board
    if (!UIOK[name] || !scene.textures.exists('ui_' + name)) return false;
    try {
      if (!bakeIm) bakeIm = scene.make.image({ x: 0, y: 0, key: 'ui_' + name, add: false }).setOrigin(0, 0);
      bakeIm.setTexture('ui_' + name); bakeIm.setDisplaySize(CELL * ZOOM, CELL * ZOOM * 1.03); bakeIm.setAlpha(name.indexOf('floor_') === 0 ? FLOOR_A : 1);
      boardRT.draw(bakeIm, (BX + c * CELL) * ZOOM, (BY + r * CELL) * ZOOM);
      return true;
    } catch (e) { return false; }
  }
  let SNK_IMG = false;
  function snakeSegPic(pts, i, n, col) {                // one tinted picture per body piece (the cheap, fixed-colour skins)
    const ft = n - 1 - i, tint = C(col), p = pts[i];
    let name = 'snake_body', d = 22.5, ang = 0;
    if (ft === 0) { name = 'snake_tail_tip'; d = 15; const q = pts[i - 1]; ang = Math.atan2(p.y - q.y, p.x - q.x) * 57.2958 + 180; }
    else if (ft === 1) { name = 'snake_tail_2'; d = 16; }
    else if (ft === 2) { name = 'snake_tail_1'; d = 19; }
    const u = UIOK[name];
    blitImg('snkB', uiKey(name, tint), p.x, p.y, d * u.w / u.h, d, 1, 10.5, ang);
  }
  function snakeHeadPic(x, y, dx, dy, k, col) {
    const u = UIOK.snake_head;
    if (!u) return false;
    const h = 26 * k, w = h * u.w / u.h, sh = (w - h) / 2;   // the round part of the picture sits on the head position, the snout points ahead
    blitImg('snkH', uiKey('snake_head', C(col)), x + dx * sh, y + dy * sh, w, h, 1, 10.6, Math.atan2(dy, dx) * 57.2958);
    return true;
  }
  function floorGloss(c, r) {                          // every floor tile gets a tiny bevel + soft shine, so the floor looks glossy too
    const x = BX + c * CELL, y = BY + r * CELL;
    boardG.fillStyle(0xffffff, 0.16); boardG.fillRect(x, y, CELL, 1.6); boardG.fillRect(x, y, 1.6, CELL);
    boardG.fillStyle(0x000000, 0.12); boardG.fillRect(x, y + CELL - 1.6, CELL, 1.6); boardG.fillRect(x + CELL - 1.6, y, 1.6, CELL);
    boardG.fillStyle(0xffffff, 0.09); boardG.fillRoundedRect(x + 3, y + 3, CELL * 0.55, CELL * 0.3, 3);
  }
  function wallGloss(c, r) {                           // glassy shine on top of the block picture
    const x = BX + c * CELL, y = BY + r * CELL;
    boardG.fillStyle(0xffffff, 0.34); boardG.fillRoundedRect(x + 3, y + 2.2, CELL - 9, 3.6, 1.8);
    boardG.fillStyle(0xffffff, 0.75); boardG.fillCircle(x + 4.6, y + 4.2, 1.5);
    boardG.fillStyle(0x000000, 0.18); boardG.fillRoundedRect(x + 2, y + CELL - 5, CELL - 4, 3, 1.5);
  }
  function boardStep() {
    const J = boardJob;
    if (!J) return;
    if (!(G && G.camp && G.camp === J.C0 && state !== 'menu' && state !== 'levels')) { boardJob = null; return; }   // left the level: start over next time
    const rt = J.rt, w = J.w, t = J.t, C0 = J.C0, s = J.stage++;
    boardG.clear();
    if (s === 0) {
      boardG.fillStyle(C(shade(t.panel, -0.25)), 1);
      boardG.fillRoundedRect(BX - 8, BY - 5, BW + 16, BH + 17, 14);
      boardG.fillStyle(C(t.panel), 1);
      boardG.fillRoundedRect(BX - 8, BY - 8, BW + 16, BH + 16, 14);
      boardG.fillStyle(C(t.board1), 1);
      boardG.fillRect(BX, BY, BW, BH);
      drawPattern(boardG, WORLDS[w].pattern, BX, BY, COLS, ROWS, CELL);
      for (let k = 0; k < 6; k++) { boardG.lineStyle(2, 0x000000, 0.06 * (6 - k)); boardG.strokeRect(BX + 1 + k * 2, BY + 1 + k * 2, BW - 2 - k * 4, BH - 2 - k * 4); }   // soft inner shadow: the board looks deeper
    } else if (s <= 3) {
      for (let r = (s - 1) * 9; r < Math.min(ROWS, s * 9); r++) for (let c = 0; c < COLS; c++) {
        const i = r * COLS + c;
        if (rt.wall[i]) continue;
        if (rt.ice[i]) { if (!bakePic('ice_floor', c, r)) iceTile(boardG, c, r, C0.id); } else if (!bakePic('floor_' + WALL_FLOOR[w] + '_' + ((c + r) % 2 ? 'b' : 'a'), c, r)) { floorDecor(boardG, w, c, r, C0.id); floorGloss(c, r); }
      }
    } else {
      for (let r = (s - 4) * 13; r < Math.min(ROWS, (s - 3) * 13); r++) for (let c = 0; c < COLS; c++) if (rt.wall[r * COLS + c]) wallTile(boardG, w, c, r, C0.id);
    }
    try {
      boardG.setScale(ZOOM); boardG.setVisible(true);
      boardRT.draw(boardG, 0, 0);
    } catch (e) { boardG.setScale(1); boardJob = null; drawCampBoardFull(); return; }
    boardG.setScale(1); boardG.setVisible(false); boardG.clear();
    if (s >= 5) { boardKeyBaked = J.key; boardJob = null; }
  }

  // ----- dynamic items -----
  function drawKey(x, y, s) {
    const bob = Math.sin(anim / 220) * 1.5;
    y += bob;
    dot(x, y, 12 * s, '#facc15', 0.22);
    line(x - 1 * s, y + 1 * s, x + 8 * s, y + 1 * s, '#b45309', 3.6 * s);
    line(x + 4 * s, y + 1 * s, x + 4 * s, y + 5.5 * s, '#b45309', 2.6 * s); line(x + 7.5 * s, y + 1 * s, x + 7.5 * s, y + 4.5 * s, '#b45309', 2.6 * s);
    line(x - 1 * s, y + 1 * s, x + 8 * s, y + 1 * s, '#facc15', 2 * s);
    dot(x - 5 * s, y + 1 * s, 5.2 * s, '#b45309'); dot(x - 5 * s, y + 1 * s, 4 * s, '#fde047'); dot(x - 5 * s, y + 1 * s, 1.8 * s, '#b45309');
  }
  function drawDoor(x, y, open, flash) {
    if (open) {
      rrect(x - 10, y - 10, 20, 20, 5, '#facc15', 0.18 + (flash ? 0.25 : 0));
      g.lineStyle(1.6, C('#facc15'), 0.75); g.strokeRoundedRect(x - 10, y - 10, 20, 20, 5);
      return;
    }
    rrect(x - 11, y - 11 + 2, 22, 22, 5, '#5b3410');
    rrect(x - 11, y - 11, 22, 22, 5, '#a8672a');
    rrect(x - 9, y - 9, 18, 5, 3, '#d99a55', 0.8);
    line(x - 9, y + 2, x + 9, y + 2, '#6b3d12', 1.4);
    dot(x, y + 1, 4.6, '#fde047'); dot(x, y + 0.2, 1.6, '#7c4a10'); rrect(x - 0.9, y + 0.5, 1.8, 4, 0.6, '#7c4a10');
  }
  function drawGate(x, y, open, col, flash) {
    if (open) {
      rrect(x - 10, y - 10, 20, 3, 1.5, col, 0.55); rrect(x - 10, y + 7, 20, 3, 1.5, col, 0.55);
      g.fillStyle(C(col), 0.25); g.fillRoundedRect(x - 10, y - 10, 20, 20, 5);
      return;
    }
    rrect(x - 11, y - 11, 22, 22, 5, '#1f2937');
    for (let i = 0; i < 4; i++) { rrect(x - 8.5 + i * 5.6, y - 10, 3, 20, 1.5, col); rrect(x - 8.5 + i * 5.6, y - 10, 1.2, 20, 0.6, '#ffffff', 0.45); }
    rrect(x - 11, y - 3, 22, 3, 1.5, col, 0.9);
    if (flash) dot(x, y, 14, col, 0.3);
  }
  function drawSwitch(x, y, col, on) {
    if (itemPic('swP', 'switch', x, y + (on ? 1.5 : 0), on ? 15 : 18, 1, 0, C(shade(col, 0.25)))) return;
    dot(x, y, 12, col, on ? 0.12 : 0.28);
    rrect(x - 10, y - 8, 20, 17, 6, '#111827', 0.8);
    rrect(x - 10, y - 10 + (on ? 3 : 0), 20, 17 - (on ? 3 : 0), 6, '#475569');
    dot(x, y - 1 + (on ? 2 : 0), 6.2, on ? shade(col, -0.35) : col);
    if (!on) dot(x - 1.8, y - 3, 1.8, '#ffffff', 0.7);
  }
  function drawPortal(x, y, col, flip) {
    if (itemPic('portP' + (flip ? 1 : 0), flip ? 'portal_purple' : 'portal_blue', x, y, 21.5 + Math.sin(anim / 240) * 0.6)) return;
    const a = anim / 400 * (flip ? -1 : 1);
    dot(x, y, 15, col, 0.18 + 0.08 * Math.sin(anim / 240));
    dot(x, y, 11.5, '#0b1020');
    for (let i = 0; i < 3; i++) {
      g.lineStyle(2.4 - i * 0.4, C(i === 1 ? '#ffffff' : col), 0.95);
      g.beginPath(); g.arc(x, y, 10.5 - i * 3, a + i * 2.1, a + i * 2.1 + 3.2); g.strokePath();
    }
    dot(x, y, 2, '#ffffff', 0.9);
  }
  const PORTAL_COLS = [['#4ade80', '#bef264', '#14532d'], ['#fbbf24', '#fde68a', '#78350f'], ['#67e8f9', '#e0f2fe', '#0c4a6e'], ['#fb923c', '#fde047', '#7f1d1d'], ['#c084fc', '#f0abfc', '#3b0764']];
  function drawExitTile(x, y, open) {
    if (UIOK.exit_open && UIOK.exit_locked) {
      const C0 = G.camp, a = anim / 1000;
      let near = 0;
      if (open && !C0.won) { const hp = headXY(), d = Math.hypot(hp.x - x, hp.y - y) / CELL; near = d < 4 ? 1 - d / 4 : 0; }
      const ent = C0.won ? Math.min(1, C0.endT / PORTAL_MS) : 0;
      itemPic('exitP', open ? 'exit_open' : 'exit_locked', x, y, open ? 21 + Math.sin(a * 4) * 0.9 + near * 3 + ent * 14 : 21);
      return;
    }
    const C0 = G.camp, pc = PORTAL_COLS[C0.L.w] || PORTAL_COLS[0], a = anim / 1000;
    let near = 0;
    if (open && !C0.won) { const hp = headXY(), d = Math.hypot(hp.x - x, hp.y - y) / CELL; near = d < 4 ? 1 - d / 4 : 0; }
    const ent = C0.won ? Math.min(1, C0.endT / PORTAL_MS) : 0;
    if (!open) {                                                  // locked: dim, slow, broken ring
      dot(x, y, 14, '#0b0b12', 0.7);
      g.lineStyle(2, C(pc[0]), 0.4);
      for (let i = 0; i < 3; i++) { const s0 = a * 0.5 + i * 2.1; g.beginPath(); g.arc(x, y, 11.5, s0, s0 + 1.3); g.strokePath(); }
      dot(x, y, 3.2, pc[0], 0.35);
      return;
    }
    const k = 1 + 0.07 * Math.sin(a * 4) + near * 0.18 + ent * 0.5, sp = 1 + near * 1.2 + ent * 5, wake = C0.exitT === undefined ? 1 : Math.min(1, (anim - C0.exitT) / 450);
    const sc = (0.4 + 0.6 * wake) * k;                            // opens up smoothly right after the last fruit
    dot(x, y, 20 * sc, pc[0], 0.16 + 0.1 * near + 0.2 * ent);
    dot(x, y, 15.5 * sc, pc[2], 0.95);
    for (let i = 0; i < 3; i++) {                                 // swirling arcs
      g.lineStyle(2.6 - i * 0.5, C(i === 1 ? pc[1] : pc[0]), 0.95);
      const s0 = a * sp * (i % 2 ? -2.2 : 2.6) + i * 2.1, r = (13.5 - i * 3.6) * sc;
      g.beginPath(); g.arc(x, y, r, s0, s0 + 3.4 - i * 0.5); g.strokePath();
    }
    dot(x, y, 4.2 * sc, pc[1], 0.95); dot(x, y, 2 * sc, '#ffffff', 0.95);
    if (!LITE) for (let i = 0; i < 4; i++) {                      // sparks pulled into the centre
      const t2 = (a * (0.8 + near) + i / 4) % 1, an = i * 1.57 + a, r = 22 * (1 - t2);
      dot(x + Math.cos(an) * r, y + Math.sin(an) * r, 1.5, pc[1], 0.9 * t2);
    }
    if (ent > 0.55) dot(x, y, 26 * (ent - 0.55) * 2.2, '#ffffff', 0.55 * (1 - ent) + 0.15);   // soft flash as the snake goes in
  }
  function drawAmbient(w) {
    const a = anim / 1000;
    for (let i = 0; i < 14; i++) {
      const s = hh(i, w, 7), s2 = hh(i, w, 9);
      let x = BX + s * BW, y = BY + s2 * BH;
      if (w === 0) { x += Math.sin(a * 0.8 + i) * 10; y += Math.cos(a * 0.6 + i * 2) * 8; dot(x, y, 1.7, '#fffbd0', 0.45 + 0.3 * Math.sin(a * 2 + i)); }
      else if (w === 1) { x = BX + ((s * BW + a * 20 * (0.5 + s2)) % BW); y += Math.sin(a + i) * 4; dot(x, y, 1.4, '#fff1c9', 0.55); }
      else if (w === 2) { y = BY + ((s2 * BH + a * 24 * (0.6 + s)) % BH); x += Math.sin(a * 1.3 + i) * 8; dot(x, y, 1.9, '#ffffff', 0.85); }
      else if (w === 3) { y = BY + BH - ((s2 * BH + a * 28 * (0.5 + s)) % BH); x += Math.sin(a * 1.6 + i) * 6; dot(x, y, 2, '#ff9a2e', 0.5); dot(x, y, 1, '#fff2a0', 0.9); }
      else dot(x, y, 1.2 + 1.2 * s, '#c7d2fe', 0.2 + 0.55 * Math.abs(Math.sin(a * 1.5 + i * 3)));
    }
  }
  function wrapText(s, n) {
    const words = s.split(' '), out = [];
    let cur = '';
    words.forEach((w) => { if ((cur + ' ' + w).trim().length > n) { out.push(cur); cur = w; } else cur = (cur + ' ' + w).trim(); });
    if (cur) out.push(cur);
    return out;
  }
  function objective(C0) {
    const rt = C0.rt, n = rt.fruits.length;
    const parts = [];
    if (rt.keys.length) parts.push('take the key');
    if (rt.switches.length) parts.push('press the switch');
    parts.push(n === 1 ? 'eat the fruit' : 'eat all ' + n + ' fruit');
    parts.push('reach the exit');
    const s = parts.join(', then ');
    return s.charAt(0).toUpperCase() + s.slice(1);
  }
  function drawCampHud() {
    const C0 = G.camp, t = th(), rt = C0.rt, st = C0.st;
    txt(BX, 22, (C0.expert ? 'EXPERT  -  ' : C0.daily ? 'DAILY  -  ' : '') + WORLDS[C0.L.w].name.toUpperCase() + '  -  WORLD ' + (C0.L.w + 1), 11, C0.expert || C0.daily ? t.accent : t.text, 0, false);
    txt(BX, 50, 'Level ' + C0.id, 28, t.accent, 0);
    txt(BX + BW, 22, 'Moves', 12, t.text, 1, false);
    txt(BX + BW, 50, C0.expert ? C0.moves + '/' + C0.L.s3 : String(C0.moves), 28, C0.moves > C0.L.s2 || (C0.expert && C0.moves >= C0.L.s3 - 3) ? '#ff5a5f' : t.text, 1);
    // tracker: fruit, keys, exit
    const items = rt.fruits.length + rt.keys.length + 1, pit = Math.min(24, 240 / items), x0 = 284 - (items - 1) * pit / 2;   // sits between the level title and the moves counter
    let k = 0;
    rt.fruits.forEach((f, i) => {
      const x = x0 + k * pit, eaten = (st.fruitMask >> i) & 1;
      dot(x, 40, 10.5, t.panel); if (eaten) { dot(x, 40, 10.5, '#4ade80', 0.35); drawFruit(C0.fr[i].kind, x, 42, 0.62); } else { dot(x, 40, 7, t.bg, 0.55); }
      k++;
    });
    rt.keys.forEach((kk, i) => { const x = x0 + k * pit, has = (st.keyMask >> i) & 1; dot(x, 40, 10.5, t.panel); if (has) drawKey(x, 40, 0.62); else dot(x, 40, 5, '#facc15', 0.3); k++; });
    { const x = x0 + k * pit, open = C0.exitOpen; dot(x, 40, 10.5, open ? '#22c55e' : t.panel); g.fillStyle(C(open ? '#14532d' : t.text), open ? 1 : 0.5); g.fillTriangle(x - 3, 34, x - 3, 46, x + 5, 40); }
    const tip = C0.hint && G.playMs < 9000 && !C0.over && !C0.won;
    txt(W / 2, 80, tip ? C0.hint : objective(C0), 12.5, tip ? t.accent : t.text, 0.5, false);
  }
  function drawPwIcon(k, x, y, on, sz) {
    const pn = { slow: 'pw_slow', shield: 'pw_shield', sweep: 'pw_defuse', coin2: 'pw_double' }[k];
    if (pn && uiPic(pn, x, y, sz || 40, sz || 40, 0xffffff, 0.55)) return;
    if (k === 'slow') drawPower('slow', x, y, 0.95);
    else if (k === 'coin2') drawPower('double', x, y, 0.95);
    else if (k === 'shield') {
      g.fillStyle(C(on ? '#ffffff' : '#38bdf8'), 1);
      g.fillPoints([{ x: x - 10, y: y - 10 }, { x: x + 10, y: y - 10 }, { x: x + 10, y: y + 1 }, { x: x, y: y + 12 }, { x: x - 10, y: y + 1 }], true);
      g.fillStyle(C('#0c4a6e'), 0.55); g.fillPoints([{ x: x - 5, y: y - 6 }, { x: x + 5, y: y - 6 }, { x: x + 5, y: y }, { x: x, y: y + 6 }, { x: x - 5, y: y }], true);
    } else { drawBomb(x, y + 1, 0.8); line(x - 8, y + 8, x + 8, y - 8, '#4ade80', 3); }
  }
  function glyphTex(name, draw) {                    // small white pictures made once on a canvas (vibrate, tap)
    if (!scene.textures.exists('ui_' + name)) {
      const cv = document.createElement('canvas'); cv.width = cv.height = 96;
      const x = cv.getContext('2d'); x.lineCap = 'round'; x.lineJoin = 'round';
      const both = (fn) => { x.strokeStyle = '#0b1426'; x.lineWidth = 11; x.fillStyle = '#0b1426'; fn(true); x.strokeStyle = '#ffffff'; x.lineWidth = 5; x.fillStyle = '#ffffff'; fn(false); };
      draw(x, both);
      scene.textures.addCanvas('ui_' + name, cv); UIOK[name] = { w: 96, h: 96 };
    }
  }
  function toggleBtn(cx, cy, kind, on, label, fn) {
    const t = th();
    if (UIOK.btn_round) {
      glyphTex('g_vibe', (x, both) => {
        both(() => { x.beginPath(); x.roundRect(34, 20, 28, 56, 7); x.stroke(); });
        x.fillStyle = '#ffffff'; x.beginPath(); x.roundRect(34, 20, 28, 56, 7); x.fill();
        both(() => { x.beginPath(); x.arc(48, 48, 26, 2.5, 3.78); x.stroke(); x.beginPath(); x.arc(48, 48, 26, -0.64, 0.64); x.stroke(); });
      });
      glyphTex('g_tap', (x, both) => {
        both(() => { x.beginPath(); x.arc(48, 48, 10, 0, 6.3); x.fill(); x.beginPath(); x.arc(48, 48, 22, 0, 6.3); x.stroke(); });
        x.fillStyle = '#ffffff'; x.beginPath(); x.arc(48, 48, 10, 0, 6.3); x.fill();
      });
      uiPic('btn_round', cx, cy + 1, 56, 56, on ? C(t.accent) : C(shade(t.panel, -0.1)), 0.5);
      const gn = kind === 'sound' ? (DATA.sound ? 'glyph_sound_on' : 'glyph_sound_off') : kind === 'vibe' ? 'g_vibe' : 'g_tap';
      if (uiPic(gn, cx, cy + 1, 30, 30, 0xffffff, 0.6)) {
        txt(cx, cy + 42, label + (on ? ': On' : ': Off'), 11.5, t.btnText, 0.5, false);
        buttons.push({ x: cx - 40, y: cy - 30, w: 80, h: 80, fn: fn });
        return;
      }
    }
    dot(cx, cy + 3, 25, shade(t.panel, -0.3)); dot(cx, cy, 25, on ? t.accent : shade(t.panel, -0.15));
    g.fillStyle(0x000000, 0); drawIcon(kind, cx, cy, on ? '#1b1b1b' : t.btnText);
    txt(cx, cy + 40, label + (on ? '' : ' off'), 12, t.btnText, 0.5, false);
    buttons.push({ x: cx - 40, y: cy - 30, w: 80, h: 80, fn: fn });
  }
  function drawCampBottom() {
    const C0 = G.camp, t = th();
    PW_KEYS.forEach((k, i) => {
      const x = BX + i * 58, y = 688, n = DATA.pw[k] | 0, cx = x + 26;
      const on = (k === 'slow' && C0.slowT > 0) || (k === 'shield' && C0.shield) || (k === 'coin2' && C0.coinMul > 1);
      if (UIOK.btn_square) {
        slice9('btn_square', cx, y + 38, 54, 76, on ? 0x0ea5e9 : C(t.panel), 16, 0.45);
        uiPic({ slow: 'pw_slow', shield: 'pw_shield', sweep: 'pw_defuse', coin2: 'pw_double' }[k], cx, y + 19, 32, 32, 0xffffff, 0.55);
        useLayer(2);
        txt(cx, y + 43, PW[k].name, 9, t.btnText, 0.5, false);
        if (n > 0) txt(cx, y + 60, 'x' + n, 13, t.accent);
        else { uiPic('icon_coins', cx - 11, y + 60, 13, 12, 0xffffff, 12); txt(cx + 8, y + 60, String(PW[k].cost), 12, DATA.coins >= PW[k].cost ? t.accent : t.btnText); }
        useLayer(0);
      } else {
        blit('pw', stamp('st_pw_' + k + (on ? 1 : 0) + '_' + C0.L.w, () => { rrect(6, 9, 52, 52, 13, shade(t.panel, -0.3)); rrect(6, 6, 52, 52, 13, on ? '#0ea5e9' : t.panel); drawPwIcon(k, 32, 29, on); }, 64), x + 26, y + 26, 1, 5);
        useLayer(2);
        if (n > 0) { dot(x + 44, y + 8, 9.5, t.accent); txt(x + 44, y + 8, String(n), 12, '#1b1b1b'); }
        else { drawCoin(x + 14, y + 43, 5.5); txt(x + 22, y + 43, String(PW[k].cost), 11, DATA.coins >= PW[k].cost ? t.accent : t.btnText, 0); }
        useLayer(0);
      }
      buttons.push({ x: x - 3, y: y - 3, w: 58, h: 80, fn: () => usePower(k) });
    });
    txt(BX + 240, 712, '3 stars: ' + C0.L.s3 + ' moves', 11.5, t.text, 0, false);
    txt(BX + 240, 736, '2 stars: ' + C0.L.s2 + ' moves', 11.5, t.text, 0, false);
    const qx = BX + BW - 78, qy = 726;                          // "?" = what is in this level
    if (!uiPic('icon_help', qx, qy, 34, 34)) { dot(qx, qy, 15, t.panel); txt(qx, qy + 1, '?', 20, t.btnText); }
    buttons.push({ x: qx - 20, y: qy - 24, w: 40, h: 48, fn: openHelp });
    const px = BX + BW - 52, py = 700;
    if (!(uiPic('btn_square', px + 26, py + 26, 58, 56, C(t.panel), 0.45) && uiPic('glyph_pause', px + 26, py + 26, 26, 26, 0xffffff, 0.55))) {
      rrect(px, py, 52, 52, 12, t.panel);
      line(px + 19, py + 15, px + 19, py + 37, t.btnText, 6);
      line(px + 33, py + 15, px + 33, py + 37, t.btnText, 6);
    }
    buttons.push({ x: px - 6, y: py - 6, w: 64, h: 64, fn: togglePause });
  }

  // ---------- Pre-drawn stamps: fruit, bombs, keys, gates, doors and power-up buttons are drawn once into small textures and then only
  // positioned as images, instead of re-recording hundreds of Graphics commands every frame. Same pictures, far less work per frame. ----------
  const stampKeep = [], pools = {};
  // ---------- Picture assets (star coin, egg, wheel frame): embedded in the page, decoded once; until they are ready the drawn versions are used ----------
  const IMGOK = {}, UIOK = {};
  let imgStarted = false;
  function loadImages() {
    const src = window.SFR_IMG || {};
    Object.keys(src).forEach((k) => {
      const im = new Image();
      im.onload = () => { try { if (!scene.textures.exists('img_' + k)) scene.textures.addImage('img_' + k, im); IMGOK[k] = true; } catch (e) { /* keep the drawn version */ } };
      im.src = src[k];
    });
    const ui = window.SFR_UI || {};                                   // the glossy UI kit
    Object.keys(ui).forEach((k) => {
      const im = new Image();
      im.onload = () => { try { if (!scene.textures.exists('ui_' + k)) scene.textures.addImage('ui_' + k, im); UIOK[k] = { w: im.width, h: im.height }; } catch (e) { /* keep the drawn version */ } };
      im.src = ui[k];
    });
  }
  function blitImg(pool, key, x, y, w, h, alpha, depth, angle, tint, frame) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key, frame).setDepth(depth); im._k = key; im._f = frame; P.a.push(im); }
    P.n++;
    if (im._k !== key || im._f !== frame) { im.setTexture(key, frame); im._k = key; im._f = frame; }
    if (tint === undefined) { if (im._t !== undefined) { im.clearTint(); im._t = undefined; } } else if (im._t !== tint) { im.setTint(tint); im._t = tint; }
    if (im.depth !== depth) im.setDepth(depth);
    im.setPosition(x, y); im.setDisplaySize(w, h); im.setAlpha(alpha === undefined ? 1 : alpha); im.setAngle(angle || 0); im.setVisible(true);
  }
  // UI kit helpers: one picture, a 3-part stretchy button, a 9-part stretchy panel. A `tint` colours the grey-white pictures with the world
  // theme: the coloured copy is made once on a small canvas (works the same on WebGL and Canvas) and then reused.
  const UIFR = {};
  function uiKey(name, tint) {
    if (tint === undefined || tint === 0xffffff) return 'ui_' + name;
    const key = 'ui_' + name + '_' + tint.toString(16);
    if (!scene.textures.exists(key)) {
      const src = scene.textures.get('ui_' + name).getSourceImage(), cv = document.createElement('canvas');
      cv.width = src.width; cv.height = src.height;
      const cx = cv.getContext('2d');
      cx.drawImage(src, 0, 0);
      cx.globalCompositeOperation = 'multiply'; cx.fillStyle = '#' + ('000000' + tint.toString(16)).slice(-6); cx.fillRect(0, 0, cv.width, cv.height);
      cx.globalCompositeOperation = 'destination-in'; cx.drawImage(src, 0, 0);
      scene.textures.addCanvas(key, cv);
    }
    return key;
  }
  function uiPic(name, x, y, w, h, tint, dOff, alpha, angle) {
    if (!UIOK[name]) return false;
    const key = uiKey(name, tint);
    blitImg('u_' + key + L.depth, key, x, y, w, h, alpha === undefined ? 1 : alpha, L.depth + (dOff === undefined ? 0.55 : dOff), angle || 0, undefined, '__BASE');   // '__BASE' = the whole picture, even after a 3/9-slice added frames to the same texture
    return true;
  }
  function slice3(name, cx, cy, w, h, tint, dOff) {
    const u = UIOK[name];
    if (!u) return false;
    const key = uiKey(name, tint);
    if (!UIFR[key]) { const tx = scene.textures.get(key), cap = Math.round(u.h / 2); tx.add('l', 0, 0, 0, cap, u.h); tx.add('m', 0, cap, 0, u.w - 2 * cap, u.h); tx.add('r', 0, u.w - cap, 0, cap, u.h); UIFR[key] = 1; }
    const d = L.depth + (dOff === undefined ? 0.45 : dOff), dc = Math.min(h / 2, w / 2), pn = 's_' + key + L.depth;
    blitImg(pn + 'l', key, cx - w / 2 + dc / 2, cy, dc, h, 1, d, 0, undefined, 'l');
    if (w - 2 * dc > 0.5) blitImg(pn + 'm', key, cx, cy, w - 2 * dc, h, 1, d, 0, undefined, 'm');
    blitImg(pn + 'r', key, cx + w / 2 - dc / 2, cy, dc, h, 1, d, 0, undefined, 'r');
    return true;
  }
  function slice9(name, cx, cy, w, h, tint, dc, dOff) {
    const u = UIOK[name];
    if (!u) return false;
    const key = uiKey(name, tint);
    if (!UIFR[key]) {
      const tx = scene.textures.get(key), k = Math.round(Math.min(u.w, u.h) * 0.32), mw = u.w - 2 * k, mh = u.h - 2 * k;
      tx.add('tl', 0, 0, 0, k, k); tx.add('t', 0, k, 0, mw, k); tx.add('tr', 0, u.w - k, 0, k, k);
      tx.add('l', 0, 0, k, k, mh); tx.add('c', 0, k, k, mw, mh); tx.add('r', 0, u.w - k, k, k, mh);
      tx.add('bl', 0, 0, u.h - k, k, k); tx.add('b', 0, k, u.h - k, mw, k); tx.add('br', 0, u.w - k, u.h - k, k, k);
      UIFR[key] = 1;
    }
    const d = L.depth + (dOff === undefined ? 0.4 : dOff), x0 = cx - w / 2, y0 = cy - h / 2, mw = w - 2 * dc, mh = h - 2 * dc, pn = 'n_' + key + L.depth;
    [['tl', x0 + dc / 2, y0 + dc / 2, dc, dc], ['t', cx, y0 + dc / 2, mw, dc], ['tr', x0 + w - dc / 2, y0 + dc / 2, dc, dc],
     ['l', x0 + dc / 2, cy, dc, mh], ['c', cx, cy, mw, mh], ['r', x0 + w - dc / 2, cy, dc, mh],
     ['bl', x0 + dc / 2, y0 + h - dc / 2, dc, dc], ['b', cx, y0 + h - dc / 2, mw, dc], ['br', x0 + w - dc / 2, y0 + h - dc / 2, dc, dc]]
      .forEach((q) => blitImg(pn + q[0], key, q[1], q[2], q[3], q[4], 1, d, 0, undefined, q[0]));
    return true;
  }
  // ---------- Gifts: egg picture + opening animation ----------
  function eggPic(x, y, w, h, alpha, angle) {
    if (IMGOK.egg) blitImg('egg' + L.depth, 'img_egg', x, y, w, h, alpha, L.depth + 0.5, angle);
    else { g.fillStyle(0xfef3c7, alpha); g.fillEllipse(x, y + 2, w * 0.86, h * 0.98); }
  }
  function drawEggArea(x, y, p) {
    const eg = gift && gift.kind === 'egg';
    if (!eg) { eggPic(x, y + Math.sin(anim / 400) * 2, 72, 92, 1, Math.sin(anim / 700) * 3); return; }
    const ms = gift.t, open = p >= 0.7, k = open ? Math.min(1, (p - 0.7) / 0.3) : 0, rise = Math.min(1, p / 0.7);
    dot(x, y, 30 + 30 * rise, '#fde047', (0.10 + 0.30 * rise) * (open ? 1 - k * 0.7 : 1));
    if (!open) {
      const amp = 2 + 9 * Math.pow(rise, 1.6), sc = 1 + 0.08 * Math.sin(ms / 90) * rise;
      eggPic(x + Math.sin(ms / 38) * amp, y, 72 * sc, 92 * sc, 1, Math.sin(ms / 38) * (3 + 10 * rise));
      if (p > 0.45) {                                                  // cracks grow across the egg
        const cc = Math.min(1, (p - 0.45) / 0.25), pts = [[-16, -8], [-7, 2], [0, -6], [9, 4], [17, -4]], n = Math.max(2, Math.ceil(pts.length * cc));
        g.lineStyle(2.2, 0xffffff, 0.95); g.beginPath(); g.moveTo(x + pts[0][0], y + pts[0][1]);
        for (let i = 1; i < n; i++) g.lineTo(x + pts[i][0], y + pts[i][1]);
        g.strokePath();
      }
    } else {
      if (k < 0.55) eggPic(x, y, 72 * (1 + 0.5 * k), 92 * (1 + 0.5 * k), 1 - k / 0.55, 0);
      g.lineStyle(3, 0xffffff, Math.max(0, 1 - k * 1.3)); g.strokeCircle(x, y, 16 + 64 * k);
      for (let i = 0; i < 18 && k < 1; i++) {                           // sparkles flying out
        const an = i * 0.349 + hh(i, 4, 1) * 0.4, d = 12 + (30 + 52 * hh(i, 4, 2)) * k;
        dot(x + Math.cos(an) * d, y + Math.sin(an) * d + 14 * k * k, 2 + 2.2 * hh(i, 4, 3), CONFETTI[i % CONFETTI.length], 1 - k * 0.7);
      }
      const pk = k < 0.3 ? 0 : Math.min(1, (k - 0.3) / 0.7), ob = 1 + 1.70158 * Math.pow(pk - 1, 3) + 1.70158 * Math.pow(pk - 1, 2), sc = pk * ob;   // pops out with a bounce
      if (pk > 0) {
        if (gift.skin) miniSnake(SKIN_BY_ID[gift.skin], x, y);
        else if (gift.pw) { drawPwIcon(gift.pw, x, y, false); }
        else drawCoin(x, y, 26 * Math.max(0.2, sc));
      }
    }
  }
  function stamp(key, fn, size) {
    if (!scene.textures.exists(key)) {
      const S = size || 44, rt = scene.make.renderTexture({ width: S * ZOOM, height: S * ZOOM }, false), tg = scene.make.graphics({ add: false }), pg = g;
      g = tg;
      try { fn(S / 2, S / 2); } finally { g = pg; }
      tg.setScale(ZOOM); rt.draw(tg, 0, 0); rt.saveTexture(key); tg.destroy(); stampKeep.push(rt);
    }
    return key;
  }
  function blit(pool, key, x, y, alpha, depth) {
    const P = pools[pool] || (pools[pool] = { a: [], n: 0 });
    let im = P.a[P.n];
    if (!im) { im = scene.add.image(0, 0, key).setScale(1 / ZOOM).setDepth(depth); im._k = key; P.a.push(im); }
    P.n++;
    if (im._k !== key) { im.setTexture(key); im._k = key; }
    im.setPosition(x, y); im.setAlpha(alpha === undefined ? 1 : alpha); im.setVisible(true);
  }
  function poolsBegin() {
    if (!imgStarted) { imgStarted = true; loadImages(); }
    for (const k in pools) pools[k].n = 0;
  }
  function poolsEnd() { for (const k in pools) { const P = pools[k]; for (let i = P.n; i < P.a.length; i++) if (P.a[i]._vis !== false) { P.a[i].setVisible(false); } } }
  function withStillClock(fn) { const a0 = anim; anim = 0; try { fn(); } finally { anim = a0; } }
  const bombSt = (flick) => ['st_bomb_' + (flick ? 1 : 0), (cx, cy) => {
    const k = 0.82;
    line(cx + 4 * k, cy - 6 * k, cx + 8 * k, cy - 11 * k, '#a16207', 2.2 * k);
    dot(cx, cy + k, 8.5 * k, '#1f2937'); dot(cx - 2.8 * k, cy - 1.8 * k, 2.4 * k, '#6b7280'); rrect(cx + 1.5 * k, cy - 8.5 * k, 5 * k, 4 * k, k, '#374151');
    dot(cx + 8.5 * k, cy - 11.5 * k, (flick ? 3.2 : 2.4) * k, flick ? '#fbbf24' : '#f97316');
  }];
  function stampBomb(x, y) {
    const a = anim / 60, flick = Math.sin(a * 1.7) > 0;
    blit('bombGlow', stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 10, '#ef4444', 1)), x, y, 0.18 + 0.12 * Math.sin(a * 0.35), 4);
    if (!itemPic('bombP', 'bomb', x, y + 0.5, 20.5)) blit('bomb', stamp(...bombSt(flick)), x, y, 1, 5);
  }
  const fruitSt = (kind) => ['st_fr_' + kind, (cx, cy) => drawFruit(kind, cx, cy, 0.84)];
  const keySt = () => ['st_key', (cx, cy) => withStillClock(() => drawKey(cx, cy, 0.84))];
  const doorSt = (open, flash) => ['st_door_' + (open ? 1 : 0) + (flash ? 1 : 0), (cx, cy) => drawDoor(cx, cy, open, flash)];
  const gateSt = (open, col, flash) => ['st_gate_' + col + (open ? 1 : 0) + (flash ? 1 : 0), (cx, cy) => drawGate(cx, cy, open, col, flash)];
  function itemPic(pool, name, x, y, h, alpha, angle, tint) {   // sheet-7 pictures: always smaller than the cell, so they never touch a wall
    const u = UIOK[name];
    if (!u) return false;
    const key = uiKey(name, tint);
    blitImg(pool, key, x, y, h * u.w / u.h, h, alpha === undefined ? 1 : alpha, 5, angle || 0);
    return true;
  }
  const stampFruit = (kind, x, y) => { if (!itemPic('fruitP', 'fruit_' + kind, x, y, 20.5)) blit('fruit', stamp(...fruitSt(kind)), x, y, 1, 5); };
  const stampKey = (x, y) => { const yy = y + Math.sin(anim / 220) * 1.5; if (!itemPic('keyP', 'key', x, yy, 20.5, 1, Math.sin(anim / 500) * 6)) blit('key', stamp(...keySt()), x, yy, 1, 5); };
  const stampDoor = (x, y, open, flash) => { if (!itemPic('doorP', 'door', x, y, open ? 16 : 20, open ? 0.3 : 1)) blit('door', stamp(...doorSt(open, flash)), x, y, 1, 5); };
  const stampGate = (x, y, open, col, flash) => { if (!itemPic('gateP', 'gate', x, y, 20, open ? 0.25 : 1, 0, C(shade(col, 0.25)))) blit('gate', stamp(...gateSt(open, col, flash)), x, y, 1, 5); };
  // The stamps are made one per frame while the menu / level map is on screen, so starting a level does not have to build them.
  let warmQ = null;
  function warmStep() {
    if (state !== 'menu' && state !== 'levels') return;
    if (!warmQ) {
      warmQ = [];
      FRUITS.forEach((k) => warmQ.push(() => stamp(...fruitSt(k))));
      [true, false].forEach((f) => warmQ.push(() => stamp(...bombSt(f))));
      warmQ.push(() => stamp('st_bomb_glow', (cx, cy) => dot(cx, cy + 1, 10, '#ef4444', 1)));
      warmQ.push(() => stamp(...keySt()));
      [[0, 0], [1, 0], [0, 1], [1, 1]].forEach((v) => warmQ.push(() => stamp(...doorSt(!!v[0], !!v[1]))));
      GATE_COLS.forEach((col) => [[0, 0], [1, 0], [0, 1], [1, 1]].forEach((v) => warmQ.push(() => stamp(...gateSt(!!v[0], col, !!v[1])))));
    }
    if (warmQ.length) warmQ.shift()();
  }
  function drawCampGame() {
    const C0 = G.camp, rt = C0.rt, st = C0.st, a = anim / 60, w = C0.L.w;
    drawCampHud();
    drawCampBottom();
    if (!LITE && !REDUCED) drawAmbient(w);
    // sparkles on the ice
    for (let n = 0; n < C0.iceList.length && !LITE && !REDUCED; n++) {
      if ((n * 7 + Math.floor(anim / 380)) % 11) continue;
      const i = C0.iceList[n], p = cellOf(i), s = 0.5 + 0.5 * Math.sin(anim / 120 + n);
      line(p.x - 3 * s - 1, p.y, p.x + 3 * s + 1, p.y, '#ffffff', 1.4); line(p.x, p.y - 3 * s - 1, p.x, p.y + 3 * s + 1, '#ffffff', 1.4);
    }
    if (C0.route) {                                   // hint: a trail of dots along the way to the exit
      let hi = C0.routeIdx.get(st.body[0]);
      if (hi === undefined && C0.hintMax) { let bd = 1e9; const hx = st.body[0] % COLS, hy = (st.body[0] / COLS) | 0; C0.route.forEach((rc, ri) => { const d = Math.abs(rc % COLS - hx) + Math.abs(((rc / COLS) | 0) - hy); if (d < bd) { bd = d; hi = ri; } }); }
      const from = hi === undefined ? 0 : hi + 1, pulse = anim / 170, upto = Math.min(C0.route.length, from + (C0.hintMax || 9999));
      for (let i = from; i < upto; i += LITE ? 2 : 1) { const p = cellOf(C0.route[i]); dot(p.x, p.y, 3, '#ffffff', 0.3 + 0.3 * Math.sin(pulse - i * 0.55)); }
    }
    drawExitTile(cellOf(rt.exit).x, cellOf(rt.exit).y, C0.exitOpen);
    rt.portalTo.forEach((to, i) => { if (to >= 0) { const p = cellOf(i), cols = ['#c084fc', '#38bdf8']; drawPortal(p.x, p.y, cols[(i < to) ? 0 : 1], i < to); } });
    rt.switches.forEach((s) => { const p = cellOf(s.cell); drawSwitch(p.x, p.y, GATE_COLS[s.gateIdx % GATE_COLS.length], E.gateOpen(rt, st, s.gateIdx)); });
    rt.gates.forEach((gt, gi) => gt.cells.forEach((c) => { const p = cellOf(c); stampGate(p.x, p.y, E.gateOpen(rt, st, gi), GATE_COLS[gi % GATE_COLS.length], C0.flash.some((f) => f.cell === c)); }));
    rt.doors.forEach((d) => { const p = cellOf(d.cell); stampDoor(p.x, p.y, E.doorOpen(rt, st, d), C0.flash.some((f) => f.cell === d.cell)); });
    rt.keys.forEach((k, i) => { if (!((st.keyMask >> i) & 1)) { const p = cellOf(k.cell); stampKey(p.x, p.y); } });
    for (let i = 0; i < COLS * ROWS; i++) if (rt.bomb[i]) { const b = cellOf(i); stampBomb(b.x, b.y); }
    C0.fr.forEach((f, i) => { if (!((st.fruitMask >> i) & 1)) { const p = cellOf(f.cell); stampFruit(f.kind, p.x, p.y + 1.5 * Math.sin(a * 0.4 + i)); } });
    useLayer(2);                                      // snake, effects and messages go above the stamped items
    drawSnake(snakePoints(), easedDir(), null);
    if (G.boom && C0.over === 'trap') { const b = cellXY(G.boom[0], G.boom[1]); drawBoom(b.x, b.y); }
    fxs.forEach((e) => {
      const k = e.life / e.max;
      if (e.k === 1) { g.lineStyle(3 * k + 1, C(e.color), k); g.strokeCircle(e.x, e.y, e.r + (1 - k) * 26); }
      else dot(e.x, e.y, e.r * k + 0.5, e.color, k);
    });
    if (state === 'play') popups.forEach((p) => txt(p.x, p.y - (900 - p.life) * 0.03, p.s, 13, p.color));
    if (banner) {
      const k = banner.life / banner.max, grow = Math.min(1, (1 - k) * 8), alpha = Math.min(1, k * 4);
      const bw = 300 * (0.7 + 0.3 * grow), by = BY + 46 - (1 - k) * 14;
      rrect(W / 2 - bw / 2, by - 24, bw, banner.sub ? 52 : 38, 18, '#000000', 0.55 * alpha);
      txt(W / 2, by - (banner.sub ? 7 : 0), banner.s, banner.sub ? 20 : 22, banner.color);
      if (banner.sub) txt(W / 2, by + 15, banner.sub, 11, '#ffffff', 0.5, false);
    }
    // (the level tip is shown in the top line now, so nothing covers the board)
    if (C0.shield) { const p = headXY(); g.lineStyle(2.5, C('#38bdf8'), 0.75 + 0.25 * Math.sin(anim / 120)); g.strokeCircle(p.x, p.y, 17); }
    if (C0.hold && state === 'play') txt(W / 2, BY + 60, C0.undone ? 'Swipe to continue' : 'Turn now!', 22, '#38bdf8');
    if (C0.ready > 0) {
      const go = C0.ready < 380, k = go ? C0.ready / 380 : 1, bw = 190;
      rrect(W / 2 - bw / 2, BY + BH * 0.42 - 34, bw, 68, 22, '#000000', 0.55);
      txt(W / 2, BY + BH * 0.42, go ? 'GO!' : 'READY', go ? 40 + (1 - k) * 8 : 34, go ? '#4ade80' : '#ffffff');
    }
  }
  function drawCampOverlayFrame(h) {
    const t = th(), top = (H - h) / 2;
    g.fillStyle(0x000000, 0.4); g.fillRect(0, 0, W, H);
    if (!slice9('panel_card', W / 2, top + h / 2, 382, h + 20, C(t.panel), 34, 0.4)) {
      rrect(W / 2 - 186, top - 6, 372, h + 12, 26, t.bg);
      rrect(W / 2 - 180, top, 360, h, 22, t.panel);
    }
    return top;
  }

  // ---------- "How to play" card: what is in this level (opens by itself the first time a thing appears, and from the "?" button) ----------
  const TIPS_KEY = 'snakeFruitRush.tips.v1';
  const tipsSeen = (() => {
    try { const a = JSON.parse(localStorage.getItem(TIPS_KEY)); return new Set(Array.isArray(a) ? a.filter((x) => typeof x === 'string').slice(0, 20) : []); } catch (e) { return new Set(); }
  })();
  function helpItems(L) {
    const it = [
      { id: 'swipe', title: 'Swipe to turn', text: 'Swipe anywhere to turn. Walls and your own body stop you.' },
      { id: 'fruit', title: 'Eat all the fruit', text: 'The exit only opens after every fruit is eaten.' }
    ];
    if (skHas(L, 'I')) it.push({ id: 'ice', title: 'Ice', text: 'You slide and cannot turn until the ice ends.' });
    if (skHas(L, 'B')) it.push({ id: 'bomb', title: 'Bombs', text: 'Touch a bomb and the level ends. Go around!' });
    if (skHas(L, 'D')) it.push({ id: 'door', title: 'Key and door', text: 'Take the key first. Then the door opens for you.' });
    if (skHas(L, 'G')) it.push({ id: 'gate', title: 'Switch and gate', text: 'Step on the switch to open (or close) the gate of the same colour.' });
    if (skHas(L, 'P')) it.push({ id: 'portal', title: 'Portals', text: 'Enter one portal and you come out of the other.' });
    it.push({ id: 'exit', title: 'The exit', text: 'It glows when all fruit is eaten. Then go in!' });
    return it;
  }
  function drawHelpIcon(id, x, y) {
    if (id === 'swipe') { g.fillStyle(C('#ffffff'), 0.95); g.fillTriangle(x - 13, y, x - 2, y - 9, x - 2, y + 9); g.fillTriangle(x + 13, y, x + 2, y - 9, x + 2, y + 9); dot(x, y, 4, '#ffffff'); }
    else if (id === 'fruit') drawFruit('apple', x, y, 1.1);
    else if (id === 'ice') { rrect(x - 12, y - 12, 24, 24, 6, '#bfe6ff'); line(x - 7, y + 4, x + 3, y - 6, '#ffffff', 2.2); line(x - 2, y + 8, x + 8, y - 2, '#ffffff', 2.2); }
    else if (id === 'bomb') drawBomb(x, y, 1.15);
    else if (id === 'door') { drawKey(x - 12, y, 0.8); drawDoor(x + 12, y, false, false); }
    else if (id === 'gate') { drawSwitch(x - 12, y, GATE_COLS[0], false); drawGate(x + 12, y, false, GATE_COLS[0], false); }
    else if (id === 'portal') { drawPortal(x - 12, y, '#c084fc', true); drawPortal(x + 12, y, '#38bdf8', false); }
    else if (id === 'exit') drawExitTile(x, y, true);
  }
  function drawCampHelp() {
    const t = th(), C0 = G.camp, items = helpItems(C0.L), rowH = 66, h = 118 + items.length * rowH + 64, top = drawCampOverlayFrame(h);
    buttons = [];                                                      // only this card reacts
    txt(W / 2, top + 36, 'How to play', 28, t.accent);
    txt(W / 2, top + 66, 'What is in level ' + C0.id, 13, t.btnText, 0.5, false);
    items.forEach((it, i) => {
      const y = top + 108 + i * rowH;
      rrect(W / 2 - 168, y - 28, 336, rowH - 6, 14, t.bg, 0.55);
      drawHelpIcon(it.id, W / 2 - 130, y + 4);
      txt(W / 2 - 96, y - 14, it.title, 15, t.btnText, 0);
      if (!tipsSeen.has(it.id) && !uiPic('badge_new', W / 2 + 138, y - 14, 52, 32)) { rrect(W / 2 + 118, y - 23, 42, 18, 9, t.accent); txt(W / 2 + 139, y - 14, 'NEW', 10, '#1b1b1b'); }
      wrapText(it.text, 34).forEach((l, k) => txt(W / 2 - 96, y + 6 + k * 16, l, 12, t.text, 0, false));
    });
    button(W / 2, top + h - 40, 260, 52, 'Got it!', closeHelp, { primary: true, size: 20 });
  }
  const COST_UNDO = 100, COST_HINT = 60, COST_SKIP = 500;
  function canUndo() { const C0 = G && G.camp; return !!C0 && !C0.won && !C0.expert && C0.hist.length > 0; }
  function doUndo() {                                                  // back to the position before the last move (fruit, keys, gates and score come back too)
    const C0 = G.camp, snap = C0.hist.pop(), st = C0.st, s = snap.st;
    st.body = s.body.slice(); st.dir = s.dir; st.fruitMask = s.fruitMask; st.keyMask = s.keyMask; st.gateMask = s.gateMask; st.moves = s.moves; st.done = false; st.swLog = s.swLog; st.fruitLog = s.fruitLog;
    G.snake = st.body.map((c) => [c % COLS, (c / COLS) | 0]); G.dir = st.dir; G.queue = []; G.eaten = snap.eaten;
    C0.moves = st.moves; C0.over = null; C0.endT = 0; C0.exitOpen = E.exitReady(C0.rt, st); C0.hold = true; C0.undone = true;   // waits for the next swipe
    G.boom = null; prevSnake = null; acc = 0; fxs.length = 0; easeT = anim;
    sfx.click(); buzz(15);
  }
  function helpMsg(s, bad) { G.camp.helpMsg = { s: s, until: anim + 2200, bad: bad !== false }; sfx.err(); }
  function useUndo() {
    const C0 = G.camp;
    if (C0.expert) { helpMsg('Not in Expert mode'); return; }
    if (!canUndo()) { helpMsg('Nothing to undo yet'); return; }
    if (DATA.coins < COST_UNDO) { helpMsg('Need ' + (COST_UNDO - DATA.coins) + ' more coins'); return; }
    DATA.coins -= COST_UNDO; writeData(); C0.helped = true; doUndo();
    if (state === 'paused') { C0.help = false; togglePause(); } else if (state === 'over') setState('play');
  }
  function giveHint() { const C0 = G.camp; C0.helped = true; C0.route = C0.L.R; C0.routeIdx = new Map(); C0.route.forEach((cell, i) => C0.routeIdx.set(cell, i)); C0.hintMax = 12; }
  function useHint() {
    const C0 = G.camp;
    if (C0.expert) { helpMsg('Not in Expert mode'); return; }
    if (C0.route) { helpMsg('The hint is already showing', false); return; }
    if (DATA.coins < COST_HINT) { helpMsg('Need ' + (COST_HINT - DATA.coins) + ' more coins'); return; }
    DATA.coins -= COST_HINT; writeData(); giveHint(); sfx.coin(); C0.help = false; togglePause();
  }
  function adHintHere() {
    const C0 = G.camp;
    if (C0.expert) { helpMsg('Not in Expert mode'); return; }
    requestRewarded('hint', { back: 'paused', ok: () => { giveHint(); C0.help = false; togglePause(); }, fail: (m) => { helpMsg(m); } });
  }
  function useSkip() {
    const C0 = G.camp;
    if (gated(C0.id + 1)) { helpMsg(gateMsg(C0.id + 1)); return; }
    if (C0.expert || C0.daily) { helpMsg('Not in this mode'); return; }
    if (DATA.coins < COST_SKIP) { helpMsg('Need ' + (COST_SKIP - DATA.coins) + ' more coins'); return; }
    if (!C0.skipArm || anim - C0.skipArm > 3000) { C0.skipArm = anim; sfx.click(); return; }     // second tap confirms
    DATA.coins -= COST_SKIP;
    if (DATA.camp.unlocked < C0.id + 1) DATA.camp.unlocked = C0.id + 1;
    DATA.camp.cur = C0.id + 1; SK.cur = null; writeData(); sfx.coin();
    C0.help = false; startLevel(C0.id + 1);
  }
  function drawCampHelpMenu() {
    const t = th(), C0 = G.camp, frontier = !C0.daily && !C0.expert && C0.id >= DATA.camp.unlocked && C0.id < LEVEL_COUNT, adOk = !C0.route && !C0.expert && adAvailable();
    const coinAd = DATA.coins < (frontier ? COST_SKIP : COST_HINT) && adCoinsLeft() && adAvailable(), top = drawCampOverlayFrame(362 + (adOk ? 50 : 0) + (frontier ? 62 : 0) + (coinAd ? 44 : 0));
    buttons = [];
    txt(W / 2, top + 38, 'Help', 30, t.accent);
    const ct = coinText(DATA.coins) + ' coins';
    drawCoin(W / 2 - ct.length * 4.2 - 12, top + 72, 9); txt(W / 2 + 2, top + 72, ct, 15, t.accent);
    if (C0.helpMsg && anim < C0.helpMsg.until) txt(W / 2, top + 98, C0.helpMsg.s, 13, C0.helpMsg.bad ? '#ff5a5f' : '#4ade80', 0.5, false);
    let y = top + 134;
    const chip = (cx, yy, cost) => { const s = String(cost), w = 30 + s.length * 9; rrect(cx - w / 2, yy - 13, w, 26, 13, '#000000', 0.38); if (!uiPic('icon_coins', cx - w / 2 + 13, yy, 18, 16)) drawCoin(cx - w / 2 + 13, yy, 7); txt(cx + 8 - (s.length - 1) * 0.5 * 0, yy + 1, s, 14, DATA.coins >= cost ? '#ffd84a' : '#ff8a8a'); };
    const hb = (yy, label, fn, on, ic, cost) => { if (on) adBtn(W / 2, yy, 300, 50, label, fn, 17); else button(W / 2, yy, 300, 50, label, fn, { size: 17, dark: true }); if (ic) uiPic(ic, W / 2 - 126, yy, 34, 34); if (cost) chip(W / 2 + 106, yy, cost); };
    hb(y, 'Undo last move', useUndo, canUndo(), 'icon_undo', COST_UNDO); y += 60;
    hb(y, C0.route ? 'Hint is on' : 'Show next steps', useHint, !C0.route, 'icon_hint', C0.route ? 0 : COST_HINT); y += 60;
    if (adOk) { adBtn(W / 2, y - 6, 300, 38, 'Watch ad - free hint', adHintHere, 15); y += 44; }
    if (DATA.coins < (frontier ? COST_SKIP : COST_HINT) && adCoinsLeft() && adAvailable()) { adBtn(W / 2, y - 6, 300, 38, 'Watch ad:  +' + adCoinNext() + ' coins', () => claimAdCoins('paused', (m, ok) => helpMsg(m, ok !== true)), 15); y += 44; }
    if (frontier) { const armed = C0.skipArm && anim - C0.skipArm < 3000; hb(y, armed ? 'Tap again to skip level' : 'Skip level', useSkip, true, 'icon_skip', armed ? 0 : COST_SKIP); y += 60; }
    button(W / 2, y, 300, 46, 'How to play', () => { C0.help = true; C0.helpFrom = 'menu'; }, { size: 16, dark: true }); uiPic('icon_help', W / 2 - 126, y, 30, 30); y += 58;
    button(W / 2, y, 300, 50, 'Resume', () => { C0.help = false; togglePause(); }, { primary: true, size: 19 });
  }
  function openHelp() {
    if (!G || !G.camp || state !== 'play' || G.camp.over || G.camp.won) return;
    G.camp.help = 'menu'; togglePause();
  }
  function closeHelp() {                                               // "Got it!" on the how-to-play card
    const C0 = G.camp;
    helpItems(C0.L).forEach((i) => tipsSeen.add(i.id));
    try { localStorage.setItem(TIPS_KEY, JSON.stringify(Array.from(tipsSeen))); } catch (e) { /* blocked: shows again next time */ }
    if (C0.helpFrom === 'menu') { C0.helpFrom = null; C0.help = 'menu'; return; }
    C0.help = false; togglePause();
  }
  function drawCampPause() {
    const t = th(), C0 = G.camp, top = drawCampOverlayFrame(420);
    txt(W / 2, top + 38, 'Paused', 33, t.accent);
    txt(W / 2, top + 74, 'Level ' + C0.id + '  -  ' + WORLDS[C0.L.w].name, 16, t.btnText);
    toggleBtn(W / 2 - 96, top + 122, 'sound', DATA.sound, 'Sound', toggleSound);
    toggleBtn(W / 2, top + 122, 'vibe', DATA.vibe, 'Vibrate', toggleVibe);
    toggleBtn(W / 2 + 96, top + 122, 'tap', DATA.tapSteer, 'Tap to turn', toggleTap);
    button(W / 2, top + 232, 290, 56, 'Resume', togglePause, { primary: true, size: 21 });
    button(W / 2, top + 300, 290, 50, 'Restart level', campRetry, { dark: true, size: 18 });
    button(W / 2, top + 362, 290, 50, 'Levels', leaveToLevels, { dark: true, size: 18 });
  }
  function drawCampFail() {
    const t = th(), C0 = G.camp, hintOk = !C0.route && adAvailable(), undoOk = canUndo(), top = drawCampOverlayFrame((hintOk ? 366 : 300) + (undoOk ? 58 : 0));
    txt(W / 2, top + 44, C0.over === 'trap' ? 'Boom!' : 'Oops!', 34, '#ff5a5f');
    const why = C0.over === 'gate' ? 'The gate is closed - use the switch' : C0.over === 'door' ? 'The door is locked - get the key first' : (FAIL_TEXT[C0.over] || 'Try again');
    txt(W / 2, top + 88, why, 15, t.btnText);
    txt(W / 2, top + 114, 'Level ' + C0.id, 13, t.btnText, 0.5, false);
    button(W / 2, top + 176, 290, 58, 'Try again', campRetry, { primary: true, size: 22 });
    let y = top + 246;
    if (undoOk) { button(W / 2, y, 290, 50, 'Undo last move   ' + COST_UNDO, useUndo, { size: 17 }); y += 58; }
    if (C0.helpMsg && anim < C0.helpMsg.until) txt(W / 2, top + 146, C0.helpMsg.s, 12.5, '#ff5a5f', 0.5, false);
    if (hintOk) { adBtn(W / 2, y, 290, 50, 'Watch ad - get hint', adHint, 17); y += 62; }
    button(W / 2, y, 290, 50, 'Levels', leaveToLevels, { dark: true, size: 18 });
    if (G.adMsg) txt(W / 2, top + 146, G.adMsg, 12.5, '#ff5a5f', 0.5, false);
  }

  // ---------- Game feel: camera shake (off with reduced motion) ----------
  function shake(ms, k) { if (REDUCED || !scene) return; try { scene.cameras.main.shake(ms, k); } catch (e) { /* ignore */ } }
  const FRUIT_COL = { apple: '#e53935', orange: '#ff9a1f', cherry: '#d81b60', grapes: '#8e5bd6', strawberry: '#ff4d6d' };   // fruit pop colours
  function drawConfetti() {                                           // falling confetti on the "level cleared" screen (cheap: no state)
    const n = LITE ? 10 : 22;
    for (let i = 0; i < n; i++) {
      const t0 = (anim / 1000 * (0.16 + 0.2 * hh(i, 9, 2)) + hh(i, 9, 3)) % 1, x = BX + hh(i, 9, 1) * BW + Math.sin(anim / 400 + i) * 10, y = -10 + t0 * (H + 20);
      g.fillStyle(C(CONFETTI[i % CONFETTI.length]), 0.9); g.fillRect(x, y, 6, 9);
    }
  }
  function doubleCoins() {                                           // optional rewarded ad: the level reward is paid a second time
    const C0 = G.camp;
    requestRewarded('double', { back: 'won', ok: () => { C0.doubled = true; addCoins(C0.coins); sfx.coin(); }, fail: (m) => { G.adMsg = m; } });
  }
  function drawCampWon() {
    if (G.camp.daily) { drawDailyWon(); return; }
    const t = th(), C0 = G.camp, last = C0.id >= LEVEL_COUNT, canDbl = adAvailable() && !C0.doubled && C0.coins > 0, canExp = C0.stars === 3 && !C0.expert, top = drawCampOverlayFrame((last ? 430 : 512) + (canDbl ? 58 : 0) + (canExp ? 56 : 0));
    txt(W / 2, top + 44, last ? 'You did it!' : 'Level cleared!', 32, t.accent);
    txt(W / 2, top + 80, last ? 'All ' + LEVEL_COUNT + ' levels complete' : 'Level ' + C0.id + '  -  ' + WORLDS[C0.L.w].name, 15, t.btnText);
    for (let s = 0; s < 3; s++) {
      const k = Math.min(1, Math.max(0, (C0.endT - PORTAL_MS - s * 220 + 700) / 260)), got = s < C0.stars;
      const x = W / 2 + (s - 1) * 62, y = top + 140 - (s === 1 ? 8 : 0), sc = got ? 1 + 0.35 * Math.sin(Math.min(1, k) * Math.PI) : 1;
      if (!uiPic(got ? 'star_full' : 'star_empty', x, y, 68 * sc, 64 * sc, 0xffffff, 0.55)) {
        starShape(x, y + 3, 30 * sc, '#000000', 0.25);
        starShape(x, y, 30 * sc, got ? '#fde047' : '#00000044');
        if (got) starShape(x - 2, y - 3, 14 * sc, '#fffbe0', 0.6);
      }
    }
    txt(W / 2, top + 208, C0.moves + ' moves', 20, t.btnText);
    const gap3 = C0.moves - C0.L.s3, gap2 = C0.moves - C0.L.s2;
    txt(W / 2, top + 236, C0.stars < 3 ? (C0.stars < 2 ? (gap2 <= 3 ? 'So close! ' + gap2 + ' move' + (gap2 > 1 ? 's' : '') + ' more than 2 stars' : '2 stars: ' + C0.L.s2 + ' moves   3 stars: ' + C0.L.s3) : (gap3 <= 4 ? 'So close! Just ' + gap3 + ' move' + (gap3 > 1 ? 's' : '') + ' too many for 3 stars' : '3 stars: ' + C0.L.s3 + ' moves or less')) : 'Perfect run!', 13, t.btnText, 0.5, false);
    drawCoin(W / 2 - 52, top + 262, 9);
    if (!C0.wonT) C0.wonT = anim;
    txt(W / 2 - 38, top + 262, '+' + Math.round(G.coins * Math.min(1, (anim - C0.wonT) / 700)) + ' coins', 15, '#fbbf24', 0);   // counts up
    if (!last) {
      if (gated(C0.id + 1)) txt(W / 2, top + 296, gateMsg(C0.id + 1), 12.5, '#fbbf24', 0.5, false);
      else { const nx = LV[C0.id], mech = [skHas(nx, 'I') && 'ice', skHas(nx, 'B') && 'bombs', skHas(nx, 'D') && 'door', skHas(nx, 'G') && 'gate', skHas(nx, 'P') && 'portal'].filter(Boolean).slice(0, 2).join(' + ');
      txt(W / 2, top + 296, 'Next: level ' + (C0.id + 1) + '  -  ' + fruitCount(C0.id + 1) + ' fruit' + (mech ? '  -  ' + mech : ''), 13, t.btnText, 0.5, false); }
    }
    drawConfetti();
    let y = top + (last ? 316 : 338);
    if (!last) { button(W / 2, y, 290, 58, gated(C0.id + 1) ? 'Level map' : 'Next level', campNextLevel, { primary: true, size: 22 }); y += 68; }
    if (canDbl) { adBtn(W / 2, y - 6, 290, 46, 'Watch ad:  double reward  +' + C0.coins, doubleCoins, 16); y += 54; }
    if (C0.stars === 3 && !C0.expert) { button(W / 2, y, 290, 46, 'Expert mode  (x3 coins)', () => startLevel(C0.id, false, { expert: true }), { dark: true, size: 17 }); y += 56; }
    button(W / 2, y, 290, 46, 'Replay', campRetry, { dark: true, size: 17 });
    button(W / 2, y + 56, 290, 46, 'Levels', leaveToLevels, { dark: true, size: 17 });
  }

  // ---------- Phaser scene ----------
  class Main extends Phaser.Scene {
    create() {
      scene = this;
      boardG = this.add.graphics();
      layers = [0, 1, 2].map((i) => { const d = i === 2 ? 11 : i * 20 + 1; return { g: this.add.graphics().setDepth(d), texts: [], n: 0, depth: d, byKey: {}, active: [], prev: [] }; });   // 2 = snake / effects above the stamped items
      useLayer(0);
      CT = menuPal();
      if (window.SFRAds) window.SFRAds.screen(state);
      demoReset();
      this.cameras.main.setZoom(ZOOM);
      this.cameras.main.centerOn(W / 2, H / 2);
      applyTheme();

      // Touch / mouse are read from the whole window, so swipes that start near the
      // screen edges (outside the game canvas) also work, and swipes react on the move.
      const canvas = this.game.canvas;
      const toWorld = (e) => {
        const r = canvas.getBoundingClientRect();
        return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height };
      };
      const touches = new Map();
      window.addEventListener('pointerdown', (e) => {
        unlockAudio();
        const w0 = toWorld(e), b0 = buttons.find((q) => w0.x >= q.x && w0.x <= q.x + q.w && w0.y >= q.y && w0.y <= q.y + q.h);
        touches.set(e.pointerId, { x: e.clientX, y: e.clientY, moved: false, t: performance.now(), b: b0 ? { x: b0.x, y: b0.y } : null });
      }, { passive: true });
      window.addEventListener('pointermove', (e) => {
        const s = touches.get(e.pointerId);
        if (!s || state !== 'play') return;
        const dx = e.clientX - s.x, dy = e.clientY - s.y, ax = Math.abs(dx), ay = Math.abs(dy);
        if (Math.max(ax, ay) < SWIPE_PX * (s.axis ? 1.15 : 0.85)) return;      // small finger wobble is not a swipe (a 2nd turn in one touch needs a clearer move)
        let axis = ax >= ay ? 'x' : 'y';
        if (Math.min(ax, ay) > Math.max(ax, ay) * 0.7 && G) {              // clear diagonal: take the axis the snake is not already moving on (the useful turn)
          const ha = G.dir[0] ? 'x' : 'y'; axis = ha === 'x' ? 'y' : 'x';
        }
        s.moved = true;
        if (axis === s.axis) { s.x = e.clientX; s.y = e.clientY; return; }  // a long swipe in the same direction makes no extra turns
        turn(axis === 'x' ? [Math.sign(dx), 0] : [0, Math.sign(dy)]);
        s.axis = axis; s.x = e.clientX; s.y = e.clientY;
      }, { passive: true });
      const end = (e, cancelled) => {
        const s = touches.get(e.pointerId);
        touches.delete(e.pointerId);
        if (!s || s.moved || cancelled) return;
        unlockAudio();
        const w = toWorld(e);
        const b = buttons.find((q) => w.x >= q.x && w.x <= q.x + q.w && w.y >= q.y && w.y <= q.y + q.h);
        if (b) { if (s.b && s.b.x === b.x && s.b.y === b.y) { sfx.click(); b.fn(); } }   // press and release must be on the same button
        else if (state === 'play' && DATA.tapSteer && performance.now() - s.t < 350) tapTurn(w.x, w.y);
      };
      window.addEventListener('pointerup', (e) => end(e, false));
      window.addEventListener('pointercancel', (e) => end(e, true));

      window.addEventListener('keydown', unlockAudio, { once: true });
      const kb = this.input.keyboard;
      if (kb) {
        const dirs = { UP: [0, -1], W: [0, -1], DOWN: [0, 1], S: [0, 1], LEFT: [-1, 0], A: [-1, 0], RIGHT: [1, 0], D: [1, 0] };
        Object.keys(dirs).forEach((k) => kb.on('keydown-' + k, () => turn(dirs[k])));
        kb.on('keydown-SPACE', togglePause);
        kb.on('keydown-ENTER', () => { if (state === 'menu') playSelected(); else if (state === 'levels') startLevel(Math.min(campUnlocked(), lvPage * 20 + 1)); else if (state === 'won') campNextLevel(); else if (state === 'over') { if (G.camp) campRetry(); else newGame(); } else if (state === 'paused') togglePause(); });
        kb.on('keydown-ESC', () => { if (state === 'levels') goHome(); else if (G && G.camp && state !== 'menu') leaveToLevels(); else if (state !== 'menu') goMenu(); else if (settingsOpen) settingsOpen = false; else closeSheet(); });
        kb.on('keydown-T', () => setTheme(DATA.theme + 1));
        kb.on('keydown-B', () => setBackground(DATA.bg + 1));
        kb.on('keydown-C', () => { if (state === 'menu') continueGame(); });
      }

      // Pause and save when the app goes to the background.
      const away = () => {
        if (state === 'play') togglePause(); else if (state !== 'ad') saveGame();
        try { if (actx && actx.state === 'running') actx.suspend(); } catch (e) { /* ignore */ }
      };
      document.addEventListener('visibilitychange', () => { if (document.hidden) away(); else dailyEnsure(true); });
      window.addEventListener('pagehide', away);
    }

    update(time, delta) {
      delta = Math.min(delta, 100);
      anim += delta;
      fpsAvg = fpsAvg * 0.97 + delta * 0.03;
      const realDt = this._lt ? time - this._lt : 16.7;
      this._lt = time;
      if (state === 'play' && !govDone && realDt < 500) {
        govT += realDt; govN++;
        if (govT > 4000) {
          govDone = true;
          if (govT / govN > 36) { LITE = true; try { localStorage.setItem(ZOOM_KEY, String(Math.max(1.75, ZOOM - 0.25))); } catch (e) { /* no storage */ } }
        }
      }
      if (!LITE && anim > 5000 && fpsAvg > 26) LITE = true;     // slow phone: switch off the decorations
      if (state === 'menu') {
        demo.acc += delta;
        while (demo.acc >= DEMO.ms) { demo.acc -= DEMO.ms; demoStep(); }
        sheetT = sheetOpen ? Math.min(1, sheetT + delta / 240) : Math.max(0, sheetT - delta / 200);
        if (gift && gift.t < 1e6) {
          gift.t += delta;
          if (!gift.done && gift.t >= gift.dur) { gift.done = true; if (gift.kind === 'egg' && !gift.skin) sfx.coin(); else sfx.win(); }
        }
      }
      if (state === 'play' && G.camp) {
        campTick(delta);
        popups.forEach((p) => { p.life -= delta; });
        for (let pi = popups.length - 1; pi >= 0; pi--) if (popups[pi].life <= 0) popups.splice(pi, 1);
      } else if (state === 'play') {
        acc += Math.min(delta, 50);
        let delay = stepDelay(), guardSteps = 0;
        while (state === 'play' && acc >= delay && guardSteps++ < 2) {
          acc -= delay;
          prevSnake = G.snake.map((s) => [s[0], s[1]]);
          step();
          delay = stepDelay();
        }
        if (acc > delay) acc = delay;
        popups.forEach((p) => { p.life -= delta; });
        for (let pi = popups.length - 1; pi >= 0; pi--) if (popups[pi].life <= 0) popups.splice(pi, 1);
        if (G) {
          const before = Math.floor(G.playMs / 1000);
          G.playMs += delta;
          if (Math.floor(G.playMs / 1000) !== before) dailyMax('survive', Math.floor(G.playMs / 1000));
        }
      }
      if (state === 'play' || state === 'over' || state === 'won') {            // short effects fade out
        for (let i = fxs.length - 1; i >= 0; i--) {
          const e = fxs[i];
          e.life -= delta; e.x += e.vx * delta; e.y += e.vy * delta;
          if (e.life <= 0) fxs.splice(i, 1);
        }
        if (banner && state === 'play' && (banner.life -= delta) <= 0) banner = null;
      }
      if (state === 'ad' && adLeft > 0) {
        adLeft -= delta;
        if (adLeft <= 0) endAd(adToken, true);
      }
      musicTick();
      poolsBegin(); draw(); poolsEnd(); boardStep(); warmStep();
    }
  }

  // WebGL is tested first on a throw-away canvas (including "software only" WebGL, which is slower than Canvas), so a device without it
  // simply gets Canvas instead of an error. ?canvas=1 / ?webgl=1 only force one of them for testing.
  function pickRenderer() {
    if (/[?&]canvas=1/.test(location.search)) return Phaser.CANVAS;
    if (/[?&]webgl=1/.test(location.search)) return Phaser.WEBGL;
    try {
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl', { failIfMajorPerformanceCaveat: true }) || c.getContext('experimental-webgl', { failIfMajorPerformanceCaveat: true });
      if (gl) { const x = gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); return Phaser.WEBGL; }
    } catch (e) { /* fall through */ }
    return Phaser.CANVAS;
  }
  function startGame() {
    if (window.snakeGame) return;
    window.snakeGame = new Phaser.Game({
    type: RENDERER,   // WebGL first when the device has a real GPU, Canvas as the safe fallback
    parent: 'game',
    width: W * ZOOM,
    height: H * ZOOM,
    backgroundColor: th().bg,
    scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
    render: { antialias: true, powerPreference: 'high-performance', failIfMajorPerformanceCaveat: !/[?&]webgl=1/.test(location.search) },   // software WebGL is slower than Canvas, so it falls back
    scene: Main
    });
  }
  // Wait for the embedded Fredoka font so the canvas text uses it (but never more than 1.5 s).
  try {
    Promise.all([document.fonts.load('500 20px Fredoka'), document.fonts.load('700 20px Fredoka')]).then(startGame, startGame);
  } catch (e) { startGame(); }
  setTimeout(startGame, 1500);

  // test hook (not used by the game itself)
  window.__snake = { ads: { meta: adsMeta, claimAdCoins: claimAdCoins, adHint: adHint, maybeInter: maybeInter, playAgain: playAgain, coinsLeft: adCoinsLeft, requestRewarded: requestRewarded, get kind() { return adKind; }, get job() { return adJob; } }, camp: { start: startLevel, open: openLevels, home: goHome, retry: campRetry, next: campNextLevel, get C() { return G && G.camp; }, LV: LV, E: E, unlockAll: () => { DATA.camp.unlocked = LEVEL_COUNT; writeData(); }, engineLevel: engineLevel, randomFruit: randomFruit, get buttons() { return buttons; }, daily: { start: startDailyPuzzle, level: dpLevelFor, prog: PROG, goals: GOALS, check: goalsCheck, rng: seededRng, hash: strHash }, help: { open: openHelp, close: closeHelp, items: helpItems, undo: useUndo, canUndo: canUndo, hint: useHint, skip: useSkip, giveHint: giveHint, get seen() { return tipsSeen; } }, stepClock: stepClock, resetOwed: () => { owed = 0; }, cd: { ensure: cdEnsure, add: cdAdd, make: makeCD }, sk: { get S() { return SK; }, adapt: skAdapt, record: skRecord, fail: skFail, fruit: adaptiveFruit, profile: skProfile, reload: () => { SK = skLoad(); return SK; }, reset: () => { SK = SK_FRESH(); } }, WORLDS: WORLDS, sliding: () => campSliding() }, get CT() { return CT; }, usePower: usePower, buyPower: buyPower, PW: PW, get LITE() { return LITE; }, pts: snakePoints, get renderer() { return scene && scene.sys.game.renderer.type === Phaser.WEBGL ? 'webgl' : 'canvas'; }, get fxCount() { return fxs.length; }, get popupCount() { return popups.length; }, get ZOOM() { return ZOOM; }, get textPool() { return layers.map((l) => l.texts.length); }, get G() { return G; }, get state() { return state; }, get buttons() { return buttons; }, step2: step, DATA: DATA, turn: turn, get acc() { return acc; }, get sheet() { return sheetOpen; }, placeBombs: placeBombs, step: step, newGame: newGame, POWER_KEYS: POWER_KEYS,
    daily: { ensure: dailyEnsure, add: dailyAdd, max: dailyMax, make: makeDaily, load: loadData, addCoins: addCoins }, buySkin: buySkin, selectSkin: selectSkin, doSpin: doSpin, openEgg: openEgg, spinReady: spinReady, closeSheet: closeSheet, openSheet: openSheet, get skinPick() { return skinPick; }, set skinPick(v) { skinPick = v; }, get gift() { return gift; }, EGG_COST: EGG_COST, sfx: sfx, shareScore: shareScore, watchAd: watchAd, adAvailable: adAvailable, SKINS: SKINS, get fxs() { return fxs; }, eat: eatAtHead, gameOver: gameOver, endless: { start: newGame, theme: (i) => { DATA.theme = i; DATA.menuMode = 'endless'; writeData(); }, get G() { return G; }, get scene() { return scene; }, get layers() { return layers; } } };
})();
